using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class RegistrationCourseCollegeSummary : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "5")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            
            popddl.Popualate(StreamCode1, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(Year, "Year", "Select Year from Year where Year > '2008'  order by Year", "Year", "Year");
            Year.Text = System.DateTime.Now.Year.ToString();
        }
    }
    protected void BtnView_Click(object sender, EventArgs e)
    {
        string sql = "SELECT     dbo.COLLEGE.CollCode, dbo.COLLEGE.CollName, COUNT(dbo.REGISTRATION.AckNo) AS [TotApp], COUNT(dbo.REGISTRATION.RegNo) " +
                     " AS [TotalAlloted] ,COUNT(dbo.REGISTRATION.AckNo)-COUNT(dbo.REGISTRATION.RegNo) as [Pending] FROM  dbo.REGISTRATION ,dbo.COLLEGE " +
                     " WHERE  (dbo.REGISTRATION.CollCode = dbo.COLLEGE.CollCode) and   (dbo.REGISTRATION.RegYear = '" + Year.Text + "')  and (dbo.REGISTRATION.streamcode='" + StreamCode1.SelectedValue + "')  and (dbo.REGISTRATION.subcode='" + SubCode1.SelectedValue + "') " +
                     " GROUP BY dbo.COLLEGE.CollCode, dbo.COLLEGE.CollName";
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        RegSummaryView.DataSource = ds;
        RegSummaryView.DataBind();

        sql = "SELECT    COUNT(dbo.REGISTRATION.AckNo) AS [TotApp], COUNT(dbo.REGISTRATION.RegNo) " +
                     " AS [TotalAlloted] ,COUNT(dbo.REGISTRATION.AckNo)-COUNT(dbo.REGISTRATION.RegNo) as [Pending] FROM " +
                     "dbo.REGISTRATION  WHERE     (dbo.REGISTRATION.RegYear = '" + Year.Text + "') and (dbo.REGISTRATION.streamcode='" + StreamCode1.SelectedValue + "')  and (dbo.REGISTRATION.subcode='" + SubCode1.SelectedValue + "') ";
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        GridView1.DataSource = ds;
        GridView1.DataBind();
        //Panel1.Visible = true;
        //Label1.Text = GridView1.Rows[0].Cells[1].Text;
        //Label2.Text = GridView1.Rows[0].Cells[2].Text;
        //Label3.Text = GridView1.Rows[0].Cells[3].Text; 
    }
    protected void StreamCode1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (StreamCode1.SelectedValue == "00") return;

        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(SubCode1, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode1.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        //SubCode_SelectedIndexChanged(StreamCode, e); // call subcode selected index
        SubCode1.Focus();
    }
}
