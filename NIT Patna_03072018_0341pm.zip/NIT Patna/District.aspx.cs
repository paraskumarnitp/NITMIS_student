using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
public partial class District : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["Role"].ToString() != "1")
            {
                Session["userName"] = null;
                FormsAuthentication.SignOut();
                Response.Redirect("default.aspx");
            }
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StateList, "StateList", "Select Statecode,State from State order by State", "State", "StateCode");
            
              
            ViewState.Add("EditMode", "false");
            DistrictNm.Focus();
        }


    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {
        string abc = "";
        Panel2.Visible = false;
        if (ViewState["EditMode"].ToString() == "false")
        {
            string[] col = new string[3];
            string[] val = new string[3];
            col[0] = "DistCode";
            col[1] = "DistName";
            col[2] = "StateCode";
            Panel2.Visible = false;
            val[1] = DistrictNm.Text.Trim();  
            val[2]=StateList.SelectedValue;

            UnivService.Service1 ss = new UnivService.Service1();
            string SQL = "SELECT     ISNULL(MAX(Abs(DistCode)), '0') + 1 AS NewDistrictCode FROM District Where Distcode<>'999'";
            string DistrictCode = ss.GetNewCode(SQL);
            val[0] = DistrictCode;

            abc = ss.SaveData("District", col, val);

            if (abc == "1")
            {
                LblMsg.Text = " district is saved successfully. District Code= " + DistrictCode ;
                string popupScript = "<script language='javascript'>" +
                                " alert('District is saved successfully. District Code=   " + DistrictCode  + " ')" +
                                 "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);
                DistrictNm.Text = "";
                DistrictNm.Focus();

            }
            else
            {
                LblMsg.Text = abc.ToString();
            }

            ss.Dispose();
        }
        else
        {

            UnivService.Service1 ss = new UnivService.Service1();
            abc = " update District set DistName='" + DistrictNm.Text + "', StateCode='"+StateList.SelectedValue +"' where DistCode='" + DistrictView.SelectedRow.Cells[2].Text + "'";
            abc = ss.UpdateData(abc);
            if (abc.ToString() == "ok")
            {
                ViewState.Add("EditMode", "false");
                LblMsg.Text = " Record is updated successfully.";
                DistrictNm.Text = "";
                DistrictNm.Focus();

            }
            else
                LblMsg.Text = abc.ToString();
                 ss.Dispose();
        }

    }
    protected void BtnPrint_Click(object sender, ImageClickEventArgs e)
    {

    }
    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        Panel2.Visible = true;
        DataSet ds = new DataSet();
        
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select * from District where DistCode<>'0' and statecode='"+StateList.SelectedValue+"' order by abs(DistCode)");
        DistrictView.DataSource = ds;
        DistrictView.DataBind(); 
    }
    protected void CateGoryView_SelectedIndexChanged(object sender, EventArgs e)
    {
        StateList.SelectedValue = DistrictView.SelectedRow.Cells[1].Text;
        DistrictNm.Text =DistrictView.SelectedRow.Cells[3].Text;
        ViewState.Add("EditMode", "true");
        DistrictNm.Focus(); 

    }
    protected void BtnAdd_Click(object sender, ImageClickEventArgs e)
    {

    }
}
