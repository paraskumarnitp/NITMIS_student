using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Faculty_assignment_Report : System.Web.UI.Page
{
    Functionreviseed fn = new Functionreviseed();
    PopulateDDL popddl = new PopulateDDL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2" && Session["Role"].ToString() != "7" && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            popddl.Popualate(examsession, "Exam", "Select Distinct Examsession From Faculty_paper_a order by Examsession", "Examsession", "Examsession");
        }

    }

    protected void Btnnew_Click(object sender, EventArgs e)
    {
        string strque = "FacultyAssignprint.aspx?examyear=" + examsession.SelectedValue + "&stmtp=" + ddlReportType.SelectedValue;

        ScriptManager.RegisterStartupScript(this, Page.GetType(), "", "window.open('" + strque + "','Graph','height=600,width=800,resizable=yes');", true);

    }


}
