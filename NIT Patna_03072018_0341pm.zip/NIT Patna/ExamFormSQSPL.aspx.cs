using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class ExamFormSQSPL : System.Web.UI.Page
{
    Functionreviseed chkfn = new Functionreviseed();
    string RegNo = "";
    DataTable dt1 = new DataTable();
    DataRow dr = null;
    DataRow[] dr1;
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "10") && (Session["Role"].ToString() != "8"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CasteCode, "Category", "Select Category,CategoryCode from Category order by Category", "Category", "CategoryCode");
            popddl.Popualate(Year1, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(Year2, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(ReligionCode, "Religion", "Select * from Religion order by ReligionCode", "Religion", "ReligionCode");
            popddl.Popualate(Program, "Stream", "Select Stream, StreamCode from Stream Where STUDY='Y' order by Stream", "Stream", "StreamCode");
            popddl.Popualate(ddlbranch, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            ddlexamtype.Items.Insert(0, new ListItem("select"));
            string examsession = "SMR-JUL_" + DateTime.Now.Year.ToString();
            ExamType.Items.Insert(0,new ListItem(examsession,examsession));
            PopulateList poplist = new PopulateList();
            
            RollNo.Focus();
        }

        RegFormEntryYear.Attributes.Add("onKeyPress", "return onlyNumbers(this);");
        ExamFeeAmt.Attributes.Add("onKeyPress", "return onlyNumbers(this);");       

    }

    DataTable dt = new DataTable();
    protected void SaveExam()
    {

        try
        {

            // Exam Year Should not be less than current year..........

            ////if (int.Parse(RegFormEntryYear.Text) < int.Parse(System.DateTime.Now.Year.ToString()))
            ////{
            ////    string popupScript = "<script language='javascript'>" +
            ////                       " alert('Exam Year should not be less than current year')" +
            ////                        "</script>";
            ////    Page.RegisterStartupScript("PopupScript", popupScript);
            ////    LblMsg.Text = "Exam Year should not be less than current year.!!!";

            ////    return;
            ////}

            dt.Columns.Add("sem");

            // Check duplicate Entry of Form (On ExamFormNo , Collcode,streampart,examyear)

            SqlConnection con = new SqlConnection();
            SqlDataReader rd;
            SqlCommand cmd = new SqlCommand();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;
            UnivService.Service1 NicService = new UnivService.Service1();


            RegNo = NicService.GetNewCode("Select TOP(1) RegNo From EXAMPAPERDETAIL Where UnivRollNo = '" + RollNo.Text.ToString().Trim() + "' AND RegNo IS NOT NULL");
            string streamcode = "";
            streamcode = NicService.GetNewCode("select streamcode  from stream where StreamAbbr='" + ddlbranch.SelectedItem + "'");
           
            
            string subcode = "";
            subcode = NicService.GetNewCode("select subcode  from subject  where streamcode='" + streamcode + "' ");
            //cmd.CommandText = "select RegNo from Exam where ExamFormNo= '" + examformno + "' AND CollCode='002' and StreamPartCode='" + StreamPart.SelectedValue + "'and examyear='" + ExamYear.Text + "' ";
            ////////if (Label1.Text != "")
            ////////{
            if (gvcourse.Rows.Count > 0)
            {
                for (int t = 0; t < gvcourse.Rows.Count; t++)
                {
                    TextBox box1 = (TextBox)gvcourse.Rows[t].Cells[2].FindControl("txtsem");
                    TextBox box2 = (TextBox)gvcourse.Rows[t].Cells[5].FindControl("txtspartcode");
                    if (box1.Text != "")
                    {
                        dr1 = dt.Select("sem =" + box2.Text);
                        if (dr1.Length == 0)
                        {
                            dt.Rows.Add(box2.Text);
                        }                        
                    }
                }
               
            }
               
            // cmd.CommandText = "select ExamFormNo,EntryOptDateTime from Exam where RegNo='" + RollNo.Text.Trim() + "' and StreamPartCode='" + StreamPart.SelectedValue + "' and examyear='" + ExamYear.Text + "' ";
            //updtad 10/12/2013
            ////cmd.CommandText = "select ExamFormNo,EntryOptDateTime from Exam where UnivRollNo='" + RollNo.Text.Trim() + "' and StreamPartCode='" + Semester.SelectedItem + "'";
            ////rd = cmd.ExecuteReader();

            ////if (rd.HasRows)
            ////{
            ////    rd.Read();
            ////    string msg = " Please Check Entry Form. This Form has been already entered. Exam Form No. is " + rd["ExamFormNo"].ToString() + " and Entry Date is " + rd["EntryOptDateTime"].ToString();
            ////    string popupScript = "<script language='javascript'>" +
            ////                       " alert('" + msg + " ')" +
            ////                        "</script>";
            ////    Page.RegisterStartupScript("PopupScript", popupScript);
            ////    //rd.Read();
            ////    rd.Close();
            ////    con.Close();
            ////    RollNo.Focus();

            ////    return;
            ////}


            ////rd.Close();
            ////con.Close();

                string SaveFlag = "";

                string[] col = new string[21];
                string[] val = new string[21];


                // Colume Variable--Field Name

                col[0] = "UnivRollNo"; val[0] = RollNo.Text.Trim();
                col[1] = "CollCode"; val[1] = "002";
                col[2] = "ClassRollNo"; val[2] = RollNo.Text.Trim();
                col[3] = "ExamYear"; val[3] = RegFormEntryYear.Text.Trim();

                col[4] = "StreamCode"; val[4] = streamcode;

                col[5] = "StreamPartCode"; 

                col[6] = "SubCode"; val[6] = subcode;                
                col[7] = "ExamFeeAmt"; val[7] = ExamFeeAmt.Text.Trim();
                col[8] = "PaymentId"; val[8] = SCBNo.Text.Trim();
                col[9] = "PaymentDate"; val[9] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(SCBDate.Text.Trim()));

                col[10] = "ExamFormNo"; 
                col[11] = "ExamType"; val[11] = "N";
                col[12] = "UserId"; val[12] = Session["UserId"].ToString();
                col[13] = "EntryOptDateTime"; val[13] = string.Format("{0:MM/dd/yyyy}", System.DateTime.Now);
                col[14] = "Gender"; val[14] = GenderM.Checked == true ? "M" : "F";
                col[15] = "ModeOfExam"; val[15] = "E";
                col[16] = "ExamCollCode"; val[16] = "002";
                col[17] = "ModeOfPayment"; val[17] = ddlPaymentmode.SelectedItem.ToString();
                col[18] = "Bank"; val[18] = txtbankname.Text.Trim();
                col[19] = "RegNo"; val[19] = RegNo;
                col[20] = "ExamSession"; val[20] = ExamType.SelectedValue;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    val[5] = dt.Rows[i]["sem"].ToString();
                    string examformno = Program.SelectedValue + RollNo.Text.Trim() + dt.Rows[i]["sem"].ToString()+"S"+DateTime.Now.Year.ToString();
                    val[10] = examformno;
                    SaveFlag = NicService.SaveData("Exam", col, val);
                }
             
                if (SaveFlag == "1")
                {
                    //LblMsg.Focus();
                    // SavePaper();
                    SaveExampaper();
                    LblMsg.Text = "Exam Form Successfully Saved";
                    //Panel2.Visible = false;
                }
                else
                {
                    LblMsg.Text = "Already Submitted Exam-Form For SQ/SPL Exam.";
                }

                // }updated
            }
             catch (Exception ex)
            {
              LblMsg.Text = ex.Message;
            }
            

        
    }
    
   

   string examsession1;
    protected void SaveExampaper()
    {
        dr1 = null;
       // DataTable dtexampaper = new DataTable();
        DataTable dtcourse = new DataTable();
        dtcourse.Columns.Add("course");
        dtcourse.Columns.Add("StreamPartCode", typeof(string));
        dtcourse.Columns.Add("PaperType", typeof(string));
        dtcourse.Columns.Add("ExamType", typeof(string));
        examsession1 = ExamType.SelectedValue;

        DataTable dtattendance = new DataTable();
        dtattendance.Columns.Add("course");
        dtattendance.Columns.Add("StreamPartCode", typeof(string));
        dtattendance.Columns.Add("PaperType", typeof(string));
        dtattendance.Columns.Add("ExamType", typeof(string));
        //if (ddlsqc1.SelectedItem.ToString() != "NA")
        //{
       if (gvcourse.Rows.Count >0)
        {
            for (int h = 0; h < gvcourse.Rows.Count; h++)
            {
                TextBox box5 = (TextBox)gvcourse.Rows[h].Cells[5].FindControl("txtspartcode");
                TextBox box6 = (TextBox)gvcourse.Rows[h].Cells[6].FindControl("txtpapercode");
                TextBox box7 = (TextBox)gvcourse.Rows[h].Cells[7].FindControl("examtypecode");
                TextBox box8 = (TextBox)gvcourse.Rows[h].Cells[8].FindControl("ptypecode");
                if (box5.Text != "" && box6.Text != "" && box7.Text != "" && box8.Text != "")
                {
                    dr1 = dtcourse.Select("course =" + box6.Text);
                    if (dr1.Length == 0)
                    {
                        dtcourse.Rows.Add(box6.Text, box5.Text, box8.Text, box7.Text);
                        if (box7.Text == "B")
                        {
                            dtattendance.Rows.Add(box6.Text, box5.Text, box8.Text, box7.Text);
                        }
                    }
                }
            }
        }            
    UnivService.Service1 NicService = new UnivService.Service1();
    for (int j = 0; j < dtcourse.Rows.Count; j++)
    {
       
            try
            {

                string SaveFlag = "";
                string[] col = new string[8];
                string[] val = new string[8];


                // Colume Variable--Field Name
                col[0] = "RegNo"; val[0] = RegNo;
                col[1] = "UnivRollNo"; val[1] = RollNo.Text.Trim().ToString();
                col[2] = "StreamPartCode"; val[2] = dtcourse.Rows[j]["StreamPartCode"].ToString();
                col[3] = "SubPaperCode"; val[3] = dtcourse.Rows[j]["course"].ToString();
                col[4] = "PaperType"; val[4] = dtcourse.Rows[j]["PaperType"].ToString();
                col[5] = "ExamYear"; val[5] = RegFormEntryYear.Text;
                col[6] = "ExamType"; val[6] = dtcourse.Rows[j]["ExamType"].ToString(); 
                col[7] = "ExamSession"; val[7] = examsession1;

                // UnivService.Service1 NicService = new UnivService.Service1();
               SaveFlag = NicService.SaveData("ExamPaperDetail", col, val);
                //SaveFlag = NicService.SaveData("Attendance", col, val);
                if (SaveFlag == "1")
                {
                    LblMsg.Text = "";
                }
                else
                {
                    LblMsg.Text = SaveFlag.ToString();
                }

            }

            catch (Exception ex)
            {
                LblMsg.Text = ex.Message;
            }

        
    }
    for (int j = 0; j < dtattendance.Rows.Count; j++)
    {

        try
        {

            string SaveFlag = "";
            string[] col = new string[8];
            string[] val = new string[8];


            // Colume Variable--Field Name
            col[0] = "RegNo"; val[0] = RegNo;
            col[1] = "UnivRollNo"; val[1] = RollNo.Text.Trim().ToString();
            col[2] = "StreamPartCode"; val[2] = dtattendance.Rows[j]["StreamPartCode"].ToString();
            col[3] = "SubPaperCode"; val[3] = dtattendance.Rows[j]["course"].ToString();
            col[4] = "PaperType"; val[4] = dtattendance.Rows[j]["PaperType"].ToString();
            col[5] = "ExamYear"; val[5] = RegFormEntryYear.Text;
            col[6] = "ExamType"; val[6] = dtattendance.Rows[j]["ExamType"].ToString(); ;
            col[7] = "ExamSession"; val[7] = examsession1;

            // UnivService.Service1 NicService = new UnivService.Service1();
           SaveFlag = NicService.SaveData("Attendance", col, val);
            if (SaveFlag == "1")
            {
                LblMsg.Text = "";
            }
            else
            {
                LblMsg.Text = SaveFlag.ToString();
            }

        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }


    }
        
    }


    string examsession = ""; DataSet dscourse; DataSet dsstuvalidate; string stremtypecode = "";
    protected void BtnReg_Click(object sender, EventArgs e)
    {
       
        Refreshcontrols();
        try
        {
            RegNo = chkfn.singlevalue("SELECT RegNo From REGISTRATION WHERE TEMPROLLNo = '" + RollNo.Text.Trim() + "'").ToString();
            string ackno = "";
            LblMsg.Text = "";

            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;
            SqlDataReader reader;
         /*    con.Open();
            
           cmd.CommandText = "select UnivRollNo,ExamYear, Remarks,UnfairMeans.Year  from ExpelledStudents,UnfairMeans where UnivRollNo='" + RollNo.Text.ToString().Trim() + "' And DebarredFromExam='Y' order by Examyear desc";
            reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                reader.Read();
                // condition
                //Expelled Exam Year+ No. of years 4 Expelled => CurrentExam Year

                if (int.Parse(reader["ExamYear"].ToString()) + int.Parse(reader[3].ToString()) <= int.Parse(DateTime.Now.Year.ToString()))
                {

                }
                else
                {
                    reader.Read();
                    LblMsg.Text = "Roll No.-" + reader["UnivRollNo"].ToString() + " has unfair case-" + reader["Remarks"].ToString() + " in exam year " + reader["ExamYear"].ToString() + ".... PLZ Contact Examination incharge";
                    reader.Close();
                    con.Close();
                    return;
                }
            }
            reader.Close();
            */
            string regvalue = ""; string sql1 = "";
            UnivService.Service1 NICService = new UnivService.Service1();
            if (RollNo.Text.ToString().IndexOf('A') > 0 || RollNo.Text.ToString().IndexOf('B') > 0)
            {
                sql1 = "SELECT Distinct REGISTRATION.RegNo FROM EXAMPAPERDETAIL INNER JOIN REGISTRATION ON " +
                    " EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE (EXAMPAPERDETAIL.UnivRollNo = '" + RollNo.Text.Trim() + "') " +
                    " AND (EXAMPAPERDETAIL.RegNo IS NOT NULL)";
            }
            else sql1 = "Select RegNo From REGISTRATION Where TempRollno = '" + RollNo.Text.ToString().Trim() + "'";

            cmd.CommandText = "select count(*) N from registration where RegNo='" + RegNo + "' "; 
            SqlDataReader rd;                     
            con.Open();
            rd = cmd.ExecuteReader();
            rd.Read();
            string temp = rd["N"].ToString();
            con.Close();
            rd.Close();

            //Check max duration
            string maxduration = "";
            if (temp == "2")
            {
                cmd.CommandText = "SELECT REGISTRATION.CourseSession,REGISTRATION.StreamCode,STREAM.StreamTypeCode " +
                " FROM REGISTRATION INNER JOIN STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode " +
                " WHERE REGISTRATION.RegNo = '" + RegNo + "' AND REGISTRATION.MigrationStatus = 'N' and IsOld='Y'";
            }
            else
            {
                cmd.CommandText = "SELECT REGISTRATION.CourseSession,REGISTRATION.StreamCode,STREAM.StreamTypeCode " +
                " FROM REGISTRATION INNER JOIN STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode " +
                " WHERE REGISTRATION.RegNo = '" + RegNo + "' AND REGISTRATION.MigrationStatus = 'N'";
            }
            
            con.Open();
            
            reader = cmd.ExecuteReader();
           if (reader.HasRows) // Seesion Check
            {
                reader.Read();
                stremtypecode = reader["StreamTypeCode"].ToString();
             /*   string yr = (reader["CourseSession"].ToString()).Substring(0, 4);
                maxduration = NicService.GetNewCode("Select MaxDuration From Stream Where StreamCode='" + reader["StreamCode"].ToString() + "'");
                if ((int.Parse(yr) + int.Parse(maxduration)) < int.Parse(System.DateTime.Now.Year.ToString()))
                {
                    LblMsg.Text = "Your session is expired. Please contact exam admin";
                    reader.Close();
                    con.Close();
                    return;
                }*/
            }
            con.Close();
            reader.Close(); 
            // Check Student eligibility for appear in Special Exam
            //dsstuvalidate = chkfn.SelectDataset("SELECT Distinct TRBTec.SubPaperCode, COURSEPAPERS.PaperAbbr FROM TRBTec " +
            //    " INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE (TRBTec.Grade " +
            //    " IN ('F', 'F*','I')) AND (TRBTec.RegNo='" + RegNo + "') AND (TRBTec.ExamSession " +
            //    " IN (Select Top(2) ExamSession From ExamSession order by " +
            //    " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4) As Datetime) desc))");
            if (stremtypecode == "01")
            {
                dsstuvalidate = chkfn.SelectDataset("SELECT Distinct COURSEPAPERS.PaperAbbr, cgpa.SubPaperCode FROM cgpa INNER JOIN " +
                     " COURSEPAPERS ON cgpa.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE cgpa.RegNo = '" + RegNo + "' " +
                     " AND cgpa.Grade IN ('F*','F','I','X')");
            }
            else
            {
                dsstuvalidate = chkfn.SelectDataset("SELECT Distinct COURSEPAPERS.PaperAbbr, cgpa_Mtec.SubPaperCode FROM cgpa_Mtec INNER JOIN " +
                    " COURSEPAPERS ON cgpa_Mtec.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE cgpa_Mtec.RegNo = '" + RegNo + "' " +
                    " AND cgpa_Mtec.Grade IN ('F*','F','I')");
            }
           
            if (dsstuvalidate.Tables[0].Rows.Count > 0)
            {               

                ddlcourse.DataSource = dsstuvalidate.Tables[0];
                ddlcourse.DataTextField = "PaperAbbr";
                ddlcourse.DataValueField = "SubPaperCode";
                ddlcourse.DataBind();

                ddlcourse.Items.Insert(0, new ListItem("--Select--", "0"));
            }

                else
                {
                    LblMsg.Text = "You are not Eligible for SQ/SPl Exam.";
                    return;
                }
            //}


            //--------- change by suraj on 19-DEC-2012
            
            if (temp == "2") 
            {
                cmd.CommandText = " select AckNo,ApplicantName,FatherName,MotherName,DOB,Gender,MaritalStatus,CastCode,NationalityCode," +
     "CollCode,AdmissionDate,RegNo,CourseSession,PresentAddress1,PresentAddress2,PresentDistrictCode,PresentPinCode," +
     "ReligionCode,CourseSession  from Registration where RegNo='" + RegNo + "' And MigrationStatus='N' and IsOld='Y'";
            }
            else
            {
                cmd.CommandText = "select AckNo,ApplicantName,FatherName,MotherName,DOB,Gender,CastCode,NationalityCode,CollCode," +
                    "AdmissionDate,RegNo,Streamcode,StreamPartcode,CourseSession,TempRollNo,ReligionCode from Registration where " +
                    " RegNo='" + RegNo + "' And MigrationStatus='N'";  
                  
            }
            LblMsg.Text = "";
            con.Open();
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();              
                ackno = reader["AckNo"].ToString();
                             
                ApplicantName.Text = reader["ApplicantName"].ToString();
               
                if (reader["FatherName"].ToString() != "") FatherName.Text = reader["FatherName"].ToString();
                else FatherName.Text = "Data Unavailable";
                if (reader["MotherName"].ToString()!="") MotherName.Text = reader["MotherName"].ToString();
                else MotherName.Text = "Data Unavailable";
                if (reader["DOB"].ToString() == "") DOB.Text = "Data Unavailable";
                else DOB.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["DOB"]));

                if (reader["ReligionCode"].ToString()!="") ReligionCode.SelectedValue = reader["ReligionCode"].ToString();
                CasteCode.SelectedValue = reader["CastCode"].ToString();
                //Program.SelectedValue = reader["Streamcode"].ToString();
                //ddlbranch.SelectedValue = reader["StreamPartcode"].ToString();
                PopulateDDL popddl = new PopulateDDL();
                popddl.Popualate(Program, "Stream", "Select Stream, StreamCode from Stream Where StreamCode = '" + reader["Streamcode"].ToString() + "' ", "Stream", "StreamCode");

                //popddl.Popualate(Semester, "STREAMPART", "Select StreamPartCode,STREAMPART from STREAMPART where StreamCode in ('" + Program.SelectedValue + "','00')  order by STREAMPART", "STREAMPART", "StreamPartCode");
                popddl.Popualate(ddlbranch, "Stream", "Select StreamAbbr, StreamCode from Stream Where StreamCode = '" + reader["Streamcode"].ToString() + "' ", "StreamAbbr", "StreamCode");                //Select StreamPartCode,STREAMPART from STREAMPART where StreamCode = '07'
                //popddl.Popualate(ddlbacklogsemester, "STREAMPART", "Select StreamPartCode,STREAMPART from STREAMPART where StreamCode  in ('" + Program.SelectedValue + "','00')  order by STREAMPART", "STREAMPART", "StreamPartCode");
                //string streamcode = reader["Streamcode"].ToString();
                //string streampartcode = reader["StreamPartcode"].ToString();

                txtrollno.Text = RollNo.Text ;
              
                txtenrollmentno.Text = reader["AckNo"].ToString();
                              

                if (reader["Gender"].ToString() == "M")
                {
                    GenderF.Checked = false;
                    GenderM.Checked = true;
                }
                else
                {
                    GenderM.Checked = false;
                    GenderF.Checked = true;
                }

                if (reader["CourseSession"].ToString() != "")
                {
                    Year1.Text = (reader["CourseSession"].ToString()).Substring(0, 4);
                    Year2.Text = (reader["CourseSession"].ToString()).Substring(5, 4);
                }
                reader.Close();
                               
                //Image Load

                ImageUpload imgUpload = new ImageUpload();
                string strFileName = imgUpload.Image_Load(ackno);


                if (strFileName.ToString().Contains("temp"))
                {


                    string photo = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/temp.jpg";

                    string strRightNow = "";
                    string IUrl = "";

                    strRightNow = System.DateTime.Now.ToString("ddMMyyyyHHmmss");
                    IUrl = photo + "?img=" + strRightNow;

                    Image3.ImageUrl = IUrl;
                    Image3.DataBind();


                }
                else if (strFileName.ToString().Contains("UploadPhoto"))
                {

                    Image3.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadPhoto.JPG";
                    Image3.DataBind();

                }

                else
                {
                    LblMsg.Text = "Error" + strFileName;

                }
            }
            else
            {
                LblMsg.Text = " Please check ROll no.";
                //Panel2.Visible = false;
                RollNo.Focus();
            }

        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }


    }
     
    private TextBox TextBox(TextBox ApplicantName)
    {
        throw new Exception("The method or operation is not implemented.");
    }
    
    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            if (gvcourse.Rows.Count > 0)
            {
                SaveExam();
            }
            else
            {
                LblMsg.Text = "Invalid Course Selection.";
            }
        
           
            // Save Data in ExamPaperDetail

        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }
         
   
    protected void Refreshcontrols()
    {      
        Program.Items.Clear(); ddlbranch.Items.Clear(); txtrollno.Text = "";
        txtenrollmentno.Text = ""; ddlcourse.Items.Clear(); ddlexamtype.SelectedIndex = 0;
        ViewState["CurrentTable"] = null;
        DataTable dt3 = (DataTable)ViewState["CurrentTable"];
        gvcourse.DataSource = dt3;
        gvcourse.DataBind();

    }
    string sql = "";
    protected void btnadd_Click(object sender, EventArgs e)
    {
        UnivService.Service1 NICService = new UnivService.Service1();
        stremtypecode = NICService.GetNewCode("SELECT STREAM.StreamTypeCode FROM REGISTRATION INNER JOIN " +
         " STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode WHERE REGISTRATION.Ackno = '" + txtenrollmentno.Text + "'");
        if (ExamType.SelectedIndex == 1)
        {
            LblMsg.Text = "Please select Exam Type";
            LblMsg.Focus();
        }
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            //if (ddlexamtype.SelectedValue == "B")
            //{
            //    DataRow[] dr = dtCurrentTable.Select("Column7='B'");
            //    if (dr.Length >= 2)
            //    {
            //        LblMsg.Text = "Only 2 SQ Course Code are Allowed!!!";
            //        return;
            //    }
            //}
            //if (ddlexamtype.SelectedValue == "N")
            //{
            //    DataRow[] dr = dtCurrentTable.Select("Column7='N'");
            //    if (dr.Length >= 5)
            //    {
            //        LblMsg.Text = "Only 5 SPL Course Code are Allowed!!!";
            //        return;
            //    }
            //}
        }
        AddRow();
    }

    private void AddRow()
    {
        
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            int index = dtCurrentTable.Rows.Count;
            if (stremtypecode == "01")
            {
                sql = "SELECT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperTypeCode, cgpa.SubPaperCode, STREAMPART.StreamPart," +
                " cgpa.StreamPart AS Streampartcode,COURSEPAPERS.PaperName FROM cgpa INNER JOIN COURSEPAPERS ON " +
                " cgpa.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN STREAMPART ON cgpa.StreamPart = STREAMPART.StreamPartcode " +
                " WHERE cgpa.Grade IN ('F', 'F*', 'I','X') AND cgpa.UnivRollNo = '" + RollNo.Text.Trim().ToString() + "' AND " +
                " cgpa.SubPaperCode = '" + ddlcourse.SelectedValue + "'";
            }
            else if (stremtypecode == "02")
            {
                sql = "SELECT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperTypeCode, cgpa_Mtec.SubPaperCode, STREAMPART.StreamPart, " +
                     " cgpa_Mtec.StreamPart AS Streampartcode, COURSEPAPERS.PaperName FROM cgpa_Mtec INNER JOIN COURSEPAPERS ON " +
                     " cgpa_Mtec.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN STREAMPART ON cgpa_Mtec.StreamPart = STREAMPART.StreamPartcode " +
                     " WHERE cgpa_Mtec.Grade IN ('F', 'F*', 'I') AND cgpa_Mtec.UnivRollNo = '" + RollNo.Text.Trim().ToString() + "' AND " +
                     " cgpa_Mtec.SubPaperCode = '" + ddlcourse.SelectedValue + "'";
            }
            DataSet dsaddrec = chkfn.SelectDataset(sql);
            if (dsaddrec.Tables[0].Rows.Count>0)
            {
                string ptypecode = "";
                if (dsaddrec.Tables[0].Rows[0]["PaperTypeCode"].ToString() == "01")
                    ptypecode = "P";
                else if (dsaddrec.Tables[0].Rows[0]["PaperTypeCode"].ToString() == "02")
                    ptypecode = "T";
                else if (dsaddrec.Tables[0].Rows[0]["PaperTypeCode"].ToString() == "04")
                    ptypecode = "X";                
            dtCurrentTable.Rows.Add(index + 1, dsaddrec.Tables[0].Rows[0]["PaperAbbr"].ToString(),dsaddrec.Tables[0].Rows[0]["StreamPart"].ToString(), ddlexamtype.SelectedItem.ToString(),dsaddrec.Tables[0].Rows[0]["PaperName"].ToString(), dsaddrec.Tables[0].Rows[0]["Streampartcode"].ToString(),dsaddrec.Tables[0].Rows[0]["SubPaperCode"].ToString(), (ddlexamtype.SelectedItem.ToString() == "SQ") ? "B" : "N",ptypecode);
            ViewState["CurrentTable"] = dtCurrentTable;
            gvcourse.DataSource = dtCurrentTable;
            gvcourse.DataBind();
            }

        }
        else
        {
            SetInitialRow();
        }
        SetPreviousData();

    }

    private void SetInitialRow()
    {
        dt1.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column1", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column2", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column3", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column4", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column5", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column6", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column7", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column8", typeof(string)));

        if (stremtypecode == "01")
        {
            sql = "SELECT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperTypeCode, cgpa.SubPaperCode, STREAMPART.StreamPart," +
            " cgpa.StreamPart AS Streampartcode,COURSEPAPERS.PaperName FROM cgpa INNER JOIN COURSEPAPERS ON " +
            " cgpa.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN STREAMPART ON cgpa.StreamPart = STREAMPART.StreamPartcode " +
            " WHERE cgpa.Grade IN ('F', 'F*', 'I','X') AND cgpa.UnivRollNo = '" + RollNo.Text.Trim().ToString() + "' AND " +
            " cgpa.SubPaperCode = '" + ddlcourse.SelectedValue + "'";
        }
        else if (stremtypecode == "02")
        {
            sql = "SELECT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperTypeCode, cgpa_Mtec.SubPaperCode, STREAMPART.StreamPart, " +
                 " cgpa_Mtec.StreamPart AS Streampartcode, COURSEPAPERS.PaperName FROM cgpa_Mtec INNER JOIN COURSEPAPERS ON " +
                 " cgpa_Mtec.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN STREAMPART ON cgpa_Mtec.StreamPart = STREAMPART.StreamPartcode " +
                 " WHERE cgpa_Mtec.Grade IN ('F', 'F*', 'I') AND cgpa_Mtec.UnivRollNo = '" + RollNo.Text.Trim().ToString() + "' AND " +
                 " cgpa_Mtec.SubPaperCode = '" + ddlcourse.SelectedValue + "'";
        }
        DataSet dsaddrec = chkfn.SelectDataset(sql);
        if (dsaddrec.Tables[0].Rows.Count > 0)
        {
            string ptypecode = "";
            if (dsaddrec.Tables[0].Rows[0]["PaperTypeCode"].ToString() == "01")
                ptypecode = "P";
            else if (dsaddrec.Tables[0].Rows[0]["PaperTypeCode"].ToString() == "02")
                ptypecode = "T";
            else if (dsaddrec.Tables[0].Rows[0]["PaperTypeCode"].ToString() == "04")
                ptypecode = "X";
            dr = dt1.NewRow();
            dr["RowNumber"] = 1;
            dr["Column1"] = dsaddrec.Tables[0].Rows[0]["PaperAbbr"].ToString();
            dr["Column2"] = dsaddrec.Tables[0].Rows[0]["StreamPart"].ToString();
            dr["Column3"] = ddlexamtype.SelectedItem.ToString();
            dr["Column4"] = dsaddrec.Tables[0].Rows[0]["PaperName"].ToString();
            dr["Column5"] = dsaddrec.Tables[0].Rows[0]["Streampartcode"].ToString();
            dr["Column6"] = dsaddrec.Tables[0].Rows[0]["SubPaperCode"].ToString();
            dr["Column7"] = (ddlexamtype.SelectedItem.ToString() == "SQ") ? "B" : "N";
            dr["Column8"] = ptypecode;
            dt1.Rows.Add(dr);
            //dr = dt.NewRow();
            //Store the DataTable in ViewState

            ViewState["CurrentTable"] = dt1;
            gvcourse.DataSource = dt1;
            gvcourse.DataBind();
        }

    }

    private void SetPreviousData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt2 = (DataTable)ViewState["CurrentTable"];
            if (dt2.Rows.Count > 0)
            {
                for (int i = 0; i < dt2.Rows.Count; i++)
                {
                    TextBox box1 = (TextBox)gvcourse.Rows[rowIndex].Cells[1].FindControl("txtcoursecode");
                    TextBox box2 = (TextBox)gvcourse.Rows[rowIndex].Cells[2].FindControl("txtsem");
                    TextBox box3 = (TextBox)gvcourse.Rows[rowIndex].Cells[3].FindControl("txtexamtype");
                    TextBox box4 = (TextBox)gvcourse.Rows[rowIndex].Cells[4].FindControl("txtcoursetitle");
                    TextBox box5 = (TextBox)gvcourse.Rows[rowIndex].Cells[5].FindControl("txtspartcode");
                    TextBox box6 = (TextBox)gvcourse.Rows[rowIndex].Cells[6].FindControl("txtpapercode");
                    TextBox box7 = (TextBox)gvcourse.Rows[rowIndex].Cells[7].FindControl("examtypecode");
                    TextBox box8 = (TextBox)gvcourse.Rows[rowIndex].Cells[8].FindControl("ptypecode");
                    box1.Text = dt2.Rows[i]["Column1"].ToString();
                    box2.Text = dt2.Rows[i]["Column2"].ToString();
                    box3.Text = dt2.Rows[i]["Column3"].ToString();
                    box4.Text = dt2.Rows[i]["Column4"].ToString();
                    box5.Text = dt2.Rows[i]["Column5"].ToString();
                    box6.Text = dt2.Rows[i]["Column6"].ToString();
                    box7.Text = dt2.Rows[i]["Column7"].ToString();
                    box8.Text = dt2.Rows[i]["Column8"].ToString();
                    rowIndex++;
                }
            }
        }
    }
    protected void ddlcourse_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlexamtype.Items.Clear();
        int year =  DateTime.Now.Year;
        int prevYear =year-1;
        string strSql = "select SubPaperCode from EXAMPAPERDETAIL "+
                        " where SubPaperCode='"+ddlcourse.SelectedValue+"' and ExamSession in ('JAN-JUN_"+year.ToString()+"','JUL-DEC_"+prevYear.ToString()+"') and UnivRollNo='"+txtrollno.Text.Trim()+"'";
        object value = chkfn.singlevalue(strSql);
        ddlexamtype.Items.Insert(0, "Select");
        ddlexamtype.Items.Insert(1, new ListItem("SPL", "N"));
        if (value != null)
        {
            ddlexamtype.Items.Insert(2, new ListItem("SQ", "B"));
        }
    
    }
}
