using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class WorkFlowStatus : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2") //Role for EC
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(Year , "year", "Select year from year where year >'2006' order by year", "year", "year");
            LockStatus();
            
        }


           
    }
    protected void BtnUpdateLock_Click(object sender, EventArgs e)
    {
        UnivService.Service1 ss = new UnivService.Service1();
        string sql = " update WorkFlowStatus set ";

        if (RegistrationProcess.Checked && RegistrationProcess.Enabled  )
        {
            sql += "RegistrationProcess='true' , RegistrationProcessLockDate=getdate() where ProcessYear='" + Year.SelectedValue + "'";
        }
        else if (RegistrationSlipPrint.Checked && RegistrationSlipPrint.Enabled)
        {
            sql += "RegistrationSlipPrint='true' ,RegistrationSlipPrintLockDate=getdate() where ProcessYear='" + Year.SelectedValue + "'";
        }
        else if (ExamFormEntry.Checked && ExamFormEntry.Enabled)
        {
            sql += "ExamFormEntry='true' ,ExamFormEntryLockDate=getdate() where ProcessYear='" + Year.SelectedValue + "'";
        }

        else if (CentreAllotment.Checked && CentreAllotment.Enabled)
        {
            sql += "CentreAllotment='true' ,CentreAllotmentLockDate=getdate() where ProcessYear='" + Year.SelectedValue + "'";
        }

        else if (AdmitCardPrint.Checked && AdmitCardPrint.Enabled)
        {
            sql += "AdmitCardPrint='true' ,AdmitCardPrintLockDate=getdate() where ProcessYear='" + Year.SelectedValue + "'";
        }

        else if (TRGeneration.Checked && TRGeneration.Enabled)
        {
            sql += "TRGeneration='true' ,TRGenerationLockDate=getdate() where ProcessYear='" + Year.SelectedValue + "'";
        }

        else if (TRPrint.Checked && TRPrint.Enabled)
        {
            sql += "TRPrint='true' ,TRPrintLockDate=getdate() where ProcessYear='" + Year.SelectedValue + "'";
        }
       
       
             
        sql = ss.UpdateData(sql);

        if (sql.ToString() == "ok")
        {
            string popupScript = "<script language='javascript'>" +
                         " alert(' Process is locked successfully. ')" +
                          "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            LockStatus();
        }
        else
        {
           string popupScript = "<script language='javascript'>" +
                         " alert('"+sql.ToString()+" ')" +
                          "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            
        }
    }
    protected void Year_SelectedIndexChanged(object sender, EventArgs e)
    {
        LockStatus();
    }
    protected void LockStatus()
    {
        RegistrationProcess.Enabled =true ;
        RegistrationSlipPrint.Enabled =true ;
        ExamFormEntry.Enabled =true ;
        CentreAllotment.Enabled =true ;
        AdmitCardPrint.Enabled =true ;
        TRGeneration.Enabled =true ;
        TRPrint.Enabled = true;
        RegistrationProcess.Checked =false ;
        RegistrationSlipPrint.Checked =false ;
        ExamFormEntry.Checked =false ;
        CentreAllotment.Checked =false ;
        AdmitCardPrint.Checked =false ;
        TRGeneration.Checked =false ;
        TRPrint.Checked = false;

        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        SqlDataReader reader;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.CommandText = "select * from WorkFlowStatus where ProcessYear='" + Year.SelectedValue + "'";
        cmd.Connection = con;
        con.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            reader.Read();
            if (reader["RegistrationProcess"].ToString() == "True")
            {
                RegistrationProcess.Checked = true; 
                RegistrationProcess.Enabled = false;
            }
            if (reader["RegistrationSlipPrint"].ToString() == "True")
            {
                RegistrationSlipPrint.Checked = true;
                RegistrationSlipPrint.Enabled = false;
            }
            if (reader["ExamFormEntry"].ToString() == "True")
            {
                ExamFormEntry.Checked = true;
                ExamFormEntry.Enabled = false;
            }
            if (reader["CentreAllotment"].ToString() == "True")
            {
                CentreAllotment.Checked = true;
                CentreAllotment.Enabled = false;
            }
            if (reader["AdmitCardPrint"].ToString() == "True")
            {
                AdmitCardPrint.Checked = true;
                AdmitCardPrint.Enabled = false;
            }
            if (reader["TRGeneration"].ToString() == "True")
            {
                TRGeneration.Checked = true;
                TRGeneration.Enabled = false;
            }
            if (reader["TRPrint"].ToString() == "True")
            {
                TRPrint.Checked = true;
                TRPrint.Enabled = false;
            }
        }
        LblMsg.Text = ""; 
        reader.Close();
        con.Close();
    }
}
