﻿using System;
using System.IO;
using System.Data;
using System.Data.SqlClient ;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class DisableMarksEntry : System.Web.UI.Page
{
    UnivService.Service1 NicService = new UnivService.Service1(); string query = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "14") && (Session["Role"].ToString() != "7"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("home.aspx");
                    return;
                }
                else
                {
                    PopulateDDL popddl = new PopulateDDL();

                    popddl.Popualate(DDexamsession, "Faculty_paper_a", "Select distinct ExamSession,substring(ExamSession,9,13) Y ,substring(ExamSession,1,3) M  from Faculty_paper_a where ExamSession is not null order by Y desc, M desc", "ExamSession", "ExamSession");

                    Lblmsg.Visible = false;
                 
                }


            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }


        }
    }




    string UpdateStatus = "";
    protected void btn_enable_Click(object sender, EventArgs e)
    {
        bool chkvalue = false;
        if (chkattendance.Checked == true)
            chkvalue = true;
        if (chkmarks.Checked == true)
            chkvalue = true;
        if (chkvalue == false)
        {
            Lblmsg.Text = "Please Select at least one criteria (Attendance/marks)."; 
            Lblmsg.Visible = true;
            return;
        }        

        if (F_id.Text != "" && F_id.Text != null && DDexamsession.SelectedValue != "")
        {
            if (chkmarks.Checked == true)
            {
                UpdateStatus = "update Faculty_paper_a set Enabled='Y' where ExamSession='" + DDexamsession.SelectedValue + "' and UserId='" + F_id.Text.Trim() + "' and Is_Active = 'Y'";
                NicService.UpdateData(UpdateStatus);
            }
            if (chkattendance.Checked == true)
            {
                UpdateStatus = "update Faculty_paper_a set Is_AttendActive='Y' where ExamSession='" + DDexamsession.SelectedValue + "' and UserId='" + F_id.Text.Trim() + "' and Is_Active = 'Y'";
                NicService.UpdateData(UpdateStatus);
            }
            UpdateStatus = "select distinct L.UserName from Faculty_paper_a F inner join LogIn L on F.UserId=L.UserId where F.UserId='" + F_id.Text.Trim() + "'";
            String Fname = NicService.GetNewCode(UpdateStatus);
            Lblmsg.Text = "Marks Entry has been Enabled for " + Fname;
            Lblmsg.Visible = true;
        }
        else
        {
            Lblmsg.Text = "Please select Exam Session & Enter Faculty User id !!!";
            Lblmsg.Visible = true;
        }
    }
    protected void btn_disable_Click(object sender, EventArgs e)
    {

        bool chkvalue = false;
        if (chkattendance.Checked == true)
            chkvalue = true;
        if (chkmarks.Checked == true)
            chkvalue = true;
        if (chkvalue == false)
        {
            Lblmsg.Text = "Please Select at least one criteria (Attendance/marks).";
            Lblmsg.Visible = true;
            return;
        }
        
        if (F_id.Text != "" && F_id.Text != null && DDexamsession.SelectedValue!="" )
        {
            if (chkmarks.Checked == true)
            {
                UpdateStatus = "update Faculty_paper_a set Enabled='N' where ExamSession='" + DDexamsession.SelectedValue + "' and UserId='" + F_id.Text.Trim() + "' and Is_Active = 'Y'";
                NicService.UpdateData(UpdateStatus);
            }
            if (chkattendance.Checked == true)
            {
                UpdateStatus = "update Faculty_paper_a set Is_AttendActive='N' where ExamSession='" + DDexamsession.SelectedValue + "' and UserId='" + F_id.Text.Trim() + "' and Is_Active = 'Y'";
                NicService.UpdateData(UpdateStatus);
            }
            //string UpdateStatus = "update Faculty_paper_a set Enabled='N',Is_AttendActive='N' where ExamSession='" + DDexamsession.SelectedValue + "' and UserId='" + F_id.Text.Trim() + "'";
            //NicService.UpdateData(UpdateStatus);

            UpdateStatus = "select distinct L.UserName from Faculty_paper_a F inner join LogIn L on F.UserId=L.UserId where F.UserId='" + F_id.Text.Trim() + "'";
            String Fname = NicService.GetNewCode(UpdateStatus);
            Lblmsg.Text = "Attendance/Marks Entry has been Disabled for " + Fname;
            Lblmsg.Visible = true;
        }
        else
        {
            Lblmsg.Text = "Please select Exam Session & Enter Faculty User id !!!";
            Lblmsg.Visible = true;
        }

    }
    protected void btn_enableall_Click(object sender, EventArgs e)
    {
        bool chkvalue = false;
        if (chkattendance.Checked == true)
            chkvalue = true;
        if (chkmarks.Checked == true)
            chkvalue = true;
        if (chkvalue == false)
        {
            Lblmsg.Text = "Please Select at least one criteria (Attendance/marks).";
            Lblmsg.Visible = true;
            return;
        }

        if (DDexamsession.SelectedValue != "" && DDexamsession.SelectedValue!=null)
        {
            if (chkmarks.Checked == true)
            {
                UpdateStatus = "update Faculty_paper_a set Enabled = 'Y' where ExamSession='" + DDexamsession.SelectedValue + "' and Is_Active = 'Y'";
                NicService.UpdateData(UpdateStatus);
            }
            if (chkattendance.Checked == true)
            {
                UpdateStatus = "update Faculty_paper_a set Is_AttendActive = 'Y' where ExamSession='" + DDexamsession.SelectedValue + "' and Is_Active = 'Y'";
                NicService.UpdateData(UpdateStatus);
            }

            //string UpdateStatus = "update Faculty_paper_a set Enabled='Y',Is_AttendActive='Y' where ExamSession='" + DDexamsession.SelectedValue + "'";
            //NicService.UpdateData(UpdateStatus);
                       
            Lblmsg.Text = "Marks Entry has been Enabled for all faculties !!! ";
            Lblmsg.Visible = true;
        }
        else
        {
            Lblmsg.Text = "Please select Exam Session !!!";
            Lblmsg.Visible = true;
        }
    }
    protected void btn_all_Click(object sender, EventArgs e)
    {
        bool chkvalue = false;
        if (chkattendance.Checked == true)
            chkvalue = true;
        if (chkmarks.Checked == true)
            chkvalue = true;
        if (chkvalue == false)
        {
            Lblmsg.Text = "Please Select at least one criteria (Attendance/marks).";
            Lblmsg.Visible = true;
            return;
        }

        if (DDexamsession.SelectedValue != "" && DDexamsession.SelectedValue != null)
        {
            if (chkmarks.Checked == true)
            {
                UpdateStatus = "update Faculty_paper_a set Enabled = 'N' where ExamSession='" + DDexamsession.SelectedValue + "' and Is_Active = 'Y'";
                NicService.UpdateData(UpdateStatus);
            }
            if (chkattendance.Checked == true)
            {
                UpdateStatus = "update Faculty_paper_a set Is_AttendActive = 'N' where ExamSession='" + DDexamsession.SelectedValue + "' and Is_Active = 'Y'";
                NicService.UpdateData(UpdateStatus);
            }

            //string UpdateStatus = "update Faculty_paper_a set Enabled='N',Is_AttendActive='N' where ExamSession='" + DDexamsession.SelectedValue + "'";
            //NicService.UpdateData(UpdateStatus);
            

            Lblmsg.Text = "Marks Entry has been Disabled for all faculties !!! ";
            Lblmsg.Visible = true;
        }
        else
        {
            Lblmsg.Text = "Please select Exam Session !!!";
            Lblmsg.Visible = true;
        }
    }
}