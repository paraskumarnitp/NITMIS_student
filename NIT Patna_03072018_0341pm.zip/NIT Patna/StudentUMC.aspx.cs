using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class StudentUMC : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //Panel1.Visible = true;
            try
            {

                if ((Session["Role"].ToString() != "2") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "14") && (Session["Role"].ToString() != "4"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
                bindexamsession(); 
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
        }          
       
    }

    private void bindexamsession() 
    {
        DataTable dtexamsession = fnrev.SelectDatatable("SELECT ExamSession FROM EXAMPAPERDETAIL GROUP BY ExamSession, " + 
            " CAST(SUBSTRING(ExamSession, 5, 3) + SUBSTRING(ExamSession, 9, 4) AS DATETIME) HAVING (ExamSession <> '') ORDER " + 
            " BY CAST(SUBSTRING(ExamSession, 5, 3) + SUBSTRING(ExamSession, 9, 4) AS DATETIME) DESC");
        ddlexamsession.DataSource = dtexamsession;
        ddlexamsession.DataTextField = "ExamSession";
        ddlexamsession.DataValueField = "ExamSession";
        ddlexamsession.DataBind();
        ddlexamsession.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    private void bindprogram()
    {
        DataTable dtprogram = fnrev.SelectDatatable("SELECT DISTINCT STREAM.StreamAbbr, STREAM.StreamCode FROM EXAMPAPERDETAIL INNER " +  
            " JOIN STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN STREAM ON " + 
            " STREAMPART.StreamCode = STREAM.StreamCode WHERE (EXAMPAPERDETAIL.ExamSession = '"+ddlexamsession.SelectedValue.ToString()+"')");
        ddlprogram.DataSource = dtprogram;
        ddlprogram.DataTextField = "StreamAbbr";
        ddlprogram.DataValueField = "StreamCode";
        ddlprogram.DataBind();
        ddlprogram.Items.Insert(0,new ListItem("--Select--","0"));
    }
    //private void bindStreampart()
    //{
    //    DataTable dtstreampart = fnrev.SelectDatatable("SELECT DISTINCT STREAMPART.StreamPartCode, STREAMPART.StreamPart FROM " + 
    //        " EXAMPAPERDETAIL INNER JOIN STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode WHERE " + 
    //        " (EXAMPAPERDETAIL.ExamSession = '"+ddlexamsession.SelectedValue.ToString()+"') AND (STREAMPART.StreamCode = '"+ddlprogram.SelectedValue.ToString()+"')");
    //    ddlsemester.DataSource = dtstreampart;
    //    ddlsemester.DataTextField = "StreamPart";
    //    ddlsemester.DataValueField = "StreamPartCode";
    //    ddlsemester.DataBind();
    //    ddlsemester.Items.Insert(0, new ListItem("--Select--", "0"));
    //}
    private void bindCourse()
    {
        DataTable dtcourse = fnrev.SelectDatatable("SELECT DISTINCT COURSEPAPERS.PaperAbbr, EXAMPAPERDETAIL.SubPaperCode, " +
            " EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.ApplicantName, REGISTRATION.AckNo FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON " + 
            " EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo " + 
            " WHERE (EXAMPAPERDETAIL.ExamSession = '"+ddlexamsession.SelectedValue.ToString()+"') AND (COURSEPAPERS.StreamCode = '"+ddlprogram.SelectedValue.ToString()+"') " + 
            " AND  UnivRollno = '"+txtrollno.Text.Trim()+"'");
        if (dtcourse.Rows.Count > 0)
        {
            ddlcourse.DataSource = dtcourse;
            ddlcourse.DataTextField = "PaperAbbr";
            ddlcourse.DataValueField = "SubPaperCode";
            ddlcourse.DataBind();
            ddlcourse.Items.Insert(0, new ListItem("--Select--", "0"));
            txtenrollment.Text = dtcourse.Rows[0]["AckNo"].ToString();
            txtname.Text = dtcourse.Rows[0]["ApplicantName"].ToString();
        }
        else lblmsg.Text = "Record(S) Not Found OR Student with Roll No.- " + txtrollno.Text.Trim() +" is not registered.";
    }
    protected void ddlexamsession_SelectedIndexChanged(object sender, EventArgs e)
    {
        bindprogram();
    }
    protected void ddlprogram_SelectedIndexChanged(object sender, EventArgs e)
    {
        //bindStreampart();
        Panel1.Visible = false;
    }
    protected void ddlsemester_SelectedIndexChanged(object sender, EventArgs e)
    {
        
            
        //}
        //else
        //{
        //    lblmsg.Text = "First Enter Roll No on which UMC Implement.";
        //}
    }

    private void bindgrid()
    {
        DataTable dtcourse = fnrev.SelectDatatable("SELECT REGISTRATION.AckNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.ApplicantName, " + 
            " COURSEPAPERS.PaperAbbr, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON " + 
            " EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo " + 
            " WHERE (EXAMPAPERDETAIL.ExamSession = '"+ddlexamsession.SelectedValue.ToString()+"') AND (COURSEPAPERS.StreamCode = '"+ddlprogram.SelectedValue.ToString()+"') " + 
            " AND  UnivRollNo = '"+txtrollno.Text.Trim()+"'");
        gvredg.DataSource = dtcourse;
        gvredg.DataBind();
        Panel1.Visible = true;
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        int Insrec = 0;
        if ((ddlumc.SelectedValue.ToString() != "ES-3") && (ddlumc.SelectedValue.ToString() != "ES-4") && (ddlumc.SelectedValue.ToString() != "ES-5"))
        {
            Insrec = fnrev.InsertUpdateDelete("Update ExampaperDetail Set UMCode = '" + ddlumc.SelectedValue.ToString() + "', Opt1 = '" + Session["UserId"].ToString() + "' Where " +
                " Examsession ='" + ddlexamsession.SelectedValue.ToString() + "' and  UnivrollNo = '" + txtrollno.Text.Trim() + "' and SubpaperCode = '" + ddlcourse.SelectedValue.ToString() + "'");
        }
        else
        {
            Insrec = fnrev.InsertUpdateDelete("Update ExampaperDetail Set UMCode = '" + ddlumc.SelectedValue.ToString() + "', Opt1 = '" + Session["UserId"].ToString() + "' Where " +
                           " Examsession ='" + ddlexamsession.SelectedValue.ToString() + "' and  UnivrollNo = '" + txtrollno.Text.Trim() + "'");
        }
        if (Insrec == 0)
        {
            lblmsg.Text = "Error : UMC Not Updated";
            return;
        }
        else
        {
            lblmsg.Text = "Success : UMC Updated on Roll No. " + txtrollno.Text.Trim();
            clear();
        }
    }

    private void clear()
    {
        try
        {
            ddlexamsession.SelectedIndex = 0;
            ddlprogram.SelectedIndex = 0;
            //ddlsemester.SelectedIndex = 0;
            txtrollno.Text = ""; txtenrollment.Text = ""; txtname.Text = ""; ddlcourse.Items.Clear();
            ddlumc.SelectedIndex = 0; ddlexamsession.Focus();
            Panel1.Visible = false;
        }
        catch
        { 

        }

    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        clear();
    }
    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        bindCourse(); bindgrid();
    }
    protected void btnblockresult_Click(object sender, EventArgs e)
    {
        object streamtypecode = fnrev.singlevalue("SELECT StreamTypeCode FROM Stream WHERE StreamCode = '"+ddlprogram.SelectedValue.ToString()+"'");
        if (streamtypecode != null)
        {
            string query = "";
            if (streamtypecode.ToString() == "01")
            {
                if (chkballcourses.Checked)
                {
                    query = "Update TRBTec SET Is_active = 'N' WHERE UnivRollNo = '" + txtrollno.Text.Trim().ToString() + "' and ExamSession = '" + ddlexamsession.SelectedValue.ToString() + "'";
                }
                else
                    query = "Update TRBTec SET Is_active = 'N' WHERE UnivRollNo = '" + txtrollno.Text.Trim().ToString() + "' and SubPaperCode = '" + ddlcourse.SelectedValue.ToString() + "' and ExamSession = '" + ddlexamsession.SelectedValue.ToString() + "'";
            }
            else
            {
                if (chkballcourses.Checked)
                {
                    query = "Update TRMTec SET Is_active = 'N' WHERE UnivRollNo = '" + txtrollno.Text.Trim().ToString() + "' and ExamSession = '" + ddlexamsession.SelectedValue.ToString() + "'";
                }
                else
                    query = "Update TRMTec SET Is_active = 'N' WHERE UnivRollNo = '" + txtrollno.Text.Trim().ToString() + "' and SubPaperCode = '" + ddlcourse.SelectedValue.ToString() + "' and ExamSession = '" + ddlexamsession.SelectedValue.ToString() + "'";
            }

            int insrec = fnrev.InsertUpdateDelete(query);
            if (insrec != 0)
            {
                lblmsg.Text = "Result has been Blocked.";
            }
            else
                lblmsg.Text = "Result has been failed to Block.";
        }
    }
}
