using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class VerifyExamForm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "3")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CastCode, "Category", "Select Category,CategoryCode from Category order by Category", "Category", "CategoryCode");
            //popddl.Popualate(PermanentDistCode, "District", "Select DistName,DistCode from District order by DistName", "DistName", "DistCode");
            popddl.Popualate(PresentDistrictCode, "District", "Select DistName,DistCode from District order by DistName", "DistName", "DistCode");
            //popddl.Popualate(NationalityCode, "Nationality", "Select Nationality,NationalityCode from Nationality order by Nationality", "Nationality", "NationalityCode");
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where Study='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(StreamCode1, "Stream", "Select StreamAbbr, StreamCode from Stream Where Study='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(Year1, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(Year2, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(ReligionCode, "Religion", "Select * from Religion order by ReligionCode", "Religion", "ReligionCode");
            //popddl.Popualate(ExamCode1, "ExamName", "Select ExamName, ExamCode from ExamName order by ExamName", "ExamName", "ExamCode");
            //popddl.Popualate(UnivCode1, "University", "Select UnivName,UnivCode from University order by UnivName", "UnivName", "UnivCode");
            popddl.Popualate(CollegeCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(Year, "Year", "Select Year from Year where year >= '2008' order by Year", "Year", "Year");
            
            
            //DataSet ds = new DataSet();
            //ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select AckNo,RegNo,ApplicantName,FatherName,MotherName,DOB,CollCode from Registration where RegNo is null or RegNo=''");
            //ExamView.DataSource = ds;
            //ExamView.DataBind();
            BindGrid();
            
            TotStudent.Text = ExamView.Rows.Count.ToString();
              MultiView1.ActiveViewIndex = 0;
        }
       

        

    }
    protected void RegView_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            RegNo.Text = ExamView.SelectedRow.Cells[2].Text;
            MultiView1.ActiveViewIndex = 1;
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;
            cmd.CommandText = "select RegNo,ReasonOfRejection,date from RejectedExamForm where RegNo='" + RegNo.Text + "' And StreamPArtCode='" + ExamView.SelectedRow.Cells[7].Text + "'";
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                RegNo.Text = reader["RegNo"].ToString();
                ReasonOfRejection.Text = reader["ReasonOfRejection"].ToString();
                LblMsg.Text = "Reamrks for Rejection is already added on Date " + string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["Date"].ToString()));

                BtnSaveReject.Enabled = false;
                reader.Close();
                con.Close();
            }
            else
            {
                BtnSaveReject.Enabled = true;
                ReasonOfRejection.Text = "";
                LblMsg.Text = "";
                reader.Close();
                con.Close();
            }
            //// Diplay Exam Form Detail of Applicant
            ViewExamFormDetail(RegNo.Text.Trim());
            ViewExamFormOtherDetails(RegNo.Text.Trim(),Year.SelectedValue.ToString());
            ViewExamPaperDetails(RegNo.Text.Trim(), StreamPart.SelectedValue, Year.SelectedValue.ToString());
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

        //--------------
 
    }
    protected void RegView_PageIndexChanged(object sender, EventArgs e)
    {
        
    }
    protected void RegView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
  
        ExamView.PageIndex = e.NewPageIndex;
        BindGrid();

    }
    protected void LnkBtnAll_Click(object sender, EventArgs e)
    {

        foreach (GridViewRow row in ExamView.Rows)
        {
            CheckBox myCheckBox = (CheckBox)row.FindControl("CheckBox1");
            myCheckBox.Checked = true;

        }


    }
    protected void LnkBtnNone_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow row in ExamView.Rows)
        {
            CheckBox myCheckBox = (CheckBox)row.FindControl("CheckBox1");
            myCheckBox.Checked = false;
        }
    }
    void BindGrid()
    {
        DataSet ds = new DataSet();
        string SQL = "";


    /*   old_source code....chnage by suraj on 20-DEC-2012
     * 
     * SQL = "SELECT EXAM.RegNo AS Reg, REGISTRATION.ApplicantName, REGISTRATION.FatherName, REGISTRATION.DOB," +
          "EXAM.StreamCode, EXAM.StreamPartCode, EXAM.SubCode, EXAM.ExamFormNo, EXAM.ExamType " +
          "FROM REGISTRATION INNER JOIN EXAM ON REGISTRATION.RegNo = EXAM.RegNo" +
          "where EXAM.CollCode='" + CollegeCode.SelectedValue + "' and ExamYear='" + Year.Text.Trim() + "' and EXAM.SubCode='" + SubCode1.SelectedValue + "' " +
          "and (UnivRollNo is NULL or UnivRollNo='') and (Exam.VerifySUDateTime is null or Exam.VerifySUDateTime='') and (Exam.verifyStatus='N') And Exam.StreamPartCode='" + StreamPartCode.SelectedValue + "' order by Exam." + OrderBy.SelectedValue + "";
          */
               
            SQL = "SELECT EXAM.RegNo AS Reg, REGISTRATION.ApplicantName, REGISTRATION.FatherName, REGISTRATION.DOB," +
            "EXAM.StreamCode, EXAM.StreamPartCode, EXAM.SubCode, EXAM.ExamFormNo, EXAM.ExamType " +
            "FROM REGISTRATION INNER JOIN EXAM ON (REGISTRATION.RegNo = EXAM.RegNo and REGISTRATION.StreamCode = EXAM.StreamCode)" +
            "where EXAM.CollCode='" + CollegeCode.SelectedValue + "' and ExamYear='" + Year.Text.Trim() + "' and EXAM.SubCode='" + SubCode1.SelectedValue + "' " +
            "and (UnivRollNo is NULL or UnivRollNo='') and (Exam.VerifySUDateTime is null or Exam.VerifySUDateTime='') and (Exam.verifyStatus='N') And Exam.StreamPartCode='" + StreamPartCode.SelectedValue + "' order by Exam." + OrderBy.SelectedValue + "";

        //ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select AckNo,RegNo,ApplicantName,FatherName,MotherName,DOB,CollCode,StreamCode from Registration where collcode='" + CollCode.SelectedValue.ToString() + "' and  YEAR(CollegeAdmissionDate) ='" + Year.SelectedValue.ToString() + "' and (regno is NULL or regno='') and (VerifySUDateTime is null or VerifySUDateTime='')  ");
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, SQL);
        ExamView.DataSource = ds;
        ExamView.DataBind();                
      
      
    }
    protected void BtnView_Click(object sender, EventArgs e)
    {
        try
        {


            BindGrid();
            if (ExamView.Rows.Count > 0)
            {
                TotStudent.Visible = true;
                TotStudent.Text = " Total Student =  " + ExamView.Rows.Count.ToString();
                Panel1.Visible = true;
            }
            else
            {
                TotStudent.Visible = true;
                TotStudent.Text = "All Records have been verified";
                Panel1.Visible = false;
            }
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }



    }
    protected void BtnVerifyRegNo_Click(object sender, EventArgs e)
    {
        try
        {

            if (ExamView.Rows.Count > 0)
            {
                SqlConnection con = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
                cmd.Connection = con;
                con.Open();
                SqlTransaction tran;

                int count = 0;

                for (int i = 0; i < int.Parse(ExamView.Rows.Count.ToString()); i++)
                {

                    CheckBox myCheckBox = (CheckBox)ExamView.Rows[i].FindControl("CheckBox1");
                    if (myCheckBox.Checked == true)
                    {
                        count = count + 1;
                        tran = con.BeginTransaction();
                        cmd.Transaction = tran;

                        cmd.CommandText = " update Exam  set  VerifySUDateTime=Getdate() where RegNo='" + ExamView.Rows[i].Cells[2].Text + "' and ExamYear='" + Year.Text + "' and StreamPartCode='" + ExamView.Rows[i].Cells[7].Text + "'";
                        cmd.ExecuteNonQuery();
                        tran.Commit();
                    }
                }

                string popupScript = "<script language='javascript'>" +
                                  " alert('   " + count + " Exam Forms Verified. ')" +
                                   "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);

                BindGrid();
            }
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0; 
    }
    protected void BtnSaveReject_Click(object sender, EventArgs e)
    {

        try
        {

            string[] col = new string[5];
            string[] val = new string[5];
            col[0] = "RegNo";
            col[1] = "ReasonOfRejection";
            col[2] = "Date";
            col[3] = "StreamPartCode";
            col[4] = "ExamYear";



            val[0] = RegNo.Text;
            val[1] = ReasonOfRejection.Text.Trim();
            val[2] = string.Format("{0:MM/dd/yyyy}", System.DateTime.Now);
            val[3] = StreamPart.SelectedValue.ToString();
            val[4] = ExamYear.Text;



            UnivService.Service1 ss = new UnivService.Service1();
            string abc = ss.SaveData("RejectedExamForm", col, val);
            string status;

            if (RadioButton1.Checked)
                status = "B";
            else
                status = "F";

            abc = ss.UpdateData(" update EXAM set verifystatus='" + status + "' where regno='" + RegNo.Text.Trim() + "' and streamPartcode='" + StreamPart.SelectedValue.ToString() + "' and ExamYear='" + ExamYear.Text.Trim() + "' ");
            if (abc == "ok")
            {

                LblMsg.Text = " Remarks is saved successfully";
                BtnSaveReject.Enabled = false;

            }
            else
            {
                LblMsg.Text = abc.ToString();
            }
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

    }

    protected void ViewExamFormDetail(string RegNo)
    {
        
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

        cmd.Connection = con;
        con.Open();
        cmd.CommandText = "select count(*) N from registration where RegNo='" + RegNo + "' "; //change by suraj for registration using old registration no.
        SqlDataReader rd;                     // change by suraj 20-dec-2012
        rd = cmd.ExecuteReader();
        rd.Read();
        string temp = rd["N"].ToString();
        con.Close();
        rd.Close();

        if(temp=="2") //change by suraj.... admission for new course using old registration
            cmd.CommandText = " select AckNo,ApplicantName,HindiName,FatherName,MotherName,DOB,Gender,CastCode," +
         "ReligionCode,CourseSession from Registration where RegNo='" + RegNo + "' and IsOld='Y'";
        else
        cmd.CommandText = " select AckNo,ApplicantName,HindiName,FatherName,MotherName,DOB,Gender,CastCode," +
                 "ReligionCode,CourseSession from Registration where RegNo='" + RegNo + "'";
        SqlDataReader reader;
        con.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            reader.Read();
            Panel2.Visible = true;
            ApplicantName.Text = reader["ApplicantName"].ToString();
            HindiName.Text = reader["HindiName"].ToString();
            FatherName.Text = reader["FatherName"].ToString();
            MotherName.Text = reader["MotherName"].ToString();
            DOB.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["DOB"]));
            ReligionCode.SelectedValue = reader["ReligionCode"].ToString();
            if (reader["Gender"].ToString() == "M")
                GenderM.Checked = true;
            else
                GenderF.Checked = true;
            Year1.Text = (reader["CourseSession"].ToString()).Substring(0, 4);
            Year2.Text = (reader["CourseSession"].ToString()).Substring(5, 4);
            
           


       //Image Load

            ImageUpload imgUpload = new ImageUpload();
            string strFileName = imgUpload.Image_Load(reader["AckNo"].ToString());

         
            if (strFileName.ToString().Contains("temp"))
            {


                string photo = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/temp.jpg";

                string strRightNow = "";
                string IUrl = "";

                strRightNow = System.DateTime.Now.ToString("ddMMyyyyHHmmss");
                IUrl = photo + "?img=" + strRightNow;

                Image3.ImageUrl = IUrl;
                Image3.DataBind();


            }
            else if (strFileName.ToString().Contains("UploadPhoto"))
            {

                Image3.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadPhoto.JPG";
                Image3.DataBind();

            }

            else
            {
                LblMsg.Text = "Error" + strFileName;
          
            }

       // IMAGE load --End
          reader.Close(); 

        }





        
           
    }
    
    protected void ViewExamFormOtherDetails(string RegNo, string CurrentExamYear)
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

        cmd.Connection = con;
        cmd.CommandText = " select CollCode,ClassRollNo,PresentAddress1,PresentAddress2,PresentDistrictCode,PresentPinCode," +
            "SCBNo,SCBDate,ExamFeeAmt,ExamFormNo,ExamType,ExamYear, " +
            "StreamCode,StreamPartCode,subcode,ModeOfExam from Exam where RegNo='" + RegNo + "' And StreamPartCode='" + ExamView.SelectedRow.Cells[7].Text + "' and ExamYear='" + CurrentExamYear.ToString() + "' ";

        SqlDataReader reader;
        con.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            reader.Read();
            CollCode.SelectedValue = reader["CollCode"].ToString();
            ClassRollNo.Text = reader["ClassRollNo"].ToString();
            PresentAddress1.Text = reader["PresentAddress1"].ToString();
            PresentAddress2.Text = reader["PresentAddress2"].ToString();
            PresentDistrictCode.SelectedValue = reader["PresentDistrictCode"].ToString();
            PresentPinCode.Text = reader["PresentPinCode"].ToString();
            SCBNo.Text = reader["SCBNo"].ToString();
            SCBDate.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["SCBDate"].ToString()));
            ExamFeeAmt.Text = reader["ExamFeeAmt"].ToString();
            ExamFormNo.Text = reader["ExamFormNo"].ToString();
            ExamType.SelectedValue = reader["ExamType"].ToString();
            ExamYear.Text = reader["ExamYear"].ToString();
           

            StreamCode.SelectedValue = reader["streamcode"].ToString();

             // Mode ofExam
            if (reader["ModeOfExam"].ToString() == "E")               ModeOfExamE.Checked = true;
            else if (reader["ModeOfExam"].ToString() == "H")          ModeOfExamH.Checked = true;
            else ModeOfExamN.Checked = true;

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
            StreamPart.SelectedValue = reader["streampartcode"].ToString();

            popddl.Popualate(SubCode, "Subject", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
            SubCode.SelectedValue = reader["subcode"].ToString();

        }

        reader.Close();
    }
    protected void ViewExamPaperDetails(string regno, string strpartcode, string CurrentExamYear)
    {
 
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

        //16201006830

        cmd.Connection = con;
        cmd.CommandText = "SELECT SubPaperCode, PaperType FROM EXAMPAPERDETAIL "+
        "WHERE RegNo='" + regno + "' AND ExamYear = '" + CurrentExamYear + "' AND StreamPartCode = '" + strpartcode + "' " +
        "ORDER BY PaperType";

        CompPaper.Items.Clear();
        HPaper.Items.Clear();
        SPaper.Items.Clear();

        SqlDataReader reader;
        con.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            string papernm="";
            
            UnivService.Service1 ss = new UnivService.Service1();
            while (reader.Read())
            {
                
                if (reader["papertype"].ToString() == "C")
                {
                    papernm =ss.GetNewCode ("select Abbr from Composition where Compcode='"+ reader["subpaperCode"].ToString ()+"'");
                    CompPaper.Items.Add(papernm);
   

                }
                else if (reader["papertype"].ToString() == "H")
                {
                    papernm = ss.GetNewCode("select papername from Coursepapers where subpapercode='" + reader["subpaperCode"].ToString() + "'");
                    HPaper.Items.Add(papernm);
                }
                else if (reader["papertype"].ToString() == "S")
                {
                    papernm = ss.GetNewCode("select subAbbr from Subject where subcode='" + reader["subpaperCode"].ToString() + "'");
                    SPaper.Items.Add(papernm);
                }
            }

        }
        reader.Close();



    }

    protected void StreamCode1_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPartCode, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode1.SelectedValue + "'order by abs(StreamPartCode)", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode1, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode1.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");

        StreamCode.Focus(); 



    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollegeCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollegeCode.SelectedIndex = 0;
        }
    }
    protected void CollegeCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollegeCode.SelectedValue.ToString();
    }
}
