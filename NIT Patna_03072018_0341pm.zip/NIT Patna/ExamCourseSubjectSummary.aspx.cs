using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class ExamCourseSubjectSummary : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "5")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(Year, "Year", "Select Year from Year where year >= '2008' order by Year", "Year", "Year");
            popddl.Popualate(StreamCode1, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from exam) order by StreamAbbr", "StreamAbbr", "StreamCode");
            CourseSubject();
        }
    }
    protected void StreamCode1_SelectedIndexChanged(object sender, EventArgs e)
    {
        CourseSubject();
    }
    protected void CourseSubject()
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart, StreamPartCode from StreamPart where streamcode='" + StreamCode1.SelectedValue + "' and streampartcode in (select distinct streampartcode from exam) order by StreamPart", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode1, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode1.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");

    }

    protected void BtnView_Click(object sender, EventArgs e)
    {

        //string sql = "SELECT dbo.COLLEGE.CollCode, dbo.COLLEGE.CollName, COUNT(dbo.Exam.RegNo) AS [TotApp], " +
        //"COUNT(dbo.Exam.UnivRollNo)  AS [TotalAlloted] , COUNT(dbo.Exam.RegNo)-COUNT(dbo.Exam.UnivRollNo) as [Pending] " +
        //"FROM  dbo.Exam ,dbo.COLLEGE  WHERE  (dbo.Exam.CollCode = dbo.COLLEGE.CollCode) and   (dbo.Exam.ExamYear = '" + Year.Text + "')  and (dbo.Exam.streamcode='" + StreamCode1.SelectedValue + "')  and (dbo.Exam.subcode='" + SubCode1.SelectedValue + "')  GROUP BY dbo.COLLEGE.CollCode, dbo.COLLEGE.CollName ";

// Changes made by 28-04-2011
        string sql = "SELECT dbo.COLLEGE.CollCode, dbo.COLLEGE.CollName, COUNT(dbo.Exam.RegNo) AS [TotApp], " +
   "COUNT(dbo.Exam.UnivRollNo)  AS [TotalAlloted] , COUNT(dbo.Exam.RegNo)-COUNT(dbo.Exam.UnivRollNo) as [Pending] " +
   "FROM  dbo.Exam ,dbo.COLLEGE  WHERE  (dbo.Exam.CollCode = dbo.COLLEGE.CollCode) and   (dbo.Exam.ExamYear = '" + Year.Text + "')  and (dbo.Exam.streamcode='" + StreamCode1.SelectedValue + "') and (dbo.Exam.streamPartcode='" + StreamPart.SelectedValue + "') and (dbo.Exam.subcode='" + SubCode1.SelectedValue + "')  GROUP BY dbo.COLLEGE.CollCode, dbo.COLLEGE.CollName ";
        

                
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        ExamSummaryView.DataSource = ds;
        ExamSummaryView.DataBind();


        //sql="SELECT    COUNT(dbo.Exam.RegNo) AS [TotApp], COUNT(dbo.Exam.UnivRollNo)  AS [TotalAlloted] ,"+
        //    "COUNT(dbo.Exam.RegNo)-COUNT(dbo.Exam.UnivRollNo) as [Pending] FROM dbo.Exam "+
        //    "WHERE     (dbo.Exam.ExamYear = '" + Year.Text + "') and (dbo.Exam.streamcode='" + StreamCode1.SelectedValue + "')  and (dbo.Exam.subcode='" + SubCode1.SelectedValue + "') ";

        sql = "SELECT    COUNT(dbo.Exam.RegNo) AS [TotApp], COUNT(dbo.Exam.UnivRollNo)  AS [TotalAlloted] ," +
                   "COUNT(dbo.Exam.RegNo)-COUNT(dbo.Exam.UnivRollNo) as [Pending] FROM dbo.Exam " +
                   "WHERE     (dbo.Exam.ExamYear = '" + Year.Text + "') and (dbo.Exam.streamcode='" + StreamCode1.SelectedValue + "') and (dbo.Exam.streamPartcode='" + StreamPart.SelectedValue + "') and (dbo.Exam.subcode='" + SubCode1.SelectedValue + "') ";
       

        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
}
