using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class AdmitCardGra : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(Year, "Year", "Select Year from Year where Year >= 2008 order by Year", "Year", "Year");
            popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
            popddl.Popualate(Year3, "Year", "Select Year from Year where year > '2008'order by Year", "Year", "Year");
            //popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        }
       

    }
    
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        
        StreamCode.Focus(); 
    }
    protected void BtnGenAdmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        SqlConnection con1 = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        //SqlCommand cmd1 = new SqlCommand();
        SqlDataReader reader;
        cmd.Connection = con;
        //cmd1.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        con1.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        
        // Select Only those students whose admit card is generated ...
        /*    
         * old code ...change by suraj on 20-DEC-2012
         * string sql = "SELECT EXAM.RegNo, EXAM.UnivRollNo, REGISTRATION.ApplicantName, REGISTRATION.HindiName, REGISTRATION.FatherName, " +
                   "Registration.Gender, EXAM.ClassRollNo, Exam.Subcode,  SUBJECT.SubAbbr, " +
                   "EXAM.ExamType,Stream.StreamAbbr,StreamPart.StreamPart FROM EXAM , REGISTRATION ,SUBJECT, Stream,StreamPart where  EXAM.RegNo=Registration.RegNo and" +
                   " Subject.SubCode=Exam.SubCode and Exam.CollCode='"+ CollCode.SelectedValue  +"' and  EXAM.ExamYear='" + Year.SelectedValue + 
                   "' and EXAM.StreamCode='" + StreamCode.SelectedValue + "' and EXAM.StreamPartCode='" + StreamPart.SelectedValue +
                   "' and EXAM.SubCode='" + SubCode.SelectedValue + "'  and Stream.StreamCode='" + StreamCode.SelectedValue + "' and StreamPart.StreamPartCode='" + StreamPart.SelectedValue +
                   "' and (Exam.UniVRollNo is Not Null or Exam.UnivRollNo <>'')  ";
*/
        string examsession = month1.SelectedItem.ToString() + "-" + month2.SelectedItem.ToString() + "_" + Year3.SelectedItem.ToString();


           //string  sql = "SELECT EXAM.RegNo, EXAM.UnivRollNo, REGISTRATION.ApplicantName, REGISTRATION.HindiName, REGISTRATION.FatherName, " +
           //            "Registration.Gender, EXAM.ClassRollNo, Exam.Subcode,  SUBJECT.SubAbbr, " +
           //            "EXAM.ExamType,Stream.StreamAbbr,StreamPart.StreamPart,EXAM.ExamSession FROM EXAM , REGISTRATION ,SUBJECT, Stream,StreamPart where  EXAM.RegNo=Registration.RegNo and EXAM.CollCode=Registration.CollCode and" +
           //            " Subject.SubCode=Exam.SubCode and Exam.CollCode='" + CollCode.SelectedValue + "' and  EXAM.ExamSession='" + examsession +
           //            "' and EXAM.StreamCode='" + StreamCode.SelectedValue + "' and EXAM.StreamPartCode='" + StreamPart.SelectedValue +
           //            "' and EXAM.SubCode='" + SubCode.SelectedValue + "'  and Stream.StreamCode='" + StreamCode.SelectedValue + "' and StreamPart.StreamPartCode='" + StreamPart.SelectedValue + "'  ";


        string sql="SELECT     EXAM.RegNo, EXAM.UnivRollNo, REGISTRATION.ApplicantName, REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.Gender,  "+
                    "  EXAM.ClassRollNo, EXAM.SubCode, SUBJECT.SubAbbr, EXAM.ExamType, STREAM.StreamAbbr, STREAMPART.StreamPart, EXAM.ExamSession "+
                    " FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo AND EXAM.CollCode = REGISTRATION.CollCode INNER JOIN "+
                    " SUBJECT ON EXAM.SubCode = SUBJECT.SubCode INNER JOIN "+
                    " STREAMPART ON EXAM.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN "+
                    " STREAM ON STREAMPART.StreamCode = STREAM.StreamCode cross apply (select UnivRollNo,ExamSession,a.StreamCode,max(CONVERT(int, LEFT(SUBSTRING(b.StreamPart, PATINDEX('%[0-9]%', b.StreamPart), 8000), "+
                    " PATINDEX('%[^0-9]%', SUBSTRING(b.StreamPart, PATINDEX('%[0-9]%', "+
                    " b.StreamPart), 8000) + 'X') - 1))) as asd from EXAM a inner join STREAMPART b on a.StreamPartCode=b.StreamPartCode where a.StreamCode='"+StreamCode.SelectedValue+"' and     (a.ExamSession = '"+examsession+"') "+
                    " Group by UnivRollNo,ExamSession,a.StreamCode "+
                    " having max(CONVERT(int, LEFT(SUBSTRING(b.StreamPart, PATINDEX('%[0-9]%', b.StreamPart), 8000),  "+
                    " PATINDEX('%[^0-9]%', SUBSTRING(b.StreamPart, PATINDEX('%[0-9]%',  "+
                    " b.StreamPart), 8000) + 'X') - 1)))=CONVERT(int, LEFT(SUBSTRING(STREAMPART.StreamPart, PATINDEX('%[0-9]%', STREAMPART.StreamPart), 8000),  "+
                    " PATINDEX('%[^0-9]%', SUBSTRING(STREAMPART.StreamPart, PATINDEX('%[0-9]%', "+
                    " STREAMPART.StreamPart), 8000) + 'X') - 1)) and a.StreamCode=EXAM.StreamCode and a.UnivRollNo=exam.UnivRollNo) as ma "+
                    " WHERE     (EXAM.ExamSession = '"+examsession+"') AND (EXAM.StreamCode = '"+StreamCode.SelectedValue+"') AND  (EXAM.StreamPartCode = '"+StreamPart.SelectedValue+"') ";

                      
        
       

        con.Open();
       // cmd.CommandText = " Delete From AdmitGra";
       // cmd.ExecuteNonQuery();
        cmd.CommandText = sql;
        reader = cmd.ExecuteReader();
        int count=0;
        // insert record in AdmitGra table
        string[] col = new string[19];
        string[] val = new string[19];
        string[] coltype = new string[19];
        for (int i = 0; i < 19; i++)
            coltype[i] = "0";
        coltype[3] = "1";
        col[0] = "RegNo";
        col[1] = "UnivRollNo";
        col[2] = "ApplicantName";
        col[3] = "HindiName";
        col[4] = "FatherName";
        col[5] = "CollCode";
        col[6] = "CollName";
        col[7] = "ClassRollNo";
        col[8] = "SubAbbr";
        col[9]="ExamType";
        col[10] = "ExamYear";
        col[11] = "StreamCode";
        col[12] = "StreamPartCode";
        col[13] = "Gender";
        col[14] = "SubCode";
        col[15] = "StreamAbbr";
        col[16] = "StreamPart";
        col[17] = "ExamSession";
        col[18] = "SemType";


        UnivService.Service1 ss = new UnivService.Service1();

        while (reader.Read ())
        {
            if (reader["UnivRollNo"].ToString() == "15B3074")
            {
                string sfind = "sbreak";
            }
            val[0] = reader["RegNo"].ToString();
            val[1] = reader["UnivRollNo"].ToString();
            val[2] = reader["ApplicantName"].ToString();
            val[3] = reader["HindiName"].ToString();
            val[4] = reader["FatherName"].ToString();
            val[5] = CollCode.SelectedValue;
            val[6] = CollCode.SelectedItem.Text.Trim();   
            val[7] = reader["ClassRollNo"].ToString();
            val[8] = reader["SubAbbr"].ToString();
            val[9] = reader["ExamType"].ToString();
            val[10] = Year.SelectedValue;
            val[11] = StreamCode.SelectedValue;
            val[12] = StreamPart.SelectedValue;
            val[13] = reader["Gender"].ToString();
            val[14] = reader["SubCode"].ToString();
            val[15] = reader["StreamAbbr"].ToString();
            val[16] = reader["StreamPart"].ToString();
            val[17] =reader["ExamSession"].ToString();
            val[18] = drpSemType.SelectedValue;
            sql= ss.SaveDataUniCode("AdmitGra", col, val, coltype);
             if(sql=="1")  count ++;                 
        }
        reader.Close();
         
        //----------------
        // Set Center Code in Admit Gra
        
        //sql = " Select ExamCentre.SubCode,ExamCentre.Gender,ExamCentre.ExamCollCode,College.CollName,College.Address1,College.Address2,"+
        //      " District.DistName,ExamCentre.ExamStartDate from ExamCentre,College,District "+
        //      " Where College.CollCode=ExamCentre.ExamCollCode and District.DistCode=College.DistCode"+
        //      " and ExamCentre.CollCode='" + CollCode.SelectedValue + "' and  ExamCentre.ExamYear='" + Year.SelectedValue + "' and ExamCentre.StreamCode='" + StreamCode.SelectedValue + "' and ExamCentre.StreamPartCode='" + StreamPart.SelectedValue + "'";

        // SELECT EXAM CENTRE FROM EXAM TABLE
        //sql = " Select Exam.regno,Exam.univrollno,Exam.SubCode,Exam.Gender,Exam.ExamCollCode,College.CollName,College.Address1,College.Address2," +
         //     " District.DistName,Exam.ExamStartDate from Exam,College,District " +
          //    " Where College.CollCode=Exam.ExamCollCode and District.DistCode=College.DistCode" +
           //   " and Exam.CollCode='" + CollCode.SelectedValue + "' and  Exam.ExamYear='" + Year.SelectedValue + "' and Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "' ";
               

        // changed - 20092010 - after exam centre modification...
        
              sql = " Select Exam.regno,Exam.univrollno,Exam.SubCode,Exam.Gender,Exam.ExamCollCode,ExamCollege.CollName,ExamCollege.Address1,ExamCollege.Address2," +
              " District.DistName,Exam.ExamStartDate from Exam,ExamCollege,District " +
              " Where ExamCollege.ExamCollCode=Exam.ExamCollCode and District.DistCode=ExamCollege.DistCode" +
              " and Exam.CollCode='" + CollCode.SelectedValue + "' and  Exam.ExamSession='" + examsession + "' and Exam.StreamCode='" + StreamCode.SelectedValue + "' and " + 
              " Exam.StreamPartCode='" + StreamPart.SelectedValue + "' and EXAM.ExamType='R' ";
        


        cmd.CommandText = sql;
        reader =cmd.ExecuteReader ();
        con1.Open();
        cmd.Connection = con1;
        while (reader.Read ())
        {
            string s = reader["Gender"].ToString();
            if (reader["Gender"].ToString() == "A")
            {
                sql = "Update AdmitGra set ExamCollCode='" + reader["ExamCollCode"].ToString() + "',ExamCollName='" + reader["CollName"].ToString() +
                    "',CentreAddress1='" + reader["Address1"].ToString() + "',CentreAddress2='" + reader["Address2"].ToString() +
                    "' ,DistName='" + reader["DistName"].ToString() +
                    "', ExamStartDate='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(reader["ExamStartDate"].ToString())) +
                    "', ExamSession='" + reader["ExamSession"].ToString() +
                    "' Where CollCode='" + CollCode.SelectedValue + "' and  ExamYear='" + Year.SelectedValue + "' and StreamCode='" + StreamCode.SelectedValue + "' and StreamPartCode='" + StreamPart.SelectedValue +
                    "' and subcode='" + reader["SubCode"].ToString() + "' and SemType='" + drpSemType.SelectedValue + "'";
                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();
            }
            else
            {
               
                //"', ExamStartDate='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(reader["ExamStartDate"].ToString())) +
                sql = "Update AdmitGra set ExamCollCode='" + reader["ExamCollCode"].ToString() + "',ExamCollName='" + reader["CollName"].ToString() +
                    "',CentreAddress1='" + reader["Address1"].ToString() + "',CentreAddress2='" + reader["Address2"].ToString() +
                    "' ,DistName='" + reader["DistName"].ToString() +
                   "' Where CollCode='" + CollCode.SelectedValue + "' and  ExamYear='" + Year.SelectedValue + "' and StreamCode='" + StreamCode.SelectedValue + "' and StreamPartCode='" + StreamPart.SelectedValue +
                    "' and subcode='" + reader["SubCode"].ToString() + "' And Gender='"+reader["Gender"].ToString () +
                    "' and regno='" + reader["regno"].ToString() + "' and  univrollno= '" + reader["univrollno"].ToString() + "' and SemType='" + drpSemType.SelectedValue + "' ";
                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();

            }
        }
        reader.Close();
        con1.Close();
        //push exampaper to AdmitGrapaper
        //

        try
        {
            cmd.Connection = con;
            // Clear AdmitGraPaper
            // cmd.CommandText = " Delete From AdmitGraPaper";
            // cmd.ExecuteNonQuery();
            //Composition

            // changes on 30th Sep 2010 ...
            //sql = "insert into AdmitGraPaper  select RegNo,UnivRollNo,StreamPartCode,ExamYear,SubPaperCode,Abbr,PaperType from ExamPaperDetail,Composition " +
            //" Where Composition.CompCode= RTrim(ExamPaperDetail.SubPaperCode) ";


            //sql = "insert into AdmitGraPaper  select RegNo,UnivRollNo,StreamPartCode,ExamYear,SubPaperCode,Abbr,PaperType from ExamPaperDetail,Composition " +
            //       " Where Composition.CompCode= RTrim(ExamPaperDetail.SubPaperCode)  and ExamPaperDetail.ExamYear= '" + Year.SelectedValue.ToString() + "' and ExamPaperDetail.StreamPartCode='" + StreamPart.SelectedValue.ToString() + "' and regno in (select regno from ADMITGRA where ExamYear= '" + Year.SelectedValue.ToString() + "' and StreamPartCode='" + StreamPart.SelectedValue.ToString() + "') ";

            
            //cmd.CommandText = sql;
            //cmd.ExecuteNonQuery();
            //Honours
            //sql = "insert into AdmitGraPaper  select RegNo,UnivRollNo,ExamPaperDetail.StreamPartCode,ExamYear,ExamPaperDetail.SubPaperCode,PaperAbbr,PaperType from ExamPaperDetail,CoursePapers " +
            //"Where CoursePapers.SubPaperCode= RTrim(ExamPaperDetail.SubPaperCode) And ExamPaperDetail.PaperType<>'P' ";
            
            //sql = "insert into AdmitGraPaper  select RegNo,UnivRollNo,ExamPaperDetail.StreamPartCode,ExamYear,ExamPaperDetail.SubPaperCode,PaperAbbr,PaperType from ExamPaperDetail,CoursePapers " +
            //      "Where CoursePapers.SubPaperCode= RTrim(ExamPaperDetail.SubPaperCode) And ExamPaperDetail.PaperType<>'P' and ExamPaperDetail.ExamYear= '" + Year.SelectedValue.ToString() + "' and ExamPaperDetail.StreamPartCode='" + StreamPart.SelectedValue.ToString() + "'  and regno in (select regno from ADMITGRA where ExamYear= '" + Year.SelectedValue.ToString() + "' and StreamPartCode='" + StreamPart.SelectedValue.ToString() + "') ";
            string str1="";

           if (drpSemType.SelectedValue=="Mid Sem")
               str1=" (EXAMPAPERDETAIL.ExamType in ('R','B'))";
           else
               str1=" ((Attendance.status='P' AND EXAMPAPERDETAIL.ExamType!='N') OR (EXAMPAPERDETAIL.ExamType='N'))";
               
            sql = "insert into AdmitGraPaper(RegNo,UnivRollNo,StreamPartCode,ExamYear,SubPaperCode,PaperAbbr,PaperType,SemType,ExamSession) SELECT     EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, " +
                    " EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, EXAMPAPERDETAIL.SubPaperCode, COURSEPAPERS.PaperAbbr, EXAMPAPERDETAIL.PaperType, '"+drpSemType.SelectedValue+"' AS semtype, EXAMPAPERDETAIL.ExamSession " +
                    " FROM         EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN " +
                    " Attendance ON EXAMPAPERDETAIL.RegNo = Attendance.RegNo AND EXAMPAPERDETAIL.SubPaperCode = Attendance.SubPaperCode and EXAMPAPERDETAIL.ExamSession = Attendance.ExamSession " +
                    " WHERE     (EXAMPAPERDETAIL.RegNo IN (SELECT RegNo FROM ADMITGRA  WHERE (ExamSession = '" + examsession + "') AND (StreamPartCode = '" + StreamPart.SelectedValue + "')))" +
                " AND (EXAMPAPERDETAIL.ExamSession = '" + examsession + "') AND " + str1;
            cmd.CommandText = sql;
            cmd.ExecuteNonQuery();

            // Process For update ExamDate in Admitgrapaper-----------

            DataTable dtexampaperdate = new DataTable();
            dtexampaperdate.Columns.Add("Course", typeof(string));
            dtexampaperdate.Columns.Add("Date", typeof(string));
            DataRow dr;
            
            DataSet dsexampaper = fnrev.SelectDataset("SELECT PaperAbbr, ExamDate FROM AddExamSchedule  Where " +
                    "  StreamPartCode ='" + StreamPart.SelectedValue + "' and PROGRAM ='" + StreamCode.SelectedItem + "' AND " +
                    " ExamSession='" + examsession + "' and SemType='" + drpSemType.SelectedItem.ToString() + "' ");
            for (int j = 0; j <= dsexampaper.Tables[0].Rows.Count - 1; j++)
            {
                dr = dtexampaperdate.NewRow();
                dr[0] = dsexampaper.Tables[0].Rows[j]["PaperAbbr"].ToString();
                dr[1] = dsexampaper.Tables[0].Rows[j]["ExamDate"].ToString();
                dtexampaperdate.Rows.Add(dr);
            }
            string course1;
            DataRow[] paperdate;
            int InsRec;
            DataSet dsadmitgrapaper = fnrev.SelectDataset("Select DISTINCT PaperAbbr From AdmitGraPaper Where StreamPartCode = '" + StreamPart.SelectedValue + "' and ExamSession ='" + examsession + "'");
            for (int i = 0; i <=dsadmitgrapaper.Tables[0].Rows.Count - 1; i++)
            {
                course1 = dsadmitgrapaper.Tables[0].Rows[i]["PaperAbbr"].ToString();
                paperdate = dtexampaperdate.Select("Course = '" + course1 + "'");
                if (paperdate.Length > 0)
                {
                    InsRec = fnrev.InsertUpdateDelete("Update AdmitGraPaper set examdate = '" + paperdate[0]["Date"] + "' Where " +
                        " StreamPartCode ='" + StreamPart.SelectedValue + "' AND ExamSession ='" + examsession + "' AND " +
                        " PaperAbbr = '" + course1 + "' and SemType='" + drpSemType.SelectedItem.ToString() + "'");
                }
                
            }
                // Subsidiary 
                //sql = "insert into AdmitGraPaper  select RegNo,UnivRollNo,StreamPartCode,ExamYear,SubPaperCode,SubAbbr,PaperType " +
                //" from ExamPaperDetail,Subject Where Subject.SubCode= RTrim(ExamPaperDetail.SubPaperCode) And ExamPaperDetail.PaperType<>'P'";

                //sql = "insert into AdmitGraPaper  select RegNo,UnivRollNo,StreamPartCode,ExamYear,SubPaperCode,SubAbbr,PaperType " +
                //      " from ExamPaperDetail,Subject Where Subject.SubCode= RTrim(ExamPaperDetail.SubPaperCode) And ExamPaperDetail.PaperType<>'P' and ExamPaperDetail.ExamYear= '" + Year.SelectedValue.ToString() + "' and ExamPaperDetail.StreamPartCode='" + StreamPart.SelectedValue.ToString() + "' and regno in (select regno from ADMITGRA where ExamYear= '" + Year.SelectedValue.ToString() + "' and StreamPartCode='" + StreamPart.SelectedValue.ToString() + "') ";

                //cmd.CommandText = sql;
                //cmd.ExecuteNonQuery();


                con.Close();
        }
        catch(Exception ex)
        {
            string popupScript1 = "<script language='javascript'>" +
                        " alert('" + ex.Message + "')" +
                        "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript1);
            return;

        }

        //
        string popupScript = "<script language='javascript'>" +
                                " alert('" + count + " Admit Cards Generated ')" +
                                "</script>";
        Page.RegisterStartupScript("PopupScript", popupScript);

       
       
          

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string examsession = month1.SelectedItem.ToString() + "-" + month2.SelectedItem.ToString() + "_" + Year3.SelectedItem.ToString();    
        Panel1.Visible = true;
        CR.ReportSource = crs;
        CR.SelectionFormula = @"{AdmitGra.streamabbr}='" + StreamCode.SelectedItem + "' and {AdmitGra.streampart}='" + StreamPart.SelectedItem + "' and {AdmitGra.ExamSession}='" + examsession + "' ";
        CR.RefreshReport();
    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }

    protected void month1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (month1.SelectedIndex == 1)
        {
            month2.SelectedIndex = 1;
        }
        else if (month1.SelectedIndex == 2)
        {
            month2.SelectedIndex = 2;
        }
        else
        {
            month2.SelectedIndex = 0;
        }


    }
}
