using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.Shared;
using CrystalDecisions.CrystalReports;
using CrystalDecisions.CrystalReports.Engine;

public partial class student_certificate : System.Web.UI.Page
{
    ReportDocument crystalReport = new ReportDocument();
    Functionreviseed fnrev = new Functionreviseed();
    dsbonafied _dsbonafied = new dsbonafied();
    dscharacter _dscharacter = new dscharacter();
    DataTable dtbonafied = new DataTable();
    DsMigration _dsMigration = new DsMigration();

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "10") && (Session["Role"].ToString() != "14"))
            {
                Session["userName"] = null;
                FormsAuthentication.SignOut();
                Response.Redirect("default.aspx?error=RoleNotFoundException");
            }
        }
        catch
        {
            Response.Redirect("default.aspx?error=RoleNotFoundException");
        }

        
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        binddetails();
       
    }

    string querypart = "";
    private void binddetails()
    {
        if (rdbcriteria.SelectedIndex == 0)
        {
            querypart = " cgpa.UnivRollNo = '" + txtinput.Text.Trim() + "'";
        }
        else if (rdbcriteria.SelectedIndex == 1)
        {
            querypart = " REGISTRATION.AckNo = '" + txtinput.Text.Trim() + "'";
        }
        DataSet dsstudentdetails = fnrev.SelectDataset("SELECT ROUND(CASE WHEN SUM(Credit) = SUM(ER_CREDIT) THEN " +
            " SUM(CONVERT(float, Grade_Point)) / SUM(CONVERT(float, ER_CREDIT)) ELSE NULL END, 2) AS CGPA, CASE WHEN SUM(Credit) = SUM(ER_CREDIT) " +
            " THEN 'P' ELSE 'F' END AS Status, REGISTRATION.AckNo, cgpa.UnivRollNo, REGISTRATION.ApplicantName,STREAM.Stream, STREAM.StreamAbbr, " +
            " STREAM.Duration, REGISTRATION.FatherName FROM cgpa INNER JOIN REGISTRATION ON cgpa.UnivRollNo = REGISTRATION.TempRollNo AND cgpa.RegNo = REGISTRATION.RegNo INNER JOIN " +
            " STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode GROUP BY REGISTRATION.AckNo,REGISTRATION.FatherName, cgpa.UnivRollNo, REGISTRATION.ApplicantName, STREAM.Stream, " +
            " STREAM.StreamAbbr, STREAM.Duration HAVING " + querypart);
        if (dsstudentdetails.Tables[0].Rows.Count > 0)
        {
            txtcandidate.Text = dsstudentdetails.Tables[0].Rows[0]["ApplicantName"].ToString();
            txtroll.Text = dsstudentdetails.Tables[0].Rows[0]["UnivRollNo"].ToString();
            txtenrollno.Text = dsstudentdetails.Tables[0].Rows[0]["AckNo"].ToString();
            txtdegree.Text = dsstudentdetails.Tables[0].Rows[0]["StreamAbbr"].ToString() + " (" + dsstudentdetails.Tables[0].Rows[0]["Stream"].ToString() + ")";
            txtstreamabbr.Text = dsstudentdetails.Tables[0].Rows[0]["StreamAbbr"].ToString();
            txtfather.Text = dsstudentdetails.Tables[0].Rows[0]["FatherName"].ToString();
            txtduration.Text = dsstudentdetails.Tables[0].Rows[0]["Duration"].ToString() + " Yrs.";
            txtinstitute.Text = "NIT Patna";
           
            txtcgpa.Text = dsstudentdetails.Tables[0].Rows[0]["CGPA"].ToString() == "" ? "Null" : dsstudentdetails.Tables[0].Rows[0]["CGPA"].ToString();
            txtstatus.Text = dsstudentdetails.Tables[0].Rows[0]["Status"].ToString() == "F" ? "Fail" : "Pass";
        }
        DataSet dspassyear = fnrev.SelectDataset("SELECT Top(1) REGISTRATION.RegYear + ' - ' + SUBSTRING(cgpa.ExamSession, 9, 4) as studyduration , " +
            " SUBSTRING(cgpa.ExamSession, 9, 4) as Passingyear,cgpa.semno FROM cgpa INNER JOIN REGISTRATION ON cgpa.RegNo = REGISTRATION.RegNo AND " +
            " cgpa.UnivRollNo = REGISTRATION.TempRollNo WHERE " + querypart + " ORDER BY CAST(SUBSTRING(cgpa.ExamSession, 5, 3) + " +
            " SUBSTRING(cgpa.ExamSession, 9, 4) AS DATETIME) DESC");
        if (dspassyear.Tables[0].Rows.Count > 0)
        {
            txtstudy.Text = dspassyear.Tables[0].Rows[0]["studyduration"].ToString();
            txtpassing.Text = dspassyear.Tables[0].Rows[0]["Passingyear"].ToString();
            txtsemester.Text = dspassyear.Tables[0].Rows[0]["semno"].ToString();
        }

        DataSet dspercent = fnrev.SelectDataset("SELECT ROUND(SUM(CONVERT(float, cgpa.Total_PMO) * (CONVERT(float, b.FullMarks) + CONVERT(float, " + 
            " ISNULL(c.FullMarks, 0))) / 100) * 100 / SUM(CONVERT(float, b.FullMarks) + CONVERT(float, ISNULL(c.FullMarks, 0))), 2) AS PercentObtained, " + 
            " REGISTRATION.AckNo FROM cgpa  INNER JOIN COURSEPAPERS AS b ON cgpa.SubPaperCode = b.SubPaperCode INNER JOIN REGISTRATION ON " + 
            " cgpa.UnivRollNo = REGISTRATION.TempRollNo AND cgpa.RegNo = REGISTRATION.RegNo LEFT OUTER JOIN PRACTICALPAPERS AS c ON " + 
            " b.SubPaperCode = c.SubPaperCode WHERE " + querypart + " GROUP BY REGISTRATION.AckNo");
        if (dspercent.Tables[0].Rows.Count > 0)
        {
            txtcgpa.Text = txtcgpa.Text.Trim() + " / " + dspercent.Tables[0].Rows[0]["PercentObtained"].ToString();
        }
    }

    string branch = "";
    private void branchbind()
    {
        if (txtstreamabbr.Text == "B.Arch")
        {
            branch = "Architecture";
        }
        else if (txtstreamabbr.Text == "B.Tech-CSE")
        {
            branch = "Computer Science & Engineering";
        }
        else if (txtstreamabbr.Text == "B.Tech-IT")
        {
            branch = "Information Technology";
        }
        else if (txtstreamabbr.Text == "B.Tech-ECE")
        {
            branch = "Electronics & Comm. Engineering";
        }
        else if (txtstreamabbr.Text == "B.Tech-CE")
        {
            branch = "Civil Engineering";
        }
        else if (txtstreamabbr.Text == "B.Tech-EE")
        {
            branch = "Electrical Engineering";
        }
        else if (txtstreamabbr.Text == "B.Tech-ME")
        {
            branch = "Mechanical Engineering";
        } 
    }
    protected void btnprint_Click(object sender, EventArgs e)
    {
        int saverec = 0;
        if (rdbcertificate.SelectedValue.ToString() == "Bonafied")
        {
            dtbonafied.Columns.Add("RefNo");
            dtbonafied.Columns.Add("Ename");
            dtbonafied.Columns.Add("RollNo");
            dtbonafied.Columns.Add("Fathername");
            dtbonafied.Columns.Add("Program");
            dtbonafied.Columns.Add("Semester");
            dtbonafied.Columns.Add("Branch");
            dtbonafied.Columns.Add("CourseSession");
            branchbind();
            // Code for Keep records in db ----
            string refId = "",semcode = "";
            if (txtsemester.Text.Trim() == "1")
                semcode = "1st";
            else if (txtsemester.Text.Trim() == "2")
                semcode = txtsemester.Text.Trim().ToString() + "nd";
            else if (txtsemester.Text.Trim() == "3")
                semcode = txtsemester.Text.Trim().ToString() + "rd";
            else
                semcode = txtsemester.Text.Trim().ToString() + "th";

            object prevrefno = fnrev.singlevalue("SELECT RefNo FROM BonafiedCertificates WHERE RollNo = '" + txtroll.Text.Trim() + "' and Semester = '" + semcode + "' order by GenTime DESC");
            if (prevrefno == null)
            {                
                    string maxid = fnrev.singlevalue("SELECT ISNULL(MAX(ID),1) AS maxId FROM BonafiedCertificates").ToString();
                    if (maxid.Length == 1)
                    {
                        refId = "NITP/BC/" + DateTime.Now.Year.ToString().Substring(2, 2) + "/00" + maxid;
                    }
                    else if (maxid.Length == 2)
                    {
                        refId = "NITP/BC/" + DateTime.Now.Year.ToString().Substring(2, 2) + "/0" + maxid;
                    }
                    else
                        refId = "NITP/BC/" + DateTime.Now.Year.ToString().Substring(2, 2) + "/" + maxid;

                    saverec = fnrev.InsertUpdateDelete("INSERT INTO BonafiedCertificates (RefNo, RollNo, Semester, UserId, GenTime) VALUES " +
                        " ('" + refId + "','" + txtroll.Text.Trim() + "','" + semcode + "','" + Session["UserId"].ToString() + "',GETDATE())");
                
            }
            else
            {
                refId = prevrefno.ToString();
                saverec = 1;
            }

            //----Code Close -------

            if (saverec != 0)
            {
                dtbonafied.Rows.Add(refId, txtcandidate.Text.Trim(), txtroll.Text.Trim(), txtfather.Text, txtstreamabbr.Text, semcode, branch, txtstudy.Text.Trim());
                _dsbonafied.Tables[0].Merge(dtbonafied);

                crystalReport.Load(Server.MapPath("~/Report/rptbonafied.rpt"));
                // dsconsomarks objdsconsomarks = GetData(Query1);
                crystalReport.SetDataSource(_dsbonafied);
                crystalReport.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, false, "ExportedReport");
            }
            else
            {
                lblmsg.Text = "Failed to generate Bonafied Certificate.";
            }

        }
        else if (rdbcertificate.SelectedValue.ToString() == "Character")
        {
            dtbonafied.Columns.Add("RefNo");
            dtbonafied.Columns.Add("Ename");
            dtbonafied.Columns.Add("FatherName");
            dtbonafied.Columns.Add("RollNo");
            dtbonafied.Columns.Add("EnrollNo");
            dtbonafied.Columns.Add("Program");
            dtbonafied.Columns.Add("duration");
            dtbonafied.Columns.Add("Branch");
            dtbonafied.Columns.Add("Period");
            
            branchbind();

            // Code for Keep records in db ----
            string refId = "", semcode = "";
            if (txtsemester.Text.Trim() == "1")
                semcode = "1st";
            else if (txtsemester.Text.Trim() == "2")
                semcode = txtsemester.Text.Trim().ToString() + "nd";
            else if (txtsemester.Text.Trim() == "3")
                semcode = txtsemester.Text.Trim().ToString() + "rd";
            else
                semcode = txtsemester.Text.Trim().ToString() + "th";

            object prevrefno = fnrev.singlevalue("SELECT RefNo FROM CharacterCertificates WHERE RollNo = '" + txtroll.Text.Trim() + "' order by GenTime DESC");
            if (prevrefno == null)
            {
                string maxid = fnrev.singlevalue("SELECT ISNULL(MAX(ID),1) AS maxId FROM CharacterCertificates").ToString();
                if (maxid.Length == 1)
                {
                    refId = "NITP/CC/" + DateTime.Now.Year.ToString().Substring(2, 2) + "/00" + maxid;
                }
                else if (maxid.Length == 2)
                {
                    refId = "NITP/CC/" + DateTime.Now.Year.ToString().Substring(2, 2) + "/0" + maxid;
                }
                else
                    refId = "NITP/CC/" + DateTime.Now.Year.ToString().Substring(2, 2) + "/" + maxid;

                saverec = fnrev.InsertUpdateDelete("INSERT INTO CharacterCertificates (RefNo, RollNo, UserID, GenTime) VALUES " +
                    " ('" + refId + "','" + txtroll.Text.Trim() + "','" + Session["UserId"].ToString() + "',GETDATE())");
            }
            else
            {
                refId = prevrefno.ToString();
                saverec = 1;
            }

            if (saverec != 0)
            {
                dtbonafied.Rows.Add(refId, txtcandidate.Text.Trim(), txtfather.Text, txtroll.Text.Trim(), txtenrollno.Text, txtstreamabbr.Text, txtduration.Text.Trim(), branch, txtstudy.Text);
                _dscharacter.Tables[0].Merge(dtbonafied);

                crystalReport.Load(Server.MapPath("~/Report/rptcharacter.rpt"));
                // dsconsomarks objdsconsomarks = GetData(Query1);
                crystalReport.SetDataSource(_dscharacter);
                crystalReport.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, false, "ExportedReport");
            }

        }
        else if (rdbcertificate.SelectedValue.ToString() == "NOC")
        {
 
        }
        else if (rdbcertificate.SelectedValue.ToString() == "Leaving")
        {
            string refId = "";
            dtbonafied.Columns.Add("Refno");
            dtbonafied.Columns.Add("Ename");
            dtbonafied.Columns.Add("FatherName");
            dtbonafied.Columns.Add("RollNo");
            dtbonafied.Columns.Add("EnrollNo");
            dtbonafied.Columns.Add("dateofadmission");
            dtbonafied.Columns.Add("Program");
            dtbonafied.Columns.Add("Branch");
            dtbonafied.Columns.Add("Period");
            dtbonafied.Columns.Add("Candidaturestatus");
            dtbonafied.Columns.Add("LeavingReason");
            dtbonafied.Columns.Add("Conduct");

            branchbind();





            object prevrefno = fnrev.singlevalue("SELECT RefNo FROM MigrationCertificate WHERE RollNo = '" + txtroll.Text.Trim() + "' order by GenTime DESC");
            if (prevrefno == null)
            {
                string maxid = fnrev.singlevalue("SELECT ISNULL(MAX(ID),1) AS maxID FROM MigrationCertificate").ToString();
                if (maxid.Length == 1)
                {
                    refId = "NITP/IL/" + DateTime.Now.Year.ToString().Substring(2, 2) + "/00" + maxid;
                }
                else if (maxid.Length == 2)
                {
                    refId = "NITP/IL/" + DateTime.Now.Year.ToString().Substring(2, 2) + "/0" + maxid;
                }
                else
                    refId = "NITP/IL/" + DateTime.Now.Year.ToString().Substring(2, 2) + "/" + maxid;

                saverec = fnrev.InsertUpdateDelete("INSERT INTO MigrationCertificate (RefNo, RollNo, UserID, GenTime) VALUES " +
                      " ('" + refId + "','" + txtroll.Text.Trim() + "','" + Session["UserId"].ToString() + "',GETDATE())");

            }
            else
            {
                refId = prevrefno.ToString();
                saverec = 1;
            }




            if (saverec != 0)
            {







                dtbonafied.Rows.Add(refId, txtcandidate.Text.Trim(), txtfather.Text, txtroll.Text.Trim(), txtenrollno.Text, "", txtstreamabbr.Text, branch, txtstudy.Text, txtstatuscon.Text.Trim().ToString(), txtleave.Text.Trim().ToString(), txtconduct.Text.Trim().ToString());
                _dsMigration.Tables[0].Merge(dtbonafied);
                //, txtconduct.Text.Trim().ToString()
                crystalReport.Load(Server.MapPath("~/Report/rptMigration.rpt"));

                // crystalReport.SetParameterValue("statuscandidate",txtstatuscon.Text.Trim());
                // dsconsomarks objdsconsomarks = GetData(Query1);
                crystalReport.SetDataSource(_dsMigration);
                crystalReport.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, false, "ExportedReport");
            }
        }
    }
    protected void rdbcertificate_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
