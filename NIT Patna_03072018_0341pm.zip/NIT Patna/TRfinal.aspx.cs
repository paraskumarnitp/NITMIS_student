using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class TRfinal : System.Web.UI.Page
{
    Functionreviseed dut = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //Panel1.Visible = true;
            try
            {
                if ((Session["Role"].ToString() != "2") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(ExamYear, "Exam", "select distinct a.ExamSession from ( SELECT StreamCode, StreamPart, ExamSession FROM TRBTec GROUP BY StreamCode, StreamPart, ExamSession except select StreamCode, StreamPartCode, ExamSession from TRfreeze)a order by ExamSession", "ExamSession", "ExamSession");
            ExamYear.Items.Insert(0, new ListItem("--Select--", "00"));
            StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
            StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        }
    }

  

    protected void BtnGenerate_Click(object sender, EventArgs e)
    {
        try
        {
            string insertquery = "INSERT INTO TRfreeze " +
                                 " (StreamCode, StreamPartCode, ExamSession, UserId) " +
                                 " VALUES     ('" + StreamCode.SelectedValue + "','" + StreamPart.SelectedValue + "','" + ExamYear.SelectedItem + "','" + Session["UserId"].ToString() +"') ";

            int i = dut.InsertUpdateDelete(insertquery);
            if (i > 0)
                LblMsg.Text = "Successfully Updated";
            else
                LblMsg.Text = "Re-try Again";
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        StreamPart.Items.Clear();
        string strstreampart = "select distinct a.StreamPartCode,STREAMPART.StreamPart " +
                                " from ( SELECT     StreamCode, StreamPart AS StreamPartCode, ExamSession " +
                                " FROM         TRBTec GROUP BY StreamCode, StreamPart, ExamSession " +
                                " having ExamSession='" + ExamYear.SelectedItem + "' and StreamCode='" + StreamCode.SelectedValue + "' except " +
                                " select StreamCode, StreamPartCode, ExamSession " +
                                " from TRfreeze)a inner join STREAMPART on " +
                                " a.StreamPartCode=STREAMPART.StreamPartCode order by STREAMPART.StreamPart ";
        DataTable dt = dut.SelectDatatable(strstreampart);
        StreamPart.DataSource = dt;
        StreamPart.DataTextField = "StreamPart";
        StreamPart.DataValueField = "StreamPartCode";
        StreamPart.DataBind();
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        LblMsg.Text = "";
    }
    protected void ExamYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        StreamCode.Items.Clear();
        string strstream = "select distinct a.StreamCode,STREAM.StreamAbbr "+
                            " from ( SELECT     StreamCode, StreamPart, ExamSession " +
                            " FROM         TRBTec GROUP BY StreamCode, StreamPart, ExamSession " +
                            " having ExamSession='" + ExamYear.SelectedItem + "' " +
                            " except select StreamCode, StreamPartCode, ExamSession " +
                            " from TRfreeze)a inner join STREAM on a.StreamCode=STREAM.StreamCode "+
                            " order by STREAM.StreamAbbr ";
        DataTable dt = dut.SelectDatatable(strstream);
        StreamCode.DataSource = dt;
        StreamCode.DataTextField="StreamAbbr";
        StreamCode.DataValueField = "StreamCode";
        StreamCode.DataBind();
        StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
    }
}
