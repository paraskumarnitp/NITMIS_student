using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class CentreAllotment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            
            // need to be changed by 
            //popddl.Popualate(ExamCollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");

            popddl.Popualate(ExamCollCode, "ExamCollege", "Select CollName,ExamCollCode from ExamCollege order by CollName", "CollName", "ExamCollCode");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            ExamYear.Text = System.DateTime.Now.Year.ToString ();
            ViewState.Add ("Alloted","");
            BindGrid();
            //ExamCentreCheckCapacity();
        }

    }
    protected void BtnSave_Click(object sender, EventArgs e)
    {
        LblMsg.Text = "";
        if ((int.Parse(TotStudent.Text)) != (int.Parse(TotalStu.Text)))
        {
            string msg = " Please Verify no of students for Centre Allotment.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            LblMsg.Text = msg;
            return;
            
            
        }
      
        //else if(int.Parse (AvailableCapacity.Text )<=0 )
        //{
        //    LblMsg.Text = "Please check available capacity ";
        //    return;
        //}
        else
        SaveCentreAllotment();
        BindGrid();
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
       
            popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
            popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
       

    }
    protected void StreamCode_TextChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
       
            popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
            popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        

    }

    protected void SaveCentreAllotment()
    {

        try
        {
            SqlConnection con1 = new SqlConnection();
            SqlConnection con2 = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            
            SqlDataReader reader;
            con1.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            con2.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            string sql = "",sex="",centercode="";
            int tot=0;
            sql = "Update Exam set examcollcode=NULL where CollCode='" + CollCode.SelectedValue + "' and ExamYear='" + ExamYear.Text.Trim() + "' AND  StreamCode='" + StreamCode.SelectedValue.ToString() + "' AND  StreamPartCode='" + StreamPart.SelectedValue.ToString() + "' AND SubCode='" + SubCode.SelectedValue.ToString() + "'";
           
            cmd.CommandText = sql;
            cmd.Connection = con1;
            con1.Open();
            cmd.ExecuteNonQuery();
            con1.Close();
            int TotalAllot = 0;

            for (int i = 0; i < CentreList.Items.Count; i++)
            {
                centercode = CentreList.Items[i].Text.Substring(0, 3);
                sex = NoOfStuList.Items[i].Text.Substring(0, 1);
                tot = int.Parse(NoOfStuList.Items[i].Text.Substring(2));
                if (sex == "A")
                {
                    sql = "select UnivRollNo  from Exam where CollCode='" + CollCode.SelectedValue + "' and ExamYear='" + ExamYear.Text.Trim() + "' AND  StreamCode='" + StreamCode.SelectedValue.ToString() + "' AND  StreamPartCode='" + StreamPart.SelectedValue.ToString() + "' AND SubCode='" + SubCode.SelectedValue.ToString() + "' and (ExamCollCode is NULL or ExamCollCode='') and univrollno is not null order by newid()";
                }
                else
                {
                    sql = "select UnivRollNo  from Exam where CollCode='" + CollCode.SelectedValue + "' and  ExamYear='" + ExamYear.Text.Trim() + "' AND  StreamCode='" + StreamCode.SelectedValue.ToString() + "' AND  StreamPartCode='" + StreamPart.SelectedValue.ToString() + "' AND SubCode='" + SubCode.SelectedValue.ToString() + "' And Gender='" + sex + "' and (ExamCollCode is NULL or ExamCollCode='') and univrollno is not null order by newid()";
                }
                cmd.CommandText = sql;
                cmd.Connection = con1;
                con1.Open();
                reader = cmd.ExecuteReader();
                cmd.Connection = con2;
                con2.Open();
                while (reader.Read() && tot > 0)
                {

                    cmd.CommandText = " update Exam Set ExamCollCode='" + centercode + "' ,ExamStartDate='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(ExamStartDate.Text.Trim())) +
                                  "' where  UnivRollNo='" + reader["UnivRollNo"].ToString() + "' And  ExamYear='" + ExamYear.Text.Trim() +
                                  "' AND  StreamPartCode='" + StreamPart.SelectedValue.ToString() + "'";
                    cmd.ExecuteNonQuery();
                    tot--;
                    TotalAllot++;
                }
                reader.Close();
                con2.Close();
                con1.Close();
            }
            string msg = " Centre Alloted for "+TotalAllot +" Students ";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            LblMsg.Text = msg;
            CentreList.Items.Clear();
            NoOfStuList.Items.Clear();
            TotStudent.Text = "0"; 

        

        }
        
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }


    }
    protected void BtnChk_Click(object sender, EventArgs e)
    {
        CheckCentreAllotment();
       
    }

    protected void CheckCentreAllotment()
    {
        SqlConnection con = new SqlConnection();
        SqlDataReader rd;
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.Connection = con;
        string sex = "";
        Label1.Text = "";
        ViewState.Add("Alloted", ""); 
        if (GenderM.Checked)
        {
            sex = "M";
            cmd.CommandText = "select RegNo from Exam where ExamYear='" + ExamYear.Text.Trim() + "' AND  StreamCode='" + StreamCode.SelectedValue.ToString() + "' AND  StreamPartCode='" + StreamPart.SelectedValue.ToString() + "' AND SubCode='" + SubCode.SelectedValue.ToString() + "' and (ExamCollCode is NULL or ExamCollCode='') And Gender='M' and collcode='" + CollCode.SelectedValue + "'  and univrollno is not null";
        }
        else if (GenderF.Checked)
        {
            sex = "F";
            cmd.CommandText = "select RegNo from Exam where ExamYear='" + ExamYear.Text.Trim() + "' AND  StreamCode='" + StreamCode.SelectedValue.ToString() + "' AND  StreamPartCode='" + StreamPart.SelectedValue.ToString() + "' AND SubCode='" + SubCode.SelectedValue.ToString() + "' and (ExamCollCode is NULL or ExamCollCode='') And Gender='F' and collcode='" + CollCode.SelectedValue + "' and univrollno is not null";
        }
        else
        {
            sex = "A";
            cmd.CommandText = "select RegNo from Exam where ExamYear='" + ExamYear.Text.Trim() + "' AND  StreamCode='" + StreamCode.SelectedValue.ToString() + "' AND  StreamPartCode='" + StreamPart.SelectedValue.ToString() + "' AND SubCode='" + SubCode.SelectedValue.ToString() + "' and (ExamCollCode is NULL or ExamCollCode='') and collcode='" + CollCode.SelectedValue + "' and univrollno is not null";
        }

        con.Open();
        rd = cmd.ExecuteReader();
        if (rd.HasRows==false )
        {
            rd.Read();
            string msg = "Centre is already alloted. ";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            Label1.Text = msg.ToString();
            rd.Close();
            ViewState.Add("Alloted", "true");
           // con.Close();


          //  return;
        }
     //   else
        {

            rd.Close();
            cmd.CommandText = "SELECT     count(gender) FROM    Exam where ExamYear='" + ExamYear.Text + "' AND  StreamCode='" + StreamCode.SelectedValue + "'  AND  StreamPartCode='" + StreamPart.SelectedValue + "' AND SubCode='" + SubCode.SelectedValue + "' and collcode='" + CollCode.SelectedValue + "' and univrollno is not null group by gender having gender='M' ";
            rd = cmd.ExecuteReader();
            int m = 0;
            if (rd.HasRows)
            {
                rd.Read();
                if (rd[0] != "") m = int.Parse(rd[0].ToString());
            }
            rd.Close();

            cmd.CommandText = "SELECT     count(gender) FROM    Exam where ExamYear='" + ExamYear.Text + "' AND  StreamCode='" + StreamCode.SelectedValue + "'  AND  StreamPartCode='" + StreamPart.SelectedValue + "' AND SubCode='" + SubCode.SelectedValue + "' and collcode='" + CollCode.SelectedValue + "' and univrollno is not null group by gender having gender='F'";
            rd = cmd.ExecuteReader();
            int f = 0;
            if (rd.HasRows)
            {
                rd.Read();
                if (rd[0] != "") f = int.Parse(rd[0].ToString());
            }
             Label1.Text += " Tot. Student= " + (m + f)+ "  (Male = "+ m +" , Female = "+f+")";
             if (GenderM.Checked)
                 NoOfStudents.Text = m.ToString();
             else if (GenderF.Checked)
                 NoOfStudents.Text  = f.ToString();
             else
                 NoOfStudents.Text = (m + f) + "";
             NoOfAllot.Text = NoOfStudents.Text;
             TotalStu.Text = (m + f) + ""; 
        }
        con.Close();
    }

    protected void ExamCollCode_SelectedIndexChanged(object sender, EventArgs e)
    {

        ExamCode.Text = ExamCollCode.SelectedValue.ToString();
        ExamCentreCheckCapacity();        
    }

    void BindGrid()
    {
       
        DataSet ds = new DataSet();
        //string sql = "SELECT     COLLEGE.CollName, EXAMCENTRE.ExamYear, STREAM.StreamAbbr, STREAMPART.StreamPart, SUBJECT.SubAbbr, " +
        //              "EXAMCENTRE.Gender, EXAMCENTRE.NoOfStudents, EXAMCENTRE.ExamStartDate, COLLEGE_1.CollName AS Centre FROM " +
        //              "EXAMCENTRE INNER JOIN  COLLEGE ON EXAMCENTRE.CollCode = COLLEGE.CollCode INNER JOIN " +
        //              "STREAM ON EXAMCENTRE.StreamCode = STREAM.StreamCode INNER JOIN " +
        //              "STREAMPART ON EXAMCENTRE.StreamCode = STREAMPART.StreamCode AND " +
        //              "EXAMCENTRE.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN " +
        //              "SUBJECT ON EXAMCENTRE.SubCode = SUBJECT.SubCode INNER JOIN " +
        //              "COLLEGE AS COLLEGE_1 ON EXAMCENTRE.ExamCollCode = COLLEGE_1.CollCode  ORDER BY dbo.COLLEGE.CollName";



        string sql = "SELECT COLLEGE.CollName, EXAM.ExamYear,STREAM.StreamAbbr,STREAMPART.StreamPart," +
                   "SUBJECT.SubAbbr,Exam.gender,EXAM.ExamStartDate,C.Collname as Centre," +
                   "Count(*) as NoOfStudents FROM EXAM " +
                   "INNER JOIN COLLEGE ON EXAM.CollCode = COLLEGE.CollCode" +
                   " INNER JOIN STREAM ON EXAM.StreamCode = STREAM.StreamCode" +
                   " INNER JOIN STREAMPART ON EXAM.StreamCode = STREAMPART.StreamCode AND EXAM.StreamPartCode = STREAMPART.StreamPartCode" +
                   " INNER JOIN SUBJECT ON EXAM.SubCode = SUBJECT.SubCode" +
                   " left outer JOIN COLLEGE C ON EXAM.ExamCollCode = C.CollCode " +
                   "GROUP BY Exam.gender,COLLEGE.CollName, EXAM.ExamYear, STREAM.StreamAbbr, STREAMPART.StreamPart, SUBJECT.SubAbbr," +
                  "EXAM.ExamStartDate, C.collname having EXAM.ExamYear>='" + (int.Parse(ExamYear.Text) - 1) + "' And COLLEGE.CollName='"+CollCode.SelectedItem.Text.Trim()+"' order by EXAM.ExamYear desc,COLLEGE.CollName,STREAM.StreamAbbr,STREAMPART.StreamPart";


        
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        ExamCenterView.DataSource = ds;
        ExamCenterView.DataBind();
       
    }
   
    protected void StreamPart_SelectedIndexChanged(object sender, EventArgs e)
    {
        NoOfStudents.Text = "0"; 
    }
    protected void GenderA_CheckedChanged(object sender, EventArgs e)
    {
        CheckCentreAllotment();
    }
    protected void GenderF_CheckedChanged(object sender, EventArgs e)
    {
        CheckCentreAllotment();
    }
    protected void GenderM_CheckedChanged(object sender, EventArgs e)
    {
        CheckCentreAllotment();
    }



    void ExamCentreCheckCapacity()
    {
        //if (ExamStartDate.Text == "") return; //commented on 11-jan-2012


        UnivService.Service1 ss = new UnivService.Service1();
        //string collegecapacity = ss.GetNewCode("SELECT ExamCapacity FROM COLLEGE  where CollCode='" + ExamCollCode.SelectedValue + "'");

        string collegecapacity = ss.GetNewCode("SELECT ExamCapacity FROM ExamCOLLEGE  where ExamCollCode='" + ExamCollCode.SelectedValue + "'");
        
        // string ss1 = "SELECT  COUNT(ExamCollCode) AS TotAllot FROM  EXAM  WHERE   ExamCollCode ='" + ExamCollCode.SelectedValue + "' And ExamYear='" + ExamYear.Text + "' And ExamStartDate='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(ExamStartDate.Text)) + "'";
        string alloted = ss.GetNewCode("SELECT  COUNT(ExamCollCode) AS TotAllot FROM  EXAM  WHERE   ExamCollCode ='" + ExamCollCode.SelectedValue + "' And ExamYear='" + ExamYear.Text + "' And ExamStartDate='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(ExamStartDate.Text))  + "' ");
        if (alloted == "") alloted = "0";
        ExamCapacity.Text = collegecapacity;
        AvailableCapacity.Text = (int.Parse(collegecapacity) - int.Parse(alloted)) + "";  // No need of verification (updated on 09.06.2008)
        //AvailableCapacity.Text = collegecapacity;
    }




    protected void BtnAddAllot_Click(object sender, EventArgs e)
    {
        int c = 0,i,tot=0;
        int flag = 0;
        string centre;
        LblMsg.Text = "";
        string sex = "";
        //Check Availabilty & requirement
        //if (  int.Parse(AvailableCapacity.Text) <int.Parse(NoOfAllot.Text)   )
        //{
        //    LblMsg.Text = "College Capacity is less than Required ";
        //    NoOfAllot.Focus();
        //    return;
        //}


        if (GenderF.Checked) sex = "F"; 
        else if (GenderM.Checked) sex = "M";
        else sex = "A";
        if (sex == "A")
        {
            for (i = 0; i < CentreList.Items.Count; i++)
            {
                if (NoOfStuList.Items[i].Text.Substring(0, 1) == "F" || NoOfStuList.Items[i].Text.Substring(0, 1) == "M")
                {
                    LblMsg.Text  = "Centre is already selected For Male/Female. ";
                    return;
                }
            }
        
            
        }
        if (int.Parse (NoOfAllot.Text)> int.Parse (NoOfStudents.Text )   )
        {
            LblMsg.Text = "No of Students selection  is greater than Requirement ";
            NoOfAllot.Focus();
            return;
        }
        //if ((int.Parse(TotStudent.Text)+int.Parse (NoOfAllot.Text ))  > int.Parse(TotalStu.Text))
        //{
        //    LblMsg.Text = "No of Students selection  is greater than Requirement";
        //    NoOfAllot.Focus(); 
        //    return;
        //}

        if ((int.Parse(TotStudent.Text) + int.Parse(NoOfAllot.Text)) > int.Parse(AvailableCapacity.Text))
        {
            LblMsg.Text = "No of Students selection  is greater than Available Capacity";
            NoOfAllot.Focus();
            return;
        }

        //Check Duplicate Centre
        for (i = 0; i < CentreList.Items.Count; i++)
        {
            
            centre=CentreList.Items[i].Text.Substring(4);
            if (centre== ExamCollCode.SelectedItem.Text)
                flag = 1;
      
        }
        if (flag == 0)
        {
           // c = CentreList.Items.Count + 1;
            CentreList.Items.Add(ExamCollCode.SelectedValue +"-"  + ExamCollCode.SelectedItem.Text);
            NoOfStuList.Items.Add(sex+"-"+ NoOfAllot.Text);
            for (i = 0; i < CentreList.Items.Count; i++)
            {
               tot += int.Parse(NoOfStuList.Items[i].Text.Substring (2));
            }
            TotStudent.Text = tot.ToString (); 


        }
        else
        {
            LblMsg.Text   = "Selected Centre is already alloted. ";
            
        }
    }
    protected void BtnRemove_Click(object sender, EventArgs e)
    {
        // Remove select item from centre lis
        int i=0,tot=0;//c=0,
        for (i = 0; i < CentreList.Items.Count; i++)
        {
            if (CentreList.Items[i].Selected == true)
            {
                CentreList.Items.RemoveAt(i);
                NoOfStuList.Items.RemoveAt(i);   
          }
       }
       for (i = 0; i < CentreList.Items.Count; i++)
       {
          tot += int.Parse(NoOfStuList.Items[i].Text.Substring(2));
       }
       TotStudent.Text = tot.ToString(); 
        

    }
    protected void BtnRemoveAll_Click(object sender, EventArgs e)
    {
        CentreList.Items.Clear();
        NoOfStuList.Items.Clear();
        TotStudent.Text = "0"; 
    }
    
    protected void ExamCenterView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        ExamCenterView.PageIndex = e.NewPageIndex;
        BindGrid();
    }
    protected void SubCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        CheckCentreAllotment();
    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
            
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
        
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
       
        
    }


    protected void ExamCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            ExamCollCode.SelectedValue = ExamCode.Text;

        }
        catch (Exception ex)
        {
            string msg = "Exam Centre College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            ExamCode.Text = "";
            ExamCode.Focus();
            ExamCollCode.SelectedIndex = 0;
        }
    }
}
