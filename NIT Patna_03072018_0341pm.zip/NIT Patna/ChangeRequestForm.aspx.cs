using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class ChangeRequestForm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "3")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

           
        }
       
    }
    protected void ChangeList_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ChangeList.SelectedValue == "Registration")
        {
            FieldList.Items.Add("HindiName");
            FieldList.Items.Add("ApplicantName");
            FieldList.Items.Add("FatherName");
            FieldList.Items.Add("DOB");
            FieldList.Items.Add("MaritalStatus");
            FieldList.Items.Add("PermanentAddress1");
            FieldList.Items.Add("PresentAddress1");
            FieldList.Items.Add("StreamCode");

        }
        else
            FieldList.Items.Clear(); 
    }
    protected void BtnOk_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.Connection = con;
        cmd.CommandText = " Select ApplicantName,DOB from Registration Where RegNo='" + RegNo.Text.Trim() + "'";  
        SqlDataReader reader;
        con.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            reader.Read();
            ApplicantName.Text = reader["ApplicantName"].ToString();
            DOB.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["DOB"]));
        }
        reader.Close();
        con.Close();
    }
    protected void FieldList_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.Connection = con;
        cmd.CommandText = " Select "+FieldList.SelectedItem.Text   + " from Registration Where RegNo='" + RegNo.Text.Trim() + "'";
        SqlDataReader reader;
        con.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            reader.Read();
            ChangeRequestValue.Text = reader[FieldList.SelectedItem.Text].ToString();  
        }
        reader.Close();
        con.Close();

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (FileUpload1.FileName == "")
        {
            string popupScript = "<script language='javascript'>" +
                           " alert(' Please select pdf file for upload   ')" +
                            "</script>";

            Page.RegisterStartupScript("PopupScript", popupScript);
            return;
        }
        // Upload Supporting Document
        string fnm = "";
        string fileExt =  System.IO.Path.GetExtension(FileUpload1.FileName);
        LblMsg.Text = "";
        if (fileExt == ".pdf")
        {
            try
            {
                string rootPath = Server.MapPath("~");
                fnm=@"\ChangeRequestDocument\"+RegNo.Text +"_"+System.DateTime.Now.Day+"-"+System.DateTime.Now.Month +"-"+System.DateTime.Now.Year + FileUpload1.FileName;
                FileUpload1.SaveAs(rootPath +fnm);
                 
            }
            catch (Exception ex)
            {
               LblMsg.Text = "ERROR: " + ex.Message.ToString();
            }
        }
        else
        {
            string popupScript = "<script language='javascript'>" +
                          " alert(' Please select pdf file for upload   ')" +
                           "</script>";

            Page.RegisterStartupScript("PopupScript", popupScript);
            return;
        }

        string[] col = new string[9];
        string[] val = new string[9];
        col[0] = "RegNo";
        col[1] = "RequestFrom";
        col[2] = "ReqDate";
        col[3] = "TableName";
        col[4] = "ChangeRequestField";
        col[5] = "ChangeRequestValue";
        col[6] = "ChangedFinalValue";
        col[7] = "AsstUserNAme";
        col[8] = "docName";
  

        val[0] = RegNo.Text;
        val[1] = RequestFrom.Text;
        val[2] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(System.DateTime.Now   ));
        val[3] = ChangeList.SelectedValue;
        val[4] = FieldList.SelectedItem.Text;
        val[5] = ChangeRequestValue.Text;
        val[6] = ChangedFinalValue.Text;
        val[7] = Session["userName"].ToString();
        val[8] = fnm;
 

        UnivService.Service1 ss = new UnivService.Service1();
        string  abc = ss.SaveData("ChangeRequest", col, val);

        if (abc == "1")
        {
            LblMsg.Text = " Request is Forwarded for Approval ";
            string popupScript = "<script language='javascript'>" +
                           " alert(' Request is Forwarded for Approval   ')" +
                            "</script>";

            Page.RegisterStartupScript("PopupScript", popupScript);
            ChangeRequestValue.Text = ""; 
            


        }
    }
    protected void UploadDoc(string fnm)
    {
        

        //
    }
}
