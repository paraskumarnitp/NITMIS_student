using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class CoursePaper : System.Web.UI.Page
{
    Functionreviseed usbfunctions = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "1") && (Session["Role"].ToString() != "10"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
           // popddl.Popualate(lstbcourse, "Stream", "Select StreamAbbr,StreamCode from Stream Where StreamCode <> '00' order by Stream ", "Stream", "StreamCode");
            bindcourse();
           // popddl.Popualate(StreamPartCode, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart where StreamCode='" + StreamCode.SelectedValue + "' order by StreamPart", "StreamPart", "StreamPartCode");
            popddl.Popualate(StreamPartCode, "StreamPart", "Select distinct StreamPart from StreamPart Where StreamPartCode <>'00' and StreamPart not in ('sem 1-A','sem 1-B','sem 2-A','sem 2-B') order by StreamPart ", "StreamPart", "StreamPart");
            StreamPartCode.Items.Insert(0, new ListItem("---Select---", "00"));
            popddl.Popualate(PaperTypeCode , "PaperType", "Select * from PaperType order by PaperType", "PaperType", "PaperTypeCode");
//            popddl.Popualate(SubCode , "Subject", "Select subcode,SubjectName from Subject order by subjectName", "SubjectName", "subCode");
            ViewState.Add("EditMode", "false");
            lstbcourse.Focus(); 
        }
    }
    protected void bindcourse()
    {
        DataTable dtcourse = usbfunctions.SelectDatatable("Select StreamAbbr,StreamCode from Stream Where StreamCode <> '00' order by Stream");
        lstbcourse.DataSource = dtcourse;
        lstbcourse.DataTextField = "StreamAbbr";
        lstbcourse.DataValueField = "StreamCode";
        lstbcourse.DataBind();
    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {
      /*  string abc = "";
        Panel2.Visible = false;
        if (ViewState["EditMode"].ToString() == "false")
        {
            string[] col = new string[14];
            string[] val = new string[14];
            col[0] = "StreamCode";
            col[1] = "StreamPartCode";
            col[2] = "SubPaperCode";
            col[3] = "PaperTypeCode";
            col[4] = "SubCode";
            col[5] = "PaperName";
            col[6] = "PaperAbbr";
            col[7] = "FullMarks";
            col[8] = "PassMarks";
            col[9]="Credit";
            col[10] = "StreamPart";
            col[11] = "L";
            col[12] = "T";
            col[13] = "P";
            Panel2.Visible = false;
            
            val[0] = StreamCode.SelectedValue;
            val[1] = StreamPartCode.SelectedValue;

            val[3]=PaperTypeCode.SelectedValue;
            val[4] = SubCode.SelectedValue;
            val[5] = PaperName.Text.Trim();
            val[6] = PaperAbb.Text.Trim();
            val[7] = FullMarks.Text;
            val[8] = PassMarks.Text; 
            val[9] = Credit.Text;
            val[10] = StreamPartCode.SelectedItem.Text.Trim();
            val[11] = L.Text;
            val[12] = T.Text;
            val[13] = P.Text;
 
 

            UnivService.Service1 ss = new UnivService.Service1();
            string SQL = "SELECT     ISNULL(MAX(Abs(SubPaperCode)), '0') + 1 AS NewSubPaperCode FROM COURSEPapers";
            string NewSubPaperCode = ss.GetNewCode(SQL);
            NewSubPaperCode = string.Format("{0:D4}", Convert.ToInt16(NewSubPaperCode));
            val[2] = NewSubPaperCode;

            abc = ss.SaveData("CoursePapers", col, val);

            if (abc == "1")
            {
                LblMsg.Text = " Paper is saved successfully. Paper Code= " + NewSubPaperCode;
                string popupScript = "<script language='javascript'>" +
                                " alert('Paper is saved successfully. Paper Code=   " + NewSubPaperCode +" ')" +
                                 "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);

                // save practical Marks
                if (Practical.Checked == true)
                {
                    string[] col1 = new string[4];
                    string[] val1 = new string[4];
                    col1[0] = "SubPaperCode";
                    col1[1] = "FullMarks";
                    col1[2] = "PassMarks";
                    col1[3] = "Credit";

                    val1[0] = NewSubPaperCode;
                    val1[1] = PraFullMarks.Text;
                    val1[2] = PraPassMarks.Text;
                    val1[3] = PraCredit.Text;
                    abc = ss.SaveData("PracticalPapers", col1, val1);
                    Practical.Checked = false; 
                }



                //-------------------

                PaperName.Text = "";
                PaperAbb.Text = "";
                FullMarks.Text = "";
                PassMarks.Text = "";
                Credit.Text="";
                PraFullMarks.Text = "";
                PraPassMarks.Text = "";
                PraCredit.Text="";
                PaperTypeCode.Focus(); 

            }
            else
            {
                LblMsg.Text = abc.ToString();
            }
        }
        else
        {

            UnivService.Service1 ss = new UnivService.Service1();
            abc = " update CoursePapers set StreamCode='" + StreamCode.SelectedValue + "',StreamPartCode='" + StreamPartCode.SelectedValue + "',PaperTypeCode='" + PaperTypeCode.SelectedValue.ToString() + "',SubCode='" + SubCode.SelectedValue.ToString() + "',PaperName='" + PaperName.Text + "',PaperAbbr='" + PaperAbb.Text + "',Credit= '" + Credit.Text + "',FullMarks= '" + FullMarks.Text + "',PassMarks='" + PassMarks.Text + "' where SubPaperCode='" + CoursePaperView.SelectedRow.Cells[3].Text + "'";
            string pra = " update PracticalPapers set Credit='"+PraCredit.Text+"',FullMarks='" + PraFullMarks.Text + "', PassMarks='" + PraPassMarks.Text + "' where SubPaperCode='" + CoursePaperView.SelectedRow.Cells[3].Text + "'";
            pra = ss.UpdateData(pra);
            abc = ss.UpdateData(abc);
            if (abc.ToString() == "ok")
            {
                ViewState.Add("EditMode", "false");
                LblMsg.Text = " Record is updated successfully.";

                PaperName.Text = "";
                PaperAbb.Text = "";
                FullMarks.Text = "";
                PassMarks.Text = "";
                Credit.Text = "";
                PraFullMarks.Text = "";
                PraPassMarks.Text = "";
                PraCredit.Text = "";
                Practical.Checked = false; 
                PaperTypeCode.Focus(); 

            }
            else
                LblMsg.Text = abc.ToString();

        } */
    }
    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        string streamcode = ""; string StreamPartC = "";
        Panel2.Visible = true; string querypart = "";
        if (lstbcourse.Items.Count > 0)
        {

            for (int i = 0; i < lstbcourse.Items.Count; i++)
            {
                if (lstbcourse.Items[i].Selected)
                {
                    if (streamcode != "")
                        streamcode = streamcode + ",'" + lstbcourse.Items[i].Value + "'";
                    else
                        streamcode = "'" + lstbcourse.Items[i].Value + "'";
                }
            }
        }
        if (streamcode != "")
        {
            querypart = "Where COURSEPAPERS.StreamCode IN (" + streamcode + ")";
        }

        if (gra.Checked == true)
            StreamPartC = StreamPartCode.SelectedItem.Text.Trim() + "-A";
        else if (grb.Checked == true)
            StreamPartC = StreamPartCode.SelectedItem.Text.Trim() + "-B";
        else
            StreamPartC = StreamPartCode.SelectedItem.Text.Trim();

        object stpartcode = usbfunctions.singlevalue("Select StreamPartCode From STREAMPART WHERE StreamPart ='"+StreamPartC+"'");

        if (stpartcode == "00")
        {
            querypart = "and COURSEPAPERS.StreamPartCode =  '" + stpartcode + "'";
        }
        else if (querypart == "" && stpartcode != "00")
        {
            querypart = "Where COURSEPAPERS.StreamPartCode = '" + stpartcode + "' ";
        }

        if (PaperAbb.Text.Trim() != "" && querypart != "")
        {
            querypart = querypart + " and COURSEPAPERS.PaperAbbr = '" + PaperAbb.Text.Trim() + "' ";

        }
        else if (querypart == "")
        {
            querypart = "Where COURSEPAPERS.PaperAbbr = '" + PaperAbb.Text.Trim() + "' ";
        }
        string sqlquery = "SELECT STREAM.StreamAbbr,COURSEPAPERS.StreamPart,COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName, CASE WHEN " +
            " COURSEPAPERS.PaperTypeCode = '02' THEN 'T' WHEN COURSEPAPERS.PaperTypeCode = '01' THEN 'P' ELSE 'T+P' END as PaperType, " +
            " COURSEPAPERS.FullMarks, COURSEPAPERS.Credit, COURSEPAPERS.L, COURSEPAPERS.T, COURSEPAPERS.P FROM COURSEPAPERS INNER JOIN " +
            " STREAM ON COURSEPAPERS.StreamCode = STREAM.StreamCode " + querypart + " ORDER BY COURSEPAPERS.StreamCode, COURSEPAPERS.StreamPartCode, COURSEPAPERS.SubPaperCode";
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sqlquery);


        CoursePaperView.DataSource = ds;
        CoursePaperView.DataBind(); 
    }
    protected void StreamCode_TextChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        //popddl.Popualate(StreamPartCode, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart where StreamCode='" + StreamCode.SelectedValue  + "' order by StreamPart", "StreamPart", "StreamPartCode");
        //popddl.Popualate(SubCode, "Subject", "Select subcode,SubjectName from Subject where StreamCode='"+StreamCode.SelectedValue  +"' order by subjectName", "SubjectName", "subCode");

    }
    protected void CoursePaperView_SelectedIndexChanged(object sender, EventArgs e)
    {
        Practical.Checked = false; 
        PopulateDDL popddl = new PopulateDDL();
        //popddl.Popualate(StreamCode, "Stream", "Select Stream,StreamCode from Stream order by Stream", "Stream", "StreamCode");
        //StreamCode.SelectedValue = CoursePaperView.SelectedRow.Cells[2].Text;
        //popddl.Popualate(StreamPartCode, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart where StreamCode='" + StreamCode.SelectedValue + "' order by StreamPart", "StreamPart", "StreamPartCode");
        //StreamPartCode.SelectedValue = CoursePaperView.SelectedRow.Cells[4].Text;
        
        
        popddl.Popualate(PaperTypeCode, "PaperType", "Select * from PaperType order by PaperType", "PaperType", "PaperTypeCode");        
        PaperTypeCode.SelectedValue = CoursePaperView.SelectedRow.Cells[7].Text.ToString();
       // popddl.Popualate(SubCode, "Subject", "Select subcode,SubjectName from Subject WHERE STREAMCODE='"+StreamCode.SelectedValue  +"' order by subjectName", "SubjectName", "subCode");        
        //SubCode.SelectedValue = CoursePaperView.SelectedRow.Cells[5].Text;
        
        PaperName.Text = CoursePaperView.SelectedRow.Cells[6].Text;
        PaperAbb.Text = CoursePaperView.SelectedRow.Cells[5].Text;
        FullMarks.Text = CoursePaperView.SelectedRow.Cells[8].Text;
        //PassMarks.Text = CoursePaperView.SelectedRow.Cells[9].Text;
        
        //Check Practical paper
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.Connection = con;
        con.Open();
        cmd.CommandText = " select Credit,FullMarks,PassMarks From PracticalPapers where SubPaperCode='" + CoursePaperView.SelectedRow.Cells[3].Text +"'";
        SqlDataReader reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            reader.Read();
            Practical.Checked = true;
            PraFullMarks.Text = reader["FullMarks"].ToString();
            PraPassMarks.Text = reader["PassMarks"].ToString();
            PraCredit.Text = reader["Credit"].ToString();
        }
        else
        {
            PraFullMarks.Text = "";
            PraPassMarks.Text = "";
            PraCredit.Text = "";
        }
        reader.Close ();
        con.Close ();
        
            


        ViewState.Add("EditMode", "true");
       // StreamCode.Focus(); 
    }

    protected void btncoursesave_Click(object sender, EventArgs e)
    {
        string abc = "";
        Panel2.Visible = false;
        ArrayList list = new ArrayList();
        if (lstbcourse.Items.Count > 0)
        {

            for (int i = 0; i < lstbcourse.Items.Count; i++)
            {
                if (lstbcourse.Items[i].Selected)
                {
                    list.Add(lstbcourse.Items[i].Value);
                }
            }
        }
        if (ViewState["EditMode"].ToString() == "false")
        {
            foreach (string t in list)
            {

                string[] col = new string[14];
                string[] val = new string[14];
                col[0] = "StreamCode";
                col[1] = "StreamPartCode";
                col[2] = "SubPaperCode";
                col[3] = "PaperTypeCode";
                col[4] = "SubCode";
                col[5] = "PaperName";
                col[6] = "PaperAbbr";
                col[7] = "FullMarks";
                col[8] = "PassMarks";
                col[9] = "Credit";
                col[10] = "StreamPart";
                col[11] = "L";
                col[12] = "T";
                col[13] = "P";
                Panel2.Visible = false;

                if (gra.Checked == true)
                    val[10] = StreamPartCode.SelectedItem.Text.Trim() + "-A";
                else if (grb.Checked == true)
                    val[10] = StreamPartCode.SelectedItem.Text.Trim() + "-B";
                else
                    val[10] = StreamPartCode.SelectedItem.Text.Trim();

                DataTable dt = usbfunctions.SelectDatatable("SELECT STREAMPART.StreamPartCode, SUBJECT.SubCode FROM STREAMPART INNER JOIN " +
                        " SUBJECT ON STREAMPART.StreamCode = SUBJECT.StreamCode WHERE (STREAMPART.StreamPart = '" + val[10].ToString() + "') " +
                        " AND (STREAMPART.StreamCode = '" + t.ToString() + "')");
                if (dt.Rows.Count > 0)
                {
                    val[0] = t.ToString();
                    val[1] = dt.Rows[0]["StreamPartCode"].ToString();

                    val[3] = PaperTypeCode.SelectedValue;
                    val[4] = dt.Rows[0]["SubCode"].ToString();
                    val[5] = PaperName.Text.Trim();
                    val[6] = PaperAbb.Text.Trim();
                    val[7] = FullMarks.Text;
                    val[8] = PassMarks.Text;
                    val[9] = Credit.Text;

                    val[11] = L.Text;
                    val[12] = T.Text;
                    val[13] = P.Text;



                    UnivService.Service1 ss = new UnivService.Service1();
                    string SQL = "SELECT     ISNULL(MAX(Abs(SubPaperCode)), '0') + 1 AS NewSubPaperCode FROM COURSEPapers";
                    string NewSubPaperCode = ss.GetNewCode(SQL);
                    NewSubPaperCode = string.Format("{0:D4}", Convert.ToInt16(NewSubPaperCode));
                    val[2] = NewSubPaperCode;

                    abc = ss.SaveData("CoursePapers", col, val);

                    if (abc == "1")
                    {
                        LblMsg.Text = " Paper saved successfully.";
                        string popupScript = "<script language='javascript'>" +
                                        " alert('Paper saved successfully.')" +
                                         "</script>";

                        Page.RegisterStartupScript("PopupScript", popupScript);

                        // save practical Marks
                        if (Practical.Checked == true)
                        {
                            string[] col1 = new string[4];
                            string[] val1 = new string[4];
                            col1[0] = "SubPaperCode";
                            col1[1] = "FullMarks";
                            col1[2] = "PassMarks";
                            col1[3] = "Credit";

                            val1[0] = NewSubPaperCode;
                            val1[1] = PraFullMarks.Text;
                            val1[2] = PraPassMarks.Text;
                            val1[3] = PraCredit.Text;
                            abc = ss.SaveData("PracticalPapers", col1, val1);
                            
                        }

                    }
                    else
                    {
                        LblMsg.Text = abc.ToString();
                    }
                }
                else
                {

                }
            }
            PaperName.Text = "";
            PaperAbb.Text = "";
            FullMarks.Text = "";
            PassMarks.Text = "";
            Credit.Text = "";
            PraFullMarks.Text = "";
            PraPassMarks.Text = "";
            PraCredit.Text = "";
            Practical.Checked = false;
            PaperTypeCode.Focus();
        }
        else
        {

            UnivService.Service1 ss = new UnivService.Service1();
            // abc = " update CoursePapers set StreamCode='" + StreamCode.SelectedValue + "',StreamPartCode='" + StreamPartCode.SelectedValue + "',PaperTypeCode='" + PaperTypeCode.SelectedValue.ToString() + "',SubCode='" + SubCode.SelectedValue.ToString() + "',PaperName='" + PaperName.Text + "',PaperAbbr='" + PaperAbb.Text + "',Credit= '" + Credit.Text + "',FullMarks= '" + FullMarks.Text + "',PassMarks='" + PassMarks.Text + "' where SubPaperCode='" + CoursePaperView.SelectedRow.Cells[3].Text + "'";
            string pra = " update PracticalPapers set Credit='" + PraCredit.Text + "',FullMarks='" + PraFullMarks.Text + "', PassMarks='" + PraPassMarks.Text + "' where SubPaperCode='" + CoursePaperView.SelectedRow.Cells[3].Text + "'";
            pra = ss.UpdateData(pra);
            abc = ss.UpdateData(abc);
            if (abc.ToString() == "ok")
            {
                ViewState.Add("EditMode", "false");
                LblMsg.Text = " Record is updated successfully.";

                PaperName.Text = "";
                PaperAbb.Text = "";
                FullMarks.Text = "";
                PassMarks.Text = "";
                Credit.Text = "";
                PraFullMarks.Text = "";
                PraPassMarks.Text = "";
                PraCredit.Text = "";
                Practical.Checked = false;
                PaperTypeCode.Focus();

            }
            else
                LblMsg.Text = abc.ToString();
        }
        
    }
    protected void StreamPartCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        if ((StreamPartCode.SelectedItem.ToString() == "sem 1") || (StreamPartCode.SelectedItem.ToString() == "sem 2"))
        {
            Hashtable hashtable = new Hashtable();
            hashtable.Add("01", 0);
            hashtable.Add("02", 1);
            hashtable.Add("03", 2);
            hashtable.Add("04", 3);            
            hashtable.Add("06", 4);
            hashtable.Add("07", 5);
            if (lstbcourse.Items.Count > 0)
            {
                foreach (ListItem item in lstbcourse.Items)
                {
                    if (item.Selected)
                    {
                        if (hashtable.Contains(item.Value)) { gra.Enabled = true; grb.Enabled = true; break; }                        
                    }
                }    
            }

                  
        }
        else { gra.Checked = false; grb.Checked = false; gra.Enabled = false; grb.Enabled = false; }
    }
}
