using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using Microsoft.Reporting.WebForms; 
public partial class GenerateComputerCode : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(Year, "Year", "Select Year from Year where year > '2008' order by Year", "Year", "Year");
        }

    }

    protected void BtnGenCode_Click(object sender, EventArgs e)
    {
        int flag=0,code=0,count=0;
        string NewCode = "";
        SqlConnection con = new SqlConnection();
        SqlConnection con1 = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        SqlCommand cmd1 = new SqlCommand();
        cmd.Connection = con;
        cmd1.Connection = con1;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        con1.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        con.Open();
        con1.Open();
        cmd.CommandText = "select UnivRollNo,StreamPartCode,SubPaperCode,PaperType From Exampaperdetail where ExamYear='" + Year.SelectedValue + "'And UnivRollNo is not null and CompCode is null order by SubPaperCode";
        SqlDataReader reader;
        reader = cmd.ExecuteReader();
        UnivService.Service1 ss = new UnivService.Service1();

        string SQL = "SELECT     ISNULL(MAX(ABS(Compcode)), '0') + 1 AS NewCompCode FROM Exampaperdetail where Examyear='"+Year.SelectedValue  +"'";
        code =int.Parse (ss.GetNewCode(SQL));
        count = code;
        while (reader.Read())
        {
            NewCode = string.Format("{0:D7}", Convert.ToInt16(code));
            cmd1.CommandText = "update Exampaperdetail set CompCode='" + NewCode + "' where UnivRollNo='" + reader["UnivRollNo"].ToString() + "' and StreamPartCode='" + reader["StreamPartCode"].ToString() + "' And SubPaperCode='" + reader["SubPaperCode"].ToString() + "' And PaperType='" + reader["PaperType"].ToString() + "' And ExamYear='" + Year.SelectedValue + "'";
             flag= cmd1.ExecuteNonQuery();
            if( flag !=0) code++;
        }
        reader.Close();
        con.Close();
        con1.Close();
        string popupScript = "<script language='javascript'>" +
                               " alert('" + (code - count) + " computer codes are generated successfully  ')" +
                                "</script>";
        Page.RegisterStartupScript("PopupScript", popupScript);

    }
}
