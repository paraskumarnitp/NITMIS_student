using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class UniversityPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
           try
           {

                if (Session["Role"].ToString() != "1")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
                PopulateDDL popddl = new PopulateDDL();
                popddl.Popualate(DistCode , "District", "Select Distcode,DistName from District order by DistName", "DistName", "DistCode");
                popddl.Popualate(StateCode , "State", "Select Statecode,State from State order by State", "State", "StateCode");
                ViewState.Add("EditMode", "false");
                UnivName.Focus();
           }
           catch (Exception ex)
           {
                Response.Redirect("default.aspx");
           }

        }

    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {
        string abc = "";
        Panel2.Visible = false;
        if (ViewState["EditMode"].ToString() == "false")
        {
            string[] col = new string[11];
            string[] val = new string[11];
            col[0] = "UnivCode";
            col[1] = "UnivName";  val[1] = UnivName.Text.Trim();
            col[2] = "Address1";  val[2] = Address1.Text.Trim();
            col[3] = "Address2";  val[3] = Address2.Text.Trim();
            col[4] = "DistCode";  val[4] = DistCode.SelectedValue.ToString(); 
            col[5] = "PinCode";   val[5] = PinCode.Text.Trim();
            col[6] = "StateCode"; val[6] = StateCode.SelectedValue.ToString();
            col[7] = "PhoneNo";   val[7] = PhoneNo.Text.Trim();
            col[8] = "Fax";       val[8] = Fax.Text.Trim();
            col[9] = "Email"; val[9] = Email.Text.Trim();
            col[10] = "UnivAbbr"; val[10] = UnivAbbr.Text.Trim();
           

            UnivService.Service1 ss = new UnivService.Service1();
            string SQL = "SELECT     ISNULL(MAX(UnivCode), '0') + 1 AS NewUnivCode FROM University";
            string NewUnivCode = ss.GetNewCode(SQL);
            val[0] = string.Format("{0:D2}", Convert.ToInt16(NewUnivCode));
            
            abc = ss.SaveData("University", col, val);

            if (abc == "1")
            {
                LblMsg.Text = " Record is saved successfully. University Code= " + NewUnivCode;
                string popupScript = "<script language='javascript'>" +
                                " alert('Record is saved successfully. University=   " + NewUnivCode  + " ')" +
                                 "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);

                UnivName.Text = "";
                Address1.Text = "";
                Address2.Text = "";
                PhoneNo.Text = "";
                PinCode.Text = "";
                Fax.Text = "";
                Email.Text = ""; 
                UnivName.Focus(); 

            }
            else
            {
                LblMsg.Text = abc.ToString();
            }
        }
        else
        {

            UnivService.Service1 ss = new UnivService.Service1();
 //         abc = " update category set category='" + CategoryNm.Text + "' where CategoryCode='" + CateGoryView.SelectedRow.Cells[1].Text + "'";
            abc = " update UNIVERSITY set UnivName='" + UnivName.Text + "',UnivAbbr='" + UnivAbbr.Text + "',Address1='" + Address1.Text + "',Address2='" + Address2.Text + "',DistCode='" + DistCode.SelectedValue.ToString() + "',PinCode='" + PinCode.Text + "',StateCode='" + StateCode.SelectedValue.ToString() + "',PhoneNo='" + PhoneNo.Text + "',Email='" + Email.Text + "',Fax='" + Fax.Text + "' where UnivCode='" + UniversityView.SelectedRow.Cells[1].Text + "'";
              
                  
            abc = ss.UpdateData(abc);
            if (abc.ToString() == "ok")
            {
                ViewState.Add("EditMode", "false");
                LblMsg.Text = " Record is updated successfully.";

                UnivName.Text = "";
                Address1.Text = "";
                Address2.Text = "";
                PinCode.Text = "";
                PhoneNo.Text = "";
                Fax.Text = "";
                Email.Text = "";
                UnivAbbr.Text = "";
                UnivName.Focus();

            }
            else
                LblMsg.Text = abc.ToString();

        }

    }
    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        Panel2.Visible = true;
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select UnivCode,UnivName,UnivAbbr,Address1,Address2,PhoneNo,DistCode,PinCode,StateCode,Email,Fax from University where univcode<>'00' order by UnivCode");
        UniversityView.DataSource = ds;
        UniversityView.DataBind(); 
    }
    protected void CateGoryView_SelectedIndexChanged(object sender, EventArgs e)
    {
        UnivName.Text = UniversityView.SelectedRow.Cells[2].Text;
        UnivAbbr.Text = UniversityView.SelectedRow.Cells[3].Text;
        Address1.Text = UniversityView.SelectedRow.Cells[4].Text;
        Address2.Text = UniversityView.SelectedRow.Cells[5].Text;
        PhoneNo.Text = UniversityView.SelectedRow.Cells[6].Text;
        DistCode.SelectedValue  = UniversityView.SelectedRow.Cells[7].Text;
        PinCode.Text = UniversityView.SelectedRow.Cells[8].Text;
        StateCode.SelectedValue = UniversityView.SelectedRow.Cells[9].Text.Trim();
        Email.Text=UniversityView.SelectedRow.Cells[10].Text;
        Fax.Text = UniversityView.SelectedRow.Cells[11].Text;
       
        
        ViewState.Add("EditMode", "true");
        UnivName.Focus(); 

    }
}
