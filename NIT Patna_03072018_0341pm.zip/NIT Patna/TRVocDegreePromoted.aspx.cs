using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class TRVocDegreePromoted : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
         if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();

            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College where collcode in (select distinct collcode from exam) order by CollName", "CollName", "CollCode");
            popddl.Popualate(ExamYear, "Exam", "Select distinct ExamYear from Exam order by ExamYear", "ExamYear", "ExamYear");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from exam) order by StreamAbbr", "StreamAbbr", "StreamCode");
            CourseValue();


          
        }
    }

     protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        CourseValue();
    }
    protected void CourseValue()
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart, StreamPartCode from StreamPart where streamcode='" + StreamCode.SelectedValue + "' and streampartcode in (select distinct streampartcode from exam) order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");


    }
    protected void CollChkBox_CheckedChanged(object sender, EventArgs e)
    {
        if (CollChkBox.Checked == true)
        {
            CollCode.Enabled = false;
            InstCode.Enabled = false;
        }
        else
        {
            CollCode.Enabled = true;
            InstCode.Enabled = true;
        }
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
    }
    
    


    protected void BtnGenerate_Click(object sender, EventArgs e)
    {
        LblMsg.Text = string.Empty;
        LblMsgDeleted.Text = string.Empty;

  
        UnivService.Service1 NicService = new UnivService.Service1();
        String TypeCode =NicService.GetNewCode("Select StreamTypeCode from Stream where StreamCode='"+ StreamCode.SelectedValue+"' ");

        if(TypeCode=="03"  && StreamCode.SelectedValue=="02")//Voc
        {
            //GenerateTRVoc(); // 3yr vocational degree

            if (SubCode.SelectedValue == "009")
            {
                // BJMC 
              
                //if (TRReprocess == true)
                //    DeleteTRProcessedData("TRVocDegree"); // Call DeleteTrProcessedData();
                
                //GenerateTRVocBJMC();// Call Tr Generate Function
            }
            else if(SubCode.SelectedValue == "008")
            {
               // BBA
                //if (TRReprocess == true) // Call DeleteTrProcessedData();
                //    DeleteTRProcessedData("TRVocDegree");
               
                GenerateTRVocBBA();
            }
            else if (SubCode.SelectedValue == "007")
            {
             // BCA
                //if (TRReprocess == true)// Call DeleteTrProcessedData();
                //     DeleteTRProcessedData("TRVocDegree");
                
                //GenerateTRVocBCA();
            }
            else
            {}
        }
    }


    protected void GenerateTRVocBBA()
    {
        SqlConnection con = new SqlConnection();
        SqlDataReader rd;
        SqlCommand cmd = new SqlCommand();

        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.Connection = con;
        // Add Subcode

        //  Only For ExamType='P'
        
        if (CollChkBox.Checked)
        {
            cmd.CommandText = "select UnivRollNo,RegNo,SubCode,Gender,ExamStartDate,CollCode,ExamType from Exam where StreamCode='" + StreamCode.SelectedValue + "' and StreamPartCode='" + StreamPart.SelectedValue + "' and subcode='" + SubCode.SelectedValue + "' and examyear='" + ExamYear.SelectedValue + "' and ExamType='P' ";
        }
        else
        {
            cmd.CommandText = "select UnivRollNo,RegNo,SubCode,Gender,ExamStartDate,CollCode,ExamType from Exam where CollCode='" + CollCode.SelectedValue + "' and StreamCode='" + StreamCode.SelectedValue + "' and StreamPartCode='" + StreamPart.SelectedValue + "' and subcode='" + SubCode.SelectedValue + "' and examyear='" + ExamYear.SelectedValue + "' and ExamType='P' ";
        }



        con.Open();
        rd = cmd.ExecuteReader();
        if (rd.HasRows)
        {
            UnivService.Service1 NicService = new UnivService.Service1();
            string EName = "";
            string HName = "";
            string FatherName = "";
            string MotherName = "";

            string ExamHeldMon = "";
            string ExamHeldYr = "";
            string ExamHeldDate = "";


            // variable for Grading
            char OP1 = 'F', OP2 = 'F', OP3 = 'F', OP4 = 'F', OP5 = 'F', OP6 = 'F';
            char IA1 = 'F', IA2 = 'F', IA3 = 'F', IA4 = 'F', IA5 = 'F', IA6 = 'F';


            //int OPpr1 = 0, OPPr2 = 0, OPpr3 = 0, OPpr4 = 0, OPpr5 = 0, OPpr6 = 0;


            int countP = 0, countH = 0;

            int NoofPaperInPassed = 0;
            int PromotedIfPassed = 0;
            int TotalPaperMarks = 0;

            // end


            string[] col = new string[40];
            string[] val = new string[40];
            string[] coltype = new string[40];
            for (int i = 0; i < 40; i++)
            {
                coltype[i] = "0";
            }
            coltype[7] = "1";
            int count = 0, TotCount = 0;

            DataSet PaperDs = new DataSet();
            DataSet PaperDsPrvResult = new DataSet();

            col[0] = "CollCode";
            col[1] = "StreamCode";
            col[2] = "StreamPart";
            col[3] = "ExamYear";
            col[4] = "ExamHeldDate";
            col[5] = "UnivRollNo";
            col[6] = "SubCode";

            col[7] = "HName";
            col[8] = "EName";
            col[9] = "FatherName";
            col[10] = "MotherName";
            col[11] = "Gender";
            col[12] = "RegNo";

            col[13] = "Paper1";
            col[14] = "Paper2";
            col[15] = "Paper3";
            col[16] = "Paper4";
            col[17] = "Paper5";
            col[18] = "Paper6";

            col[19] = "PaperMarks1";
            col[20] = "PaperMarks2";
            col[21] = "PaperMarks3";
            col[22] = "PaperMarks4";
            col[23] = "PaperMarks5";
            col[24] = "PaperMarks6";

            col[25] = "PaperPracMarks1";
            col[26] = "PaperPracMarks2";
            col[27] = "PaperPracMarks3";
            col[28] = "PaperPracMarks4";
            col[29] = "PaperPracMarks5";
            col[30] = "PaperPracMarks6";


            col[31] = "PaperTotalMarks";
            col[32] = "GrandTotal";
            col[33] = "TotalPercentage";
            col[34] = "Pass";
            col[35] = "Promoted";
            col[36] = "Failed";
            col[37] = "Grade";
            col[38] = "Remarks";
            col[39] = "ExamType";

            // rd.Read();
            // rd.Read();

            while (rd.Read())
            {

                try
                {

                    OP1 = 'F'; OP2 = 'F'; OP3 = 'F'; OP4 = 'F'; OP5 = 'F'; OP6 = 'F';
                    IA1 = 'F'; IA2 = 'F'; IA3 = 'F'; IA4 = 'F'; IA5 = 'F'; IA6 = 'F';

                    countP = 0; countH = 0;
                    for (int i = 0; i < 40; i++)
                    {

                        val[i] = "";
                    }

                    NoofPaperInPassed = 0;
                    TotalPaperMarks = 0;



                    EName = NicService.GetNewCode("Select ApplicantName from Registration where regno='" + rd["regno"].ToString() + "'");
                    HName = NicService.GetNewCode("Select HindiName from Registration where regno='" + rd["regno"].ToString() + "'");
                    FatherName = NicService.GetNewCode("Select FatherName from Registration where regno='" + rd["regno"].ToString() + "'");
                    MotherName = NicService.GetNewCode("Select MotherName from Registration where regno='" + rd["regno"].ToString() + "'");

                    ExamHeldDate = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(rd["ExamStartDate"].ToString()));
                    //ExamHeldMon = GetMonthName(ExamHeldDate.Substring(3, 2).ToString());
                    ExamHeldYr = ExamHeldDate.Substring(6, 4);
                    ExamHeldDate = ExamHeldMon + "-" + ExamHeldYr;



                    val[0] = rd["CollCode"].ToString();
                    val[1] = StreamCode.SelectedValue;
                    val[2] = StreamPart.SelectedValue;
                    val[3] = ExamYear.SelectedValue;
                    val[4] = ExamHeldDate.ToString();
                    val[5] = rd["UnivRollNo"].ToString();
                    val[6] = rd["SubCode"].ToString();
                    val[7] = HName;
                    val[8] = EName;
                    val[9] = FatherName;
                    val[10] = MotherName;
                    val[11] = rd["Gender"].ToString();
                    val[12] = rd["RegNo"].ToString();


                    // Theory paper only...  06062010 bjmc
                          //PaperDs = GetPaper(rd["UnivRollNo"].ToString(), 'H');
                          //                  count = 0;

                    //<-----------------------Theory Paper------------------------------------>           

                    //if (rd["ExamType"].ToString() == "R")
                    //{

                    //    PaperDs = GetPaper(rd["UnivRollNo"].ToString(), 'H');
                    //    count = 0;
                    //    val[39] = "R";
                    //}
                    if (rd["ExamType"].ToString() == "P")
                    {
                        val[39] = "P";
                        // Select only promoted papers..[paperabbr,ClassTest1,papertype,IsAppeared,exampaperdetail.SubPaperCode]
                        //PaperDs = GetPaper(rd["UnivRollNo"].ToString(), 'H', 'P');
                        // select last year papers....
                        //PaperDsPrvResult = GetPaperFrmTRVoc(rd["UnivRollNo"].ToString(), 'H', StreamPart.SelectedValue, SubCode.SelectedValue);
                        Boolean InsertIt = false;

                        foreach (DataRow dr in PaperDsPrvResult.Tables[0].Rows)
                        {
                            InsertIt = true;
                            foreach (DataRow dr1 in PaperDs.Tables[0].Rows)
                            {
                                if (dr1["SubPaperCode"].ToString() == dr["SubPaperCode"].ToString() && dr1["PaperType"].ToString() == dr["PaperType"].ToString())
                                {
                                    InsertIt = false;
                                    break;
                                }
                            }
                            if (InsertIt == true)
                            {
                                //PaperDs.Tables[0].Rows.Add(dr);
                                PaperDs.Tables[0].ImportRow(dr);
                            }
                        }

                    }

                    // Sort the dataset-- PaperDS                    // check each paper marks----------


//                    foreach (DataRow myDataRow in PaperDs.Tables[0].Rows)
                    foreach (DataRow myDataRow in PaperDs.Tables[0].Select("", "subpapercode ASC,PaperType ASC"))
                    {
                        if (myDataRow[2].ToString() == "H" && countH == 0)
                        {
                            val[13] = myDataRow[0].ToString();//Paper1
                            if (myDataRow[3].ToString() != "P")
                                val[19] = myDataRow[3].ToString();// If Absent
                            else
                                val[19] = myDataRow[1].ToString();//"Marks1";
                            countH++;
                            OP1 = 'F';
                        }
                        else if (myDataRow[2].ToString() == "H" && countH == 1)
                        {
                            val[14] = myDataRow[0].ToString();//GenPaper2
                            if (myDataRow[3].ToString() != "P")
                                val[20] = myDataRow[3].ToString();// If Absent
                            else
                                val[20] = myDataRow[1].ToString();//"GenMarks2";
                            countH++;
                            OP2 = 'F';
                        }
                        else if (myDataRow[2].ToString() == "H" && countH == 2)
                        {
                            val[15] = myDataRow[0].ToString();//GenPaper3
                            if (myDataRow[3].ToString() != "P")
                                val[21] = myDataRow[3].ToString();// If Absent
                            else
                                val[21] = myDataRow[1].ToString();//"GenMarks3";
                            countH++;
                            OP3 = 'F';
                        }
                        else if (myDataRow[2].ToString() == "H" && countH == 3)
                        {
                            val[16] = myDataRow[0].ToString();//GenPaper3
                            if (myDataRow[3].ToString() != "P")
                                val[22] = myDataRow[3].ToString();// If Absent
                            else
                                val[22] = myDataRow[1].ToString();//"GenMarks3";
                            countH++;
                            OP4 = 'F';
                        }
                        else if (myDataRow[2].ToString() == "H" && countH == 4)
                        {
                            val[17] = myDataRow[0].ToString();//GenPaper3
                            if (myDataRow[3].ToString() != "P")
                                val[23] = myDataRow[3].ToString();// If Absent
                            else
                                val[23] = myDataRow[1].ToString();//"GenMarks3";
                            countH++;
                            OP5 = 'F';
                        }
                        else if (myDataRow[2].ToString() == "H" && countH == 5)
                        {
                            val[18] = myDataRow[0].ToString();//GenPaper3
                            if (myDataRow[3].ToString() != "P")
                                val[24] = myDataRow[3].ToString();// If Absent
                            else
                                val[24] = myDataRow[1].ToString();//"GenMarks3";
                            countH++;
                            OP6 = 'F';
                        }


// IA begins

                        else if (myDataRow[2].ToString() == "P" && countP == 0)
                        {

                            if (myDataRow[3].ToString() != "P")
                                val[25] = myDataRow[3].ToString(); //"If Absent";
                            else
                                val[25] = myDataRow[1].ToString(); //"GenPracMarks1";
                            countP++;
                            IA1 = 'F';
                        }
                        else if (myDataRow[2].ToString() == "P" && countP == 1)
                        {
                            if (myDataRow[3].ToString() != "P")
                                val[26] = myDataRow[3].ToString(); //"If Absent";
                            else
                                val[26] = myDataRow[1].ToString(); //"GenPracMarks2";
                            countP++;
                            IA2 = 'F';
                        }
                        else if (myDataRow[2].ToString() == "P" && countP == 2)
                        {
                            if (myDataRow[3].ToString() != "P")
                                val[27] = myDataRow[3].ToString(); //"If Absent";
                            else
                                val[27] = myDataRow[1].ToString(); //"GenPracMarks3";
                            countP++;
                            IA3 = 'F';
                        }
                        else if (myDataRow[2].ToString() == "P" && countP == 3)
                        {
                            if (myDataRow[3].ToString() != "P")
                                val[28] = myDataRow[3].ToString(); //"If Absent";
                            else
                                val[28] = myDataRow[1].ToString(); //"GenPracMarks3";
                            countP++;
                            IA4 = 'F';
                        }
                        else if (myDataRow[2].ToString() == "P" && countP == 4)
                        {
                            if (myDataRow[3].ToString() != "P")
                                val[29] = myDataRow[3].ToString(); //"If Absent";
                            else
                                val[29] = myDataRow[1].ToString(); //"GenPracMarks3";
                            countP++;
                            IA5 = 'F';
                        }
                        else if (myDataRow[2].ToString() == "P" && countP == 5)
                        {
                            if (myDataRow[3].ToString() != "P")
                                val[30] = myDataRow[3].ToString(); //"If Absent";
                            else
                                val[30] = myDataRow[1].ToString(); //"GenPracMarks3";
                            countP++;
                            IA6 = 'F';
                        }


                    }

                    // end of foreach statement

                    // 25/06/2010 BY RAVI


                    val[31] = "0"; //"PaperTotalMarks";
                    //UE


                    // 09-06-2011 session check ............

                    //string RegSession = NicService.GetNewCode("select CourseSession from registration where RegNo='" + rd["RegNo"].ToString() + "' ");

                    //if (RegSession != "2009-2012")
                    //{
                    //    // For Session 2010-2013 .... Onwards.......
                    //        //UE + IA >=45 for pass...

                    //        if (val[19] != null && val[19] != "" && val[19] != "A")
                    //        {
                    //            if (val[25] != null && val[25] != "" && val[25] != "A")
                    //            {
                    //                TotalPaperMarks = TotalPaperMarks + int.Parse(val[19]) + int.Parse(val[25]);

                    //                if (int.Parse(val[19]) + int.Parse(val[25]) >= 45)
                    //                { OP1 = 'P'; IA1 = 'P'; }
                    //                else
                    //                { OP1 = 'F'; IA1 = 'F'; }
                    //            }
                    //        }

                    //        if (val[20] != null && val[20] != "" && val[20] != "A")
                    //        {
                    //            if (val[26] != null && val[26] != "" && val[26] != "A")
                    //            {
                    //                TotalPaperMarks = TotalPaperMarks + int.Parse(val[20]) + int.Parse(val[26]);

                    //                if (int.Parse(val[20]) + int.Parse(val[26]) >= 45)
                    //                { OP2 = 'P'; IA2 = 'P'; }
                    //                else
                    //                { OP2 = 'F'; IA2 = 'F'; }
                    //            }
                    //        }


                    //        if (val[21] != null && val[21] != "" && val[21] != "A")
                    //        {
                    //            if (val[27] != null && val[27] != "" && val[27] != "A")
                    //            {
                    //                TotalPaperMarks = TotalPaperMarks + int.Parse(val[21]) + int.Parse(val[27]);

                    //                if (int.Parse(val[21]) + int.Parse(val[27]) >= 45)
                    //                { OP3 = 'P'; IA3 = 'P'; }
                    //                else
                    //                { OP3 = 'F'; IA3 = 'F'; }
                    //            }
                    //        }

                    //        if (val[22] != null && val[22] != "" && val[22] != "A")
                    //        {
                    //            if (val[28] != null && val[28] != "" && val[28] != "A")
                    //            {
                    //                TotalPaperMarks = TotalPaperMarks + int.Parse(val[22]) + int.Parse(val[28]);

                    //                if (int.Parse(val[22]) + int.Parse(val[28]) >= 45)
                    //                { OP4 = 'P'; IA4 = 'P'; }
                    //                else
                    //                { OP4 = 'F'; IA4 = 'F'; }
                    //            }
                    //        }

                    //        if (val[23] != null && val[23] != "" && val[23] != "A")
                    //        {
                    //            if (val[29] != null && val[29] != "" && val[29] != "A")
                    //            {
                    //                TotalPaperMarks = TotalPaperMarks + int.Parse(val[23]) + int.Parse(val[29]);

                    //                if (int.Parse(val[23]) + int.Parse(val[29]) >= 34)
                    //                { OP5 = 'P'; IA5 = 'P'; }
                    //                else
                    //                { OP5 = 'F'; IA5 = 'F'; }
                    //            }
                    //        }


                    //        if (val[24] != null && val[24] != "" && val[24] != "A")
                    //        {
                    //            if (val[30] != null && val[30] != "" && val[30] != "A")
                    //            {
                    //                TotalPaperMarks = TotalPaperMarks + int.Parse(val[24]) + int.Parse(val[30]);

                    //                if (int.Parse(val[24]) + int.Parse(val[30]) >= 34)
                    //                { OP6 = 'P'; IA6 = 'P'; }
                    //                else
                    //                { OP6 = 'F'; IA6 = 'F'; }
                    //            }
                    //        }



                    //}
                    //else
                    //{
                        // For Session 2009-2012


                    //05-June-2012                
                    if(val[2]=="5")  // Checking for PART-III  -----------

                    {
                        if (val[19] != null && val[19] != "" && val[19] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[19]);
                                if (int.Parse(val[19]) >= 36)
                                    OP1 = 'P';
                                else
                                    OP1 = 'F';
                        }

                        if (val[20] != null && val[20] != "" && val[20] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[20]);
                            if (int.Parse(val[20]) >= 36)
                                OP2 = 'P';
                            else
                                OP2 = 'F';
                        }


                        if (val[21] != null && val[21] != "" && val[21] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[21]);
                            if (int.Parse(val[21]) >= 36)
                                OP3 = 'P';
                            else
                                OP3 = 'F';
                        }

                        if (val[22] != null && val[22] != "" && val[22] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[22]);
                            if (int.Parse(val[22]) >= 45)
                                OP4 = 'P';
                            else
                                OP4 = 'F';
                        }


                        //IA

                        if (val[25] != null && val[25] != "" && val[25] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[25]);
                            if (int.Parse(val[25]) >= 9)
                                IA1 = 'P';
                            else
                                IA1 = 'F';
                        }

                        if (val[26] != null && val[26] != "" && val[26] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[26]);
                            if (int.Parse(val[26]) >= 9)
                                IA2 = 'P';
                            else
                                IA2 = 'F';
                        }

                        if (val[27] != null && val[27] != "" && val[27] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[27]);
                            if (int.Parse(val[27]) >= 9)
                                IA3 = 'P';
                            else
                                IA3 = 'F';
                        }


                    }

                    else
                    {




                        if (val[19] != null && val[19] != "" && val[19] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[19]);
                                if (int.Parse(val[19]) >= 36)
                                    OP1 = 'P';
                                else
                                    OP1 = 'F';
                        }

                        if (val[20] != null && val[20] != "" && val[20] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[20]);
                            if (int.Parse(val[20]) >= 36)
                                OP2 = 'P';
                            else
                                OP2 = 'F';
                        }


                        if (val[21] != null && val[21] != "" && val[21] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[21]);
                            if (int.Parse(val[21]) >= 36)
                                OP3 = 'P';
                            else
                                OP3 = 'F';
                        }

                        if (val[22] != null && val[22] != "" && val[22] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[22]);
                            if (int.Parse(val[22]) >= 36)
                                OP4 = 'P';
                            else
                                OP4 = 'F';
                        }


                        if (val[23] != null && val[23] != "" && val[23] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[23]);
                            if (int.Parse(val[23]) >= 27)
                                OP5 = 'P';
                            else
                                OP5 = 'F';
                        }



                        if (val[24] != null && val[24] != "" && val[24] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[24]);
                            if (int.Parse(val[24]) >= 27)
                                OP6 = 'P';
                            else
                                OP6 = 'F';
                        }

                        //IA

                        if (val[25] != null && val[25] != "" && val[25] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[25]);
                            if (int.Parse(val[25]) >= 9)
                                IA1 = 'P';
                            else
                                IA1 = 'F';
                        }

                        if (val[26] != null && val[26] != "" && val[26] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[26]);
                            if (int.Parse(val[26]) >= 9)
                                IA2 = 'P';
                            else
                                IA2 = 'F';
                        }

                        if (val[27] != null && val[27] != "" && val[27] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[27]);
                            if (int.Parse(val[27]) >= 9)
                                IA3 = 'P';
                            else
                                IA3 = 'F';
                        }

                        if (val[28] != null && val[28] != "" && val[28] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[28]);
                            if (int.Parse(val[28]) >= 9)
                                IA4 = 'P';
                            else
                                IA4 = 'F';
                        }

                        if (val[29] != null && val[29] != "" && val[29] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[29]);
                            if (int.Parse(val[29]) >= 7)
                                IA5 = 'P';
                            else
                                IA5 = 'F';
                        }

                        if (val[30] != null && val[30] != "" && val[30] != "A")
                        {
                            TotalPaperMarks = TotalPaperMarks + int.Parse(val[30]);
                            if (int.Parse(val[30]) >= 7)
                                IA6 = 'P';
                            else
                                IA6 = 'F';
                        }

                    }




//---------

                    val[31] = TotalPaperMarks.ToString();
                    val[32] = TotalPaperMarks.ToString();

                    

                    if(val[2]=="5") // part-III
                    {

                    double TotPer = double.Parse(TotalPaperMarks.ToString()) / 4;
                    val[33] = TotPer.ToString("F2");


                        // Check number of UE and IA Pass paper
                    if (OP1 == 'P' && IA1 == 'P') NoofPaperInPassed++;
                    if (OP2 == 'P' && IA2 == 'P') NoofPaperInPassed++;
                    if (OP3 == 'P' && IA3 == 'P') NoofPaperInPassed++;
                    if (OP4 == 'P')               NoofPaperInPassed++;
                   


                    if (NoofPaperInPassed == 4)
                        val[34] = "Pass";
                    else
                        val[36] = "Fail";

                    }
                    else // For all part except P-III
                    {

                    double TotPer = double.Parse(TotalPaperMarks.ToString()) / 6;
                    val[33] = TotPer.ToString("F2");


                    // Check number of UE and IA Pass paper
                    if (OP1 == 'P' && IA1 == 'P') NoofPaperInPassed++;
                    if (OP2 == 'P' && IA2 == 'P') NoofPaperInPassed++;
                    if (OP3 == 'P' && IA3 == 'P') NoofPaperInPassed++;
                    if (OP4 == 'P' && IA4 == 'P') NoofPaperInPassed++;
                    if (OP5 == 'P' && IA5 == 'P') NoofPaperInPassed++;
                    if (OP6 == 'P' && IA6 == 'P') NoofPaperInPassed++;


                    if (NoofPaperInPassed == 6)
                        val[34] = "Pass";
                    else if (NoofPaperInPassed >= 4)
                        val[35] = "Promoted";
                    else
                        val[36] = "Fail";
                    }
                    

                    // Required Logic of Promoted Case ...... 



                    // Absent Case ........ 08-06-2011

                    // check absent case - 07-06-2011 changed
                    if (val[19] == "A" && val[20] == "A" && val[21] == "A" && val[22] == "A" && val[23] == "A" && val[24] == "A" && val[25] == "A" && val[26] == "A" && val[27] == "A" && val[28] == "A" && val[29] == "A" && val[30] == "A")
                    {
                        val[36] = "Absent";
                    }



                    // End of Check Pass


                    // for 25062010----------------------------

                    // grade



                    if(val[2]=="5") // part-III
                    {
                        
                        if (val[34] == "Pass")
                        {
                            if (TotalPaperMarks >= 300)
                            {
                                val[37] = "O";
                                //val[38] = "Ist Div";
                                val[38] = "Pass";
                            }
                            else if (TotalPaperMarks >= 240)
                            {
                                val[37] = "A";
                                //val[38] = "Ist Div";
                                val[38] = "Pass";
                            }
                            else if (TotalPaperMarks >= 180)
                            {
                                val[37] = "B";
                                //val[38] = "IInd Div";
                                val[38] = "Pass";
                            }
                            else
                            {
                                val[38] = "Pass";
                            }

                        }

                        else if (val[35] == "Promoted")
                        {
                            val[38] = "Promoted";
                            val[37] = "F";
                        }
                        else if (val[36] == "Absent")
                        {
                            val[38] = "Absent";
                            val[37] = "F";
                        }
                        else
                        {
                            val[37] = "F";
                            val[38] = "Fail";
                        }

                    }
                    else
                    {

                        if (val[34] == "Pass")
                        {
                            if (TotalPaperMarks >= 450)
                            {
                                val[37] = "O";
                                //val[38] = "Ist Div";
                                val[38] = "Pass";
                            }
                            else if (TotalPaperMarks >= 360)
                            {
                                val[37] = "A";
                                //val[38] = "Ist Div";
                                val[38] = "Pass";
                            }
                            else if (TotalPaperMarks >= 270)
                            {
                                val[37] = "B";
                                //val[38] = "IInd Div";
                                val[38] = "Pass";
                            }
                            else
                            {
                                val[38] = "Pass";
                            }

                        }

                        else if (val[35] == "Promoted")
                        {
                            val[38] = "Promoted";
                            val[37] = "F";
                        }
                        else if (val[36] == "Absent")
                        {
                            val[38] = "Absent";
                            val[37] = "F";
                        }
                        else
                        {
                            val[37] = "F";
                            val[38] = "Fail";
                        }

                    }




                    // INSERT


                    HName = NicService.SaveDataUniCode("TRVocDegree", col, val, coltype); 
                    if (HName == "1")
                    {
                        TotCount++;
                        HName = NicService.GetNewCode("insert into Examhistory select * from currentexamstatus where regno='" + val[12] + "' And ExamYear='" + ExamYear.Text + "' And StreamPartCode='" + StreamPart.SelectedValue + "'");
                        if (val[34] == "Pass")
                            HName = NicService.GetNewCode("update currentExamstatus set status='PA' , ExamYear='" + ExamYear.Text + "' where regno='" + val[12] + "' And ExamYear='" + ExamYear.Text + "' And StreamPartCode='" + StreamPart.SelectedValue + "'");
                        else if (val[35] == "Promoted")
                            HName = NicService.GetNewCode("update currentExamstatus set status='PR' , ExamYear='" + ExamYear.Text + "' where regno='" + val[12] + "' And ExamYear='" + ExamYear.Text + "' And StreamPartCode='" + StreamPart.SelectedValue + "'");
                        else if (val[36] == "Fail")
                            HName = NicService.GetNewCode("update currentExamstatus set status='FA' , ExamYear='" + ExamYear.Text + "' where regno='" + val[12] + "' And ExamYear='" + ExamYear.Text + "' And StreamPartCode='" + StreamPart.SelectedValue + "'");

                    }
                }
                catch (Exception ex)
                {
                    LblMsg.Text = ex.Message.ToString();
                }

            }

            // Check Expelled Student
            rd.Close();
            cmd.CommandText = "select * from Expelledstudents where CollCode='" + CollCode.SelectedValue + "' and StreamCode='" + StreamCode.SelectedValue + "' and StreamPartCode='" + StreamPart.SelectedValue + "' and examyear='" + ExamYear.SelectedValue + "' ";
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                cmd.CommandText = "Update TRVocDegree set Remarks='Expelled',Grade='F', Failed='', Pass='',Promoted='', PaperMarks1='',PaperMarks2='',PaperMarks3='',PaperMarks4='',PaperMarks5='',PaperMarks6='',PaperMarks7='',PaperMarks8='',PaperPracMarks1='',PaperPracMarks2='',PaperPracMarks3='',PaperPracMarks4='',PaperPracMarks5='',PaperPracMarks6='',PaperPracMarks7='',PaperPracMarks8='',GrandTotal='',TotalPercentage=''  where UnivRollNo='" + rd["UnivRollNo"].ToString() + "' and CollCode='" + CollCode.SelectedValue + "' and StreamCode='" + StreamCode.SelectedValue + "' and StreamPart='" + StreamPart.SelectedValue + "' and examyear='" + ExamYear.SelectedValue + "' ";
                NicService.UpdateData(cmd.CommandText);
                cmd.CommandText = "update CurrentExamStatus set Status='DE' where UnivRollNo='" + rd["UnivRollNo"].ToString() + "' and StreamPartCode='" + StreamPart.SelectedValue + "' and examyear='" + ExamYear.SelectedValue + "' ";
                NicService.UpdateData(cmd.CommandText);
            }
            rd.Close();
            con.Close();
            // end Expelled Student


            string popupScript = "<script language='javascript'>" +
                       " alert('TR generate for " + TotCount + " Students.  ')" +
                        "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);


            LblMsg.Text = "TR generate for " + TotCount + " Students. ";
        }
        
    }






}
