using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class MapRollCodeMarks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "3")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
                ViewState.Add("EditMode", "false");
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(Year, "Year", "Select Year from Year where Year > '2008'  order by Year", "Year", "Year");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        


        }
    }

    
    protected void MapRollCode_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        SqlDataReader rd;
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.Connection = con;

        cmd.CommandText = "select  ExamYear,StreamPartCode,SubPaperCode,PaperType,CompCode,ClassTest1,opt1,entrydate1,ClassTest2,opt2,entrydate2 from codemarks where ExamYear = '" + Year.SelectedValue + "' and StreamPartCode='" + StreamPart.SelectedValue + "' and isPosted='N' and entrydate1 is not null and entrydate2 is not null";
        con.Open();
        rd = cmd.ExecuteReader();
        string upd;
        int TotCount = 0;
        string updPosted;

        while (rd.Read())
        {
            try
            {
                UnivService.Service1 NicService = new UnivService.Service1();
                string sql = " Update ExamPaperDetail set IsAppeared='P',ClassTest1='" + rd["ClassTest1"].ToString() + "',Opt1='" + rd["opt1"].ToString() + "',entryDate1='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(rd["entrydate1"].ToString())) + "',ClassTest2='" + rd["ClassTest2"].ToString() + "',Opt2='" + rd["opt2"].ToString() + "',entryDate2='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(rd["entrydate2"].ToString())) + "'  where ExamYear='" + rd["ExamYear"].ToString() + "' And StreamPartCode='" + rd["StreamPartCode"].ToString() + "' And SubPaperCode='" + rd["SubPaperCode"].ToString() + "' And PaperType='" + rd["PaperType"].ToString() + "' And CompCode='" + rd["CompCode"].ToString() + "' ";
                //upd = NicService.GetNewCode(" Update ExamPaperDetail set IsAppeared='P',ClassTest1='" + rd["ClassTest1"].ToString() + "',Opt1='" + rd["opt1"].ToString() + "',entryDate1='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(rd["entrydate1"].ToString())) + "',ClassTest2='" + rd["ClassTest2"].ToString() + "',Opt2='" + rd["opt2"].ToString() + "',entryDate2='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(rd["entrydate2"].ToString())) + "'  where ExamYear='" + rd["ExamYear"].ToString() + "' And StreamPartCode='" + rd["StreamPartCode"].ToString() + "' And SubPaperCode='" + rd["SubPaperCode"].ToString() + "' And PaperType='" + rd["PaperType"].ToString() + "' And CompCode='" + rd["CompCode"].ToString() + "' ");
                upd = NicService.UpdateData(" Update ExamPaperDetail set IsAppeared='P',ClassTest1='" + rd["ClassTest1"].ToString() + "',Opt1='" + rd["opt1"].ToString() + "',entryDate1='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(rd["entrydate1"].ToString())) + "',ClassTest2='" + rd["ClassTest2"].ToString() + "',Opt2='" + rd["opt2"].ToString() + "',entryDate2='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(rd["entrydate2"].ToString())) + "'  where ExamYear='" + rd["ExamYear"].ToString() + "' And StreamPartCode='" + rd["StreamPartCode"].ToString() + "' And SubPaperCode='" + rd["SubPaperCode"].ToString() + "' And PaperType='" + rd["PaperType"].ToString() + "' And CompCode='" + rd["CompCode"].ToString() + "' ");
                if (upd == "ok")
                {
                    
                    TotCount++;
                    string tempsql = "Update codemarks set IsPosted='Y'  where ExamYear='" + rd["ExamYear"].ToString() + "' And StreamPartCode='" + rd["StreamPartCode"].ToString() + "' And SubPaperCode='" + rd["SubPaperCode"].ToString() + "' And PaperType='" + rd["PaperType"].ToString() + "' And CompCode='" + rd["CompCode"].ToString() + "' ";
                    updPosted=NicService.UpdateData("Update codemarks set IsPosted='Y'  where ExamYear='" + rd["ExamYear"].ToString() + "' And StreamPartCode='" + rd["StreamPartCode"].ToString() + "' And SubPaperCode='" + rd["SubPaperCode"].ToString() + "' And PaperType='" + rd["PaperType"].ToString() + "' And CompCode='" + rd["CompCode"].ToString() + "' ");
                    //codemarks where ExamYear = '" + Year.SelectedValue + "' and StreamPartCode='" + StreamPart.SelectedValue + "' and isPosted='N' and entrydate1 is not null and entrydate2 is not null";

                }


            }
            catch (Exception ex)
            {
                LblMsg.Text = ex.Message.ToString();
            }
                
        }
        
        LblMsg.Text = TotCount + " Records Updated";

    }

    
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        StreamCode.Focus();  
    }
}
