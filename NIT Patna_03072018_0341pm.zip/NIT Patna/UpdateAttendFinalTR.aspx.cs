using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.SessionState;
using System.Web.Caching;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.Collections.Generic;

public partial class UpdateAttendFinalTR : System.Web.UI.Page
{

    Functionreviseed dut = new Functionreviseed();
    string ThFMarks, PractFMarks;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }



        }
        LblMsg.Text = "";
    }
    protected void BtnReg_Click(object sender, EventArgs e)
    {
        try
        {


            string sql = " SELECT     REGISTRATION.ApplicantName, REGISTRATION.DOB, REGISTRATION.StreamCode, STREAM.StreamAbbr, " +
                            " STREAMPART.StreamPart, STREAMPART.StreamPartCode, REGISTRATION.TempRollNo, REGISTRATION.RegNo " +
                            " FROM         REGISTRATION INNER JOIN " +
                            " EXAMPAPERDETAIL ON REGISTRATION.RegNo = EXAMPAPERDETAIL.RegNo INNER JOIN " +
                            " STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode INNER JOIN " +
                            " STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode " +
                            " GROUP BY REGISTRATION.ApplicantName, REGISTRATION.DOB, REGISTRATION.StreamCode, " +
                            " STREAM.StreamAbbr, STREAMPART.StreamPart, STREAMPART.StreamPartCode, " +
                            " REGISTRATION.TempRollNo, REGISTRATION.RegNo " +
                            " HAVING      (REGISTRATION.TempRollNo = '" + txtrollno.Text + "')";

            DataTable dtvalue = dut.SelectDatatable(sql);

            if (dtvalue.Rows.Count > 0)
            {
                Panel1.Visible = true;
                Panel1.Enabled = true;

                ApplicantName.Text = dtvalue.Rows[0]["ApplicantName"].ToString();
                DOB.Text = Convert.ToDateTime(String.IsNullOrEmpty(dtvalue.Rows[0]["DOB"].ToString()) ? "1990-01-01" : dtvalue.Rows[0]["DOB"]).ToString("dd/MM/yyyy");
                StreamCode.Text = dtvalue.Rows[0]["StreamAbbr"].ToString();
                txtregno.Text = dtvalue.Rows[0]["RegNo"].ToString();
                ddlsemester.DataSource = dtvalue;
                ddlsemester.DataTextField = "StreamPart";
                ddlsemester.DataValueField = "StreamPartCode";
                ddlsemester.DataBind();
                ddlsemester.Items.Insert(0, new ListItem("--select--", "00"));
                ddlcourses.Items.Insert(0, new ListItem("--select--", "00"));
                ddlexamsess.Items.Insert(0, new ListItem("--select--", "00"));

            }
            else
            {
                Panel1.Visible = false;
                LblMsg.Text = " Please check Roll No.";

                return;
            }

        }



        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }


    }
    protected void BtnUpdate_Click(object sender, EventArgs e)
    {
        try
        {

            int Insdata = 0;

            string thtotclass = Convert.ToString(((TextBox)Panel1.FindControl("TheoryTotalClN")).Text);
            string thattendance = Convert.ToString(((TextBox)Panel1.FindControl("TheoryAttendanceN")).Text);
            string thmedrel = Convert.ToString(((TextBox)Panel1.FindControl("ThMedRelaxationN")).Text);
            string prtotclass = Convert.ToString(((TextBox)Panel1.FindControl("PracticalTotalClN")).Text);
            string prtotattandance = Convert.ToString(((TextBox)Panel1.FindControl("PracticalAttendanceN")).Text);
            string prmedrel = Convert.ToString(((TextBox)Panel1.FindControl("PrMedRelaxationN")).Text);





            DataSet dsthfullmark = dut.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                    "COURSEPAPERS.Credit,COURSEPAPERS.PaperTypeCode,STREAM.StreamTypeCode,STREAM.StreamCode FROM COURSEPAPERS inner join Stream on COURSEPAPERS.StreamCode=STREAM.StreamCode  LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                    " WHERE COURSEPAPERS.subpapercode = '" + ddlcourses.SelectedValue.Trim() + "'");
            string papertypecode = dsthfullmark.Tables[0].Rows[0]["PaperTypeCode"].ToString();
            string StreamTypeCode = dsthfullmark.Tables[0].Rows[0]["StreamTypeCode"].ToString();
            string StreamCode = dsthfullmark.Tables[0].Rows[0]["StreamCode"].ToString();
            ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
            PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
            if (ThFMarks != "" && ThFMarks != null)
                ThFMarks = (int.Parse(ThFMarks)).ToString();
            else ThFMarks = "0";
            if (PractFMarks != "" && PractFMarks != null)
                PractFMarks = (int.Parse(PractFMarks)).ToString();
            else PractFMarks = "0";
            string sql = ""; string Admyear = "";
            if (ddlexamsess.SelectedValue.IndexOf("SMR") > 0)
            {
                if (txtrollno.Text.IndexOf('A') > 0 || txtrollno.Text.IndexOf('B') > 0)
                {
                    sql = "SELECT Distinct REGISTRATION.AdmYear FROM EXAMPAPERDETAIL INNER JOIN REGISTRATION " +
                        " ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE Registration.TempRollNo = '" + txtrollno.Text + "'" +
                        " AND (EXAMPAPERDETAIL.RegNo IS NOT NULL)";
                }
                else sql = "select AdmYear from registration where TempRollNo='" + txtrollno.Text + "'";
            }
            else sql = "select AdmYear from registration where TempRollNo='" + txtrollno.Text + "'";
            UnivService.Service1 NICService = new UnivService.Service1();
            Admyear = NICService.GetNewCode(sql);
            string examsess = "01-" + ddlexamsess.SelectedValue.Substring(4, 3) + "-" + ddlexamsess.SelectedValue.Substring(8, 4);
            string PaperMarks = "";
            if (papertypecode == "01")
                PaperMarks = ThFMarks;
            else if (papertypecode == "04")
                PaperMarks = PractFMarks;
            if ((int.Parse(Admyear) == 2013 && ((StreamTypeCode != "02") || (StreamTypeCode == "02" && StreamCode == "32")) && Convert.ToDateTime(examsess) > Convert.ToDateTime("01-JUL-2014")) || (int.Parse(Admyear) >= 2014))
            {

            }
            else if (int.Parse(Admyear) == 2013 && ((StreamTypeCode != "02") || (StreamTypeCode == "02" && StreamCode == "32")) && Convert.ToDateTime(examsess) <= Convert.ToDateTime("01-JUL-2014"))
            {
                if (papertypecode == "02" || papertypecode == "04")
                {
                    //conversion of Theory attendance to marks


                    double THAttendanceMarks = double.Parse(thtotclass) > 0 ? (double.Parse(thattendance)) / double.Parse(thtotclass) : 0;
                    THAttendanceMarks *= 100;
                    if (THAttendanceMarks >= 85)
                        THAttendanceMarks = double.Parse(ThFMarks.Trim()) * .1;
                    else
                    {
                        THAttendanceMarks = ((double.Parse(ThFMarks.Trim()) * .1) / 85) * (THAttendanceMarks);
                        THAttendanceMarks = Math.Round(THAttendanceMarks, 2);
                    }
                    Insdata = dut.InsertUpdateDelete("Update ExamPaperDetail Set TH_Attendance='" + THAttendanceMarks + "', opt1='" + Session["UserId"].ToString() + "' FROM EXAMPAPERDETAIL inner join Registration on EXAMPAPERDETAIL.RegNo=Registration.RegNo " +
                                                     " WHERE Registration.TempRollNo = '" + txtrollno.Text + "' AND ExamPaperDetail.SubPaperCode='" + ddlcourses.SelectedValue + "'  AND  " +
                                                     " ExamPaperDetail.ExamSession = '" + ddlexamsess.SelectedValue + "'");
                }
                 if (papertypecode == "01" || papertypecode == "04")
                {
                    //conversion of Practical attendance to marks32

                    double PRAttendanceMarks = double.Parse(prtotclass) > 0 ? (double.Parse(prtotattandance)) / double.Parse(prtotclass) : 0;
                    PRAttendanceMarks *= 100;
                    if (PRAttendanceMarks >= 85)
                        PRAttendanceMarks = double.Parse(PaperMarks.Trim()) * .1;
                    else
                    {
                        PRAttendanceMarks = ((double.Parse(PaperMarks.Trim()) * .1) / 85) * PRAttendanceMarks;
                        PRAttendanceMarks = Math.Round(PRAttendanceMarks, 2);
                    }
                    Insdata = dut.InsertUpdateDelete("Update ExamPaperDetail Set PR_Attendance='" + PRAttendanceMarks + "', opt1='" + Session["UserId"].ToString() + "'  FROM EXAMPAPERDETAIL inner join Registration on EXAMPAPERDETAIL.RegNo=Registration.RegNo  " +
                                                     " WHERE Registration.TempRollNo = '" + txtrollno.Text + "' AND ExamPaperDetail.SubPaperCode='" + ddlcourses.SelectedValue + "'  AND  " +
                                                     " ExamPaperDetail.ExamSession = '" + ddlexamsess.SelectedValue + "'");
                }

            }

            else
            {
                if (papertypecode == "02" || papertypecode == "04")
                {
                    //conversion of Theory attendance to marks

                    double THAttendanceMarks = double.Parse(thtotclass) > 0 ? (double.Parse(thattendance)) / double.Parse(thtotclass) : 0;
                    THAttendanceMarks *= 100;
                    if (THAttendanceMarks >= 85) THAttendanceMarks = double.Parse(ThFMarks.Trim()) * .1;
                    else
                    {
                        THAttendanceMarks = ((double.Parse(ThFMarks.Trim()) * .1) / 85) * (THAttendanceMarks);
                        THAttendanceMarks = Math.Round(THAttendanceMarks, 2);
                    }
                    Insdata = dut.InsertUpdateDelete("Update ExamPaperDetail Set TH_Attendance='" + THAttendanceMarks + "', opt1='" + Session["UserId"].ToString() + "' FROM EXAMPAPERDETAIL   inner join Registration on EXAMPAPERDETAIL.RegNo=Registration.RegNo  " +
                                                     " WHERE Registration.TempRollno = '" + txtrollno.Text + "' AND ExamPaperDetail.SubPaperCode='" + ddlcourses.SelectedValue + "'  AND  " +
                                                     " ExamPaperDetail.ExamSession = '" + ddlexamsess.SelectedValue + "'");
                }
                if (papertypecode == "01" || papertypecode == "04")
                {
                    //conversion of Practical attendance to marks

                    double PRAttendanceMarks = double.Parse(prtotclass) > 0 ? (double.Parse(prtotattandance)) / double.Parse(prtotclass) : 0;
                    PRAttendanceMarks *= 100;
                    if (PRAttendanceMarks >= 85) PRAttendanceMarks = double.Parse(PaperMarks.Trim()) * .2;
                    else
                    {
                        PRAttendanceMarks = ((double.Parse(PaperMarks.Trim()) * .2) / 85) * PRAttendanceMarks;
                        PRAttendanceMarks = Math.Round(PRAttendanceMarks, 2);
                    }
                    Insdata = dut.InsertUpdateDelete("Update ExamPaperDetail Set PR_Attendance='" + PRAttendanceMarks + "', opt1='" + Session["UserId"].ToString() + "' FROM EXAMPAPERDETAIL  inner join Registration on EXAMPAPERDETAIL.RegNo=Registration.RegNo  " +
                                                     " WHERE Registration.TempRollno = '" + txtrollno.Text + "' AND ExamPaperDetail.SubPaperCode='" + ddlcourses.SelectedValue + "'  AND  " +
                                                     " ExamPaperDetail.ExamSession = '" + ddlexamsess.SelectedValue + "'");
                }


            }

            bool status = true;
            double thmed = string.IsNullOrEmpty(thmedrel) ? 0 : double.Parse(thmedrel);
            double ptmed = string.IsNullOrEmpty(prmedrel) ? 0 : double.Parse(prmedrel);

            double THAttper = string.IsNullOrEmpty(thtotclass) ? 0 : ((double.Parse(thattendance)) * 100 / double.Parse(thtotclass)) + thmed;

            if (papertypecode == "02" || papertypecode == "04")
            {
                if (THAttper < 75 || string.IsNullOrEmpty(thtotclass) || double.Parse(thtotclass) == 0)
                    status = false;
            }
            double PRAttper = string.IsNullOrEmpty(prtotattandance) ? 0 : ((double.Parse(prtotattandance)) * 100 / double.Parse(prtotclass)) + ptmed;

            if (papertypecode == "01" || papertypecode == "04")
            {
                if (PRAttper < 75 || string.IsNullOrEmpty(prtotattandance) || double.Parse(prtotattandance) == 0)
                    status = false;
            }
            string stat = status == true ? "P" : "D";


            //new
            TextBox verify = new TextBox();
            List<string> finqueue = (List<string>)ViewState["verpap"];
            string updatefield = "";
            bool update = false;

            foreach (string item in finqueue)
            {
                verify = (TextBox)Panel1.FindControl(item + "N");
                double updfield = double.Parse(string.IsNullOrEmpty(verify.Text.Trim()) ? "0" : verify.Text.Trim());
                verify = (TextBox)Panel1.FindControl(item);
                if (updfield != double.Parse(string.IsNullOrEmpty(verify.Text.Trim()) ? "0" : verify.Text.Trim()))
                {

                    if (updatefield == "")
                    {
                        updatefield += verify.ID.Trim() + "='" + updfield.ToString().Trim() + "'";
                        update = true;
                    }
                    else
                    {
                        updatefield += "," + verify.ID.Trim() + "='" + updfield.ToString().Trim() + "'";
                    }
                }

            }
            if (update == true)
            {
                string result = "UPDATE    Attendance SET ";


                result += updatefield;

                result += ", status='" + stat + "',opt1='" + Session["UserId"].ToString() + "', EntryDate = getdate() from Attendance inner join Registration on Attendance.RegNo=Registration.RegNo  WHERE     (Registration.TempRollNo = '" + txtrollno.Text.Trim() + "') AND (SubPaperCode = '" + ddlcourses.SelectedValue.Trim() + "') and (ExamSession = '" + ddlexamsess.SelectedValue.Trim() + "') ";


                int totalrow = dut.InsertUpdateDelete(result);
                string msg = "";
                if (totalrow == 0)
                {
                    msg = " Could Not Saved!!!. ";

                }
                else
                {
                    msg = " Marks Saved!!!. ";

                    // int l = e.RowIndex + 1;

                    // gr4.Rows[l].Cells[3].Focus();
                }
                LblMsg.Text = msg;
            }




        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;

        }
    }



    protected void ddlsemester_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ddlcourses.Items.Clear();
            ddlexamsess.Items.Clear();
            string sql = "SELECT  distinct   a.examsession " +
                         " FROM         Attendance a inner join Registration b on a.RegNo=b.RegNo " +
                          " where not exists ( Select TRfreeze.StreamPartCode,TRfreeze.ExamSession from trfreeze " +
                            " where   TRfreeze.StreamPartCode=a.StreamPartCode and TRfreeze.ExamSession=a.ExamSession  ) " +
                             " and     (b.TempRollNo = '" + txtrollno.Text + "') AND " +
                          " (a.StreamPartCode = '" + ddlsemester.SelectedValue + "')  ";
            DataTable examses = dut.SelectDatatable(sql);
            if (examses.Rows.Count > 0)
            {
                ddlexamsess.DataSource = examses;
                ddlexamsess.DataTextField = "examsession";
                ddlexamsess.DataValueField = "examsession";
                ddlexamsess.DataBind();


            }
            ddlcourses.Items.Insert(0, new ListItem("--Select--", "00"));
            ddlexamsess.Items.Insert(0, new ListItem("--Select--", "00"));

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }




    }
    protected void ddlcourses_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            UnivService.Service1 nicuni = new UnivService.Service1();
            string papertype = nicuni.GetNewCode("select PaperTypeCode from COURSEPAPERS where SubPaperCode='" + ddlcourses.SelectedValue + "'");
            string examtype = nicuni.GetNewCode("select examtype FROM Attendance inner join Registration on Attendance.RegNo=Registration.RegNo WHERE     (Registration.TempRollNo = '" + txtrollno.Text + "') AND (Attendance.SubPaperCode = '" + ddlcourses.SelectedValue + "') AND (Attendance.examsession = '" + ddlexamsess.SelectedValue + "') ");
            txtexamtype.Text = examtype;
            string[] p1 = new string[] { "TheoryTotalCl", "TheoryAttendance", "ThMedRelaxation" };
            string[] p2 = new string[] { "PracticalTotalCl", "PracticalAttendance", "PrMedRelaxation" };
            string[] z = new string[p1.Length + p2.Length];
            p1.CopyTo(z, 0);
            p2.CopyTo(z, p1.Length);

            List<string> ew2 = new List<string>(z);
            List<string> ew1;

            string strquery = "";

            if (papertype == "01")
            {
                ew1 = new List<string>(p2);
                strquery += " PracticalTotalCl, PracticalAttendance, PrMedRelaxation ";

            }
            else if (papertype == "02")
            {
                ew1 = new List<string>(p1);
                strquery += " TheoryTotalCl, TheoryAttendance, ThMedRelaxation ";
            }
            else
            {

                ew1 = new List<string>(z);
                strquery += " TheoryTotalCl, TheoryAttendance, ThMedRelaxation,PracticalTotalCl, PracticalAttendance, PrMedRelaxation  ";

            }

            string sql = " select Papercomp,Markscomp,PaperTypeCode,examtype  from  " +
                        " ( select Papercomp,Markscomp,PaperTypeCode,examtype from " +
                         " (SELECT     Attendance.TheoryTotalCl, Attendance.TheoryAttendance, Attendance.ThMedRelaxation," +
                         "  Attendance.PracticalTotalCl, Attendance.PracticalAttendance,Attendance.PrMedRelaxation,  " +
                         " COURSEPAPERS.PaperTypeCode,examtype FROM         Attendance INNER JOIN " +
                        " COURSEPAPERS ON Attendance.SubPaperCode = COURSEPAPERS.SubPaperCode inner join Registration on Attendance.RegNo=Registration.RegNo  " +
                         " WHERE     (Registration.TempRollno = '" + txtrollno.Text + "') AND (Attendance.SubPaperCode = '" + ddlcourses.SelectedValue + "') AND (Attendance.examsession = '" + ddlexamsess.SelectedValue + "')) as p " +
                         " unpivot " +
                         " ( Markscomp for Papercomp in (" + strquery + ")) as q  ) s ";


            DataTable dt = dut.SelectDatatable(sql);



            TextBox textassign = new TextBox();




            List<string> verify = new List<string>(ew1);
            ViewState["verpap"] = verify;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                textassign = (TextBox)Panel1.FindControl(dt.Rows[i][0].ToString());
                textassign.Text = dt.Rows[i][1].ToString();
                textassign = (TextBox)Panel1.FindControl(dt.Rows[i][0].ToString() + "N");
                textassign.Text = dt.Rows[i][1].ToString();
                textassign.Enabled = true;
                ew1.Remove(dt.Rows[i][0].ToString());
                ew2.Remove(dt.Rows[i][0].ToString());


            }
            foreach (string item in ew1)
            {
                textassign = (TextBox)Panel1.FindControl(item);
                textassign.Text = "";
                textassign = (TextBox)Panel1.FindControl(item + "N");
                textassign.Text = "";
                textassign.Enabled = true;
                ew2.Remove(item);

            }

            foreach (string allitem in ew2)
            {
                textassign = (TextBox)Panel1.FindControl(allitem);
                textassign.Text = "";
                textassign = (TextBox)Panel1.FindControl(allitem + "N");
                textassign.Text = "";
                textassign.Enabled = false;


            }
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }
    protected void ddlexamsess_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ddlcourses.Items.Clear();
            string sql = "SELECT     COURSEPAPERS.PaperAbbr, COURSEPAPERS.SubPaperCode " +
                         " FROM         Attendance  INNER JOIN " +
                         " COURSEPAPERS ON Attendance.StreamPartCode = COURSEPAPERS.StreamPartCode AND " +
                          " Attendance.SubPaperCode = COURSEPAPERS.SubPaperCode inner join Registration on Registration.Regno=Attendance.RegNo  " +
                          " where not exists ( Select TRfreeze.StreamCode,TRfreeze.StreamPartCode,TRfreeze.ExamSession from trfreeze " +
                            " where  TRfreeze.StreamCode= COURSEPAPERS.StreamCode and TRfreeze.StreamPartCode=Attendance.StreamPartCode and TRfreeze.ExamSession=Attendance.ExamSession  ) " +
                             " and     (Registration.TempRollNo = '" + txtrollno.Text + "') AND " +
                          " (Attendance.StreamPartCode = '" + ddlsemester.SelectedValue + "') AND (Attendance.examsession = '" + ddlexamsess.SelectedValue + "')   ";
            DataTable coursedet = dut.SelectDatatable(sql);
            if (coursedet.Rows.Count > 0)
            {
                ddlcourses.DataSource = coursedet;
                ddlcourses.DataTextField = "PaperAbbr";
                ddlcourses.DataValueField = "SubPaperCode";
                ddlcourses.DataBind();


            }
            ddlcourses.Items.Insert(0, new ListItem("--Select--", "00"));

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }



    }
}
