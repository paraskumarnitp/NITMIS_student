using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// Summary description for AESEncryption
/// </summary>
public class AESEncryption
{
    private const string EncryptionKey = "CASC2SADEI99212";
    public static string Encrypt(string clearText)
    {

        byte[] clearBytes = ASCIIEncoding.Default.GetBytes(clearText);
        Byte[] encodedBytes;
        MD5 md5;
        md5 = new MD5CryptoServiceProvider();
        encodedBytes = md5.ComputeHash(clearBytes);
        //Convert encoded bytes back to a 'readable' string
        return BitConverter.ToString(encodedBytes);
    }
}



