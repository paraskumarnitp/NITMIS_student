using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net;
using System.Net.Mail;
/// <summary>
/// Summary description for EmailService
/// </summary>
public class EmailService
{
    public static bool SendEmail(string emailTo, string token)
    {
        string senderEmail = (String)ConfigurationManager.AppSettings["senderEmail"];
        string senderHost = (String)ConfigurationManager.AppSettings["senderHost"];
        string senderPassword = (String)ConfigurationManager.AppSettings["senderPassword"];
        int senderPort = Convert.ToInt32(ConfigurationManager.AppSettings["senderPort"]);
        using (MailMessage mm = new MailMessage(senderEmail, emailTo))
        {
            mm.IsBodyHtml = true;
            mm.Subject = "Password Reset For Chanakaya";
            mm.Body = string.Format(@"<p style='color: rgb(91, 91, 91); font-family: arial; line-height: 17px;>Hi there!</p>
<p style='color: rgb(91, 91, 91); font-family: arial; line-height: 17px;'>Somebody recently asked to&nbsp;<span class='il'>reset</span>&nbsp;your Chanakaya account&nbsp;<span class='il'>password</span>.</p>
<p style='color: rgb(91, 91, 91); font-family: arial; line-height: 17px;'>Click to {0}<span class='il'>reset</span>&nbsp;your&nbsp;<span class='il'>password</span>.</p>
<p style='color: rgb(91, 91, 91); font-family: arial; line-height: 17px;'>If you did not request a new&nbsp;<span class='il'>password</span>, please let us know immediately at<a href='mailto:mis.help@nitp.ac.in' style='color: rgb(0, 186, 240); text-decoration: none;' target='_blank'>mis.help@nitp.ac.in</a></p>
<p style='color: rgb(91, 91, 91); font-family: arial; line-height: 17px;'>MIS Team</p>", token);
            SmtpClient smtp = new SmtpClient();
            smtp.Host = senderHost;
            smtp.EnableSsl = true;
            NetworkCredential NetworkCred = new NetworkCredential(senderEmail, senderPassword);
            smtp.UseDefaultCredentials = true;
            smtp.Credentials = NetworkCred;
            smtp.Port = senderPort;
            smtp.Send(mm);
        }
        return true;
    }

    public bool SendEmail(string emailTo, string subject, string token)
    {
        string senderEmail = (String)ConfigurationManager.AppSettings["senderEmail"];
        string senderHost = (String)ConfigurationManager.AppSettings["senderHost"];
        string senderPassword = (String)ConfigurationManager.AppSettings["senderPassword"];
        int senderPort = Convert.ToInt32(ConfigurationManager.AppSettings["senderPort"]);
        using (MailMessage mm = new MailMessage(senderEmail, emailTo))
        {
            mm.IsBodyHtml = true;
            mm.Subject = subject;
            mm.Body = token;//string.Format(token);
            SmtpClient smtp = new SmtpClient();
            smtp.Host = senderHost;
            smtp.EnableSsl = true;
            NetworkCredential NetworkCred = new NetworkCredential(senderEmail, senderPassword);
            smtp.UseDefaultCredentials = true;
            smtp.Credentials = NetworkCred;
            smtp.Port = senderPort;
            smtp.Send(mm);
        }
        return true;
    }
}
