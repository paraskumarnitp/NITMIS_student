using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NIC.ApplicationFramework.Data;
using NIC.Connection;
using System.Data.SqlClient;


/// <summary>
/// Summary description for GetCertIssueDetail
/// </summary>
public class GetCertIssueDetail
{
    public string Name;
    public string sDoB;
    public string sCertTypeCd;
    public string IssueDate;
    public string sDesignation;

	public GetCertIssueDetail()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public bool GetDetail(string CertificateNo, string Level, string LevelCode, string CertTypeCode)
    {
        try
        {
            //string sql = "Select a.ReceiptDate, b.Name, b.DateOfBirth, c.CertType from (Receipt a inner join Applicant b on a.ReceiptNo=b.ReceiptNo) inner join CERTIFICATETYPE c on (c.CertTypeCode=b.CertTypeCode) where a.ReceiptNo=@pReceiptNo";
            //string sql = "Select convert(char,a.ReceiptDate,106), a.ApplicantName, a.DateOfBirth, b.CertType,b.CertTypeCode from Receipt a inner join CERTIFICATETYPE b on (b.CertTypeCode=a.CertTypeCode) where a.ReceiptNo=@pReceiptNo";
            //1810100003
            //string sql = "Select convert(varchar,a.IssueDate,106), a.ApplicantName, convert(varchar,a.DateOfBirth,106), b.CertType,b.CertTypeCode from Receipt a inner join CERTIFICATETYPE b on (b.CertTypeCode=a.CertTypeCode) where a.ReceiptNo=@pReceiptNo and a.[level]=@pLevel and a.levelcode=@pLevelCode and a.certtypecode=@pCertTypeCode";
            string sql = "select a.certtypecode,d.designation, convert(varchar,issuedate,106) , convert(varchar,dateofbirth,106),name from certificateissue a, applicant b, officer c, Designation d where a.[level]=b.[level] and a.levelcode=b.levelcode and a.receiptno=b.receiptno and c.offcode=c.offcode and a.[level]=c.[level] and a.levelcode=c.levelcode and c.DesigCode=d.DesigCode and a.CertificateNo=@pCertificateNo and a.[level]=@pLevel and a.levelcode=@pLevelCode and a.certtypecode=@pCertTypeCode";

            //pReceiptNo and [level]=@pLevel and levelcode=@LevelCode";
            SqlParameter[] myParameter = new SqlParameter[4];
            
            myParameter[0] = new SqlParameter("pCertificateNo", SqlDbType.Char, 6);
            myParameter[1] = new SqlParameter("pLevel", SqlDbType.Char, 1);
            myParameter[2] = new SqlParameter("pLevelCode", SqlDbType.VarChar, 4);
            myParameter[3] = new SqlParameter("pCertTypeCode", SqlDbType.Char, 2);

            myParameter[0].Value = CertificateNo;
            myParameter[1].Value = Level;
            myParameter[2].Value = LevelCode;
            myParameter[3].Value = CertTypeCode;

            SqlDataReader odr;

            odr = (SqlHelper.ExecuteReader(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql, myParameter));

            if (odr.Read())
            {
                //ReceiptDate = odr.GetDateTime(0);
                IssueDate = odr.GetString(2);
                Name = odr.GetString(4);
                sDoB = odr.GetString(3);                
                sCertTypeCd = odr.GetString(0);
                sDesignation = odr.GetString(1);
                return true;
            }
            else
                return false;
        }
        catch
        {
            return false;
        }
    }
}
