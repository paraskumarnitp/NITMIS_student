using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;

/// <summary>
/// Summary description for pwdrand
/// </summary>
public class pwdrand
{
    public static readonly Random random=new Random();
	public pwdrand()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public string generate()
    {
        

// get 1st random string 
string Rand1 = RandomString(2);
string Rand3 = Randomnumber();

string Rand2 = RandomString(2);
// create full rand string
string docNum = Rand1 + Rand3 + Rand2;
return docNum;
       
    
    }
    private static string RandomString(int size)
    {
        StringBuilder builder = new StringBuilder();
       
        char ch;
        for (int i = 0; i < size; i++)
        {
            ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
            builder.Append(ch);
         
        }

        return builder.ToString();

    }

    private static string Randomnumber()
    {
        StringBuilder builder = new StringBuilder();
        Random random = new Random();
        int i = random.Next(1000, 9999);
     
            builder.Append(i.ToString());


        return builder.ToString();

    }
}
