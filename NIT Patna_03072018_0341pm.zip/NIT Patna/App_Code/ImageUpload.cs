using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.UI.Design;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
/// <summary>
/// Summary description for ImageUpload
/// </summary>
public class ImageUpload
{
    public ImageUpload()
    {
    }
    //HtmlInputFile 
    public String ImageSave(FileUpload ScanImage,String AckNo)
    { 
    
    try
        {

            //FileInfo imageInfo = new FileInfo(ScanImage.Value.Trim());
        
                //ScanImage.PostedFile.FileName = "";

        string file = Path.GetFullPath(ScanImage.PostedFile.FileName);

            //ViewState.Add("path", imageInfo).ToString();
            if (file!=null)
                
                return "please select one image file.";
            else
            {
                //switch (true)
                //{ 
                //    // uploading/save into database
                //    case ".JPG": UpLoadImageFile(imageInfo,AckNo); break;
                //    case ".JPEG": UpLoadImageFile(imageInfo, AckNo); break;
                //    case ".GIF": UpLoadImageFile(imageInfo,AckNo); break;
                //    case ".BMP": UpLoadImageFile(imageInfo,AckNo); break;

                //     //default: this.RegisterClientScriptBlock("alertMsg", "<script>alert('file type error.');</script>"); break;
                //    default:
                //        return "File Type Error";
                //}

               // UpLoadImageFile(file, AckNo);
               
            }
        }
        catch (Exception ex)
        {
            return ex.Message;
            
        }

        // thats show the image from database.
                try
                {
                    
                    return Image_Load(AckNo ); 
                    
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }

	}
    

    // For Photo
    public String Image_Load(String AckNo)
    { 
        string strFileName = "";
       // string strTempPath = "";
        SqlConnection con = new SqlConnection();
        try
        {
           

            
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            SqlCommand cmdSelect = new SqlCommand("select Photo from registration where AckNo=@AckNumber", con);
            SqlParameter cmdSelectParameters = new SqlParameter("@AckNumber", SqlDbType.Char);

            if (AckNo.Equals(""))
                cmdSelectParameters.Value = "";
            else
                cmdSelectParameters.Value =AckNo;
            cmdSelect.Parameters.Add(cmdSelectParameters);

            con.Open();

            byte[] barrImg = (byte[])cmdSelect.ExecuteScalar();
            strFileName = System.Web.HttpContext.Current.Server.MapPath(@".\image\temp.jpg");
                 
            FileStream fs = new FileStream(strFileName  , FileMode.OpenOrCreate, FileAccess.Write);
            int offset = 0;
            fs.Write(barrImg, offset, barrImg.Length - offset);
            fs.Flush();
            fs.Close();
            fs = null;
            
            return strFileName;
        }
        catch (Exception ex)
        {
            //LblMsg.Text = ex.Message;
            //Image1.ImageUrl = @".\Image\UploadPhoto.JPG";
           // strFileName = 
            return @".\Image\UploadPhoto.JPG";
        }
        finally
        {
            con.Close();
        }
    }

 
    
    // For Signature
    public String Sign_Load(String AckNo)
    {
        string strFileName = "";
        // string strTempPath = "";
        SqlConnection con = new SqlConnection();
        try
        {



            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            SqlCommand cmdSelect = new SqlCommand("select Signature from registration where AckNo=@AckNumber", con);
            SqlParameter cmdSelectParameters = new SqlParameter("@AckNumber", SqlDbType.Char);

            if (AckNo.Equals(""))
                cmdSelectParameters.Value = "";
            else
                cmdSelectParameters.Value = AckNo;
            cmdSelect.Parameters.Add(cmdSelectParameters);

            con.Open();

            byte[] barrImg = (byte[])cmdSelect.ExecuteScalar();
            strFileName = System.Web.HttpContext.Current.Server.MapPath(@".\image\temp1.jpg");

            FileStream fs = new FileStream(strFileName, FileMode.OpenOrCreate, FileAccess.Write);
            int offset = 0;
            fs.Write(barrImg, offset, barrImg.Length - offset);
            fs.Flush();
            fs.Close();
            fs = null;

            return strFileName;
        }
        catch (Exception ex)
        {
            //LblMsg.Text = ex.Message;
            //Image1.ImageUrl = @".\Image\UploadPhoto.JPG";
            // strFileName = 
            return @".\Image\UploadSIGN.JPG";
        }
        finally
        {
            con.Close();
        }
    }
    //public void UpLoadImageFile(string info,String AckNo)
    //{

    //    SqlConnection con = new SqlConnection();
    //    SqlCommand objcmd = new SqlCommand();
    //    objcmd.Connection = con;
    //    con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

    //    try
    //    {
    //        byte[] content = new byte[info.Length];
    //        FileStream imagestream = info.OpenRead();
    //        imagestream.Read(content, 0, content.Length);
    //        imagestream.Close();


    //        objcmd = new SqlCommand("update Registration set Photo=@Picture where AckNo=@AckNumber", con);
    //        SqlParameter AckParameter = new SqlParameter("@AckNumber", SqlDbType.Char);

    //        if (AckNo.Equals(""))
    //            AckParameter.Value = "";
    //        else
    //            AckParameter.Value = AckNo;
    //        objcmd.Parameters.Add(AckParameter);


    //        SqlParameter pictureParameter = new SqlParameter("@Picture", SqlDbType.Image);
    //        pictureParameter.Value = content;
    //        objcmd.Parameters.Add(pictureParameter);

    //        con.Open();
    //        objcmd.ExecuteNonQuery();
    //        con.Close();
    //    }
    //    catch (Exception ex)
    //    {
    //        throw new Exception(ex.Message);
    //    }
    //    finally
    //    {
    //        con.Close();
            
    //    }
    //}


    public string UpdateImage(Int32 length, Byte[] value, string TempRollNo)
    {
        SqlConnection con = new SqlConnection();
        try
        {
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Update registration set photo=@photo where ackno='" + TempRollNo + "'";
            cmd.Connection = con;
            cmd.Parameters.Add("@photo", SqlDbType.Image, length).Value = value;
            cmd.ExecuteNonQuery();
            return "1";
        }
        catch (Exception ex)
        {
            return ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }
    }

    public string UpdateSign(Int32 length, Byte[] value, string AckNo)
    {
        SqlConnection con = new SqlConnection();
        try
        {
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Update registration set Signature=@photo where AckNo='" + AckNo + "'";
            cmd.Connection = con;
            cmd.Parameters.Add("@photo", SqlDbType.Image, length).Value = value;
            cmd.ExecuteNonQuery();
            return "1";
        }
        catch (Exception ex)
        {
            return ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }
    }


}
