using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


	/// <summary>
	/// Summary description for PopulateDDL.
	/// </summary>
	public class PopulateDDL
	{
		public PopulateDDL()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		public void Popualate(DropDownList ddl,String TableName,String SelectQuery,String dataTextField,String dataValueField)
		{
			DataSet DS=new DataSet(TableName);			
			DS=SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(),CommandType.Text,SelectQuery);
			ddl.DataSource=DS;			
			ddl.DataTextField=dataTextField;
			ddl.DataValueField=dataValueField.Trim();
			ddl.DataBind();
		}
		public void Popualate(DropDownList ddl,String TableName,String SelectQuery,String dataTextField,String dataValueField,String ParamName,String ParamValue,SqlDbType DataType)
		{
			
            SqlCommand cmd=new SqlCommand(SelectQuery);
			//cmd.Parameters.Add (new SqlParameter(ParamName,DataType).Value =ParamValue);
			cmd.Parameters.Add (new SqlParameter(ParamName,ParamValue ));
	     	DataSet DS=new DataSet(TableName);			
			DS=SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(),CommandType.Text,cmd.CommandText );
			ddl.DataSource=DS;			
			ddl.DataTextField=dataTextField;
			ddl.DataValueField=dataValueField;
			ddl.DataBind();

		}

	}


