using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NIC.ApplicationFramework.Data;
using NIC.Connection;


/// <summary>
/// Summary description for GetLevNLevCodeFromAbbv
/// </summary>
public class GetLevNLevCodeFromAbbv
{
	public GetLevNLevCodeFromAbbv()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public string  GetDetail(string LevelAbbv, string LevelCodeAbbv)
    {
        //try
        {
            string sql = "Select [level] from [Level] where LevelAbbv=@pLevelAbbv";
            SqlParameter[] myParameter1 = new SqlParameter[1];
            myParameter1[0] = new SqlParameter("pLevelAbbv", SqlDbType.VarChar, 1);

            myParameter1[0].Value = LevelAbbv;

            string Level = (Convert.ToString( SqlHelper.ExecuteScalar(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql, myParameter1)));

            sql = "";
            switch (Level)
            {
                case "1":
                    {
                        sql = "Select DistCode from district where distAbbv=@pLevelCode";
                        break;
                    }
                case "2":
                    {
                        sql = "Select subdivCode from subdivision where subdivAbbv=@pLevelCode";
                        break;
                    }

                case "3":
                    {
                        sql = "Select blockCode from Block where BlockAbbv=@pLevelCode";
                        break;
                    }

                case "4":
                    {
                        sql = "Select circleCode from Circle where CircleAbbv=@pLevelCode";
                        break;
                    }
            }

            SqlParameter[] myParameter = new SqlParameter[1];
            myParameter[0] = new SqlParameter("pLevelCode", SqlDbType.VarChar, 3);

            myParameter[0].Value = LevelCodeAbbv;

            SqlDataReader odr;

            odr = (SqlHelper.ExecuteReader(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql, myParameter));
            string LevelNameAb="";
            if (odr.Read())
            {
                LevelNameAb = Level.Trim() + "000".Substring(0, 3 - odr.GetString(0).Trim().Length) + odr.GetString(0).Trim();
                return (LevelNameAb);
            }
            else
                return (LevelNameAb);
        }
        //catch
        //{
        //    return ("");
        //}
    }
}
