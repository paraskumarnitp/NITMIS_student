using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NIC.ApplicationFramework.Data;
using NIC.Connection;


/// <summary>
/// Summary description for GetCertCodeFromAbbv
/// </summary>
public class GetCertCodeFromAbbv
{
	public GetCertCodeFromAbbv()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public string GetDetail(string CertTypeAbbv)
    {
       
            string sql = "Select CertTypeCode from CertificateType where CertTypeAbbv=@pCertTypeAbbv";
            SqlParameter[] myParameter1 = new SqlParameter[1];
            myParameter1[0] = new SqlParameter("pCertTypeAbbv", SqlDbType.VarChar, 2);

            myParameter1[0].Value = CertTypeAbbv;

            return  (Convert.ToString( SqlHelper.ExecuteScalar(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql, myParameter1)));

    }
}