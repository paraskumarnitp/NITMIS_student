using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
//using System.Security.Cryptography;

/// <summary>
/// Summary description for Encryption
/// </summary>
public class Encryption
{
	public Encryption()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public string EncryptPassword(string pwd)
    {
        char Character ;
        string Password = "";
        int CharacterAscii;
        char EncryptedCharacter;

        pwd = pwd.Substring(0, 1) + pwd + pwd.Substring(0, 1);

        int TotalLength = pwd.Length;
        int DynLength = TotalLength+2;

        for (int i = 0; i < TotalLength; i++)
        {
            Character = Convert.ToChar(pwd.Substring(i, 1));
            CharacterAscii = (int)(Character);
            int EncryptedCharacterAscii = CharacterAscii + (DynLength * 3) / 2;

            if (EncryptedCharacterAscii > 127)
            {
                int diff = (EncryptedCharacterAscii - 128)+DynLength;
                EncryptedCharacterAscii = EncryptedCharacterAscii - diff;
            }


            EncryptedCharacter = Convert.ToChar(EncryptedCharacterAscii);
            Password = Password + Convert.ToString(EncryptedCharacter);
            DynLength = DynLength - 1;
            //TotalLength = TotalLength - 1;
        }
       

        return Password;
    }
}
