using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NIC.ApplicationFramework.Data;
using NIC.Connection;
using System.Data.SqlClient;

 /// <summary>
    /// Summary description for GetReceiptDetail
    /// </summary>
    public class GetReceiptDetail
    {
        public string Name;
        public DateTime DoB;
        public string sDoB;
        public string sCertTypeCd;
        //public DateTime ReceiptDate;
        public string ReceiptDate;
        public string CertTypeCode;
        public string CertType;


        public GetReceiptDetail()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public bool GetDetail(string ReceiptNo)
        {
            try
            {
                //string sql = "Select a.ReceiptDate, b.Name, b.DateOfBirth, c.CertType from (Receipt a inner join Applicant b on a.ReceiptNo=b.ReceiptNo) inner join CERTIFICATETYPE c on (c.CertTypeCode=b.CertTypeCode) where a.ReceiptNo=@pReceiptNo";
                string sql = "Select convert(varchar,a.ReceiptDate,106), a.ApplicantName, a.DateOfBirth, b.CertType,b.CertTypeCode from Receipt a inner join CERTIFICATETYPE b on (b.CertTypeCode=a.CertTypeCode) where a.ReceiptNo=@pReceiptNo";
                SqlParameter sqlparameter = new SqlParameter("pReceiptNo", SqlDbType.Char, 6);
                sqlparameter.Value = ReceiptNo;

                SqlDataReader odr;

                odr = (SqlHelper.ExecuteReader(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql, sqlparameter));

                if (odr.Read())
                {
                    //ReceiptDate = odr.GetDateTime(0);
                    ReceiptDate = odr.GetString(0);
                    Name = odr.GetString(1);
                    DoB = odr.GetDateTime(2);
                    CertType = odr.GetString(3);
                    CertTypeCode = odr.GetString(4);
                    return true;    
                }
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }

        public bool GetDetail(string ReceiptNo, string Level , string LevelCode,string CertTypeCode)
        {
            try
            {
                //string sql = "Select a.ReceiptDate, b.Name, b.DateOfBirth, c.CertType from (Receipt a inner join Applicant b on a.ReceiptNo=b.ReceiptNo) inner join CERTIFICATETYPE c on (c.CertTypeCode=b.CertTypeCode) where a.ReceiptNo=@pReceiptNo";
                //string sql = "Select convert(char,a.ReceiptDate,106), a.ApplicantName, a.DateOfBirth, b.CertType,b.CertTypeCode from Receipt a inner join CERTIFICATETYPE b on (b.CertTypeCode=a.CertTypeCode) where a.ReceiptNo=@pReceiptNo";
                //1810100003
                string sql = "Select convert(varchar,a.ReceiptDate,106), a.ApplicantName, convert(varchar,a.DateOfBirth,106), b.CertType,b.CertTypeCode from Receipt a inner join CERTIFICATETYPE b on (b.CertTypeCode=a.CertTypeCode) where a.ReceiptNo=@pReceiptNo and a.[level]=@pLevel and a.levelcode=@pLevelCode and a.certtypecode=@pCertTypeCode";

                //pReceiptNo and [level]=@pLevel and levelcode=@LevelCode";
                SqlParameter[] myParameter = new SqlParameter [4];
                myParameter[0] = new SqlParameter("pReceiptNo",SqlDbType.Char , 6);
                myParameter[1] = new SqlParameter("pLevel", SqlDbType.Char, 1);
                myParameter[2] = new SqlParameter("pLevelCode", SqlDbType.VarChar, 4);
                myParameter[3] = new SqlParameter("pCertTypeCode", SqlDbType.Char, 2);

                myParameter[0].Value = ReceiptNo;
                myParameter[1].Value =Level;
                myParameter[2].Value = LevelCode;
                myParameter[3].Value = CertTypeCode;               

                SqlDataReader odr;

                odr = (SqlHelper.ExecuteReader(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql, myParameter));

                if (odr.Read())
                {
                    ReceiptDate = odr.GetString(0);
                    Name = odr.GetString(1);
                    sDoB = odr.GetString(2);
                    CertType = odr.GetString(3);
                    sCertTypeCd = odr.GetString(4);
                    return true;
                }
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }
    }