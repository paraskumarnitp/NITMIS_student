using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Text;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Functionreviseed
/// </summary>
public class Functionreviseed
{
	public Functionreviseed()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ToString());
    DataSet ds;
    DataTable dt;
    public DataSet SelectDataset(string query)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);
            con.Close();
            
        }
        catch (Exception ex)
        {
            
        }
        return ds;

    }
    public DataTable SelectDatatablecmd(SqlCommand cmd)
    {
        try
        {
            con.Open();            
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            con.Close();

        }
        catch (Exception ex)
        {
            
        }
        finally
        {
            con.Close();
        }
        return dt;

    }
    public DataTable SelectDatatable(string query)
    {
        SqlConnection con1 = new SqlConnection(ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ToString());
        try
        {
           
            con1.Open();
            SqlCommand cmd = new SqlCommand(query, con1);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            con1.Close();

        }
        catch (Exception ex)
        {

        }
        finally {
            con1.Close();
            con1.Dispose();
        }
        return dt;

    }
    public object singlevalue(String query)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand(query, con);
        object dtdate = cmd.ExecuteScalar();
        con.Close();
        return dtdate;
    }

    public int InsertUpdateDelete(string query)
    {

        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            return cmd.ExecuteNonQuery();

        }
        catch (SqlException ex)
        {
            if (ex.Number == 2627)
            {
                return -1000;
            }
        }
        finally
        {
            con.Close();
        }
        return 0;

    }

    //this function Convert to Encord 
    public string EncodePasswordToBase64(string password)
    {
        try
        {
            byte[] encData_byte = new byte[password.Length];
            encData_byte = System.Text.Encoding.UTF8.GetBytes(password);
            string encodedData = Convert.ToBase64String(encData_byte);
            return encodedData;
        }
        catch (Exception ex)
        {
            throw new Exception("Error in base64Encode" + ex.Message);
        }
    } //this function Convert to Decord 
    public string DecodeFrom64(string encodedData)
    {
        System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
        System.Text.Decoder utf8Decode = encoder.GetDecoder();
        byte[] todecode_byte = Convert.FromBase64String(encodedData);
        int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
        char[] decoded_char = new char[charCount];
        utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
        string result = new String(decoded_char);
        return result;
    }
}
