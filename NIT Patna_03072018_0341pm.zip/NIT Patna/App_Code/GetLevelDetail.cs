using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NIC.ApplicationFramework.Data;
using NIC.Connection;
using System.Data.SqlClient;

/// <summary>
/// Summary description for GetLevelDetail
/// </summary>
public class GetLevelDetail
{
    public string LevelName;
    

	public GetLevelDetail()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public bool GetDetail( string Level, string LevelCode)
    {
        try
        {

            string sql = "";
            switch (Level)
            {
                case "1":
                    {
                        sql = "Select distname from district where distcode=@pLevelCode";
                        break;
                    }
                case "2":
                    {
                        sql = "Select subdivname from subdivision where subdivcode=@pLevelCode";
                        break;
                    }

                case "3":
                    {
                        sql = "Select blockname from Block where Blockcode=@pLevelCode";
                        break;
                    }

                case "4":
                    {
                        sql = "Select circlename from Circle where Circlecode=@pLevelCode";
                        break;
                    }
            }
                    
            SqlParameter[] myParameter = new SqlParameter[1];
            myParameter[0] = new SqlParameter("pLevelCode", SqlDbType.VarChar, 4);

            myParameter[0].Value = LevelCode ;

            SqlDataReader odr;

            odr = (SqlHelper.ExecuteReader(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql, myParameter));

            if (odr.Read())
            {
                LevelName = odr.GetString(0);
                return true;
            }
            else
                return false;
        }
        catch
        {
            return false;
        }
    }
}
