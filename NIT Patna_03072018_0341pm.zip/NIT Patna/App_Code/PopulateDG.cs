using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NIC.Connection;
using NIC.ApplicationFramework.Data;



	/// <summary>
	/// Summary description for PopulateDG.
	/// </summary>
	public class PopulateDG
	{
		public PopulateDG()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public void Popualate(DataGrid dg,String TableName,String SelectQuery)
		{
			DataSet DS=new DataSet(TableName);			
			DS=SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(),CommandType.Text,SelectQuery);
			dg.DataSource=DS;			
			dg.DataBind();

		}

        public void Popualate(GridView dgv, String TableName, String SelectQuery)
        {
            DataSet DS = new DataSet(TableName);
            DS = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, SelectQuery);
            dgv.DataSource = DS;
            dgv.DataBind();

        }
		public void Popualate(SqlConnection sqlCon, DataGrid dg,String TableName,String SelectQuery)
		{
			DataSet DS=new DataSet(TableName);	
			SqlCommand cmd1=new SqlCommand (SelectQuery,sqlCon);
			
			SqlDataAdapter da = new SqlDataAdapter(cmd1);

			//fill the DataSet using default values for DataTable names, etc.
			da.Fill(DS);	

			//DS=SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(),CommandType.Text,SelectQuery);
			dg.DataSource=DS;			
			dg.DataBind();

		}
	}

