using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class Caste : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
            if (!Page.IsPostBack)
            {
                try
                {
                    if (Session["Role"].ToString() != "1")
                    {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                    }
                }
                catch (Exception ex)
                {
                       Response.Redirect("default.aspx");
                }
                
                PopulateDDL popddl = new PopulateDDL();
                popddl.Popualate(CategoryNm, "Category", "Select Category,CategoryCode from Category order by CategoryCode", "Category", "CategoryCode");
                ViewState.Add("EditMode", "false");
                ViewState.Add("DeleteFlag", "0");  
                CategoryNm.Focus(); 
            }
        
           
       

    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {
       
         string abc = "";
         Panel2.Visible = false;
         if (ViewState["EditMode"].ToString() == "false")
         {

             string[] col = new string[3];
             string[] val = new string[3];
             col[0] = "CategoryCode";
             col[1] = "CasteCode";
             col[2] = "Caste";

             val[0] = CategoryNm.SelectedValue.ToString();
             val[2] = CateNm.Text.Trim();


             UnivService.Service1 ss = new UnivService.Service1();
             string SQL = "SELECT     ISNULL(MAX(CasteCode), '0') + 1 AS NewCasteCode FROM CASTE";

             string NewCasteCode = ss.GetNewCode(SQL);
             val[1] = NewCasteCode;

             abc = ss.SaveData("Caste", col, val);

             if (abc == "1")
             {
                 LblMsg.Text = " Caste is saved successfully. Caste Code= " + NewCasteCode;
                 string popupScript = "<script language='javascript'>" +
                                " alert('Caste Code=   " + NewCasteCode + " is saved successfully. ')" +
                                 "</script>";

                 Page.RegisterStartupScript("PopupScript", popupScript);
                 CateNm.Text = "";
                 CateNm.Focus();


             }
             else
             {
                 LblMsg.Text = abc.ToString();
             }
         }
         else
         {

             UnivService.Service1 ss = new UnivService.Service1();
             abc = " update caste set caste='" +CateNm.Text + "', CategoryCode='"+CategoryNm.SelectedValue.ToString ()   +"' where CasteCode='" + CasteView.SelectedRow.Cells[3].Text.Trim () + "'";
             abc = ss.UpdateData(abc);
             if (abc.ToString() == "ok")
             {
                 ViewState.Add("EditMode", "false");
                 LblMsg.Text = " Record is updated successfully.";
                 CateNm.Text = "";
                 CateNm.Focus(); 

             }
             else
                 LblMsg.Text = abc.ToString();

         }



    }
    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        GridBind(); 
    }
    protected void BtnPrint_Click(object sender, ImageClickEventArgs e)
    {

    }
    protected void CasteView_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ViewState["DeleteFlag"].ToString() == "1")
        {
            UnivService.Service1 ss = new UnivService.Service1();
            string abc = ss.UpdateData("delete from caste where CasteCode='" + CasteView.SelectedRow.Cells[3].Text.Trim() + "'");
            if (abc.ToString() == "ok")
            {
                GridBind();
                LblMsg.Text = " Record is deleted successfully.";
                

            }
            else
                   LblMsg.Text = abc.ToString();
                   ViewState.Add("DeleteFlag", "0");
                   ViewState.Add("EditMode", "false");
                   CateNm.Text = "";
                   CateNm.Focus();
            
            
        }
        else
        {
            CateNm.Text = CasteView.SelectedRow.Cells[4].Text;
            CategoryNm.SelectedValue = CasteView.SelectedRow.Cells[2].Text;
            ViewState.Add("EditMode", "true");
        }
        

    }
    
    //protected void Delete_Click(object sender, EventArgs e)
    //{
    //    UnivService.Service1 ss = new UnivService.Service1();
    //    string abc = " delete from caste where CasteCode='" + CasteView.SelectedRow.Cells[2].Text.Trim() + "'";
    //    abc = ss.UpdateData(abc);
    //    if (abc.ToString() == "ok")
    //    {
            
    //        LblMsg.Text = " Record is deleted successfully.";
    //        CateNm.Text = "";
    //        CateNm.Focus();

    //    }
    //    else
    //        LblMsg.Text = abc.ToString();
    //}
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        ViewState.Add("DeleteFlag", "1");  
    }
    void GridBind()
    {
        Panel2.Visible = true;
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select * from Caste order by CategoryCode,casteCode");
        CasteView.DataSource = ds;
        CasteView.DataBind(); 

    }
}
