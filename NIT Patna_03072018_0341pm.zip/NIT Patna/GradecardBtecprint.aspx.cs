using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;

public partial class GradecardBtecprint : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    ReportDocument crystalReport = new ReportDocument();
    string streamcode, streampartcode, examyear, str, streamtypecode;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "3") && (Session["Role"].ToString() != "7"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
        }
        streamcode = Request.QueryString["sc"];
        streampartcode = Request.QueryString["spc"];
        examyear = Request.QueryString["ey"];
        streamtypecode = Request.QueryString["stmtp"];
        if (Session["btechgrage"] != null)
            CrystalReportViewer1.ReportSource = Session["btechgrage"];
        if (!Page.IsPostBack)
        {
            btechgrade();
        }



    }

    private DSGradeCard GetData(string query)
    {
        string conString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlCommand cmd = new SqlCommand(query);
        using (SqlConnection con = new SqlConnection(conString))
        {
            using (SqlDataAdapter sda = new SqlDataAdapter())
            {
                cmd.Connection = con;

                sda.SelectCommand = cmd;
                using (DSGradeCard dsgrade = new DSGradeCard())
                {
                    sda.Fill(dsgrade, "DataTable1");
                    return dsgrade;
                }
            }
        }
    }
    DSGradeCard dsgrade;
    private void btechgrade()
    {

        crystalReport.Load(Server.MapPath("~/Report/MarksSheetBtech.rpt"));
        string Querystr = "";

        if (streampartcode.IndexOf('A') > 0 || streampartcode.IndexOf('B') > 0)
        {
            Querystr = " (BtecGrade.StreamPart = '" + streampartcode + "')";

        }
        else
        {
            if (streamtypecode == "01")
                Querystr = " cgpa.StreamPart ='" + streampartcode + "'";
            else if (streamtypecode == "02")
                Querystr = "cgpa_Mtec.StreamPart ='" + streampartcode + "'";
        }
       
        if (streamtypecode == "01")
        {
            dsgrade = GetData("SELECT     BtecGrade.GrcardNo, cgpa.EName, BtecGrade.UnivRollNo, BtecGrade.Enrollmentno, "+
                               " BtecGrade.StreamAbbr, BtecGrade.StreamPart, BtecGrade.Marks_percent, "+
                                " BtecGrade.Remarks, BtecGrade.SGPA, BtecGrade.CGPA, "+
                                " CONVERT(VARCHAR(15), BtecGrade.GenDate, 105) AS GenDate, "+
                                " COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName, COURSEPAPERS.L + '-' + COURSEPAPERS.T + '-' + COURSEPAPERS.P AS LTP, "+
                                " COURSEPAPERS.Credit, cgpa.Grade,  "+
                                " BtecGrade.ExamSession, "+
                                " LEFT(SUBSTRING(COURSEPAPERS.StreamPart, PATINDEX('%[0-9.]%', COURSEPAPERS.StreamPart), 5000), PATINDEX('%[^0-9.]%', "+
                                " SUBSTRING(COURSEPAPERS.StreamPart, PATINDEX('%[0-9.]%', COURSEPAPERS.StreamPart), 5000) + 'X') - 1) AS semvalue, STREAM.Duration "+
                                " FROM         BtecGrade INNER JOIN "+
                                " cgpa ON BtecGrade.UnivRollNo = cgpa.UnivRollNo INNER JOIN "+
                                " COURSEPAPERS ON cgpa.SubPaperCode = COURSEPAPERS.SubPaperCode  "+
                                " INNER JOIN STREAM ON COURSEPAPERS.StreamCode = STREAM.StreamCode INNER JOIN STREAMPART ON BtecGrade.StreamPart = STREAMPART.StreamPart AND cgpa.StreamPart = STREAMPART.StreamPartCode"+
                                " Where BtecGrade.ExamSession ='" + examyear + "' and " + Querystr);
        }
        else if (streamtypecode == "02")
        {
            dsgrade = GetData("SELECT MtecGrade.GrcardNo, cgpa_Mtec.EName, MtecGrade.UnivRollNo, MtecGrade.Enrollmentno, " + 
                 " MtecGrade.StreamAbbr, MtecGrade.StreamPart, MtecGrade.Marks_percent, MtecGrade.Remarks, MtecGrade.SGPA, " + 
                 " MtecGrade.CGPA, CONVERT(VARCHAR(15), MtecGrade.GenDate, 105) AS GenDate, COURSEPAPERS.PaperAbbr, " + 
                 " COURSEPAPERS.PaperName, COURSEPAPERS.L + '-' + COURSEPAPERS.T + '-' + COURSEPAPERS.P AS LTP, " +
                 " COURSEPAPERS.Credit, cgpa_Mtec.Grade, MtecGrade.ExamSession, LEFT(SUBSTRING(COURSEPAPERS.StreamPart, " + 
                 " PATINDEX('%[0-9.]%', COURSEPAPERS.StreamPart), 5000), PATINDEX('%[^0-9.]%', SUBSTRING(COURSEPAPERS.StreamPart, " + 
                 " PATINDEX('%[0-9.]%', COURSEPAPERS.StreamPart), 5000) + 'X') - 1) AS semvalue, STREAM.Duration "+
                 " FROM         MtecGrade INNER JOIN "+
                 " cgpa_Mtec ON MtecGrade.UnivRollNo = cgpa_Mtec.UnivRollNo INNER JOIN " +
                 " COURSEPAPERS ON cgpa_Mtec.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN "+
                 " STREAM ON COURSEPAPERS.StreamCode = STREAM.StreamCode INNER JOIN STREAMPART ON MtecGrade.StreamPart = STREAMPART.StreamPart AND cgpa_Mtec.StreamPart = STREAMPART.StreamPartCode" +
                 " Where MtecGrade.ExamSession ='" + examyear + "' and " + Querystr);
        }
        crystalReport.SetDataSource(dsgrade);
        Session["btechgrage"] = crystalReport;
        CrystalReportViewer1.ReportSource = crystalReport;
    }

    protected void Btnnext_Click(object sender, EventArgs e)
    {
        crystalReport.Load(Server.MapPath("~/Report/MarksSheetBtechBack.rpt"));
        Session["btechgrage"] = crystalReport;
        CrystalReportViewer1.ReportSource = crystalReport;

    }
    protected void Btnprev_Click(object sender, EventArgs e)
    {
        btechgrade();

    }

    //protected void Page_LoadComplete(object sender, EventArgs e)
    //{
    //    CrystalReportViewer1.ReportSource = Session["btechgrage"];
    //}
}
