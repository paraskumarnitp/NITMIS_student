using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class ViewCollege : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DataSet ds = new DataSet();
        string SqlQuery = "SELECT  dbo.COLLEGE.CollCode, dbo.COLLEGE.CollName, dbo.COLLEGE.CollType, dbo.COLLEGE.DateOfConst, dbo.COLLEGE.PrincipalName, dbo.COLLEGE.Address1, dbo.COLLEGE.Address2, dbo.DISTRICT.DistName, dbo.COLLEGE.PinCode, " +
                          "dbo.COLLEGE.PhoneNo, dbo.COLLEGE.Email, dbo.COLLEGE.Fax, dbo.COLLEGE.ExamCapacity FROM         dbo.COLLEGE INNER JOIN" +
                          " dbo.DISTRICT ON dbo.COLLEGE.DistCode = dbo.DISTRICT.DistCode WHERE     (dbo.COLLEGE.CollCode <> '0')" +
                          "ORDER BY dbo.COLLEGE.CollCode";
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, SqlQuery);
        CollegeView.DataSource = ds;
        CollegeView.DataBind();
    }
    protected void UniversityView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
