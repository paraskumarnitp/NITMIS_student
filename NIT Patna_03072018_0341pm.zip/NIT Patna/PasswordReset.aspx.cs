using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class PasswordReset : System.Web.UI.Page
{
    SqlConnection con;
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            string token = Request.QueryString["Token"];
            DataTable dt = fnrev.SelectDatatable("select * from ForgotToken where Status=0 and DATEDIFF(MINUTE,Created,GETDATE())<=60 and Token='" + token + "'");
            if (dt.Rows.Count > 0)
            {
                string userId = dt.Rows[0]["UserId"].ToString();
                ViewState["UserId"] = userId;
                Div3.Visible = true;
            }
            else
            {
                Div3.Visible = false;
                Lblmsg1.Text = "Please Try again with Password Reset Link";
            }
        }

    }

    public string GetConnectionString()
    {
        return System.Configuration.ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

    }


    protected void loginlink_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Default.aspx");
    }
    protected void btnpasschange_Click(object sender, EventArgs e)
    {
        try
        {
            Encryption enc = new Encryption();

            if (txtconfpass.Text != txtpass.Text)
            {
                txtconfpass.Text = "";
                txtpass.Text = "";
                txtpass.Focus();
                Label1.Text = "Please Re-Enter New Password";
                return;
            }


            string sql = "";
            UnivService.Service1 ss = new UnivService.Service1();
            string abc = "";
            sql = "";
            sql = "Update ForgotToken set status=1 where UserId='" + ViewState["UserId"].ToString() + "'";
            abc = ss.UpdateData(sql);
            sql = "Update LOGIN Set Password='" + enc.EncryptPassword(txtpass.Text.ToString()) + "' where UserId='" + ViewState["UserId"].ToString() + "' ";
            abc = ss.UpdateData(sql);

            if (abc == "ok")
            {
                txtconfpass.Text = "";
                txtpass.Text = "";
                txtpass.Focus();
                string msg = "Password Changed Successfully";
                string popupScript = "<script language='javascript'>" +
                                   " alert('" + msg + " ')" +
                                    "</script>";
                Page.RegisterStartupScript("PopupScript", popupScript);
            }
            else
            {
                Label1.Text = abc.ToString();
            }
        }
        catch (Exception ex)
        {
            Lblmsg1.Text = ex.ToString();
        }
        finally
        {
            Response.Redirect("~/Default.aspx");

        }
    }
}
