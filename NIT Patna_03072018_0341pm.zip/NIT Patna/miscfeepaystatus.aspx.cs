using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class miscfeepaystatus : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        string querypart = "";
        if (all.Checked == true)
        {
            querypart = "";
        }
        else if (individual.Checked == true)
        {             
            querypart = "and AdditionalInfo1 = '' and authStatus = '0399'";
        }
        DataTable dtdetails = fnrev.SelectDatatable("SELECT CustomerId, txnReferenceNo, bankReferenceNo, txnAmount, " +
            " txnDate, authStatus, AdditionalInfo1,AdditionalInfo5, AdditionalInfo6, ErrorStatus, " +
            " ErrorDescription FROM PGResponse WHERE (AdditionalInfo5 = 'MISCFEE') and authStatus = '0399'");
    }
}
