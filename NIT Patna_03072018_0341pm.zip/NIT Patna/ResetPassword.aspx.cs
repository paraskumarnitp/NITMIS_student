using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class ResetPassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "6")&& (Session["Role"].ToString() != "16"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
            }
            catch (Exception ex)
            {
                LblMsg.Text = ex.Message;
            }
            UserId.Focus();
        }
    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            string login;
            Encryption enc = new Encryption();

            if (NewPassword.Text != reNewPassword.Text)
            {
                reNewPassword.Text = "";
                NewPassword.Text = "";
                NewPassword.Focus();
                LblMsg.Text = "Please Re-Enter New Password";
                return;
            }


            string sql = "";
            //Validating Old Password
            UnivService.Service1 ss = new UnivService.Service1();
            sql = "Select Count(UserName) From Login where UserId='" + UserId.Text.ToString() + "' ";
            //login = ss.Login(UserId.Text.ToString(), enc.EncryptPassword(OldPassword.Text.ToString()));
            login = ss.GetNewCode(sql);

            if (login != "1")
            {
                LblMsg.Text = "Invalid User Id";
                return;
            }




            //Setting New Password

            string abc = "";
             sql = "";
           
            if (login == "1")
            {
                sql = "Update LOGIN Set Password='" + enc.EncryptPassword(NewPassword.Text.ToString()) + "' where UserId='" + UserId.Text.ToString() + "' ";

                abc = ss.UpdateData(sql);

                if (abc == "ok")
                {
                    LblMsg.Text = "Your Password has been changed successfully";

                    UserId.Text = "";
                    NewPassword.Text = "";
                    reNewPassword.Text = "";
                    UserId.Focus();
                }

                else
                {
                    LblMsg.Text = abc.ToString();
                }
            }

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

    }
}
