using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using System.IO;
using CrystalDecisions.Shared;

public partial class FacultyAssignprint : System.Web.UI.Page
{
    ReportDocument rpt = new ReportDocument();
    Functionreviseed fn = new Functionreviseed();
    string examyear, stmp;
    protected void Page_Load(object sender, EventArgs e)
    {
        examyear = Request.QueryString["examyear"];
        stmp = Request.QueryString["stmtp"];
        btechgrade();
    }
    protected void Page_Unload(object sender, EventArgs e)
    {
        if (rpt != null)
        {
            rpt.Close();
            rpt.Dispose();
        }
    }
    protected void btechgrade()
    {
        string whereSql = string.Empty;
        if (stmp == "1")
        {
            whereSql = " and f.userId is not  null ";
        }
        else if (stmp == "2")
        {
            whereSql = " and f.userId is null ";
        }
        string sql = " select distinct l.StreamTypeCode,l.StreamTypeName, d.StreamAbbr as Program,c.SplCode,h.SpDescription, " +
                      " b.StreamPart, a.SubPaperCode,b.PaperAbbr,b.PaperName,e.UserId,f.UserName from EXAMPAPERDETAIL a inner join COURSEPAPERS b on a.SubPaperCode=b.SubPaperCode " +
                      " inner join REGISTRATION c on a.RegNo=c.RegNo inner join STREAM d on c.StreamCode=d.StreamCode inner join STREAMTYPE l on l.StreamTypeCode=d.StreamTypeCode " +
                      " inner join CourseSpecialization h on h.SPCode=c.SplCode left join Faculty_paper_a e on a.ExamSession=e.ExamSession and a.SubPaperCode=e.SubPaperCode and c.SplCode=e.Splcode and e.Enabled='Y' and e.Is_Active='Y'  left join LogIn f on e.UserId=f.UserId	" +
                      " where a.ExamSession='" + examyear + "'  " + whereSql +
                      " order by l.StreamTypeCode, d.StreamAbbr,b.StreamPart ";
        DataTable dt = fn.SelectDatatable(sql);
        rpt.Load(Server.MapPath("~/Report/FacultyAssignprint.rpt"));
        dt.TableName = "Facult_assign";
        //dt.WriteXmlSchema(Server.MapPath("~/Trans_Marksheet.xsd"));
        rpt.SetDataSource(dt);
        MemoryStream oStream = new MemoryStream();
        oStream = (MemoryStream)rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
        Response.Clear();
        Response.Buffer = true;
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "inline;filename=report.pdf");
        Response.BinaryWrite(oStream.ToArray());
        Response.End();

        //rpt.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, false, "PersonDetails");



    }


}




//protected void Page_LoadComplete(object sender, EventArgs e)
//{
//    CrystalReportViewer1.ReportSource = Session["btechgrage"];
//}

