using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class MigrationStatus : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

        }
    }
    protected void BtnReg_Click(object sender, EventArgs e)
    {
        try
        {

            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;

            cmd.CommandText = " select ApplicantName from Registration where RegNo='" +RegNo.Text + "' And MigrationStatus='N'";
            SqlDataReader reader;
            LblMsg.Text = "";
            con.Open();
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {

                reader.Read();
                Panel2.Visible = true;
                StudentName.Text = reader["ApplicantName"].ToString();
                RegNo2.Text = RegNo.Text;  
                reader.Close();
                MigrationNo.Focus(); 
            }
            else
            {
                LblMsg.Text = " Please check Reg.No.";
                Panel2.Visible = false;
                RegNo.Focus(); 
            }
            con.Close();
            MigrationIssueDate.Text = System.DateTime.Now.Day + "/" + System.DateTime.Now.Month + "/" + System.DateTime.Now.Year;


        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }
    protected void BtnSave_Click(object sender, EventArgs e)
    {
        string[] col = new string[3];
        string[] val = new string[3];


        // Colume Variable--Field Name
        col[0] = "RegNo"; val[0] = RegNo2.Text;
        col[1] = "MigrationNo"; val[1] = MigrationNo.Text;
        col[2] = "MigrationIssueDate"; val[2] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(MigrationIssueDate.Text)); 
        
        try
        {
            string SaveFlag = "";
            UnivService.Service1 NicService = new UnivService.Service1();
            SaveFlag = NicService.SaveData("Migration", col, val);

            if (SaveFlag == "1")
            {
                LblMsg.Text = "Successfully Saved";
                NicService.UpdateData("Update Registration set MigrationStatus='Y' Where RegNo='"+RegNo2.Text +"'"); 
            }
            else
            {
                LblMsg.Text = "Error";
            }
        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }
}
