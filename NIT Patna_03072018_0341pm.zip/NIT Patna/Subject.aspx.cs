using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class Subject : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "1")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");

            ViewState.Add("EditMode", "false");
            SubjectName.Focus();
        }

    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {
        string abc = "";
        Panel2.Visible = false;
        if (ViewState["EditMode"].ToString() == "false")
        {

            string[] col = new string[4];
            string[] val = new string[4];
            
            col[0] = "StreamCode";
            col[1] = "SubCode";
            col[2] = "SubjectName";
            col[3] = "SubAbbr";

            val[0] = StreamCode.SelectedValue.ToString();
            val[2] = SubjectName.Text.Trim();
            val[3] = SubAbbr.Text.Trim();


            UnivService.Service1 ss = new UnivService.Service1();
            string SQL = "SELECT     ISNULL(MAX(SubCode), '0') + 1 AS NewSubCode FROM Subject";

            string NewSubCode = ss.GetNewCode(SQL);
            NewSubCode = string.Format("{0:D3}", Convert.ToInt16(NewSubCode));
            val[1] = NewSubCode;

            abc = ss.SaveData("Subject", col, val);


//---------------For Hons. Paper
            //string[] col1 = new string[4];
            //string[] val1 = new string[4];

            //col1[0] = "StreamCode";
            //col1[1] = "SubCode";
            //col1[2] = "SubjectName";
            //col1[3] = "SubAbbr";

            //val1[0] = StreamCode.SelectedValue.ToString();
            //val1[2] = SubjectName.Text.Trim();
            //val1[3] = SubAbbr.Text.Trim();

            //abc1 = ss.SaveData("Subject", col1, val1);
//---------------For Hons. Paper

            if (abc == "1")
            {
                LblMsg.Text = " Subject is saved successfully. Subject Code= " + NewSubCode;
                string popupScript = "<script language='javascript'>" +
                               " alert('Subject Code=   " + NewSubCode + " is saved successfully. ')" +
                                "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);
                //SubjectName.Text = "";
                //SubAbbr.Text = "";
                SubjectName.Focus();


            }
            else
            {
                LblMsg.Text = abc.ToString();
            }
        }
        else
        {

            UnivService.Service1 ss = new UnivService.Service1();
            abc = " update Subject set SubjectName='" + SubjectName.Text.Trim() + "',SubAbbr='" + SubAbbr.Text.Trim() + "' where SubCode='" + SubjectView.SelectedRow.Cells[2].Text.Trim() + "'";
            abc = ss.UpdateData(abc);
            if (abc.ToString() == "ok")
            {
                ViewState.Add("EditMode", "false");
                LblMsg.Text = " Record is updated successfully.";
                SubjectName.Text = "";
                SubAbbr.Text = "";
                SubjectName.Focus();

            }
            else
                LblMsg.Text = abc.ToString();

        }



    }

    protected void SubjectView_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        StreamCode.SelectedValue = SubjectView.SelectedRow.Cells[1].Text;
        SubjectName.Text = SubjectView.SelectedRow.Cells[3].Text;
        SubAbbr.Text = SubjectView.SelectedRow.Cells[4].Text;
        ViewState.Add("EditMode", "true");
        SubjectName.Focus();
    }


    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        Panel2.Visible = true;
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select * from Subject order by StreamCode,SubCode");
        SubjectView.DataSource = ds;
        SubjectView.DataBind(); 
    }
   
    
}
