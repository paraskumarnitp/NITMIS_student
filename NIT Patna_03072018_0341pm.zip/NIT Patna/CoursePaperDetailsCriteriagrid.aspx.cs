using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
public partial class CoursePaperDetailsCriteriagrid : System.Web.UI.Page
{
    string  slno,slno1;
    int ltotal ,ptotal,ttotal,credittotal= 0;
    int ltotal1, ptotal1, ttotal1, credittotal1 = 0;
    int fltotal = 0, fltotal1 = 0;
    int rowIndex = 1, rowIndex1 = 1;
    //int sem = "sem 7";
    string coursetttle = "";
    string coursecode = "";

    Functionreviseed dut = new Functionreviseed();
    string streamcode = "";
    

    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            if ((Session["Role"].ToString() != "1") && (Session["Role"].ToString() != "10") && (Session["Role"].ToString() != "14"))
            {
                Session["userName"] = null;
                FormsAuthentication.SignOut();
                Response.Redirect("default.aspx");
                return;
            }
        }
        catch (Exception ex)
        {
            Response.Redirect("default.aspx");
        }   


        if (Session["streamcode"] != null)
        {
            streamcode = Session["streamcode"].ToString ();
        }


        if (!IsPostBack)
        {

            setData();
        }


    }


    public void setData()
    {


        try
        {
            // dut.singlevalue(cmssemester, "COURSEPAPERS", "select distinct STREAMPART,STREAMcode from COURSEPAPERS where StreamCode='" + streamcode + "'", "STREAMPART", "STREAMcode");
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(cmbexamsession, "EXAMPAPERDETAIL", "select DIStinct ExamSession from EXAMPAPERDETAIL", "ExamSession", "ExamSession");

            //select distinct STREAMPART from COURSEPAPERS where StreamCode='05'
            //      popddl.Popualate(cmssemester, "COURSEPAPERS", "select distinct STREAMPART,STREAMcode from COURSEPAPERS where StreamCode='" + streamcode + "'", "STREAMPART", "STREAMcode");
            //     cmssemester.Items.Insert(0, new ListItem("ALL", "00"));

            string query = "select distinct STREAMPART,STREAMcode from COURSEPAPERS where StreamCode='" + streamcode + "'";
            string conString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                //   coursetttle = dr[0].ToString();
                // coursecode = dr[1].ToString();

                cmssemester.Items.Add(dr[0].ToString());
            }
            cmssemester.Items.Insert(0, new ListItem("ALL", "00"));
            con.Close();

        }
        catch (Exception ex)
        {
        }
    }


    protected void grdcoursecriteria_RowDataBound(object sender, GridViewRowEventArgs e)
    {


        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            slno = DataBinder.Eval(e.Row.DataItem, "STREAMPART").ToString();
            int lTotal = Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "l").ToString());
            int tTotal = Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "t").ToString());
            int pTotal = Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "p").ToString());
            int creditTotal = Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "credit").ToString());

            ltotal += lTotal;
            ttotal += tTotal;
            ptotal += pTotal;
            credittotal += creditTotal;

            fltotal += creditTotal;
            if (e.Row.RowType == DataControlRowType.Footer)
            {
                Label lblTotall = (Label)e.Row.FindControl("lblTotall");
                lblTotall.Text = ltotal.ToString();
                Label lblTotalt = (Label)e.Row.FindControl("lblTotalt");
                lblTotalt.Text = ttotal.ToString();
                Label lblTotalp = (Label)e.Row.FindControl("lblTotalp");

                lblTotalp.Text = ptotal.ToString();
                Label lblTotalcredit = (Label)e.Row.FindControl("lblTotalcredit");
                lblTotalcredit.Text = credittotal.ToString();

            }
        }
    }



    protected void grdcoursecriteria_RowCreated(object sender, GridViewRowEventArgs e)
    {


        Label2.Text = coursetttle;
        Label1.Text = "Core Papers";
        bool newRow = false;
        if ((slno != null) && (DataBinder.Eval(e.Row.DataItem, "STREAMPART") != null))
        {
            if (slno != DataBinder.Eval(e.Row.DataItem, "STREAMPART").ToString())
                newRow = true;
        }
        if ((slno != null) && (DataBinder.Eval(e.Row.DataItem, "STREAMPART") == null))
        {
            newRow = true;
            rowIndex = 0;
        }

        if (newRow)
        {
            GridView GridView1 = (GridView)sender;
            GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert);
            NewTotalRow.Font.Bold = true;
            NewTotalRow.BackColor = System.Drawing.Color.Gray;
            NewTotalRow.ForeColor = System.Drawing.Color.White;
            
            TableCell HeaderCell = new TableCell();
            HeaderCell.Text = "Sub Total";


            HeaderCell.HorizontalAlign = HorizontalAlign.Left;
           
            HeaderCell.ColumnSpan = 4;

            NewTotalRow.Cells.Add(HeaderCell);

            HeaderCell = new TableCell();

            HeaderCell.HorizontalAlign = HorizontalAlign.Right;

            HeaderCell.ColumnSpan = 1;

            NewTotalRow.Cells.Add(HeaderCell);


            HeaderCell.Text = ltotal.ToString();
           

              HeaderCell = new TableCell();
              HeaderCell.HorizontalAlign = HorizontalAlign.Right;
              HeaderCell.ColumnSpan = 1;
            NewTotalRow.Cells.Add(HeaderCell);



            HeaderCell.Text = ttotal.ToString();

            HeaderCell = new TableCell();
            HeaderCell.HorizontalAlign = HorizontalAlign.Right;
            HeaderCell.ColumnSpan = 1;

            NewTotalRow.Cells.Add(HeaderCell);

            HeaderCell.Text = ptotal.ToString();

            HeaderCell = new TableCell();
            HeaderCell.HorizontalAlign = HorizontalAlign.Right;
            HeaderCell.ColumnSpan = 1;

            NewTotalRow.Cells.Add(HeaderCell);

            HeaderCell.Text = credittotal.ToString();


            HeaderCell = new TableCell();
            HeaderCell.HorizontalAlign = HorizontalAlign.Right;
            HeaderCell.ColumnSpan = 1;

            NewTotalRow.Cells.Add(HeaderCell);

            HeaderCell.Text = credittotal.ToString();





            HeaderCell = new TableCell();
            HeaderCell.HorizontalAlign = HorizontalAlign.Right;
            HeaderCell.ColumnSpan = 1;

            NewTotalRow.Cells.Add(HeaderCell);

            HeaderCell.Text = fltotal.ToString();
           


            GridView1.Controls[0].Controls.AddAt(e.Row.RowIndex + rowIndex, NewTotalRow);
            rowIndex++;
           
            ltotal = 0;
            ptotal = 0;
            ttotal = 0;
            credittotal = 0;
        }




    }
    protected void btngetdetails_Click(object sender, EventArgs e)
    {

        bindData();

    }


    public void bindData()
    {
   try
        {
            string sql = "";
            string sql1 = "";
            string query = "SELECT STREAM ,streamAbbr from STREAM where stream<>'--select--' and StreamCode='" + streamcode.Trim() + "'";


            if (cmssemester.SelectedItem.ToString().Equals("ALL"))
            {
                sql = "SELECT ROW_NUMBER()OVER(ORDER BY  COURSEPAPERS.PaperAbbr ASC) as 'SerialNO', STREAMPART,  COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName,     COURSEPAPERS.Credit, COURSEPAPERS.L, COURSEPAPERS.T, COURSEPAPERS.P ,sum(cast(COURSEPAPERS.P as int))as Total  FROM CourseCodeOfferedDetail INNER JOIN   COURSEPAPERS ON CourseCodeOfferedDetail.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN  CoursePaperOfferedType ON CourseCodeOfferedDetail.OfferedTypeId = CoursePaperOfferedType.Id   WHERE     (CourseCodeOfferedDetail.CourseCodeOfferedId IN  (SELECT     Id  FROM          CourseCodeOffered  WHERE      (ExamSession = '" + cmbexamsession.SelectedItem.ToString() + "')   and StreamCode='" + streamcode.Trim() + "') )  group by PaperAbbr,PaperName,Credit,L,T,P,STREAMPART order by COURSEPAPERS.PaperAbbr";
               // sql1 = "SELECT   COURSEPAPERS.PaperAbbr ,COURSEPAPERS.PaperName,COURSEPAPERS.StreamPart,   COURSEPAPERS.Credit as Credit1, COURSEPAPERS.L as L1,COURSEPAPERS.T as T1, COURSEPAPERS.P as P1,sum(cast(COURSEPAPERS.L as int))as Total,sum(cast(COURSEPAPERS.T as int))as Total, sum(cast(COURSEPAPERS.p as int))as Total,sum(cast(COURSEPAPERS.Credit as int))as Total FROM  COURSEPAPERS INNER JOIN   MasterCoursePaper ON COURSEPAPERS.MasterPaperId = MasterCoursePaper.Id where IsOpenElective='1' and StreamCode='05'   group by PaperAbbr,PaperName,COURSEPAPERS.Credit,COURSEPAPERS.L,COURSEPAPERS.T,COURSEPAPERS.P,STREAMPART order by PaperAbbr";

                sql1 = "SELECT   ROW_NUMBER()OVER(ORDER BY  MasterCoursePaper.CourseCode ASC) as 'SerialNO',  MasterCoursePaper.CourseCode,MasterCoursePaper.Title ,COURSEPAPERS.STREAMPART,MasterCoursePaper.L, MasterCoursePaper.T, MasterCoursePaper.P, MasterCoursePaper.Credit ,  sum(cast(MasterCoursePaper.L as int)), sum(cast(MasterCoursePaper.T as int)), sum(cast(MasterCoursePaper.P as int)), sum(cast(MasterCoursePaper.Credit as int)) FROM         MasterCoursePaper INNER JOIN    COURSEPAPERS ON MasterCoursePaper.Id = COURSEPAPERS.MasterPaperId INNER JOIN   CourseCodeOffered ON COURSEPAPERS.StreamPartCode = CourseCodeOffered.StreamPartCode WHERE     (MasterCoursePaper.IsOpenElective = 1) AND (CourseCodeOffered.ExamSession = '" + cmbexamsession.SelectedItem.ToString() + "') AND (COURSEPAPERS.StreamCode = '" + streamcode.Trim() + "')  group by COURSEPAPERS.STREAMPART, MasterCoursePaper.CourseCode,MasterCoursePaper.Title ,MasterCoursePaper.L, MasterCoursePaper.T, MasterCoursePaper.P, MasterCoursePaper.Credit  order by COURSEPAPERS.STREAMPART";
           
            
            }
            else
            {

                sql = "SELECT ROW_NUMBER()OVER(ORDER BY  COURSEPAPERS.PaperAbbr ASC) as 'SerialNO',STREAMPART,  COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName,     COURSEPAPERS.Credit, COURSEPAPERS.L, COURSEPAPERS.T, COURSEPAPERS.P ,sum(cast(COURSEPAPERS.P as int))as Total  FROM CourseCodeOfferedDetail INNER JOIN   COURSEPAPERS ON CourseCodeOfferedDetail.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN  CoursePaperOfferedType ON CourseCodeOfferedDetail.OfferedTypeId = CoursePaperOfferedType.Id   WHERE     (CourseCodeOfferedDetail.CourseCodeOfferedId IN  (SELECT     Id  FROM          CourseCodeOffered  WHERE      (ExamSession = '" + cmbexamsession.SelectedItem.ToString() + "') and STREAMPART='"+cmssemester.SelectedItem.ToString().Trim() + "'  and StreamCode='" + streamcode.Trim() + "') )  group by PaperAbbr,PaperName,Credit,L,T,P,STREAMPART order by COURSEPAPERS.PaperAbbr";
                sql1 = "SELECT   ROW_NUMBER()OVER(ORDER BY  MasterCoursePaper.CourseCode ASC) as 'SerialNO',  MasterCoursePaper.CourseCode,MasterCoursePaper.Title ,COURSEPAPERS.STREAMPART,MasterCoursePaper.L, MasterCoursePaper.T, MasterCoursePaper.P, MasterCoursePaper.Credit ,  sum(cast(MasterCoursePaper.L as int)), sum(cast(MasterCoursePaper.T as int)), sum(cast(MasterCoursePaper.P as int)), sum(cast(MasterCoursePaper.Credit as int)) FROM         MasterCoursePaper INNER JOIN    COURSEPAPERS ON MasterCoursePaper.Id = COURSEPAPERS.MasterPaperId INNER JOIN   CourseCodeOffered ON COURSEPAPERS.StreamPartCode = CourseCodeOffered.StreamPartCode WHERE     (MasterCoursePaper.IsOpenElective = 1) AND (CourseCodeOffered.ExamSession = '" + cmbexamsession.SelectedItem.ToString() + "') AND (COURSEPAPERS.StreamCode = '" + streamcode.Trim() + "') AND      (COURSEPAPERS.StreamPart = '" + cmssemester.SelectedItem.ToString().Trim() + "') group by COURSEPAPERS.STREAMPART,MasterCoursePaper.CourseCode,MasterCoursePaper.Title ,MasterCoursePaper.L, MasterCoursePaper.T, MasterCoursePaper.P, MasterCoursePaper.Credit order by COURSEPAPERS.STREAMPART";
            
            }


            string conString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataSet ds = new DataSet();
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            DataSet ds1 = new DataSet();
            int i = 0;
          

           
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                coursetttle = dr[0].ToString();
                coursecode = dr[1].ToString();


            }
            con.Close();



           
            con.Open();
            SqlCommand command = new SqlCommand(sql, con);



            adapter.SelectCommand = command;
            adapter.Fill(ds);
            adapter.Dispose();
            command.Dispose();
            con.Close();
            grdcoursecriteria.DataSource = ds.Tables[0];
            grdcoursecriteria.DataBind();
            con.Open();
            command = new SqlCommand(sql1, con);



            adapter1.SelectCommand = command;
            adapter1.Fill(ds1);
            adapter1.Dispose();
            command.Dispose();
            con.Close();
            grdelective.DataSource = ds1.Tables[0];
           grdelective.DataBind();


           
         
        }
        catch (Exception ex)
        {
        }

    }


    protected void grdelective_RowCreated(object sender, GridViewRowEventArgs e)
    {
        Label3.Text = "Elective Papers";

        bool newRow = false;
        if ((slno1 != null) && (DataBinder.Eval(e.Row.DataItem, "STREAMPART") != null))
        {
            if (slno1 != DataBinder.Eval(e.Row.DataItem, "STREAMPART").ToString())
                newRow = true;
        }
        if ((slno1 != null) && (DataBinder.Eval(e.Row.DataItem, "STREAMPART") == null))
        {
            newRow = true;
            rowIndex1 = 0;
        }

        if (newRow)
        {
            GridView GridView1 = (GridView)sender;
            GridViewRow NewTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert);
            NewTotalRow.Font.Bold = true;
            NewTotalRow.BackColor = System.Drawing.Color.Gray;
            NewTotalRow.ForeColor = System.Drawing.Color.White;

            TableCell HeaderCell = new TableCell();
            HeaderCell.Text = "Sub Total";


            HeaderCell.HorizontalAlign = HorizontalAlign.Left;

            HeaderCell.ColumnSpan = 4;

            NewTotalRow.Cells.Add(HeaderCell);

            HeaderCell = new TableCell();

            HeaderCell.HorizontalAlign = HorizontalAlign.Right;

            HeaderCell.ColumnSpan = 1;

            NewTotalRow.Cells.Add(HeaderCell);


            HeaderCell.Text = ltotal1.ToString();


            HeaderCell = new TableCell();
            HeaderCell.HorizontalAlign = HorizontalAlign.Right;
            HeaderCell.ColumnSpan = 1;
            NewTotalRow.Cells.Add(HeaderCell);



            HeaderCell.Text = ttotal1.ToString();

            HeaderCell = new TableCell();
            HeaderCell.HorizontalAlign = HorizontalAlign.Right;
            HeaderCell.ColumnSpan = 1;

            NewTotalRow.Cells.Add(HeaderCell);

            HeaderCell.Text = ptotal1.ToString();

            HeaderCell = new TableCell();
            HeaderCell.HorizontalAlign = HorizontalAlign.Right;
            HeaderCell.ColumnSpan = 1;

            NewTotalRow.Cells.Add(HeaderCell);

            HeaderCell.Text = credittotal1.ToString();


            HeaderCell = new TableCell();
            HeaderCell.HorizontalAlign = HorizontalAlign.Right;
            HeaderCell.ColumnSpan = 1;

            NewTotalRow.Cells.Add(HeaderCell);

            HeaderCell.Text = credittotal1.ToString();


            HeaderCell = new TableCell();
            HeaderCell.HorizontalAlign = HorizontalAlign.Right;
            HeaderCell.ColumnSpan = 1;

            NewTotalRow.Cells.Add(HeaderCell);

            HeaderCell.Text = fltotal1.ToString();



            GridView1.Controls[0].Controls.AddAt(e.Row.RowIndex + rowIndex1, NewTotalRow);
            rowIndex1++;

            ltotal1 = 0;
            ptotal1 = 0;
            ttotal1 = 0;
            credittotal1 = 0;
        }



    }
    protected void grdelective_RowDataBound(object sender, GridViewRowEventArgs e)
    {


        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            slno1 = DataBinder.Eval(e.Row.DataItem, "STREAMPART").ToString();
            int lTotal = Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "l").ToString());
            int tTotal = Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "t").ToString());
            int pTotal = Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "p").ToString());
            int creditTotal = Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "credit").ToString());

            ltotal1 += lTotal;
            ttotal1 += tTotal;
            ptotal1 += pTotal;
            credittotal1 += creditTotal;

            fltotal1 += creditTotal;
            if (e.Row.RowType == DataControlRowType.Footer)
            {
                Label lblTotall = (Label)e.Row.FindControl("lblTotall");
                lblTotall.Text = ltotal.ToString();
                Label lblTotalt = (Label)e.Row.FindControl("lblTotalt");
                lblTotalt.Text = ttotal.ToString();
                Label lblTotalp = (Label)e.Row.FindControl("lblTotalp");

                lblTotalp.Text = ptotal.ToString();
                Label lblTotalcredit = (Label)e.Row.FindControl("lblTotalcredit");
                lblTotalcredit.Text = credittotal.ToString();

            }
        }



    }
    protected void btnexcel_Click(object sender, EventArgs e)
    {


        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=CoursePaper.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            //To Export all pages
            grdcoursecriteria.AllowPaging = false;
          
            grdelective.AllowPaging = false;
            this.bindData();

            //grdcoursecriteria.HeaderRow.BackColor = System.Drawing.Color.White;
            //foreach (TableCell cell in grdcoursecriteria.HeaderRow.Cells)
            //{
            //    cell.BackColor = grdcoursecriteria.HeaderStyle.BackColor;
            //}
            //foreach (GridViewRow row in grdcoursecriteria.Rows)
            //{
            //    row.BackColor = System.Drawing.Color.White;
            //    foreach (TableCell cell in row.Cells)
            //    {
            //        if (row.RowIndex % 2 == 0)
            //        {
            //            cell.BackColor = grdcoursecriteria.AlternatingRowStyle.BackColor;
            //        }
            //        else
            //        {
            //            cell.BackColor = grdcoursecriteria.RowStyle.BackColor;
            //        }
            //        cell.CssClass = "textmode";
            //    }
            //}


            grdcoursecriteria.RenderControl(hw);
            grdelective.RenderControl(hw);

            // grdelective.RenderControl(hw);
            //style to format numbers to string
            string style = @"<style> .textmode { } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }








       
   

    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }







    
}
