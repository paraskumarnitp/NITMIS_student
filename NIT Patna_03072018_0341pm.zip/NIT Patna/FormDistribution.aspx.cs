using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class FormDistribution : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "3")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(UserId, "Login", "Select UserId,UserName from Login where Userrole='4' order by UserName ", "UserName", "UserId");
            popddl.Popualate(CollCode, "College", "Select Collcode,CollName from College  order by CollName ", "CollName", "CollCode");
            popddl.Popualate(Year, "Year", "Select Year from Year where year > '2006' order by Year", "Year", "Year");
           // ViewState.Add("EditMode", "false");
            UserId.Focus();
        }
    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {

        
            string abc = "";
            string[] col = new string[6];
            string[] val = new string[6];


            col[0] = "OperatorId"; val[0] = UserId.SelectedValue.ToString();
            col[1] = "NoOfForms"; val[1] = NoOfForms.Text.ToString();
            col[2] = "Date"; val[2] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(TxtDate.Text));
            col[3] = "CollCode"; val[3] = CollCode.SelectedValue.ToString();
            col[4] = "Year"; val[4] = Year.SelectedValue.ToString();
            col[5] = "UserId"; val[5] = Session["UserId"].ToString();


            UnivService.Service1 ss = new UnivService.Service1();
            abc = ss.SaveData("RegFormDistribution", col, val);


            if (abc == "1")
            {
                LblMsg.Text = "Forms Distribution is successfully assigned";
                string popupScript = "<script language='javascript'>" +
                                " alert('Forms Distribution is successfully assigned')" +
                                 "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);

                TxtDate.Text = "";
                NoOfForms.Text = "";
                UserId.Focus();


            }
            else
            {
                LblMsg.Text = abc.ToString();
            }
      
    

    }
    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "SELECT OperatorId,CollCode,NoOfForms,Year,Date FROM REGFORMDISTRIBUTION ORDER BY CollCode, Year");
        FormDistributionView.DataSource = ds;
        FormDistributionView.DataBind(); 
    }
}
