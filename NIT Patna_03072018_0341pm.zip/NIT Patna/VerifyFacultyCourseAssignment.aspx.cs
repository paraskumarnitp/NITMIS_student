using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class VerifyFacultyCourseAssignment : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "10"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(Year3, "Year", "Select Year from Year where year > '2016' order by Year", "Year", "Year");
            popddl.Popualate(ddlProgramCategory, "ProgramCategory", "SELECT Id, Name FROM ProgramCategory", "Name", "Id");
            ddlProgramCategory.Items.Insert(0, new ListItem("-Select", "0"));
            Year3.Text = System.DateTime.Now.Year.ToString();


        }
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("/Home.aspx");
    }

    private void bindcourses()
    {
        string qpart = "", querypart = "";
        string examsession = month1.SelectedItem.ToString() + "-" + month2.SelectedItem.ToString() + "_" + Year3.SelectedItem.ToString();
        if (ddlprogram.SelectedItem.ToString() == "ALL")
        {
            qpart = "";
            querypart = "";
        }
        else
        {
            qpart = " AND b.StreamCode = '" + ddlprogram.SelectedValue.ToString() + "'";
            querypart = "AND Department_Stream.StreamCode = '" + ddlprogram.SelectedValue.ToString() + "'";
        }
        DataTable dtfacnullassign = fnrev.SelectDatatable(@"select StreamAbbr as Program, b.StreamPart as Semester, b.PaperAbbr,f.SpDescription,
         b.PaperName,b.Credit,Row_number() over (order by a.SubpaperCode) as orderNumber,h.UserId,LogIn.UserName  from 
         CourseCodeOfferedDetail a inner join CourseCodeOffered k on a.CourseCodeOfferedId=k.Id  inner join 
         COURSEPAPERS b on a.SubPaperCode=b.SubPaperCode  inner join MasterCoursePaper c on b.MasterPaperId=c.Id 
         inner join Stream e on e.streamcode=b.streamcode inner join  CourseSpecialization f on k.splcode=f.spcode 
         inner join ProgramCategory_Stream d on e.streamCode=d.streamCode left join  faculty_paper_a h on 
         a.subpaperCode=h.SubPaperCode and k.SplCode=h.SplCode  and h.Is_Active='Y' and k.ExamSession=h.ExamSession LEFT OUTER JOIN Login ON h.UserID = Login.UserID
         where  k.ExamSession='" + examsession + "' and d.ProgCategoryId IN ('" + ddlProgramCategory.SelectedValue.ToString() + "') " + qpart + " order by b.StreamCode");

        //gvfacassignment.DataSource = dtfacnullassign;
        //gvfacassignment.DataBind();
        if (dtfacnullassign.Rows.Count > 0)
        {
            Panel1.Visible = true;
            string tablestring = "";

            for (int i = 0; i < dtfacnullassign.Rows.Count; i++)
            {
                tablestring += "<tr>";
                tablestring += "<td>" + (i + 1) + "</td>";
                tablestring += "<td>" + dtfacnullassign.Rows[i]["Program"].ToString() + "</td>";
                tablestring += "<td>" + dtfacnullassign.Rows[i]["Semester"].ToString() + "</td>";
                tablestring += "<td>" + dtfacnullassign.Rows[i]["SpDescription"].ToString() + "</td>";
                tablestring += "<td>" + dtfacnullassign.Rows[i]["PaperAbbr"].ToString() + "</td>";
                tablestring += "<td>" + dtfacnullassign.Rows[i]["PaperName"].ToString() + "</td>";
                tablestring += "<td>" + dtfacnullassign.Rows[i]["Credit"].ToString() + "</td>";
                tablestring += "<td>" + dtfacnullassign.Rows[i]["UserId"].ToString() + "</td>";
                tablestring += "<td>" + dtfacnullassign.Rows[i]["UserName"].ToString() + "</td>";
                tablestring += "</tr>";
            }
            tlist.InnerHtml = tablestring;
        }
        else
        {
            tlist.InnerHtml = "";
            Panel1.Visible = false;
        }

        DataTable dtopnfacnullassign = fnrev.SelectDatatable(@"SELECT MasterCoursePaper.CourseCode, MasterCoursePaper.Title, STREAM.StreamAbbr, MasterCoursePaper.Credit, Faculty_paper_a.UserId,Login.UserName
                    FROM Department_Stream INNER JOIN OpenElectiveOffered INNER JOIN MasterCoursePaper ON OpenElectiveOffered.MasterPaperId = MasterCoursePaper.Id 
                    ON Department_Stream.DepartmentId = MasterCoursePaper.DepartmentId INNER JOIN STREAM ON Department_Stream.StreamCode = STREAM.StreamCode 
                    LEFT OUTER JOIN Faculty_paper_a ON OpenElectiveOffered.MasterPaperId = Faculty_paper_a.MasterPaperId AND 
                    OpenElectiveOffered.ExamSession = Faculty_paper_a.ExamSession LEFT OUTER JOIN Login ON Faculty_paper_a.UserID = Login.UserID WHERE (OpenElectiveOffered.ExamSession = '" + examsession + "') " +
                    " AND (OpenElectiveOffered.CategoryId = '" + ddlProgramCategory.SelectedValue.ToString() + "') AND (Faculty_paper_a.Is_Active = 'Y') " + querypart + " AND " +
                    " Faculty_paper_a.UserId IS NULL order By Department_Stream.StreamCode");

        //gvfacassignment.DataSource = dtfacnullassign;
        //gvfacassignment.DataBind();
        if (dtopnfacnullassign.Rows.Count > 0)
        {
            string tablestring = "";

            for (int i = 0; i < dtopnfacnullassign.Rows.Count; i++)
            {
                tablestring += "<tr>";
                tablestring += "<td>" + (i + 1) + "</td>";
                tablestring += "<td>" + dtopnfacnullassign.Rows[i]["StreamAbbr"].ToString() + "</td>";
                tablestring += "<td>" + dtopnfacnullassign.Rows[i]["CourseCode"].ToString() + "</td>";
                tablestring += "<td>" + dtopnfacnullassign.Rows[i]["Title"].ToString() + "</td>";
                tablestring += "<td>" + dtopnfacnullassign.Rows[i]["Credit"].ToString() + "</td>";
                tablestring += "<td>" + dtopnfacnullassign.Rows[i]["UserId"].ToString() + "</td>";
                tablestring += "<td>" + dtopnfacnullassign.Rows[i]["UserName"].ToString() + "</td>";
                tablestring += "</tr>";
            }
            opentlist.InnerHtml = tablestring;
        }
        else
            opentlist.InnerHtml = "";
    }
    protected void month1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (month1.SelectedIndex == 1)
        {
            month2.SelectedIndex = 1;
        }
        else if (month1.SelectedIndex == 2)
        {
            month2.SelectedIndex = 2;
        }
        else
        {
            month2.SelectedIndex = 0;
        }
    }
    protected void ddlProgramCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        bindstream();
    }
    protected void btngetdetails_Click(object sender, EventArgs e)
    {
        bindcourses();
    }

    private void bindstream()
    {
        string query = "SELECT ProgramCategory_Stream.StreamCode, STREAM.StreamAbbr FROM ProgramCategory_Stream INNER JOIN STREAM ON ProgramCategory_Stream.StreamCode = STREAM.StreamCode WHERE ProgCategoryId = '" + ddlProgramCategory.SelectedValue + "' order By StreamAbbr ";
        DataTable dtstream = fnrev.SelectDatatable(query);
        ddlprogram.DataSource = dtstream;
        ddlprogram.DataTextField = "StreamAbbr";
        ddlprogram.DataValueField = "StreamCode";
        ddlprogram.DataBind();
        //ddlprogram.Items.Insert(0, new ListItem("ALL", "0"));
    }
    protected void btnverify_Click(object sender, EventArgs e)
    {
        if (month1.Text == "SELECT")
        {
            LblMsg.Text = "Invalid ExamSession Selected.";
            return;
        }
        if (ddlprogram.Text == "")
        {
            LblMsg.Text = "Invalid Program Selected.";
            return;
        }
        if (chkbverify.Checked)
        {
            string examsession = month1.SelectedItem.ToString() + "-" + month2.SelectedItem.ToString() + "_" + Year3.SelectedItem.ToString();
            int insrec = fnrev.InsertUpdateDelete("DELETE FROM ValidateCourseOffered WHERE (StreamPartCode IN (SELECT DISTINCT CourseCodeOffered.StreamPartCode FROM CourseCodeOffered INNER JOIN STREAMPART ON " +
                " CourseCodeOffered.StreamPartCode = STREAMPART.StreamPartCode WHERE (STREAMPART.StreamCode = '" + ddlProgramCategory.SelectedValue.ToString() + "') AND (CourseCodeOffered.ExamSession = '"+ examsession +"')))");

            insrec = fnrev.InsertUpdateDelete("INSERT INTO ValidateCourseOffered (StreamPartCode, SplCode, ExamSession,UserID,Ctime) SELECT CourseCodeOffered.StreamPartCode, CourseCodeOffered.Splcode, " +
                " CourseCodeOffered.ExamSession, '" + Session["UserId"].ToString() + "',GETDATE() FROM CourseCodeOffered INNER JOIN STREAMPART ON CourseCodeOffered.StreamPartCode = STREAMPART.StreamPartCode WHERE StreamCode = '" + ddlProgramCategory.SelectedValue.ToString() + "'");
            if (insrec == 0)
            {
                LblMsg.Text = "Failed to save verification";
                return;
            }
            else
            {
                LblMsg.Text = "Verification saved successfully";
                return;
            }
        }
        else
        {
            LblMsg.Text = "Please Check Verification.";
            return;
        }
    }
}
