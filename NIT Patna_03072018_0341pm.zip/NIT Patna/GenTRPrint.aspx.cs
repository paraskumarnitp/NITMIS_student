using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
public partial class GenTRPrint : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "3")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();

            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College where collcode in (select distinct collcode from TRGen) order by CollName", "CollName", "CollCode");
            popddl.Popualate(ExamYear, "Exam", "Select distinct ExamYear from Exam order by ExamYear", "ExamYear", "ExamYear");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from TRGen) order by StreamAbbr", "StreamAbbr", "StreamCode");
            CourseValue();

        }
    }



    protected void ViewTR_Click(object sender, EventArgs e)
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        String TypeCode = NicService.GetNewCode("Select StreamTypeCode from Stream where StreamCode='" + StreamCode.SelectedValue + "' ");

        // Get Stream Type--------------
        if (TypeCode == "01")//Gen
        {
            Panel1.Visible = true;
            CR.ReportSource = crs;
            CR.SelectionFormula = @"{TRGen.CollCode} = '" + CollCode.SelectedValue + "' And {TRGen.ExamYear} ='" + ExamYear.SelectedValue + "' And {TRGen.StreamCode} ='" + StreamCode.SelectedValue + "' And {TRGen.StreamPart} ='" + StreamPart.SelectedValue + "'";
            CR.RefreshReport();
        }
        else if (TypeCode == "02")//Hons
        {
           
           
        }
        else if (TypeCode == "03")//Voc
        {
        }
        else if (TypeCode == "04")//Pro
        {
        }
    }

    protected void CourseValue()
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart, StreamPartCode from StreamPart where streamcode='" + StreamCode.SelectedValue + "' and streampartcode in (select distinct streampartcode from exam) order by StreamPartCode", "StreamPart", "StreamPartCode");

    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        CourseValue();
    }
}
