using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class ViewRegStudents : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(Year, "Year", "Select Year from Year where Year > '2008'  order by Year", "Year", "Year");
            popddl.Popualate(StreamCode1, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(SubCode1, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode1.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
            
            DataSet ds = new DataSet();
            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select AckNo,RegNo,ApplicantName,FatherName,MotherName,DOB,CollCode,streamcode from Registration where RegNo is null or RegNo=''");
            RegView.DataSource = ds;
            RegView.DataBind();


            TotStudent.Text = RegView.Rows.Count.ToString();
            Year.Text = System.DateTime.Now.Year.ToString();    
        }


    }
    protected void BtnView_Click(object sender, EventArgs e)
    {
        BindGrid();
        if (RegView.Rows.Count > 0)
        {
            TotStudent.Visible = true;
            TotStudent.Text = " Total Student =  " + RegView.Rows.Count.ToString();
            Panel1.Visible = true;
        }
        else
        {
            TotStudent.Visible = true;
            TotStudent.Text = "No Records Found";
            Panel1.Visible = false;
        }

    }
    protected void BtnAllotRegNo_Click(object sender, EventArgs e)
    {

    }
    protected void RegView_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void RegView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        RegView.PageIndex = e.NewPageIndex;
        BindGrid();
    }
    protected void RegView_SelectedIndexChanged(object sender, EventArgs e)
    {
        
       // Response.Write ("ok"+RegView.SelectedRow.Cells[3].Text);
        
    }
    void BindGrid()
    {
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select AckNo,RegNo,ApplicantName,FatherName,MotherName,DOB,CollCode,StreamCode from Registration where collcode='" + CollCode.SelectedValue.ToString() + "' and  RegYear ='" + Year.SelectedValue.ToString() + "' and SubCode='" + SubCode1.SelectedValue + "' and (regno is not NULL and regno<>'') order by "+ OrderBy.SelectedValue +" ");
        RegView.DataSource = ds;
        RegView.DataBind();
    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }
    protected void StreamCode1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (StreamCode1.SelectedValue == "00") return;

        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(SubCode1, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode1.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        //SubCode_SelectedIndexChanged(StreamCode, e); // call subcode selected index
        SubCode1.Focus();
    }
}
