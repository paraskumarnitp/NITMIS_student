using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class WindowClose : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
             UnivService.Service1 ss = new UnivService.Service1();
             string abc = " update UserLogTime set Online='N',LogoutTime=GetDate()  where Online='Y' and LoginId='" + Session["UserId"].ToString() + "' ";
             abc = ss.UpdateData(abc);
             ss.Dispose();
                 string popupScript = "<script language='javascript'>" +
                                " window.close(this)" +
                                 "</script>";

                 Page.RegisterStartupScript("PopupScript", popupScript);

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
}
