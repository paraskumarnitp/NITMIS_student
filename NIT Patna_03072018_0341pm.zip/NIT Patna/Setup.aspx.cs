using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class Setup : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {

                if (Session["Role"].ToString() != "1")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
                PopulateDDL popddl = new PopulateDDL();
                popddl.Popualate(DistCode, "District", "Select Distcode,DistName from District order by DistName", "DistName", "DistCode");
                popddl.Popualate(UnivCode, "University", "Select Univcode,UnivName from University where univcode<>'00' order by UnivName", "UnivName", "UnivCode");               
                ViewState.Add("EditMode", "false");
                UnivCode.Focus();
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

        }
    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {
        try
        {

            string abc = "";
            Panel2.Visible = false;
            if (ViewState["EditMode"].ToString() == "false")
            {
                string[] col = new string[6];
                string[] val = new string[6];
                col[0] = "UnivCode";
                col[1] = "UnivName";
                col[2] = "UnivAddress";
                col[3] = "VcName";
                col[4] = "InstallDate";
                col[5] = "InstallPlace";



                Panel2.Visible = false;

                val[0] = UnivCode.SelectedValue;
                val[1] = UnivCode.SelectedItem.Text.Trim();
                val[2] = UnivAddress.Text.Trim();
                val[3] = VcName.Text.Trim();
                val[4] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(InstallDate.Text));
                val[5] = InstallPlace.Text.Trim();


                UnivService.Service1 ss = new UnivService.Service1();
                ss.UpdateData("delete from install");
                abc = ss.SaveData("Install", col, val);


                if (abc == "1")
                {
                    LblMsg.Text = " Setup is saved successfully.";
                    string popupScript = "<script language='javascript'>" +
                                    " alert('Setup is saved successfully. ')" +
                                     "</script>";

                    Page.RegisterStartupScript("PopupScript", popupScript);

                }
                else
                {
                    LblMsg.Text = abc.ToString();
                }
            }
            else
            {

                UnivService.Service1 ss = new UnivService.Service1();
                abc = " update District set UnivCode='" + UnivCode.SelectedValue + "',UnivName='" + UnivCode.SelectedItem.Text.Trim() + "' ";
                abc = ss.UpdateData(abc);
                if (abc.ToString() == "ok")
                {
                    ViewState.Add("EditMode", "false");
                    LblMsg.Text = " Record is updated successfully.";

                }
                else
                    LblMsg.Text = abc.ToString();

            }
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

    }
    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {

    }

    protected void UnivCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

            SqlDataReader reader;
            cmd.CommandText = "Select Address1,distcode from university where UnivCode='" + UnivCode.SelectedValue.ToString() + "'";
            con.Open();
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                UnivAddress.Text = reader["Address1"].ToString();
                DistCode.SelectedValue = reader["distcode"].ToString();

            }

            reader.Close();
            con.Close();
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

        }

    

}
