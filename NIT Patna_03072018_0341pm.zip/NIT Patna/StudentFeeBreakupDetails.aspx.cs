using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Drawing;

public partial class StudentFeeBreakupDetails : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnexport);
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "17")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
                bindexamSession();
                paymenttype.Items.Insert(0, new ListItem("ALL", "0"));
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

        }
    }
    string querypart = ""; DataTable dtfeebreakupsfinal; DataRow drw;
    protected void btnexport_Click(object sender, EventArgs e)
    {
        /*
        if (paymenttype.SelectedValue.ToString() == "0")
        {
            querypart = "";
        }
        else
        {
            querypart = "AND (STREAM.StreamCode = '" + paymenttype.SelectedValue.ToString() + "') ";
        } */

        //if (StreamCode.SelectedValue.ToString() == "0")
        //{
        //    querypart = querypart + "";
        //}
        //else
        //    querypart = querypart + " AND CategoryFeeSettings.FeeCategoryType = '" + StreamCode.SelectedItem.ToString() + "'";

        DataTable dtfeeBreakupdata = fnrev.SelectDatatable("with cte as (SELECT FeeConcession.UnivRollNo, FeeConcession.ExamSession," + 
            " (FeeConcession.Amount * -1) As FeeAmount, FeeConcession.Remarks, CategoryFeeSettings.FeeCategoryType FROM FeeConcession LEFT OUTER JOIN " + 
            " CategoryFeeSettings ON FeeConcession.RegNo = CategoryFeeSettings.RegNo AND FeeConcession.ExamSession = CategoryFeeSettings.ExamSession " +
            " WHERE FeeConcession.Remarks  <> 'PHD PartTime Internal Program' AND FeeConcession.ExamSession = '" + admyear.SelectedItem.ToString() + "' Union SELECT UnivRollNo, " +
            " ExamSession,Amount,Feedeposited As Remarks, '' As FeeCategoryType FROM DepositedFeeDetails WHERE (ExamSession = '" + admyear.SelectedItem.ToString() + "')) SELECT * FROM " +
            " (SELECT EXAM.[UnivRollNo],EXAM.ExamSession, Remarks,FeeAmount FROM cte INNER join EXAM on cte.ExamSession = EXAM.ExamSession AND cte.UnivRollNo = EXAM.UnivRollNo WHERE Status = 'SUBMIT' AND EXAM.ExamSession = '" + admyear.SelectedItem.ToString() + "') " + 
            " as s PIVOT (SUM(FeeAmount) FOR [Remarks] IN ([Category Fee Waive], " + 
            " [Educational Tour And Visit], [Examination Fee], [Late Fine],[Medical Insurance Fee], [Previous Due Fee], [Registration Fee], " + 
            " [Student Activity Fee], [Student Welfare Fund], [Tuition Fee]))AS pvt order by UnivRollNo");
        if (dtfeeBreakupdata.Rows.Count > 0)
        {
             dtfeeBreakupdata.Columns.Add("TotalFee");
             dtfeeBreakupdata.Columns.Add("TXN_DD_NO");
             dtfeeBreakupdata.Columns.Add("MODEOFPAY");
             dtfeeBreakupdata.Columns.Add("PAYDATE");
             dtfeeBreakupdata.Columns.Add("BANK");
            dtfeebreakupsfinal = new DataTable();
            dtfeebreakupsfinal = dtfeeBreakupdata.Clone();           

            DataTable dtfeesum = fnrev.SelectDatatable("with cte as (SELECT FeeConcession.UnivRollNo, FeeConcession.ExamSession, (FeeConcession.Amount * -1) " + 
                " As FeeAmount, FeeConcession.Remarks, CategoryFeeSettings.FeeCategoryType FROM FeeConcession LEFT OUTER JOIN CategoryFeeSettings ON " + 
                " FeeConcession.RegNo = CategoryFeeSettings.RegNo AND FeeConcession.ExamSession = CategoryFeeSettings.ExamSession WHERE " +
                " FeeConcession.Remarks  <> 'PHD PartTime Internal Program' AND FeeConcession.ExamSession = '" + admyear.SelectedItem.ToString() + "' Union SELECT UnivRollNo, " +
                " ExamSession,Amount,Feedeposited As Remarks, '' As FeeCategoryType FROM DepositedFeeDetails WHERE (ExamSession = '" + admyear.SelectedItem.ToString() + "')) SELECT " + 
                " UnivRollNo,SUM(FeeAmount) As TotalFee FROM cte group by UnivRollNo");
            DataTable dtregpayemnt = fnrev.SelectDatatable("SELECT DISTINCT UnivRollNo,PaymentId,PaymentDate,ModeOfPayment,Bank FROM EXAM WHERE " +
                " ExamSession = '" + admyear.SelectedItem.ToString() + "' and Status = 'SUBMIT' union SELECT DISTINCT UnivrollNo,PaymentId,PaymentDate,PaymentMode AS ModeOfPayment," +
                " PayBank AS BANK FROM Phdregistration WHERE ExamSession = '" + admyear.SelectedItem.ToString() + "' and Status = 'SUBMIT'");
            for (int i = 0; i < dtfeeBreakupdata.Rows.Count; i++)
            {
                int u;
                DataRow[] datarow = dtfeesum.Select("UnivRollNo = '" + dtfeeBreakupdata.Rows[i]["UnivRollNo"].ToString() + "'");
                DataRow[] dataregrow = dtregpayemnt.Select("UnivRollNo = '" + dtfeeBreakupdata.Rows[i]["UnivRollNo"].ToString() + "'");
                drw = dtfeebreakupsfinal.NewRow();
                for(u = 0; u < dtfeeBreakupdata.Columns.Count-5;u++)
                {
                    drw[u] = dtfeeBreakupdata.Rows[i][u].ToString() == "" ? "0" : dtfeeBreakupdata.Rows[i][u].ToString();
                }
                //u = u+1;
                if (datarow != null)
                {
                    drw[u] = datarow[0][1].ToString();
                }
                else
                    drw[u] = "";
                if (dataregrow.Length > 0)
                {
                    drw[u + 1] = dataregrow[0][1].ToString();
                    drw[u + 2] = dataregrow[0][2].ToString();
                    drw[u + 3] = dataregrow[0][3].ToString();
                    drw[u + 4] = dataregrow[0][4].ToString();
                }

                dtfeebreakupsfinal.Rows.Add(drw);
            }
            GridView gvfeebreakup = new GridView();
            gvfeebreakup.DataSource = dtfeebreakupsfinal;
            gvfeebreakup.DataBind();

            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=RegistrationFeeBrakupDetailsExport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                //gvpayonline.AllowPaging = false;
                //this.BindGrid();

                gvfeebreakup.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in gvfeebreakup.HeaderRow.Cells)
                {
                    cell.BackColor = gvfeebreakup.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in gvfeebreakup.Rows)
                {
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = gvfeebreakup.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = gvfeebreakup.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                gvfeebreakup.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
    }
    protected void ddlprogramtype_SelectedIndexChanged(object sender, EventArgs e)
    {
       
        string query = "";
        paymenttype.Items.Clear();
        if (ddlprogramtype.SelectedValue.ToString() == "0")
        {
            query = "SELECT StreamCode, StreamAbbr AS StreamName, StreamTypeCode FROM STREAM WHERE StreamCode <> '00'";
        }
        else if (ddlprogramtype.SelectedValue.ToString() == "UG")
        {
            query = "SELECT StreamCode, StreamAbbr AS StreamName, StreamTypeCode FROM STREAM WHERE StreamCode <> '00' And StreamTypeCode = '01'";
        }
        else
        {
            query = "SELECT StreamCode, StreamAbbr AS StreamName, StreamTypeCode FROM STREAM WHERE StreamCode <> '00' And StreamTypeCode IN ('02','04')";
        }
        DataTable dtprogram = fnrev.SelectDatatable(query);
        paymenttype.DataSource = dtprogram;
        paymenttype.DataTextField = "StreamName";
        paymenttype.DataValueField = "StreamTypeCode";
        paymenttype.DataBind();
        paymenttype.Items.Insert(0, new ListItem("ALL", "0")); 

    }

    private void bindexamSession()
    {
        DataTable dtexamSession = fnrev.SelectDatatable("SELECT DISTINCT ExamSession FROm FeeConcession WHERE ExamSession <> 'JAN-JUN_2017'");
        admyear.DataSource = dtexamSession;
        admyear.DataValueField = "ExamSession";
        admyear.DataTextField = "ExamSession";
        admyear.DataBind();
    }
    protected void btnview_Click(object sender, EventArgs e)
    {

    }
}
