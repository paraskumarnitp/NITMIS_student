using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.SessionState;
using System.Web.Caching;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.Collections.Generic;

public partial class UpdateMedicalRelaxation : System.Web.UI.Page
{

    Functionreviseed dut = new Functionreviseed();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "14") && (Session["Role"].ToString() != "13"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            if (Session["Role"].ToString() == "13")
            {
                string deptcode = (dut.singlevalue("Select DepartmentId From Login Where Userid = '" + Session["UserId"].ToString() + "'")).ToString();
                ViewState["DeptCode"] = deptcode;
            }
            BtnUpdate.Visible = false;
        }
        LblMsg.Text = "";
    }
    protected void BtnReg_Click(object sender, EventArgs e)
    {
        try
        {
            ddlsemester.Items.Clear();
            ddlexamsess.Items.Clear();
            string whereQuery = string.Empty;
            if (!string.IsNullOrEmpty((string)ViewState["DeptCode"]))
            {
                whereQuery = " where Department_Stream.DepartmentId='" + (string)ViewState["DeptCode"] + "' ";
            }
            string sql = " SELECT     REGISTRATION.ApplicantName, REGISTRATION.DOB, REGISTRATION.StreamCode, STREAM.StreamAbbr, " +
                        " REGISTRATION.TempRollNo, REGISTRATION.RegNo, " +
                      " EXAMPAPERDETAIL.ExamSession FROM  REGISTRATION INNER JOIN " +
                      " EXAMPAPERDETAIL ON REGISTRATION.RegNo = EXAMPAPERDETAIL.RegNo INNER JOIN " +
                     " STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode INNER JOIN " +
                    "  Department_Stream ON STREAM.StreamCode = Department_Stream.StreamCode " + whereQuery +
                " GROUP BY REGISTRATION.ApplicantName, REGISTRATION.DOB, REGISTRATION.StreamCode, STREAM.StreamAbbr, REGISTRATION.TempRollNo, REGISTRATION.RegNo, " +
                  " EXAMPAPERDETAIL.ExamSession HAVING REGISTRATION.TempRollNo = '" + txtrollno.Text + "'";

            DataTable dtvalue = dut.SelectDatatable(sql);

            if (dtvalue.Rows.Count > 0)
            {
                Panel1.Visible = true;
                Panel1.Enabled = true;

                ApplicantName.Text = dtvalue.Rows[0]["ApplicantName"].ToString();
                DOB.Text = Convert.ToDateTime(String.IsNullOrEmpty(dtvalue.Rows[0]["DOB"].ToString()) ? "1990-01-01" : dtvalue.Rows[0]["DOB"]).ToString("dd/MM/yyyy");
                StreamCode.Text = dtvalue.Rows[0]["StreamAbbr"].ToString();
                txtregno.Text = dtvalue.Rows[0]["RegNo"].ToString();

                if (Session["Role"].ToString() == "13")
                {
                    string examSession = (string)ConfigurationManager.AppSettings["ddexamsession"];
                    ddlexamsess.Items.Add(new ListItem(examSession, examSession));
                }
                else
                {
                    ddlexamsess.DataSource = dtvalue;
                    ddlexamsess.DataTextField = "ExamSession";
                    ddlexamsess.DataValueField = "ExamSession";
                    ddlexamsess.DataBind();
                }
                ddlsemester.Items.Insert(0, new ListItem("--select--", "00"));
                ddlexamsess.Items.Insert(0, new ListItem("--select--", "00"));
            }
            else
            {
                Panel1.Visible = false;
                LblMsg.Text = " Please check Roll No.";

                return;
            }
            ClearTextBox();
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }


    }

    private void ClearTextBox()
    {
        Panel2.Visible = false;
        gvTheory.DataSource = null;
        gvTheory.DataBind();
        gvPractical.DataSource = null;
        gvPractical.DataBind();
    }
    protected void BtnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            UnivService.Service1 NicService = new UnivService.Service1();
            int result = 0;
            for (int i = 0; i <= gvTheory.Rows.Count - 1; i++)
            {
                HiddenField hfValue = (HiddenField)gvTheory.Rows[i].FindControl("hfThRelax");
                bool isValid = !string.IsNullOrEmpty(hfValue.Value) ? bool.Parse(hfValue.Value) : false;
                if (isValid)
                {
                    TextBox txtThOther = (TextBox)gvTheory.Rows[i].FindControl("txtThOtherRelax");
                    TextBox thRelax = (TextBox)gvTheory.Rows[i].FindControl("txtThRelax");
                    TextBox txtTotal = (TextBox)gvTheory.Rows[i].FindControl("txtTotalTh");
                    TextBox txtAttended = (TextBox)gvTheory.Rows[i].FindControl("txtThAttended");
                    int otherRelaxation = string.IsNullOrEmpty(txtThOther.Text) ? 0 : int.Parse(txtThOther.Text);
                    int medicalRelaxation = string.IsNullOrEmpty(thRelax.Text) ? 0 : int.Parse(thRelax.Text);
                    int otherRelaxationLimit = int.Parse(txtTotal.Text) - int.Parse(txtAttended.Text) - medicalRelaxation;
                    if (otherRelaxationLimit < otherRelaxation)
                    {
                        otherRelaxation = otherRelaxationLimit;
                    }
                    int countExisting = Convert.ToInt32(NicService.GetNewCode(" select Count(*) from AttendanceRelaxation c   where c.RegNo='" + txtregno.Text + "' and SubPaperCode='" + (string)gvTheory.DataKeys[i].Value + "' and ExamSession='" + ddlexamsess.SelectedValue + "' and PaperType='T'"));
                    if (countExisting > 0)
                    {
                        string updateHistory = " INSERT INTO AttendanceRelaxationHistory " +
                                               " (RegNo,SubPaperCode, ExamSession, PaperType, UnivRollNo,MedicalRelaxation, OtherRelaxation,EntryDate,UserId,DeletedUserId) " +
                                               " SELECT RegNo,SubPaperCode, ExamSession, PaperType, UnivRollNo, MedicalRelaxation, OtherRelaxation,EntryDate, UserId,'" + Session["UserId"].ToString() + "' " +
                                               " FROM         AttendanceRelaxation AS c " +
                                               " WHERE     (RegNo = '" + txtregno.Text + "') and SubPaperCode='" + (string)gvTheory.DataKeys[i].Value + "' and ExamSession='" + ddlexamsess.SelectedValue + "' and PaperType='T'; " +
                                               " DELETE FROM AttendanceRelaxation WHERE     (RegNo = '" + txtregno.Text + "') and SubPaperCode='" + (string)gvTheory.DataKeys[i].Value + "' and ExamSession='" + ddlexamsess.SelectedValue + "' and PaperType='T'; ";
                        int updateAttendance = dut.InsertUpdateDelete(updateHistory);
                    }
                    if (otherRelaxation > 0 || medicalRelaxation > 0)
                    {
                        string insertQuery = " INSERT INTO AttendanceRelaxation " +
                                               " (SubPaperCode, ExamSession, PaperType, RegNo, UnivRollNo, MedicalRelaxation,OtherRelaxation,  ModifiedDate, UserId) " +
                                               " VALUES     ('" + (string)gvTheory.DataKeys[i].Value + "','" + ddlexamsess.SelectedValue + "','T','" + txtregno.Text + "','" + txtrollno.Text + "'," + medicalRelaxation.ToString() + "," + otherRelaxation.ToString() + ",getdate(),'" + Session["UserId"].ToString() + "' )";
                        result = dut.InsertUpdateDelete(insertQuery);
                    }
                }
            }

            for (int i = 0; i <= gvPractical.Rows.Count - 1; i++)
            {
                HiddenField hfValue = (HiddenField)gvPractical.Rows[i].FindControl("hfPtRelax");
                bool isValid = !string.IsNullOrEmpty(hfValue.Value) ? bool.Parse(hfValue.Value) : false;
                if (isValid)
                {
                    TextBox txtPtOther = (TextBox)gvPractical.Rows[i].FindControl("txtPtOtherRelax");
                    TextBox ptRelax = (TextBox)gvPractical.Rows[i].FindControl("txtPtRelax");
                    TextBox txtTotal = (TextBox)gvPractical.Rows[i].FindControl("txtTotalPTRelax");
                    TextBox txtAttended = (TextBox)gvPractical.Rows[i].FindControl("txtPTAttended");

                    int otherRelaxation = string.IsNullOrEmpty(txtPtOther.Text) ? 0 : int.Parse(txtPtOther.Text);
                    int medicalRelaxation = string.IsNullOrEmpty(ptRelax.Text) ? 0 : int.Parse(ptRelax.Text);
                    int otherRelaxationLimit = int.Parse(txtTotal.Text) - int.Parse(txtAttended.Text) - medicalRelaxation;
                    if (otherRelaxationLimit < otherRelaxation)
                    {
                        otherRelaxation = otherRelaxationLimit;
                    }
                    int countExisting = Convert.ToInt32(NicService.GetNewCode(" select Count(*) from AttendanceRelaxation c   where c.RegNo='" + txtregno.Text + "' and SubPaperCode='" + (string)gvPractical.DataKeys[i].Value + "' and ExamSession='" + ddlexamsess.SelectedValue + "' and PaperType='P'"));
                    if (countExisting > 0)
                    {
                        string updateHistory = " INSERT INTO AttendanceRelaxationHistory " +
                                               " (RegNo,SubPaperCode, ExamSession, PaperType, UnivRollNo,MedicalRelaxation, OtherRelaxation,EntryDate,UserId,DeletedUserId) " +
                                               " SELECT     RegNo,SubPaperCode, ExamSession, PaperType, UnivRollNo, MedicalRelaxation, OtherRelaxation,EntryDate, UserId,'" + Session["UserId"].ToString() + "' " +
                                               " FROM         AttendanceRelaxation AS c " +
                                               " WHERE     (RegNo = '" + txtregno.Text + "') and SubPaperCode='" + (string)gvPractical.DataKeys[i].Value + "' and ExamSession='" + ddlexamsess.SelectedValue + "' and PaperType='P'; " +
                                               " DELETE FROM AttendanceRelaxation WHERE     (RegNo = '" + txtregno.Text + "') and SubPaperCode='" + (string)gvPractical.DataKeys[i].Value + "' and ExamSession='" + ddlexamsess.SelectedValue + "' and PaperType='P'; ";
                        int updateAttendance = dut.InsertUpdateDelete(updateHistory);
                    }
                    if (otherRelaxation > 0 || medicalRelaxation > 0)
                    {
                        string insertQuery = " INSERT INTO AttendanceRelaxation " +
                                             " (SubPaperCode, ExamSession, PaperType, RegNo, UnivRollNo, MedicalRelaxation, OtherRelaxation,  ModifiedDate, UserId) " +
                                             " VALUES     ('" + (string)gvPractical.DataKeys[i].Value + "','" + ddlexamsess.SelectedValue + "','P','" + txtregno.Text + "','" + txtrollno.Text + "'," + medicalRelaxation.ToString() + "," + otherRelaxation.ToString() + ",getdate(),'" + Session["UserId"].ToString() + "' )";
                        result = dut.InsertUpdateDelete(insertQuery);
                    }
                }
            }
            if (result >= 0)
            {
                LblMsg.Text = "Update Successfully";
            }
            else
            {
                LblMsg.Text = "Error in save";
            }

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;

        }
    }



    protected void ddlsemester_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            Panel2.Visible = false;
            gvTheory.DataSource = null;
            gvTheory.DataBind();
            string sql = "SELECT     COURSEPAPERS.PaperAbbr as CourseCode, COURSEPAPERS.SubPaperCode,'' as ClassHeld, '' as Attended, '' as MaxiumRelax,'' as MedicalRelaxation	,'' as OtherRelaxation, 'false' as hiddenValue, 0 as ValueToCompare,'false' as txtThRelaxEnabled,'false' as txtThOtherRelaxEnabled " +
                         " FROM         EXAMPAPERDETAIL INNER JOIN " +
                         " COURSEPAPERS ON EXAMPAPERDETAIL.StreamPartCode = COURSEPAPERS.StreamPartCode AND " +
                          " EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                          " where (EXAMPAPERDETAIL.RegNo = '" + txtregno.Text + "') AND " +
                          " (EXAMPAPERDETAIL.StreamPartCode = '" + ddlsemester.SelectedValue + "') AND (EXAMPAPERDETAIL.examsession = '" + ddlexamsess.SelectedValue + "') and EXAMPAPERDETAIL.ExamType in ('B','R') and EXAMPAPERDETAIL.PaperType in ('X','T')   ";
            DataTable courseTheory = dut.SelectDatatable(sql);
            if (courseTheory.Rows.Count > 0)
            {
                Panel2.Visible = true;
                BtnUpdate.Visible = true;
                foreach (DataRow dr in courseTheory.Rows)
                {
                    DataTable dtTheory = dut.SelectDatatable(" select Count(*) as RowsCount, Sum( ClassHeld) as ClassHeld,SUM(COUNT) as Attended,case when CEILING( 0.15*Convert(float,Sum( ClassHeld)))>Sum( ClassHeld)-SUM(COUNT) then Sum( ClassHeld)-SUM(COUNT) else CEILING( 0.15*Convert(float,Sum( ClassHeld))) end as MaxiumRelax,  MedicalRelaxation as MedicalRelaxation, OtherRelaxation as OtherRelaxation from AttendanceDetail a inner Join AttendanceRegister b on a.RegisterId=b.Id left join AttendanceRelaxation c on b.SubPaperCode=c.SubPaperCode and b.ExamSession=c.ExamSession and a.RegNo=c.RegNo and b.PaperType=c.PaperType where a.RegNo='" + txtregno.Text + "' and b.SubpaperCode='" + dr["SubPaperCode"].ToString() + "' and b.ExamSession='" + ddlexamsess.SelectedValue + "' and b.paperType='T'   group by MedicalRelaxation, OtherRelaxation");
                    if (dtTheory.Rows.Count > 0)
                    {
                        dr["hiddenValue"] = true.ToString();
                        dr["txtThRelaxEnabled"] = true.ToString();
                        dr["txtThOtherRelaxEnabled"] = true.ToString();
                        dr["ClassHeld"] = dtTheory.Rows[0]["ClassHeld"].ToString();
                        dr["Attended"] = dtTheory.Rows[0]["Attended"].ToString();
                        if (dtTheory.Rows[0]["MedicalRelaxation"] != DBNull.Value)
                        {
                            dr["MedicalRelaxation"] = dtTheory.Rows[0]["MedicalRelaxation"].ToString();
                        }
                        if (dtTheory.Rows[0]["OtherRelaxation"] != DBNull.Value)
                        {
                            dr["OtherRelaxation"] = dtTheory.Rows[0]["OtherRelaxation"].ToString();
                        }
                        dr["ValueToCompare"] = dtTheory.Rows[0]["MaxiumRelax"].ToString();
                    }

                }
                gvTheory.DataSource = courseTheory;
                gvTheory.DataBind();
            }

            sql = "SELECT     COURSEPAPERS.PaperAbbr as CourseCode, COURSEPAPERS.SubPaperCode,'' as ClassHeld, '' as Attended, '' as MaxiumRelax,'' as MedicalRelaxation	,'' as OtherRelaxation, 'false' as hiddenValue, 0 as ValueToCompare,'false' as txtPtRelaxEnabled,'false' as txtPtOtherRelaxEnabled " +
                          " FROM         EXAMPAPERDETAIL INNER JOIN " +
                          " COURSEPAPERS ON EXAMPAPERDETAIL.StreamPartCode = COURSEPAPERS.StreamPartCode AND " +
                           " EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                           " where (EXAMPAPERDETAIL.RegNo = '" + txtregno.Text + "') AND " +
                           " (EXAMPAPERDETAIL.StreamPartCode = '" + ddlsemester.SelectedValue + "') AND (EXAMPAPERDETAIL.examsession = '" + ddlexamsess.SelectedValue + "') and EXAMPAPERDETAIL.ExamType in ('B','R') and EXAMPAPERDETAIL.PaperType in ('X','P')  ";
            DataTable coursePractical = dut.SelectDatatable(sql);
            gvPractical.DataSource = null;
            gvPractical.DataBind();
            if (coursePractical.Rows.Count > 0)
            {
                Panel2.Visible = true;
                BtnUpdate.Visible = true;
                foreach (DataRow dr in coursePractical.Rows)
                {
                    DataTable dtTheory = dut.SelectDatatable(" select Count(*) as RowsCount, Sum( ClassHeld) as ClassHeld,SUM(COUNT) as Attended,case when CEILING( 0.15*Convert(float,Sum( ClassHeld)))>Sum( ClassHeld)-SUM(COUNT) then Sum( ClassHeld)-SUM(COUNT) else CEILING( 0.15*Convert(float,Sum( ClassHeld))) end as MaxiumRelax,  MedicalRelaxation as MedicalRelaxation, OtherRelaxation as OtherRelaxation from AttendanceDetail a inner Join AttendanceRegister b on a.RegisterId=b.Id left join AttendanceRelaxation c on b.SubPaperCode=c.SubPaperCode and b.ExamSession=c.ExamSession and a.RegNo=c.RegNo and b.PaperType=c.PaperType where a.RegNo='" + txtregno.Text + "' and b.SubpaperCode='" + dr["SubPaperCode"].ToString() + "' and b.ExamSession='" + ddlexamsess.SelectedValue + "' and b.paperType='P'  group by MedicalRelaxation, OtherRelaxation ");
                    if (dtTheory.Rows.Count > 0)
                    {
                        dr["hiddenValue"] = true.ToString();
                        dr["txtPtRelaxEnabled"] = true.ToString();
                        dr["txtPtOtherRelaxEnabled"] = true.ToString();
                        dr["ClassHeld"] = dtTheory.Rows[0]["ClassHeld"].ToString();
                        dr["Attended"] = dtTheory.Rows[0]["Attended"].ToString();
                        if (dtTheory.Rows[0]["MedicalRelaxation"] != DBNull.Value)
                        {
                            dr["MedicalRelaxation"] = dtTheory.Rows[0]["MedicalRelaxation"].ToString();
                        }
                        if (dtTheory.Rows[0]["OtherRelaxation"] != DBNull.Value)
                        {
                            dr["OtherRelaxation"] = dtTheory.Rows[0]["OtherRelaxation"].ToString();
                        }
                        dr["ValueToCompare"] = dtTheory.Rows[0]["MaxiumRelax"].ToString();
                    }

                }
                gvPractical.DataSource = coursePractical;
                gvPractical.DataBind();
            }

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }



    }
    protected void ddlexamsess_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ddlsemester.Items.Clear();
            string ddlQuery = "select distinct b.StreamPart,b.StreamPartCode from EXAMPAPERDETAIL a  inner join STREAMPART b on a.StreamPartCode=b.StreamPartCode" +
                                " where RegNo='" + txtregno.Text + "' AND ExamType in ('B','R') and ExamSession='" + ddlexamsess.SelectedValue + "' ";
            DataTable semDet = dut.SelectDatatable(ddlQuery);
            if (semDet.Rows.Count > 0)
            {
                ddlsemester.DataSource = semDet;
                ddlsemester.DataTextField = "StreamPart";
                ddlsemester.DataValueField = "StreamPartCode";
                ddlsemester.DataBind();
            }
            ddlsemester.Items.Insert(0, new ListItem("--Select--", "00"));
            ClearTextBox();
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }



    }

    protected void gvTheory_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
}
