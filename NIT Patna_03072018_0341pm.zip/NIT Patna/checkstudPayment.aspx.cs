using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class checkstudPayment : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    PopulateDDL popddl = new PopulateDDL();

    protected void Page_Load(object sender, EventArgs e)
    {
        //lblroll.Visible = false;
        //txtrollno.Visible = false;
        lblfromdate.Visible = false;
        txtfrmdate.Visible = false;
        lbltodate.Visible = false;
        txttodate.Visible = false;
      //  btnsearch.Visible = false ;
        if (!Page.IsPostBack)
        {

        ExamYear.Visible = false;
        lblExamsession.Visible = false;
        lblbank.Visible = false;
        lblmis.Visible = false;
        lblreg.Visible = false;


            gvbank.Visible = false;
            gvredg.Visible = false;

            gvmis.Visible = false;
            lblbank.Visible = false;
            lblmis.Visible = false;
            lblreg.Visible = false;
            
            
            //Session["checkclear"] = criteria;
            try
            {

                if ((Session["Role"].ToString() != "15") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "17") && (Session["Role"].ToString() != "10") && (Session["Role"].ToString() != "19"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }

              }

        
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        string mis = "";

        if (rdoMisFee.Checked)
        {


            string cri = ExamYear.SelectedItem.ToString();
            if (ExamYear.SelectedItem.ToString().Equals("By Roll"))
            {


                mis = "MISCFEE";
                validate5.Visible = false;
                DataTable dtmis = fnrev.SelectDatatable("SELECT CustomerId AS NIT_TXN_NO, txnReferenceNo AS PG_TXN_REF_NO, bankReferenceNo AS BANK_REF_NO, " +
                    " txnAmount AS AMOUNT, bankId AS BANKID, txnDate AS TXN_DATE, authStatus AS AUTH_STATUS_CODE, AdditionalInfo1 AS ROLL_NO, AdditionalInfo5 AS " +
                    " EXAM_SESSION, ErrorStatus AS ERROR_STATUS,ErrorDescription AS ERROR_DESCRIPTION FROM PGResponse WHERE (AdditionalInfo1 = '" + txtrollno.Text.Trim() + "') and  AdditionalInfo5='" + mis + "'  ");
               
                gvmis.DataSource = dtmis;
                gvmis.DataBind();
            }
            else if (ExamYear.SelectedItem.ToString().Equals("By Date"))

            {
                validate5.Visible = false;
                mis = "MISCFEE";


                DateTime frmdat = Convert.ToDateTime(txtfrmdate.Text.Trim());
                string dt = frmdat.ToString("yyyy-MM-dd");
                
                string query = "SELECT CustomerId AS NIT_TXN_NO, txnReferenceNo AS PG_TXN_REF_NO, bankReferenceNo AS BANK_REF_NO, " +
              "txnAmount AS AMOUNT, bankId AS BANKID, txnDate AS TXN_DATE, authStatus AS AUTH_STATUS_CODE, AdditionalInfo1 AS ROLL_NO," +
               "AdditionalInfo5 AS EXAM_SESSION, ErrorStatus AS ERROR_STATUS,ErrorDescription AS ERROR_DESCRIPTION FROM PGResponse WHERE  Authstatus = '0300'" +
                "AND (CONVERT(date,txnDate,103) = '"+dt+"')  AND AdditionalInfo5 = 'MISCFEE'";
                  DataTable dtmis = fnrev.SelectDatatable(query);
                  gvmis.DataSource = dtmis;
                  gvmis.DataBind();
            }
            else if (ExamYear.SelectedItem.ToString().Equals("By Date Range"))
            {
                validate5.Visible = false;
                mis = "MISCFEE";
                DateTime frmdat = Convert.ToDateTime(txtfrmdate.Text.Trim());
                string dt = frmdat.ToString("yyyy-MM-dd");


                DateTime todat = Convert.ToDateTime(txttodate.Text.Trim());
                string dt1 = todat.ToString("yyyy-MM-dd");

               string query="SELECT CustomerId AS NIT_TXN_NO, txnReferenceNo AS PG_TXN_REF_NO, bankReferenceNo AS BANK_REF_NO, "+
                "txnAmount AS AMOUNT, bankId AS BANKID, txnDate AS TXN_DATE, authStatus AS AUTH_STATUS_CODE, AdditionalInfo1 AS ROLL_NO,"+
                 "AdditionalInfo5 AS EXAM_SESSION, ErrorStatus AS ERROR_STATUS,ErrorDescription AS ERROR_DESCRIPTION FROM PGResponse WHERE  Authstatus = '0300'"+
                  "AND (CONVERT(date,txnDate,103) >= '" + dt + "' AND  CONVERT(date,txnDate,103) <= '" + dt1 + "') AND AdditionalInfo5 = 'MISCFEE'";
               DataTable dtmis = fnrev.SelectDatatable(query);
               gvmis.DataSource = dtmis;
               gvmis.DataBind();
            }
            if (gvmis.Rows.Count == 0)
            {
                System.Web.HttpContext.Current.Response.Write("<SCRIPT>alert('No Data Available')</SCRIPT>");
                lblmis.Visible = false;
                gvbank.Visible = false;
                gvredg.Visible = false;
                gvmis.Visible = false;
                btnsearch.Visible = true;

            }
            else
            {
                gvmis.Visible = true;
                gvbank.Visible = false;
                gvredg.Visible = false;
                lblbank.Visible = false;
                lblmis.Visible = true;
                lblreg.Visible = false;
                btnsearch.Visible = true;

            }
            
            gvbank.Visible = false;
            gvredg.Visible = false;
         
        }

        else   if (rdoRegfee.Checked)
        {
            validate5.Visible = true;
            DataTable dtbank = fnrev.SelectDatatable("SELECT CustomerId AS NIT_TXN_NO, txnReferenceNo AS PG_TXN_REF_NO, bankReferenceNo AS BANK_REF_NO, " +
                " txnAmount AS AMOUNT, bankId AS BANKID, txnDate AS TXN_DATE, authStatus AS AUTH_STATUS_CODE, AdditionalInfo1 AS ROLL_NO, AdditionalInfo4 AS " +
                " EXAM_SESSION, ErrorStatus AS ERROR_STATUS,ErrorDescription AS ERROR_DESCRIPTION FROM BankStatement WHERE (AdditionalInfo1 = '" + txtrollno.Text.Trim() + "') " +
                " AND (AdditionalInfo4 = '" + ExamYear.SelectedItem.ToString() + "')");
            gvbank.DataSource = dtbank;
            gvbank.DataBind(); 
           
            DataTable dtredg = fnrev.SelectDatatable("SELECT EXAM.UnivRollNo AS ROLL_NO, STREAM.StreamAbbr AS PROGRAM, STREAMPART.StreamPart AS SEMESTER, " +
                " EXAM.ExamSession AS EXAMSESSION, EXAM.ExamFeeAmt AS EXAM_FEE, EXAM.PaymentId AS NITP_TXN_NO, EXAM.PaymentDate AS PAYMENT_DATE, " +
                " EXAM.ExamType AS EXAM_TYPE, EXAM.ModeOfPayment AS MODE_OF_PAYMENT, EXAM.Bank AS BANK, EXAM.Status AS REDG_SATUS FROM " +
                " EXAM INNER JOIN STREAM ON EXAM.StreamCode = STREAM.StreamCode INNER JOIN STREAMPART ON EXAM.StreamPartCode = STREAMPART.StreamPartCode " +
                " WHERE (EXAM.ExamSession = '" + ExamYear.SelectedItem.ToString() + "') AND (EXAM.UnivRollNo = '" + txtrollno.Text.Trim().ToString() + "')");
            gvredg.DataSource = dtredg;
            gvredg.DataBind();

            gvbank.Visible = true;
            gvredg.Visible = true;
            gvmis.Visible = false;

            lblbank.Visible =true;
            lblmis.Visible = false;
            lblreg.Visible = true;
            btnsearch.Visible = true;
            lblroll.Visible = true;
            txtrollno.Visible = true;
        } 
    }
    protected void rdoMisFee_CheckedChanged(object sender, EventArgs e)
    {
        ExamYear.Items.Clear();
        ExamYear.Items.Add("-SELECT-");
        ExamYear.Items.Add("By Roll");
        ExamYear.Items.Add("By Date");
        ExamYear.Items.Add("By Date Range");
        ExamYear.Visible = true;
        lblExamsession.Text = "Select Criteria";
        lblExamsession.Visible = true;
        btnsearch.Visible = true;

        
    }
    protected void rdoRegfee_CheckedChanged(object sender, EventArgs e)
    {
        ExamYear.Items.Clear();

        popddl.Popualate(ExamYear, "Year", "select distinct ExamSession from EXAMPAPERDETAIL order by ExamSession desc", "ExamSession", "ExamSession");

        ExamYear.Items.Insert(0, new ListItem("--Select--", "00"));
           
        ExamYear.Visible = true;
        lblExamsession.Text = "Exam Session";
        lblExamsession.Visible = true;
        txtrollno.Visible = true;
        txttodate.Visible = false;
        txtfrmdate.Visible = false;
        lbltodate.Visible = false;
        lblfromdate.Visible = false;

        lblroll.Visible = true;
        btnsearch.Visible = true;

    }
   
   
    protected void ExamYear_SelectedIndexChanged2(object sender, EventArgs e)
    {

        if (ExamYear.SelectedItem.ToString().Equals("By Roll"))
        {
            txtrollno.Visible = true;
            txttodate.Visible = false;
            txtfrmdate.Visible = false;
            lbltodate.Visible = false;
            lblfromdate.Visible = false;

            lblroll.Visible = true;
            btnsearch.Visible = true;

        }
        else if (ExamYear.SelectedItem.ToString().Equals("By Date"))
        {
            lblroll.Visible = false;
            txtrollno.Visible = false;
            txtfrmdate.Visible = true;
            txtfrmdate.Visible = true;
            //lbltodate.Visible = true;
            lblfromdate.Text = "Enter Date"; 
           lblfromdate.Visible = true;
           lbltodate.Visible = false;
           txttodate.Visible = false;
           btnsearch.Visible = true;

        }
        else if (ExamYear.SelectedItem.ToString().Equals("By Date Range"))
        {


            lblroll.Visible = false;
            txtrollno.Visible = false;
            txttodate.Visible = true;
            txtfrmdate.Visible = true;
            lbltodate.Visible = true;
            lblfromdate.Visible = true;
            lblfromdate.Text = "From Date";
            btnsearch.Visible = true;


        }

    }
}


  

