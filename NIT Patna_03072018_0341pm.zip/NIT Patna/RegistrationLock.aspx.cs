using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class RegistrationLock : System.Web.UI.Page
{
   static string userid = "";
    Functionreviseed chkfn = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void BtnReg_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;
            SqlDataReader reader;

            cmd.CommandText = " select ApplicantName,FatherName,MotherName,DOB,Gender,CourseSession,regno,ackno,Admyear" +
                            " from Registration  where TempRollNo='" + RollNo.Text.Trim() + "'";
            con.Open();
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                ApplicantName.Text = reader[0].ToString();
                FatherName.Text = reader[1].ToString();
                MotherName.Text = reader[2].ToString();
                DOB.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader[3]));
             
                if (reader["Gender"].ToString() == "M")
                {
                    GenderF.Checked = false;
                    GenderM.Checked = true;
                }
                else
                {
                    GenderM.Checked = false;
                    GenderF.Checked = true;
                }
                txtsession.Text = reader[5].ToString();
                txtregno.Text = reader[6].ToString();
                userid = reader[7].ToString();
                RegFormEntryYear.Text = reader[8].ToString();
            }
                ImageUpload imgUpload = new ImageUpload();
                string strFileName = imgUpload.Image_Load(userid);



                if (strFileName.ToString().Contains("temp"))
                {


                    string photo = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/temp.jpg";

                    string strRightNow = "";
                    string IUrl = "";

                    strRightNow = System.DateTime.Now.ToString("ddMMyyyyHHmmss");
                    IUrl = photo + "?img=" + strRightNow;

                    Image3.ImageUrl = IUrl;
                    Image3.DataBind();


                }

            con.Close();

            DataSet streamdetails = chkfn.SelectDataset("SELECT STREAM.Stream, STREAM.StreamAbbr FROM  STREAM INNER JOIN  REGISTRATION ON STREAM.StreamCode = REGISTRATION.StreamCode WHERE     REGISTRATION.TempRollNo = '" + RollNo.Text.Trim() + "' ");

               if (streamdetails.Tables[0].Rows.Count > 0)
               {

                   txtprogram.Text = streamdetails.Tables[0].Rows[0]["Stream"].ToString();
                   txtstreamabbr.Text = streamdetails.Tables[0].Rows[0]["StreamAbbr"].ToString();

               }
            txtexamsession.Text=ConfigurationManager.AppSettings["ddexamsession"].ToString ();
        }
        catch (Exception ex)
        {
        }
    }
    
    protected void btnsave_Click(object sender, EventArgs e)
    {


        try
        {

            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;

            con.Open();
            cmd.CommandText = "update LogIn set IsLock='Y' where userid='" + userid + "' ";
            cmd.ExecuteNonQuery();

            con.Close();

            con.Open();
            cmd.CommandText = "update registration set MigrationStatus='Y' where TempRollNo='" + RollNo.Text.Trim() + "' ";
            cmd.ExecuteNonQuery();

            con.Close();
            LblMsg.Text = "Admission Cancelled Sucessfully.";

        }
        catch (Exception ex)
        {
        }
    }

   
}
