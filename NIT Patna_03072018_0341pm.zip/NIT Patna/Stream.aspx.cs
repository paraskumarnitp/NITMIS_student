using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.IO;
public partial class Stream : System.Web.UI.Page
{
    Functionreviseed dut = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "1") && (Session["Role"].ToString() != "10"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamTypeCode, "STREAMTYPE", "Select StreamTypeCode,StreamTypeName from StreamType order by StreamTypeCode", "StreamTypeName", "StreamTypeCode");
            popddl.Popualate(MainStream, "MAINSTREAM", "Select MainStreamCode,MainStreamName from MainStream order by MainStreamName", "MainStreamName", "MainStreamCode");
            
           ViewState.Add("EditMode", "false");
           StreamNm.Focus(); 
        }

    }

 

    protected void btnexport_Click(object sender, EventArgs e)
    {



        try
        {
            string query = "SELECT StreamCode As 'ProgramCode', ShortCode, Stream as 'Program', StreamAbbr as 'Program Abbr', StreamTypeCode as 'Program Type Code', MainStreamCode, Duration, ExamPattern, NoOfPapers, TotalMarks, MaxDuration, PromotedIfPassed, Study FROM   STREAM where streamAbbr like  '" + StreamNm.Text + "%' and streamcode<>'00'  order by StreamCode ";
    
            //string query = "select * from Category  order by CategoryCode";
            DataSet dsmasterpaper = new DataSet();
            DataSet dsexportexcel = dut.SelectDataset(query);
            if (dsexportexcel.Tables[0].Rows.Count > 0)
            {
                //Create a dummy GridView
                GridView GridView1 = new GridView();
                GridView1.AllowPaging = false;
                GridView1.DataSource = dsexportexcel.Tables[0];
                GridView1.DataBind();
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=stream_" + DateTime.Now.Date + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                for (int i = 0; i < GridView1.Rows.Count; i++)
                {
                    //Apply text style to each Row
                    GridView1.Rows[i].Attributes.Add("class", "textmode");

                }
                GridView1.RenderControl(hw);
                //style to format numbers to string
                string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
        catch (Exception ex)
        {
        }
    }
   
 
 
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        string query = "SELECT StreamCode As 'ProgramCode', ShortCode, Stream as 'Program', StreamAbbr as 'Program Abbr', StreamTypeCode as 'Program Type Code', MainStreamCode, Duration, ExamPattern, NoOfPapers, TotalMarks, MaxDuration, PromotedIfPassed FROM   STREAM where streamAbbr like  '" + StreamNm.Text + "%' and streamcode<>'00'  order by StreamCode ";

        Panel2.Visible = true;
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, query);
        StreamView.DataSource = ds;
        StreamView.DataBind();




    }
    protected void btnsave_Click(object sender, EventArgs e)
    {



    }
    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        string query = "SELECT StreamCode As 'ProgramCode', ShortCode, Stream as 'Program', StreamAbbr as 'Program Abbr', StreamTypeCode as 'Program Type Code', MainStreamCode, Duration, ExamPattern, NoOfPapers, TotalMarks, MaxDuration, PromotedIfPassed FROM   STREAM where streamcode<>'00' order by StreamCode ";
        Panel2.Visible = true;
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, query);
        StreamView.DataSource = ds;
        StreamView.DataBind();

    }
    protected void StreamView_SelectedIndexChanged(object sender, EventArgs e)
    {
        StreamNm.Text = StreamView.SelectedRow.Cells[3].Text;
        StreamAbbr.Text = StreamView.SelectedRow.Cells[4].Text;
        //StreamTypeCode.Text=StreamView.SelectedRow.Cells[4].Text;
        MainStream.Text = StreamView.SelectedRow.Cells[5].Text;
        Duration.Text = StreamView.SelectedRow.Cells[7].Text;
        ExamPattern.Text = StreamView.SelectedRow.Cells[8].Text;
        NoOfPapers.Text = StreamView.SelectedRow.Cells[9].Text;
        TotalMarks.Text = StreamView.SelectedRow.Cells[10].Text;
        //IstDivMarksPercentage.Text = StreamView.SelectedRow.Cells[10].Text;
        // IIndDivMarksPercentage.Text = StreamView.SelectedRow.Cells[11].Text;
        // IIIrdDivMarksPercentage.Text = StreamView.SelectedRow.Cells[12].Text;
        MaxDuration.Text = StreamView.SelectedRow.Cells[11].Text;
        PromotedIfPassed.Text = StreamView.SelectedRow.Cells[12].Text;


        ViewState.Add("EditMode", "true");
        StreamNm.Focus();



    }
    protected void btnsave_Click1(object sender, EventArgs e)
    {


        try
        {

            string abc = "";
            Panel2.Visible = false;
            if (ViewState["EditMode"].ToString() == "false")
            {


                string[] col = new string[14];
                string[] val = new string[14];
                col[0] = "StreamCode";
                col[1] = "Stream";
                col[2] = "StreamAbbr";
                col[3] = "Duration";
                col[4] = "ExamPattern";
                col[5] = "NoOfPapers";
                col[6] = "TotalMarks";
                // col[7] = "IstDivMarksPercentage";
                // col[8] = "IIndDivMarksPercentage";
                // col[9] = "IIIrdDivMarksPercentage";
                col[10] = "StreamTypeCode";
                col[11] = "MainStreamCode";
                col[12] = "MaxDuration";
                col[13] = "PromotedIfPassed";


                val[1] = StreamNm.Text.Trim();
                val[2] = StreamAbbr.Text.Trim();
                val[3] = Duration.Text;
                val[4] = ExamPattern.SelectedValue.ToString();
                val[5] = NoOfPapers.Text;
                val[6] = TotalMarks.Text;
                //val[7]=IstDivMarksPercentage.Text;
                // val[8]=IIndDivMarksPercentage.Text;
                // val[9]=IIIrdDivMarksPercentage.Text;
                val[10] = StreamTypeCode.SelectedValue;
                val[11] = MainStream.SelectedValue;
                val[12] = MaxDuration.Text;
                val[13] = PromotedIfPassed.Text;


                UnivService.Service1 ss = new UnivService.Service1();
                string SQL = "SELECT     ISNULL(MAX(ABS(StreamCode)), '0') + 1 AS NewStreamCode FROM Stream";

                string NewStreamCode = ss.GetNewCode(SQL);
                // val[0] = NewStreamCode;
                val[0] = string.Format("{0:D2}", Convert.ToInt32(NewStreamCode));

                abc = ss.SaveData("Stream", col, val);

                if (abc == "1")
                {
                    LblMsg.Text = " Stream is saved successfully. Stream Code= " + NewStreamCode;
                    string popupScript = "<script language='javascript'>" +
                                   " alert('Course Code=   " + NewStreamCode + " is saved successfully. ')" +
                                    "</script>";

                    Page.RegisterStartupScript("PopupScript", popupScript);
                    StreamAbbr.Text = "";
                    StreamAbbr.Focus();


                }
                else
                {
                    LblMsg.Text = abc.ToString();
                }
            }
            else
            {

                UnivService.Service1 ss = new UnivService.Service1();
                //abc = " update Stream set Stream='" + StreamNm.Text.Trim() + "',StreamAbbr='" + StreamAbbr.Text.Trim() + "',Duration='" + Duration.Text + "',ExamPattern='" + ExamPattern.SelectedValue.ToString() + "',"+
                //      "StreamTypeCode='"+ StreamTypeCode.SelectedValue + "',MainStreamCode='"+MainStream.SelectedValue+"',     "+
                //      "NoOfPapers='" + NoOfPapers.Text + "',TotalMarks='" + TotalMarks.Text + "',IstDivMarksPercentage='" + IstDivMarksPercentage.Text + "',IIndDivMarksPercentage='" + IIndDivMarksPercentage.Text + "',IIIrdDivMarksPercentage='" + IIIrdDivMarksPercentage.Text + "', MaxDuration='" + MaxDuration.Text + "', PromotedIfPassed='"+PromotedIfPassed.Text   +"' where StreamCode='" + StreamView.SelectedRow.Cells[1].Text.Trim() + "'";


                abc = " update Stream set Stream='" + StreamNm.Text.Trim() + "',StreamAbbr='" + StreamAbbr.Text.Trim() + "',Duration='" + Duration.Text + "',ExamPattern='" + ExamPattern.SelectedValue.ToString() + "'," +
                      "StreamTypeCode='" + StreamTypeCode.SelectedValue + "',MainStreamCode='" + MainStream.SelectedValue + "',     " +
                      "NoOfPapers='" + NoOfPapers.Text + "',TotalMarks='" + TotalMarks.Text + "', MaxDuration='" + MaxDuration.Text + "', PromotedIfPassed='" + PromotedIfPassed.Text + "' where StreamCode='" + StreamView.SelectedRow.Cells[1].Text.Trim() + "'";



                abc = ss.UpdateData(abc);
                if (abc.ToString() == "ok")
                {
                    ViewState.Add("EditMode", "false");
                    LblMsg.Text = " Record is updated successfully.";
                    StreamNm.Text = "";
                    StreamAbbr.Text = "";
                    Duration.Text = "";
                    NoOfPapers.Text = "";
                    TotalMarks.Text = "";
                    IstDivMarksPercentage.Text = "";
                    IIndDivMarksPercentage.Text = "";
                    IIIrdDivMarksPercentage.Text = "";
                    MaxDuration.Text = "";
                    PromotedIfPassed.Text = "";
                    StreamNm.Focus();

                }
                else
                    LblMsg.Text = abc.ToString();

            }


        }
        catch(Exception ex)
        {
        }
    }

}
