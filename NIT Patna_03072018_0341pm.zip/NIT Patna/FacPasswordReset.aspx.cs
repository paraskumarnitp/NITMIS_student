using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class FacPasswordReset : System.Web.UI.Page
{
    Functionreviseed usbfunctions = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "2") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
                binduserid();
            }
            catch (Exception ex)
            {
                LblMsg.Text = ex.Message;
            }
            UserId.Focus();
        }
    }
    protected void resetpassword_Click(object sender, EventArgs e)
    {
        try
        {
            string login;
            Encryption enc = new Encryption();

            if (NewPassword.Text != reNewPassword.Text)
            {
                reNewPassword.Text = "";
                NewPassword.Text = "";
                NewPassword.Focus();
                LblMsg.Text = "Please Re-Enter New Password";
                return;
            }


            string sql = "";
            //Validating Old Password
            UnivService.Service1 ss = new UnivService.Service1();
            sql = "Select Count(UserName) From Login where UserId='" + UserId.SelectedItem.ToString() + "' ";
            //login = ss.Login(UserId.Text.ToString(), enc.EncryptPassword(OldPassword.Text.ToString()));
            login = ss.GetNewCode(sql);

            if (login != "1")
            {
                LblMsg.Text = "Invalid User Id";
                return;
            }




            //Setting New Password

            string abc = "";
            sql = "";

            if (login == "1")
            {
                int InsRec = usbfunctions.InsertUpdateDelete("INSERT INTO PasswordHistory(UserId, Password,OptUserId) " +
                    " SELECT UserId, Password,'" + Session["UserId"].ToString() + "' as OptUserId FROM LogIn WHERE UserId = '" + UserId.SelectedItem.ToString() + "'");
                if (InsRec == 1)
                {
                    InsRec = usbfunctions.InsertUpdateDelete("INSERT INTO tempregister(UserId, temppass) VALUES " +
                        " ('" + UserId.SelectedItem.ToString() + "','" + NewPassword.Text.ToString() + "')");
                    if (InsRec == 1)
                    {
                        sql = "Update LOGIN Set Password='" + enc.EncryptPassword(NewPassword.Text.ToString()) + "' where UserId='" + UserId.SelectedItem.ToString() + "' ";

                        abc = ss.UpdateData(sql);

                        if (abc == "ok")
                        {
                            LblMsg.Text = "Your Password has been changed successfully";

                            UserId.SelectedIndex = 0;
                            NewPassword.Text = "";
                            reNewPassword.Text = "";
                            UserId.Focus();
                        }

                        else
                        {
                            LblMsg.Text = abc.ToString();
                        }
                    }
                }
            }

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }


    private void binduserid()
    {
        string query = "Select UserId,UserName FRom LogIn WHERE UserId LIKE 'Fc%'";
        DataTable dtuserid = usbfunctions.SelectDatatable(query);
        UserId.DataSource = dtuserid;
        UserId.DataTextField = "UserId";
        UserId.DataValueField = "UserId";
        UserId.DataBind();
        UserId.Items.Insert(0,new ListItem("--Select--","0"));
    }
}
