
var dtCh= "/";
var minYear=1900;
var maxYear=2100;

function E1(d1)
  {
var t1=document.getElementById(d1).value;
//alert (t1);
     // Numbers Checking
      var i;
        for (i = 0; i < t1.length; i++)
         {
            var c = t1.charAt(i);
            if ( (c < "0") || (c > "9") )
            { 
            alert ("All characters are not numbers.");
            document.getElementById(d1).value="";
            return false;
            }
        }
     // Numbers Checking
      
  
  
  if (document.getElementById(d1).value=="")
    {
    //alert ("Date Should not be blank");
    return false;
    }
    
  else
    {
        var s1=t1.substring(0,2);
        var s2=t1.substring(2,4);
        var s3=t1.substring(4,8);

        
        
        var i1=parseInt(s1);
        var i2=parseInt(s2);
        
        if (i1>=1 && i1<=9)
        {
        i1=s1;
        }
        
        if (i2>=1 && i2<=9)
        {
        i2=s2;
        }
        
        
        var i3=parseInt(s3);
        
        
//        alert(i1);alert(s1);
//        alert(i2);alert(s2);
//        alert(i3);alert(s3);
        
        //MakeDOB(i1,i2,i3,d1);
        MakeDOB(s1,s2,i3,d1);
        
   }
}


function MakeDOB(day,month,year,d1)
  {

	     var DOB = day + '/' + month + '/' + year;
	     document.getElementById(d1).value=DOB;
	     var dt=document.getElementById(d1);
	     if (isDate(dt.value)==false)
	     {
	     dt.focus()
		 return false;
		 }
	
    return true;
		 
 }
 
function isInteger(s){
	var i;
    for (i = 0; i < s.length; i++){   
        // Check that current character is number.
        var c = s.charAt(i);
        if (((c < "0") || (c > "9"))) return false;
    }
    // All characters are numbers.
    return true;
}
 
function stripCharsInBag(s, bag){
	var i;
    var returnString = "";
    // Search through string's characters one by one.
    // If character is not in bag, append to returnString.
    for (i = 0; i < s.length; i++){   
        var c = s.charAt(i);
        if (bag.indexOf(c) == -1) returnString += c;
    }
    return returnString;
}

function daysInFebruary (year){
	// February has 29 days in any year evenly divisible by four,
    // EXCEPT for centurial years which are not also divisible by 400.
    return (((year % 4 == 0) && ( (!(year % 100 == 0)) || (year % 400 == 0))) ? 29 : 28 );
}
function DaysArray(n) {
	for (var i = 1; i <= n; i++) {
		this[i] = 31
		if (i==4 || i==6 || i==9 || i==11) {this[i] = 30}
		if (i==2) {this[i] = 29}
   } 
   return this;
}
function isDate(dtStr){
	var daysInMonth = DaysArray(12)
	var pos1=dtStr.indexOf(dtCh)
	var pos2=dtStr.indexOf(dtCh,pos1+1)

	var strDay=dtStr.substring(0,pos1)
	var strMonth=dtStr.substring(pos1+1,pos2)
	var strYear=dtStr.substring(pos2+1)
	strYr=strYear
	if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1)
	if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1)
	for (var i = 1; i <= 3; i++) {
		if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1)
	}
	month=parseInt(strMonth)
	day=parseInt(strDay)
	year=parseInt(strYr)
	if (pos1==-1 || pos2==-1){
		alert("The date format should be : dd/mm/yyyy")
		return false;
	}
	if (strMonth.length<1 || month<1 || month>12){
		alert("Please enter a valid month")
		return false
	}
	if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
		alert("Please enter a valid day")
		return false
	}
	if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
		alert("Please enter a valid 4 digit year between "+minYear+" and "+maxYear)
		return false
	}
	if (dtStr.indexOf(dtCh,pos2+1)!=-1 || isInteger(stripCharsInBag(dtStr, dtCh))==false){
		alert("Please enter a valid date")
		return false
	}
return true;
}
 
 
 
 
 // Set the value in the textbox on Focus
function blank(d1)
 {
   var t1=document.getElementById(d1).value;

if (document.getElementById(d1).value=="")
    {
    //alert ("Date Should not be blank");
    return false;
    }
    
else
   {
     var s1=t1.substring(0,2);
     var s2=t1.substring(3,5);
     var s3=t1.substring(6,10);
     var DOB = s1 +s2 +s3;
     document.getElementById(d1).value=DOB;
   }

 }
 
 