 // Date Check 
  var taxtval="";
  var total=0;
  function checkDOB(day,month,year,d1)
	{
	     var DOB = day + '/' + month + '/' + year;
	     var dobdate = new Date(year,month,day);
	     if ( month!=dobdate.getMonth() )
       {
         var month1=parseInt(month)+1;
         var DOB1=day + '/' + month1 + '/' + year;
	       alert(DOB1 + " is NOT a valid !!!" );
         document.getElementById(d1).value="";
         document.getElementById(d1).focus;
	     }
	     else
      {
        event.keyCode=9;
      }
	 }
  function D1(d1)
  {
  taxtval=document.getElementById(d1).value;
  }
  function E1(d1)
  {
   if(event.keyCode==13)
   {
    var t1=document.getElementById(d1).value;
    var s1=t1.substring(0,2);
    var s2=t1.substring(3,5);
    var s3=t1.substring(6,10);
    var i1=parseInt(s1);
    var i2=parseInt(s2);
    var i3=parseInt(s3);
    checkDOB(i1,i2-1,i3,d1);
   }
  
  }
  function D2(d1)

  {
alert('ok');
    if((event.keyCode>=48 && event.keyCode<=57) ||(event.keyCode>=96 && event.keyCode<=105)||event.keyCode==8)
   {
    var l=document.getElementById(d1).value;
    if(l.length==2 && event.keyCode!=8)
    {
     document.getElementById(d1).value=l+"-";
    }
    if(l.length==5 && event.keyCode!=8)
    {
     document.getElementById(d1).value=l+"-";
    }
   }
   else
   {
   document.getElementById(d1).value=taxtval;
   document.getElementById(d1).focus;
   return;
   }
  }
  
  // Date Check
  // Select (Combo Box Set)
  
 function f2(f,t)
{
 for(var i=0;i<document.getElementById(f).length;i++)
  {
   var a=document.getElementById(t).value;
   if(document.getElementById(t).value==document.getElementById(f).options[i].value.substring(0,a))
   {
      document.getElementById(f).value=document.getElementById(f).options[i].value;
      break;
   }
 }
}
// Select (Combo Box Set)

// Select another Text Box
function E2(f)
   {
     if(event.keyCode==13 )
      {
        document.getElementById(f).focus();
      }
   }
function E()
{
  if(event.keyCode==13 )
   {
     event.keyCode=9;
   }
}
// Select another Text Box
// Check Number Format
function checkNumber(f)
{
   var value1=document.getElementById(f).value;
   if(document.getElementById(f).value=="")
   {
     document.getElementById(f).focus();
     return;
   }
   if(event.keyCode==13 && isNaN(value1))
   {
     alert("Invalid Number");
     document.getElementById(f).value="";
     document.getElementById(f).focus();
   }
  else if(event.keyCode==13)
  {
   event.keyCode=9;
  }
}
// Check Number Format
// Submit button
function submit1(frm,action1)
{
 document.getElementById(frm).action=action1;
 document.getElementById(frm).submit();
}
// Submit button

