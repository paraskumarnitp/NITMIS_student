﻿// JScript File


  function alerting()  {

alert('Ouch, you clicked me!');
}
