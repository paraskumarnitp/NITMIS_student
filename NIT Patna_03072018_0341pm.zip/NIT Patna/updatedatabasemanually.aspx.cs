using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class updatedatabasemanually : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DataTable dtstuddetails = fnrev.SelectDatatable("SELECT EXAM.UnivRollNo, REGISTRATION.RegNo, REGISTRATION.AdmYear, REGISTRATION.StreamCode, REGISTRATION.ActualAdmYear " + 
            " FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo WHERE (EXAM.ExamSession = 'JUL-DEC_2017') AND (EXAM.Status = 'SUBMIT') AND (EXAM.UnivRollNo NOT IN (SELECT DISTINCT UnivRollNo FROM DepositedFeeDetails WHERE (ExamSession = 'JUL-DEC_2017'))) AND (EXAM.ExamType = 'R')");
        if (dtstuddetails.Rows.Count > 0)
        {
            for (int j = 0; j < dtstuddetails.Rows.Count; j++)
            {
                DataTable Feesummary = fnrev.SelectDatatable("SELECT Fee_Details.Description, Fee_Details.Amount FROM Feetype INNER JOIN  Fee_Details " +
                            " ON Feetype.ID = Fee_Details.Fee_Id WHERE (Feetype.StreamTypeCode = '01') AND  (Fee_Details.IsOdd = 1) AND " +
                            " (ISNULL(Feetype.FrmAdmYear, '1990') <= " + dtstuddetails.Rows[j]["AdmYear"].ToString() + ")  AND (ISNULL(Feetype.ToAdmYear, year(getdate())) >= " + dtstuddetails.Rows[j]["AdmYear"].ToString() + ")");
                if (dtstuddetails.Rows[j]["StreamCode"].ToString() == "05")
                {
                    Feesummary.Rows.Add("Educational Tour And Visit", "1000.00");
                }
                if (Feesummary.Rows.Count > 0)
                {
                    for (int y = 0; y < Feesummary.Rows.Count; y++)
                    {
                        int InRec = fnrev.InsertUpdateDelete("INSERT INTO DepositedFeeDetails(UnivRollNo, Feedeposited, " +
                            " Amount, ExamSession, txnType) VALUES ('" + dtstuddetails.Rows[j]["UnivRollNo"].ToString() + "'," +
                            " '" + Feesummary.Rows[y][0].ToString() + "','" + Feesummary.Rows[y][1].ToString() + "','JUL-DEC_2017','DR')");
                    }
                }
            }
        }
    }
}
