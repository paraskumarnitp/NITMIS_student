using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class Clear_ExpelledStudents : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "3")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(UnfairList, "UnfairMeans", "Select UnfairDesc,UnfairCode from UnfairMeans order by UnfairDesc", "UnfairDesc", "UnfairCode");
            BindRoll();
        }
    }
    protected void BtnSave_Click(object sender, EventArgs e)
    {
        SaveRecord();
        BindRoll();
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void BtnReg_Click(object sender, EventArgs e)
    {

        try
        {
            Remarks.Text = "";
            ExamYear.Text = "";

            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;

            cmd.CommandText = " select * from ExpelledStudents where UnivRollNo='" + UnivRollNo.Text + "' And DebarredFromExam='Y'";
            SqlDataReader reader;
            LblMsg.Text = "";
            con.Open();
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
         
                reader.Read();
                Panel2.Visible = true;
                
                RegNo.Text = reader["regNo"].ToString();
                StreamCode.SelectedValue = reader["StreamCode"].ToString();
                CollCode.Text = reader["CollCode"].ToString();

                PopulateDDL popddl = new PopulateDDL();
                popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
                
                string spc = reader["StreamPartCode"].ToString();
                StreamPart.SelectedValue = spc;
                ExamYear.Text = reader["ExamYear"].ToString();
                UnfairList.SelectedValue = reader["UnfairCode"].ToString();
                
                UnivService.Service1 NicService = new UnivService.Service1();
                Punishment.Text = NicService.GetNewCode("Select punishment from Unfairmeans where Unfaircode='" + UnfairList.SelectedValue + "'");
                NicService.Dispose();
                              
                Remarks.Text = reader["Remarks"].ToString();
                reader.Close();


                //Get Student Name
                cmd.CommandText = " Select ApplicantName from registration where RegNo='" + RegNo.Text + "'";
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    StudentName.Text = reader["ApplicantName"].ToString();
                    reader.Close();
                }
                reader.Close();

               

           }
           else
            {
                LblMsg.Text = " Please check University Roll no.";
                Panel2.Visible = false;
                UnivRollNo.Focus();
            }
            con.Close();
           

        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }

    protected void SaveRecord()
    {


        try
        {
            if (CheckBox1.Checked == true)
            {
                string SaveFlag = "Update ExpelledStudents set OrderNo='" + OrderNo.Text + "', OrderDate='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(OrderDate.Text.Trim())) + "', DebarredFromExam='N' where UnivRollNo='" + UnivRollNo.Text + "' And streampartcode='" + StreamPart.SelectedValue + "' And ExamYear='" + ExamYear.Text + "'";
                UnivService.Service1 NicService = new UnivService.Service1();
                SaveFlag = NicService.UpdateData(SaveFlag);

                if (SaveFlag == "ok")
                {
                    LblMsg.Text = "Successfully Saved";
                }
                else
                {
                    LblMsg.Text = "Error";
                }
            }
            else
                LblMsg.Text = "Please check clear unfair cause";
        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }
    protected void BindRoll()
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(UnivRollNo, "ExpelledStudents", "Select UnivRollNo from ExpelledStudents where DebarredFromExam='Y'", "UnivRollNo", "UnivRollNo");
           
    }

}
