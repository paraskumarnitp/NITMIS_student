using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class marksEntrySheet : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
           
            try
            {

                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "9") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "15"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }              
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }


            UnivService.Service1 NicService = new UnivService.Service1();
            int status = Convert.ToInt32(NicService.GetNewCode("select count(Enabled) from Faculty_paper_a where Userid='" + Session["userid"] + "' and Enabled='Y'"));
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(ExamYear, "Year", "select distinct ExamSession from Faculty_paper_a where is_active='Y'  order by ExamSession desc", "ExamSession", "ExamSession");
            ExamYear.Items.Insert(0, new ListItem("--Select--", "00"));
                      
        }      
    }
    protected void btnprint_Click(object sender, EventArgs e)
    {

    }
    protected void ExamYear_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Subject_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
  
}
