using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.Collections.Generic;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Text.RegularExpressions;

public partial class ExtendAttendanceEntry : System.Web.UI.Page
{
    Functionreviseed fn = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            try
            {

                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "14") && (Session["Role"].ToString() != "7"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }

                ViewState.Add("EditMode", "false");

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }


            UnivService.Service1 NicService = new UnivService.Service1();

            string strrole = "";
            if (Session["Role"].ToString() == "9")
                strrole = " and UserId='" + Session["UserId"].ToString() + "'";
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(ExamYear, "Year", "select distinct ExamSession from Faculty_paper_a where is_active='Y'  order by ExamSession desc", "ExamSession", "ExamSession");
            ddlfaculty.Items.Insert(0, new ListItem("--Select--", "00"));
            ExamYear.Items.Insert(0, new ListItem("--Select--", "00"));
            StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
            StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
            splcode.Items.Insert(0, new ListItem("--Select--", "00"));
            Subject.Items.Insert(0, new ListItem("--Select--", "00"));
            ddlMonth.Items.Insert(0, new ListItem("--Select--", "00"));

        }
    }

    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        MTheory.Checked = false;
        MPrac.Checked = false;
        StreamPart.Items.Clear();
        Subject.Items.Clear();
        splcode.Items.Clear();
        string strrole = "  AND (Faculty_paper_a.UserId = '" + ddlfaculty.SelectedValue + "') ";
        PopulateDDL popddl = new PopulateDDL();
        string strspecilaization = "SELECT     CourseSpecialization.SpDescription, CourseSpecialization.SPCode " +
                                   " FROM Faculty_paper_a INNER JOIN COURSEPAPERS ON " +
                                   " Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " +
                                   " CourseSpecialization ON Faculty_paper_a.Splcode = CourseSpecialization.SPCode " +
                                   " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                                   " and COURSEPAPERS.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                                   " GROUP BY CourseSpecialization.SpDescription, CourseSpecialization.SPCode " +
                                   " order by CourseSpecialization.SPCode ";

        popddl.Popualate(splcode, "Specialization", strspecilaization, "SpDescription", "SPCode");
        string strstreampart = "SELECT     STREAMPART.StreamPart,STREAMPART.StreamPartCode " +
                             " FROM         COURSEPAPERS AS COURSEPAPERS_1 INNER JOIN " +
                             " STREAMPART ON COURSEPAPERS_1.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN " +
                             " Faculty_paper_a INNER JOIN " +
                             " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode ON COURSEPAPERS_1.PaperAbbr = COURSEPAPERS.PaperAbbr " +
                             " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                             " and (Faculty_paper_a.splcode='" + splcode.SelectedValue + "') and STREAMPART.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                             " GROUP BY STREAMPART.StreamPartCode, STREAMPART.StreamPart " +
                             " order by StreamPart";


        popddl.Popualate(StreamPart, "StreamPart", strstreampart, "StreamPart", "StreamPartCode");
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
        StreamCode.Focus();
        ddlMonth.Items.Clear();
        ddlMonth.Items.Insert(0, new ListItem("--Select--", "00"));
    }
    protected void MTheory_CheckedChanged(object sender, EventArgs e)
    {
        Subject.Items.Clear();
        GetPaperCode("T");
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
    }

    protected void MPrac_CheckedChanged(object sender, EventArgs e)
    {
        Subject.Items.Clear();
        GetPaperCode("P");
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
    }

    private void GetPaperCode(string PaperType)
    {

        string Querystr = "";
        string queryjoin = "";

        string strrole = "  AND (Faculty_paper_a.UserId = '" + ddlfaculty.SelectedValue + "') ";

        string strcourse = "SELECT    Faculty_paper_a.SubpaperCode, COURSEPAPERS.PaperAbbr " +
                           " FROM         Faculty_paper_a INNER JOIN COURSEPAPERS  ON " +
                           " Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " +
                            " EXAMPAPERDETAIL ON COURSEPAPERS.SubPaperCode = EXAMPAPERDETAIL.SubPaperCode " +
                          " WHERE     (Faculty_paper_a.Is_Active = 'Y') and EXAMPAPERDETAIL.StreamPartCode='" + StreamPart.SelectedValue + "'   And (Faculty_paper_a.splcode = '" + splcode.SelectedValue + "') " + strrole +
                          " and  (EXAMPAPERDETAIL.ExamSession='" + ExamYear.SelectedValue + "') and (EXAMPAPERDETAIL.ExamType in ('R','B')) and  ";

        string querypart = "group by Faculty_paper_a.SubpaperCode,PaperAbbr ORDER BY COURSEPAPERS.PaperAbbr ";

        PopulateDDL popddl = new PopulateDDL();
        UnivService.Service1 NicService = new UnivService.Service1();
        //  Subcode = NicService.GetNewCode("select subcode from subject where streamcode='" + StreamCode.SelectedValue + "'");


        if (PaperType == "T")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "(COURSEPAPERS.PaperTypeCode='02' or COURSEPAPERS.PaperTypeCode='04') and (Faculty_paper_a.PaperType='T' or Faculty_paper_a.PaperType is null)" + querypart, "PaperAbbr", "SubPaperCode");
        }
        else if (PaperType == "X")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "PaperTypeCode='04'" + querypart, "PaperAbbr", "SubPaperCode");
        }
        else if (PaperType == "P")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "(COURSEPAPERS.PaperTypeCode='01' or COURSEPAPERS.PaperTypeCode='04') and (Faculty_paper_a.PaperType='P' or Faculty_paper_a.PaperType is null)" + querypart, "PaperAbbr", "PaperAbbr");
        }
        else if (PaperType == "E")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "PaperTypeCode='03'" + querypart, "PaperAbbr", "PaperAbbr");
        }
        ddlMonth.Items.Clear();
        ddlMonth.Items.Insert(0, new ListItem("--Select--", "00"));
    }
    String papertype;



    protected void splcode_SelectedIndexChanged(object sender, EventArgs e)
    {
        MTheory.Checked = false;
        // RBComp.Checked=false ;
        //MElective.Checked = false;
        //MThPr.Checked = false;
        MPrac.Checked = false;

        //shivam - 23-04-2014
        StreamPart.Items.Clear();
        Subject.Items.Clear();

        string strrole = "  AND (Faculty_paper_a.UserId = '" + ddlfaculty.SelectedValue + "') ";

        PopulateDDL popddl = new PopulateDDL();

        string strstreampart = "SELECT     STREAMPART.StreamPart,STREAMPART.StreamPartCode " +
                              " FROM         COURSEPAPERS AS COURSEPAPERS_1 INNER JOIN " +
                              " STREAMPART ON COURSEPAPERS_1.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN " +
                              " Faculty_paper_a INNER JOIN " +
                              " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode ON COURSEPAPERS_1.PaperAbbr = COURSEPAPERS.PaperAbbr " +
                              " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                              " and (Faculty_paper_a.splcode='" + splcode.SelectedValue + "') and STREAMPART.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                              " GROUP BY STREAMPART.StreamPartCode, STREAMPART.StreamPart " +
                              " order by StreamPart";


        popddl.Popualate(StreamPart, "StreamPart", strstreampart, "StreamPart", "StreamPartCode");
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
        splcode.Focus();


    }


    protected void ExamYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(ddlfaculty, "Login", "select UserName+'-'+Designation AS UserName,UserId from LogIn where IsLock='N' and (Userrole='9' or Userrole='13')  order by UserName", "UserName", "UserId");
        StreamCode.Items.Clear();
        StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
        StreamPart.Items.Clear();
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        splcode.Items.Clear();
        splcode.Items.Insert(0, new ListItem("--Select--", "00"));
        Subject.Items.Clear();
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
        ddlMonth.Items.Clear();
        ddlMonth.Items.Insert(0, new ListItem("--Select--", "00"));
    }



    protected void Btnnew_Click(object sender, EventArgs e)
    {
        int noOfDays = Convert.ToInt32(txtDays.Text) - 1;
        string insertAttendance = " INSERT INTO AttendanceExtended " +
                                    " (RegisterId, FacultyId, FromDate, ToDate, CreatedBy) " +
                                    " VALUES     (" + ddlMonth.SelectedValue + ",'" + ddlfaculty.SelectedValue.Trim() + "',Convert(date, getdate()),Convert(date,dateadd(dd," + noOfDays + ", getdate())),'" + Session["UserId"].ToString() + "')";
        int insertCommited = fn.InsertUpdateDelete(insertAttendance);
        if (insertCommited > 0)
        {
            lblMsg.Text = "Saved Successfully";
        }
        else
        {
            lblMsg.Text = "Error!!!";
        }
    }
    protected void Subject_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        string strstream = string.Empty;
        if (ExamYear.SelectedValue.Substring(0, 7) == "JAN-JUN")
        {
            strstream = "select a.Id,b.Name from AttendanceRegister a inner join Months b on a.Month=b.Id  where SubPaperCode='" + Subject.SelectedValue + "' and SplCode='" + splcode.SelectedValue + "' and ExamSession='" + ExamYear.SelectedValue + "' and Month<month(DATEADD(dd,-6,getdate())) and  Month between 1 and 6";
        }
        else if (ExamYear.SelectedValue.Substring(0, 7) == "JUL-DEC")
        {
            strstream = "select a.Id,b.Name from AttendanceRegister a inner join Months b on a.Month=b.Id  where SubPaperCode='" + Subject.SelectedValue + "' and SplCode='" + splcode.SelectedValue + "' and ExamSession='" + ExamYear.SelectedValue + "' and  Month between 7 and 12";
        }
        else
        {
            strstream = "select a.Id,b.Name from AttendanceRegister a inner join Months b on a.Month=b.Id  where SubPaperCode='" + Subject.SelectedValue + "' and SplCode='" + splcode.SelectedValue + "' and ExamSession='" + ExamYear.SelectedValue + "' and Month<month(DATEADD(dd,-6,getdate())) and  Month=7";
        }
        ddlMonth.Items.Clear();
        popddl.Popualate(ddlMonth, "Month", strstream, "Name", "Id");
        ddlMonth.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void ddlfaculty_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        string strstream = "SELECT     STREAM.StreamAbbr, STREAM.StreamCode FROM Faculty_paper_a INNER JOIN " +
                  " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " +
                  " STREAM ON COURSEPAPERS.StreamCode = STREAM.StreamCode " +
                  " Where Faculty_paper_a.Is_Active='Y' and Faculty_paper_a.examsession='" + ExamYear.SelectedValue + "' and Faculty_paper_a.UserId='" + ddlfaculty.SelectedValue + "'" +
                  " GROUP BY STREAM.StreamAbbr, STREAM.StreamCode order by StreamAbbr ";

        StreamCode.Items.Clear();
        popddl.Popualate(StreamCode, "Stream", strstream, "StreamAbbr", "StreamCode");
        StreamCode.Items.Insert(0, new ListItem("--Select--", "0"));

        StreamPart.Items.Clear();
        Subject.Items.Clear();
        splcode.Items.Clear();
        ddlMonth.Items.Clear();
        StreamPart.Items.Insert(0, new ListItem("--Select--", "0"));
        Subject.Items.Insert(0, new ListItem("--Select--", "0"));
        splcode.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlMonth.Items.Insert(0, new ListItem("--Select--", "0"));

    }
    protected void ddlMonth_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlMonth.SelectedValue != "00")
            txtDays.Enabled = true;
        else
        {
            txtDays.Text = "";
            txtDays.Enabled = false;
        }
    }


}
