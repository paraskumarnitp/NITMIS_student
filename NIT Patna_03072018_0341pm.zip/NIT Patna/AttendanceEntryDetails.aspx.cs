using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AttendanceEntryDetails : System.Web.UI.Page
{
    string criteria = "false";
    string Subcode;
    DataSet dsmarksdata;
    Functionreviseed fn = new Functionreviseed();
    string ThFMarks, PractFMarks;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Session["checkclear"] = criteria;        
            try
            {

                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "9") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "15"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }

                ViewState.Add("EditMode", "false");

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }

            string strrole = "";
            if (Session["Role"].ToString() == "9")
                strrole = " and UserId='" + Session["UserId"].ToString() + "'";
            PopulateDDL popddl = new PopulateDDL();


            //Manish-06092014
            popddl.Popualate(ExamYear, "Year", "select distinct ExamSession from Faculty_paper_a where is_active='Y'  order by ExamSession desc", "ExamSession", "ExamSession");
            ExamYear.Items.Insert(0, new ListItem("--Select--", "00"));
            StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
            StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
            Subject.Items.Insert(0, new ListItem("--Select--", "00"));
            splcode.Items.Insert(0, new ListItem("--Select--", "00"));
            //  ExamYear.Focus();
        }
    }
    protected void ExamYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        string strstream = "SELECT     STREAM.StreamAbbr, STREAM.StreamCode FROM Faculty_paper_a INNER JOIN " +
                  " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " +
                  " STREAM ON COURSEPAPERS.StreamCode = STREAM.StreamCode " +
                  " Where Faculty_paper_a.Is_Active='Y' and Faculty_paper_a.examsession='" + ExamYear.SelectedValue + "'" +
                  " GROUP BY STREAM.StreamAbbr, STREAM.StreamCode order by StreamAbbr ";

        StreamCode.Items.Clear();
        popddl.Popualate(StreamCode, "Stream", strstream, "StreamAbbr", "StreamCode");
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        MTheory.Checked = false;       
        MPrac.Checked = false;

        //shivam - 23-04-2014
        StreamPart.Items.Clear();
        Subject.Items.Clear();
        splcode.Items.Clear();
        string strrole = "";
        if (Session["Role"].ToString() == "9" || Session["Role"].ToString() == "15")
            strrole = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";
        string strspecilaization = "SELECT     CourseSpecialization.SpDescription, CourseSpecialization.SPCode " +
                                    " FROM Faculty_paper_a INNER JOIN COURSEPAPERS ON " +
                                    " Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " +
                                    " CourseSpecialization ON Faculty_paper_a.Splcode = CourseSpecialization.SPCode " +
                                    " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                                    " and COURSEPAPERS.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                                    " GROUP BY CourseSpecialization.SpDescription, CourseSpecialization.SPCode " +
                                    " order by CourseSpecialization.SPCode ";

        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(splcode, "Specialization", strspecilaization, "SpDescription", "SPCode");
        string strstreampart = "SELECT     STREAMPART.StreamPart,STREAMPART.StreamPartCode " +
                               " FROM         COURSEPAPERS AS COURSEPAPERS_1 INNER JOIN " +
                               " STREAMPART ON COURSEPAPERS_1.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN " +
                               " Faculty_paper_a INNER JOIN " +
                               " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode ON COURSEPAPERS_1.PaperAbbr = COURSEPAPERS.PaperAbbr " +
                               " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                               " and (Faculty_paper_a.splcode='" + splcode.SelectedValue + "') and STREAMPART.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                               " GROUP BY STREAMPART.StreamPartCode, STREAMPART.StreamPart " +
                               " order by StreamPart";

        popddl.Popualate(StreamPart, "StreamPart", strstreampart, "StreamPart", "StreamPartCode");
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
        StreamCode.Focus();
    }
    protected void splcode_SelectedIndexChanged(object sender, EventArgs e)
    {
        MTheory.Checked = false;
        MPrac.Checked = false;
        StreamPart.Items.Clear();
        Subject.Items.Clear();

        string strrole = "";
        if (Session["Role"].ToString() == "9")
            strrole = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";

        PopulateDDL popddl = new PopulateDDL();

        string strstreampart = "SELECT     STREAMPART.StreamPart,STREAMPART.StreamPartCode " +
                           " FROM         COURSEPAPERS AS COURSEPAPERS_1 INNER JOIN " +
                           " STREAMPART ON COURSEPAPERS_1.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN " +
                           " Faculty_paper_a INNER JOIN " +
                           " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode ON COURSEPAPERS_1.PaperAbbr = COURSEPAPERS.PaperAbbr " +
                           " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                           " and (Faculty_paper_a.splcode='" + splcode.SelectedValue + "') and STREAMPART.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                           " GROUP BY STREAMPART.StreamPartCode, STREAMPART.StreamPart " +
                           " order by StreamPart";


        popddl.Popualate(StreamPart, "StreamPart", strstreampart, "StreamPart", "StreamPartCode");
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
        splcode.Focus();
    }
    protected void MTheory_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("T");
    }
    protected void MPrac_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("P");
    }
    protected void Subject_SelectedIndexChanged(object sender, EventArgs e)
    {
        //and  ( b.id>=month(DATEADD(dd,-6,getdate())) or Convert(Date,getdate()) between d.Fromdate and d.ToDate
        UnivService.Service1 NicService = new UnivService.Service1();
        string query = "SELECT DISTINCT CASE WHEN AttendanceRegister.Month = '1' THEN 'January' WHEN AttendanceRegister.Month = '2' THEN 'February' WHEN AttendanceRegister.Month = '3' THEN 'March' WHEN " +
            " AttendanceRegister.Month = '4' THEN 'April' WHEN AttendanceRegister.Month = '5' THEN 'May' WHEN AttendanceRegister.Month = '6' THEN 'June' WHEN AttendanceRegister.Month = '7' THEN 'July' WHEN AttendanceRegister.Month " +
            " = '8' THEN 'August' WHEN AttendanceRegister.Month = '9' THEN 'September' WHEN AttendanceRegister.Month = '10' THEN 'October' WHEN AttendanceRegister.Month = '11' THEN 'November' WHEN AttendanceRegister.Month = '12' THEN 'December' END AS MonthNAME, AttendanceRegister.Month " +
            " FROM AttendanceRegister INNER JOIN COURSEPAPERS ON AttendanceRegister.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE (COURSEPAPERS.PaperAbbr = '" + Subject.SelectedValue + "') AND " +
            " (AttendanceRegister.ExamSession = '" + ExamYear.SelectedValue + "') AND (AttendanceRegister.SplCode = '" + splcode.SelectedValue + "') AND (COURSEPAPERS.StreamPartCode = '" + StreamPart.SelectedValue + "') ";
        //string query = "select b.Name,a.Id from attendanceregister a inner join Months b on a.Month = b.Id inner join Coursepapers c on a.subpapercode=c.subpapercode " +
        //                " left join AttendanceExtended d on a.Id=d.RegisterId where c.paperabbr = '" + Subject.SelectedValue + "' and c.streampartcode = '" + StreamPart.SelectedValue + "' and a.SplCode='" + splcode.SelectedValue + "'  ";
        PopulateDDL popddl = new PopulateDDL();
        if (MTheory.Checked == true)
        {
            popddl.Popualate(ddlMonth, "COURSEPAPERS", query + " AND (AttendanceRegister.PaperType = 'T')", "MonthNAME", "Month");

        }
        else
        {
            popddl.Popualate(ddlMonth, "COURSEPAPERS", query + " AND (AttendanceRegister.PaperType = 'P')", "MonthNAME", "Month");
        }
        ddlMonth.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void ddlMonth_SelectedIndexChanged(object sender, EventArgs e)
    {
        //UnivService.Service1 NicService = new UnivService.Service1();
        //string countQuery = "   select Count( distinct Classheld) from attendancedetail where registerId= " + ddlMonth.SelectedValue;
        //int totalClassCount = (int)fn.singlevalue(countQuery);
        //if (totalClassCount > 1)
        //{
            
        //    //chkDifferentClass.Enabled = false;   
        //    //RequiredFieldValidator3.ValidationGroup = "NoVali";
        //}
        //else
        //{
        //    string query = " select ISNULL(convert(varchar, Classheld),'') from attendancedetail where registerId=" + ddlMonth.SelectedValue;
        //    string totalClass = (string)fn.singlevalue(query);
     
           
        //}
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            string strque = "AttendanceEntryPrint.aspx?es=" + ExamYear.SelectedValue + "&mn=" + ddlMonth.SelectedValue + "&spl=" + splcode.SelectedValue + "&spc=" + StreamPart.SelectedValue + "&par=" + Subject.SelectedItem;
            ScriptManager.RegisterStartupScript(this, Page.GetType(), "", "window.open('" + strque + "','Attendance_Entry_Print','height=600,width=800,resizable=yes');", true);            
        }
    }

    private void GetPaperCode(string PaperType)
    {
        Subject.Items.Clear();
        string Querystr = "";
        string queryjoin = "";     
        Querystr = " (COURSEPAPERS.StreamPartCode='" + StreamPart.SelectedValue + "')";
        queryjoin = "COURSEPAPERS_1.SubPaperCode = COURSEPAPERS.SubPaperCode";
     
        string strrole = "";
        if (Session["Role"].ToString() == "9" || Session["Role"].ToString() == "13")
            strrole = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";

        string strcourse = "SELECT     COURSEPAPERS.PaperAbbr " +
                           " FROM         Faculty_paper_a INNER JOIN COURSEPAPERS AS COURSEPAPERS_1 ON " +
                           " Faculty_paper_a.SubPaperCode = COURSEPAPERS_1.SubPaperCode INNER JOIN COURSEPAPERS " +
                            " ON " + queryjoin + " INNER JOIN " +
                            " EXAMPAPERDETAIL ON COURSEPAPERS.SubPaperCode = EXAMPAPERDETAIL.SubPaperCode " +
                          " WHERE     (Faculty_paper_a.Is_Active = 'Y') And (Faculty_paper_a.splcode = '" + splcode.SelectedValue + "') " + strrole +
                          " and" + Querystr + " and  (EXAMPAPERDETAIL.ExamSession='" + ExamYear.SelectedValue + "') and ";

        string querypart = " GROUP BY COURSEPAPERS.PaperAbbr ORDER BY COURSEPAPERS.PaperAbbr ";

        PopulateDDL popddl = new PopulateDDL();
        UnivService.Service1 NicService = new UnivService.Service1();
        Subcode = NicService.GetNewCode("select subcode from subject where streamcode='" + StreamCode.SelectedValue + "'");


        if (PaperType == "T")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "(COURSEPAPERS.PaperTypeCode='02' or COURSEPAPERS.PaperTypeCode='04') and (Faculty_paper_a.PaperType='T' or Faculty_paper_a.PaperType is null)" + querypart, "PaperAbbr", "PaperAbbr");
        }
        else if (PaperType == "X")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "PaperTypeCode='04'" + querypart, "PaperAbbr", "PaperAbbr");
        }
        else if (PaperType == "P")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "(COURSEPAPERS.PaperTypeCode='01' or COURSEPAPERS.PaperTypeCode='04') and (Faculty_paper_a.PaperType='P' or Faculty_paper_a.PaperType is null)" + querypart, "PaperAbbr", "PaperAbbr");
        }
        else if (PaperType == "E")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "PaperTypeCode='03'" + querypart, "PaperAbbr", "PaperAbbr");
        }
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
        //  GetMarks();
        Subject.Focus();

    }
}
