using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.IO;
public partial class StreamPart : System.Web.UI.Page
{
    Functionreviseed dut = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "1") && (Session["Role"].ToString() != "10"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamCode, "stream", "Select StreamCode,stream from Stream order by Stream", "Stream", "StreamCode");
            popddl.Popualate(StrmPart, "Part", "Select Part from part order by Part", "part", "part");
            ViewState.Add("EditMode", "false");
            StreamCode.Focus(); 

        }
    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            string abc = "";
            Panel2.Visible = false;
            if (ViewState["EditMode"].ToString() == "false")
            {

                string[] col = new string[3];
                string[] val = new string[3];
                col[0] = "StreamCode";
                col[1] = "StreamPartCode";
                col[2] = "StreamPart";

                val[0] = StreamCode.SelectedValue.ToString();
                val[2] = StrmPart.Text.Trim();


                UnivService.Service1 ss = new UnivService.Service1();
                string SQL = "SELECT     ISNULL(MAX(ABS(StreamPartCode)), '0') + 1 AS NewPartCode FROM StreamPart";

                string NewPartCode = ss.GetNewCode(SQL);
                val[1] = NewPartCode;

                //val[1] = string.Format("{0:D2}", Convert.ToInt32(NewPartCode));


                abc = ss.SaveData("StreamPart", col, val);

                if (abc == "1")
                {
                    LblMsg.Text = " StreamPart is saved successfully. Part Code= " + NewPartCode;
                    string popupScript = "<script language='javascript'>" +
                                   " alert('Part Code=   " + NewPartCode + " is saved successfully. ')" +
                                    "</script>";

                    Page.RegisterStartupScript("PopupScript", popupScript);
                    //StrmPart.Text = "";
                    StrmPart.Focus();


                }
                else
                {
                    LblMsg.Text = abc.ToString();
                }
            }
            else
            {

                UnivService.Service1 ss = new UnivService.Service1();
                abc = " update StreamPart set StreamPart='" + StrmPart.Text.Trim() + "', StreamCode='" + StreamCode.SelectedValue.ToString() + "' where StreamPartCode='" + StreamPartView.SelectedRow.Cells[2].Text.Trim() + "'";
                abc = ss.UpdateData(abc);
                if (abc.ToString() == "ok")
                {
                    ViewState.Add("EditMode", "false");
                    LblMsg.Text = " Record is updated successfully.";
                    StreamCode.Focus();
                }
                else
                    LblMsg.Text = abc.ToString();

            }
        }
        catch (Exception ex)
        {

        }

    }
    //protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    //{
    //    Panel2.Visible = true;
    //    DataSet ds = new DataSet();
    //    ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select * from streamPart order by StreamCode,StreamPartCode");
    //    StreamPartView.DataSource = ds;
    //    StreamPartView.DataBind(); 
    //}
    protected void StreamPartView_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            StrmPart.Text = StreamPartView.SelectedRow.Cells[3].Text;
            StreamCode.SelectedValue = StreamPartView.SelectedRow.Cells[1].Text;
            ViewState.Add("EditMode", "true");
        }
        catch (Exception ex)
        {

            
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {


        try
        {
            string abc = "";
            Panel2.Visible = false;
            if (ViewState["EditMode"].ToString() == "false")
            {

                string[] col = new string[3];
                string[] val = new string[3];
                col[0] = "StreamCode";
                col[1] = "StreamPartCode";
                col[2] = "StreamPart";

                val[0] = StreamCode.SelectedValue.ToString();
                val[2] = StrmPart.Text.Trim();


                UnivService.Service1 ss = new UnivService.Service1();
                string SQL = "SELECT     ISNULL(MAX(ABS(StreamPartCode)), '0') + 1 AS NewPartCode FROM StreamPart";

                string NewPartCode = ss.GetNewCode(SQL);
                val[1] = NewPartCode;

                //val[1] = string.Format("{0:D2}", Convert.ToInt32(NewPartCode));


                abc = ss.SaveData("StreamPart", col, val);

                if (abc == "1")
                {
                    LblMsg.Text = " StreamPart is saved successfully. Part Code= " + NewPartCode;
                    string popupScript = "<script language='javascript'>" +
                                   " alert('Part Code=   " + NewPartCode + " is saved successfully. ')" +
                                    "</script>";

                    Page.RegisterStartupScript("PopupScript", popupScript);
                    //StrmPart.Text = "";
                    StrmPart.Focus();


                }
                else
                {
                    LblMsg.Text = abc.ToString();
                }
            }
            else
            {

                UnivService.Service1 ss = new UnivService.Service1();
                abc = " update StreamPart set StreamPart='" + StrmPart.Text.Trim() + "', StreamCode='" + StreamCode.SelectedValue.ToString() + "' where StreamPartCode='" + StreamPartView.SelectedRow.Cells[2].Text.Trim() + "'";
                abc = ss.UpdateData(abc);
                if (abc.ToString() == "ok")
                {
                    ViewState.Add("EditMode", "false");
                    LblMsg.Text = " Record is updated successfully.";
                    StreamCode.Focus();
                }
                else
                    LblMsg.Text = abc.ToString();

            }

        }
        catch (Exception ex)
        {

        }





    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        try
        {
            Panel2.Visible = true;
            DataSet ds = new DataSet();

            if (StreamCode.SelectedIndex == 0)
            {

                ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select * from streamPart  where streampartcode<>'00' order by StreamCode,StreamPartCode");
            }
            else
            {
                ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select * from streamPart where  StreamCode='" + StreamCode.SelectedValue + "' order by StreamCode,StreamPartCode");

            }


            StreamPartView.DataSource = ds;
            StreamPartView.DataBind();
        }
        catch (Exception ex)
        {
        }
    }
    protected void btnexport_Click(object sender, EventArgs e)
    {

        try
        {
            string query = "select * from streamPart where streampartcode<>'00' order by  StreamCode,StreamPartCode";
          //  string query = "SELECT StreamCode As 'ProgramCode', ShortCode, Stream as 'Program', StreamAbbr as 'Program Abbr', StreamTypeCode as 'Program Type Code', MainStreamCode, Duration, ExamPattern, NoOfPapers, TotalMarks, MaxDuration, PromotedIfPassed, Study FROM   STREAM where streamAbbr like  '" + StreamNm.Text + "%' and streamcode<>'00'  order by StreamCode ";

            //string query = "select * from Category  order by CategoryCode";
            DataSet dsmasterpaper = new DataSet();
            DataSet dsexportexcel = dut.SelectDataset(query);
            if (dsexportexcel.Tables[0].Rows.Count > 0)
            {
                //Create a dummy GridView
                GridView GridView1 = new GridView();
                GridView1.AllowPaging = false;
                GridView1.DataSource = dsexportexcel.Tables[0];
                GridView1.DataBind();
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=streampart_" + DateTime.Now.Date + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                for (int i = 0; i < GridView1.Rows.Count; i++)
                {
                    //Apply text style to each Row
                    GridView1.Rows[i].Attributes.Add("class", "textmode");

                }
                GridView1.RenderControl(hw);
                //style to format numbers to string
                string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
        catch (Exception ex)
        {
        }



    }
}
