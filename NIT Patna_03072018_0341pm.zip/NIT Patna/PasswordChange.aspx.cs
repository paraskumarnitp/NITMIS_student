using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class PasswordChange : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["UserId"].ToString() == "")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
            }
            catch (Exception ex)
            {
                LblMsg.Text = ex.Message;
            }

        }
    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            Boolean login;
            Encryption enc = new Encryption();

            if (NewPassword.Text != reNewPassword.Text)
            {
                reNewPassword.Text = "";
                NewPassword.Text = "";
                NewPassword.Focus();
                LblMsg.Text = "Please Re-Enter New Password";
                return;
            }



            //Validating Old Password
            UnivService.Service1 ss = new UnivService.Service1();
            login = ss.Login(Session["UserId"].ToString(), enc.EncryptPassword(OldPassword.Text.ToString()));
            
            
           

            if (login == false)
            {
                LblMsg.Text = "Invalid Old Password";
                return;
            }




            //Setting New Password

            string abc = "";
            string sql = "";
           
            if (login == true)
            {
                sql = "Update LOGIN Set Password='" + enc.EncryptPassword(NewPassword.Text.ToString()) + "' where UserId='" + Session["UserId"].ToString() + "' ";

                abc = ss.UpdateData(sql);

                if (abc == "ok")
                {
                    LblMsg.Text = "Your Password has been changed successfully";

                   // UserId.Text = "";
                    NewPassword.Text = "";
                    reNewPassword.Text = "";
                    //UserId.Focus();
                }

                else
                {
                    LblMsg.Text = abc.ToString();
                }
            }

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

    
    }
}
