using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class ViewUniversity : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        DataSet ds = new DataSet();
        string SqlQuery="SELECT     dbo.UNIVERSITY.UnivCode, dbo.UNIVERSITY.UnivName, dbo.UNIVERSITY.Address1, dbo.UNIVERSITY.Address2, dbo.DISTRICT.DistName, " +
                        "dbo.UNIVERSITY.PinCode, dbo.State.state, dbo.UNIVERSITY.PhoneNo, dbo.UNIVERSITY.Email, dbo.UNIVERSITY.Fax FROM         dbo.UNIVERSITY INNER JOIN"+
                        " dbo.DISTRICT ON dbo.UNIVERSITY.DistCode = dbo.DISTRICT.DistCode INNER JOIN dbo.State ON dbo.UNIVERSITY.StateCode = dbo.State.StateCode WHERE     (dbo.UNIVERSITY.UnivCode <> '0') ORDER BY dbo.UNIVERSITY.UnivCode ";
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, SqlQuery );
        UniversityView.DataSource = ds;
        UniversityView.Columns[2].HeaderText = "Code";
        UniversityView.DataBind();
       

    }
    protected void UniversityView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
