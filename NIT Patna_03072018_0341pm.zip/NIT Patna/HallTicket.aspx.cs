using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class HallTicket : System.Web.UI.Page
{
      protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack)
            {
                try
                {
                    if (Session["Role"].ToString() != "3")
                    {
                        Session["userName"] = null;
                        FormsAuthentication.SignOut();
                        Response.Redirect("default.aspx");
                        return;
                    }
                }
                catch (Exception ex)
                {
                    Response.Redirect("default.aspx");
                }

                PopulateDDL popddl = new PopulateDDL();
              //  popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
                popddl.Popualate(CollCode, "ExamCollege", "Select CollName,ExamCollCode from ExamCollege order by ExamCollCode", "CollName", "CollName");
                popddl.Popualate(ExamCollCode, "ExamCollege", "Select CollName,ExamCollCode from ExamCollege order by ExamCollCode", "ExamCollCode", "ExamCollCode");

                popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
                popddl.Popualate(Year, "Year", "Select Year from Year where Year >= 2012 order by Year", "Year", "Year");
                popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
            }


        }

        protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
            popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");

            StreamCode.Focus();
        }

    protected string hallTicketCode()
    {
        string course="",code="";
        if(StreamCode.SelectedValue=="04")
        {
            if (StreamPart.SelectedValue == "6")
                course = "A";
            else if (StreamPart.SelectedValue == "7")
                course = "B";
            else
                course = "C";                                             
               
        }
        if(StreamCode.SelectedValue=="05")
        {
            if (StreamPart.SelectedValue == "9")
                course = "F";
            else course = "G";

        }

        if (SubCode.SelectedValue == "010" || SubCode.SelectedValue == "017") code = course + "T";
        else if (SubCode.SelectedValue == "011" || SubCode.SelectedValue == "018") code = course + "H";
        else if (SubCode.SelectedValue == "012" || SubCode.SelectedValue == "019") code = course + "F";
        else if (SubCode.SelectedValue == "013" || SubCode.SelectedValue == "020") code = course + "A";
        else if (SubCode.SelectedValue == "014" || SubCode.SelectedValue == "021") code = course + "P";
        else if (SubCode.SelectedValue == "015" || SubCode.SelectedValue == "022") code = course + "U";
        else if(SubCode.SelectedValue == "016" || SubCode.SelectedValue == "023") code = course + "I";

        return code;
    
    
    }

        protected void BtnGenTicket_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            SqlConnection con1 = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            SqlCommand cmd1 = new SqlCommand();
            SqlDataReader reader;
            SqlDataReader rd;
            cmd.Connection = con;
            cmd1.Connection = con1;
            string sql, temp; int count = 1;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            con1.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

            string sql1 = "select UnivRollNo,Hall_Ticket_No from HallTicket where HallTicket.CollCode='" + ExamCollCode.SelectedValue + "' and HallTicket.ExamYear='" + Year.SelectedValue + "' and HallTicket.StreamCode='" + StreamCode.SelectedValue + "' and HallTicket.subcode='" + SubCode.SelectedValue + "' ";
           
            
            
            con1.Open();
            cmd1.CommandText = sql1;
            rd = cmd1.ExecuteReader();


            if (rd.HasRows)
            {
              
                sql = "select RegNo,UnivRollNo,ExamYear,EXAM.StreamCode,STREAMPART.StreamPart,EXAM.Subcode,EXAM.ExamCollCode from EXAM,streampart where Exam.streampartcode=StreamPart.streampartCode and Exam.ExamCollCode='" + ExamCollCode.SelectedValue + "' and Exam.ExamYear='" + Year.SelectedValue + "' and Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "' and Exam.subcode='" + SubCode.SelectedValue + "' and Exam.UnivRollNo not in (select univrollno from HallTicket where HallTicket.CollCode='" + ExamCollCode.SelectedValue + "' and HallTicket.ExamYear='" + Year.SelectedValue + "' and HallTicket.StreamCode='" + StreamCode.SelectedValue + "' and HallTicket.subcode='" + SubCode.SelectedValue + "') ";
                while (rd.Read())
                {
                    temp = rd["Hall_Ticket_No"].ToString(); count = int.Parse(temp.Substring(3));
                } count++;
              /*  rd.Read();
                temp = rd["Hall_Ticket_No"].ToString();
                count = int.Parse(temp.Substring(3));
                count++;*/

            }
            else
            {
                sql = "select RegNo,UnivRollNo,ExamYear,EXAM.StreamCode,STREAMPART.StreamPart,EXAM.Subcode,EXAM.ExamCollCode from EXAM,streampart where Exam.streampartcode=StreamPart.streampartCode and Exam.ExamCollCode='" + ExamCollCode.SelectedValue + "' and Exam.ExamYear='" + Year.SelectedValue + "' and Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "' and Exam.subcode='" + SubCode.SelectedValue + "' ";

            }


            con.Open(); 
            cmd.CommandText = sql; 
            reader = cmd.ExecuteReader();
            
            // insert record in HallTicket table
            string[] col = new string[8];
            string[] val = new string[8];
         string[] coltype = new string[8];
            for (int i = 0; i < 8; i++)
          coltype[i] = "0";
          coltype[3] = "1";
         

            col[0] = "RegNo";
            col[1] = "UnivRollNo";
            col[2] = "Hall_Ticket_No";
            col[3] = "ExamYear";
            col[4] = "StreamCode";
            col[5] = "StreamPart";
            col[6] = "SubCode";
            col[7] = "CollCode";






            UnivService.Service1 ss = new UnivService.Service1();

            while (reader.Read())
            {
                val[0] = reader["RegNo"].ToString();
                val[1] = reader["UnivRollNo"].ToString();
                val[2] =  hallTicketCode() +"-"+count;
                val[3] = reader["ExamYear"].ToString();
                val[4] = StreamCode.SelectedValue;
                val[5] = reader["StreamPart"].ToString();
                val[6] = reader["SubCode"].ToString();
                val[7] = reader["ExamCollCode"].ToString();
               
               
                
                sql = ss.SaveDataUniCode("HallTicket", col, val, coltype);
                if (sql == "1") count++;
            }
            reader.Close();
            rd.Close();




            con.Close();
            con1.Close();

           
            string popupScript = "<script language='javascript'>" +
                                    " alert('" + --count + " Hall Ticket Generated ')" +
                                    "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);





        }
  /*      protected void Button1_Click(object sender, EventArgs e)
        {

            Panel1.Visible = true;
            CR.ReportSource = crs;
            CR.RefreshReport();
        }*/
        

  /*  protected void InstCode_TextChanged(object sender, EventArgs e)
        {
            try
            {
                CollCode.SelectedValue = InstCode.Text;
            }
            catch (Exception ex)
            {
                string msg = "College Code is not correct.";
                string popupScript = "<script language='javascript'>" +
                                   " alert('" + msg + " ')" +
                                    "</script>";
                Page.RegisterStartupScript("PopupScript", popupScript);
                InstCode.Text = "";
                InstCode.Focus();
                CollCode.SelectedIndex = 0;
            }
        }*/

    protected void ExamCollCode_SelectedIndexChanged(object sender, EventArgs e)
    {


        //string ExColCode;
        PopulateDDL popddl = new PopulateDDL();
       // ExColCode = ExamCollCode.SelectedValue.ToString();
        popddl.Popualate(CollCode, "ExamCollege", "Select CollName,ExamCollCode from ExamCollege where ExamCollCode='" + ExamCollCode.SelectedValue + "'  order by ExamCollCode", "CollName", "CollName");
        ExamCollCode.Focus();

    }


   /* protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
      //  string ExColName;
      //  PopulateDDL popddl = new PopulateDDL();
        ExamCollCode.SelectedValue.ToString()= CollCode.SelectedValue.ToString();
      //  popddl.Popualate(ExamCollCode, "ExamCollege", "Select CollName,ExamCollCode from ExamCollege where CollName='" + ExColName + "'  order by ExamCollCode", "ExamCollCode", "ExamCollCode");
    }*/



 
    

}
