﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AndroidAppSecurity : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        UnivService.Service1 ss = new UnivService.Service1();
        string abc = "select HighSecurity from Login  where UserId='" + Session["UserId"].ToString() + "' ";
        abc=ss.GetNewCode(abc);
        string x="0",z;      
      
        if (abc == "Y")
        {
           lblmsg.Text = "You are already Registered For App-based OTP Authentication.";

        }
        else
        {
            Random random = new Random();
            int OTP = random.Next(1000, 9999);

            z = (Session["UserId"].ToString()).Substring(2, 3);

            string t = (Session["UserId"].ToString()).Substring(0, 1);
            if (t == "f" || t == "F") // to identify Faculty
            {
                int y = 0;
                while (y % 2 == 0)
                {
                    y = random.Next(1, 9);

                    if (y % 2 != 0)
                    {

                        x = y.ToString();
                    }
                }
            }
            else if (t == "e" || t == "E")
            {
                int y = 1;
                while (y % 2 != 0)
                {
                    y = random.Next(1, 9);

                    if (y % 2 == 0)
                    {

                        x = y.ToString();
                    }
                }

            }


            z = (Int32.Parse(x) * Int32.Parse(z)).ToString();

            string basecode = x + OTP + z;

            BCode.Text = basecode ;
            abc = "update Login set HighSecurity='Y',BaseCode='" + basecode + "'  where UserId='" + Session["UserId"].ToString() + "' ";
            ss.UpdateData(abc);
            lblmsg.BackColor = System.Drawing.Color.LawnGreen;
            lblmsg.Text = "Thank You. You are now Registered for app-based OTP authentication. Please READ instruction below to use android app for Login authentication. ";
         }

           
           
          
        }



    
   

    protected void Button1_Click(object sender, EventArgs e)
    {
        UnivService.Service1 ss = new UnivService.Service1();
        string abc = "update Login set HighSecurity='N' where UserId='" + Session["UserId"].ToString() + "' ";
        ss.UpdateData(abc);
        BCode.Text = "";
        lblmsg.BackColor = System.Drawing.Color.Tomato;
        lblmsg.Text = "App-based OTP authentication has been DEACTIVATED for your account. Thank You. ";
        
    }
}