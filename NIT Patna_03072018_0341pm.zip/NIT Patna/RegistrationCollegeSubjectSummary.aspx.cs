using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class RegistrationCollegeSubjectSummary : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "5")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();

            popddl.Popualate(StreamCode1, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(Year, "Year", "Select Year from Year where Year > '2008'  order by Year", "Year", "Year");
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            
            Year.Text = System.DateTime.Now.Year.ToString();
        }
    }


    protected void BtnView_Click(object sender, EventArgs e)
    {
        //string sql = "SELECT     dbo.COLLEGE.CollCode, dbo.COLLEGE.CollName, COUNT(dbo.REGISTRATION.AckNo) AS [TotApp], COUNT(dbo.REGISTRATION.RegNo) " +
        //            " AS [TotalAlloted] ,COUNT(dbo.REGISTRATION.AckNo)-COUNT(dbo.REGISTRATION.RegNo) as [Pending] FROM  dbo.REGISTRATION ,dbo.COLLEGE " +
        //            " WHERE  (dbo.REGISTRATION.CollCode = dbo.COLLEGE.CollCode) and   (dbo.REGISTRATION.RegYear = '" + Year.Text + "')  and (dbo.REGISTRATION.streamcode='" + StreamCode1.SelectedValue + "')  and (dbo.REGISTRATION.subcode='" + SubCode1.SelectedValue + "') " +
        //            " GROUP BY dbo.COLLEGE.CollCode, dbo.COLLEGE.CollName";


        string sql="SELECT     dbo.subject.subCode AS [subcode], dbo.subject.subjectName AS [SUBNAME], COUNT(dbo.REGISTRATION.AckNo) AS [TotApp], COUNT(dbo.REGISTRATION.RegNo) " +
                      " AS [TotalAlloted] ,COUNT(dbo.REGISTRATION.AckNo)-COUNT(dbo.REGISTRATION.RegNo) as [Pending] FROM  dbo.REGISTRATION ,dbo.SUBJECT " +
                      " WHERE  (dbo.REGISTRATION.SubCode = dbo.Subject.SubCode) and (dbo.REGISTRATION.RegYear = '" + Year.Text + "')  and (dbo.REGISTRATION.streamcode='" + StreamCode1.SelectedValue + "')  and (dbo.REGISTRATION.collcode='" + CollCode.SelectedValue + "')  " +
                      " GROUP BY dbo.Subject.SubCode, dbo.Subject.SubjectName";

        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        RegSummaryView.DataSource = ds;
        RegSummaryView.DataBind();

        sql = "SELECT    COUNT(dbo.REGISTRATION.AckNo) AS [TotApp], COUNT(dbo.REGISTRATION.RegNo) " +
                     " AS [TotalAlloted] ,COUNT(dbo.REGISTRATION.AckNo)-COUNT(dbo.REGISTRATION.RegNo) as [Pending] FROM " +
                     "dbo.REGISTRATION  WHERE     (dbo.REGISTRATION.RegYear = '" + Year.Text + "') and (dbo.REGISTRATION.streamcode='" + StreamCode1.SelectedValue + "')  and (dbo.REGISTRATION.collcode='" + CollCode.SelectedValue + "') ";
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        GridView1.DataSource = ds;
        GridView1.DataBind();


    }



    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
    }
    protected void StreamCode1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
