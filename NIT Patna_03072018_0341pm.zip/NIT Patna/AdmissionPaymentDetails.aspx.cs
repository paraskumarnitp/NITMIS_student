using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Drawing;

public partial class AdmissionPaymentDetails : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnexport);
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "17")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

        }
    }
     string qpart = "";
    protected void btnview_Click(object sender, EventArgs e)
    {
        bindgrid();             
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (StreamCode.SelectedItem.ToString() == "B.Tech")
        {
            ddlsubcategory.Items.Clear();
            ddlsubcategory.Items.Add(new ListItem("SELECT", "0"));
            ddlsubcategory.Items.Add(new ListItem("SC/ST/PWD", "SC/ST/PWD"));
            ddlsubcategory.Items.Add(new ListItem("OTHERS", "OTHERS"));
        }
        else if (StreamCode.SelectedItem.ToString() == "B.Arch")
        {
            ddlsubcategory.Items.Clear();
            ddlsubcategory.Items.Add(new ListItem("SELECT", "0"));
            ddlsubcategory.Items.Add(new ListItem("SC/ST/PWD", "SC/ST/PWD"));
            ddlsubcategory.Items.Add(new ListItem("OTHERS", "OTHERS"));
        }
        else if (StreamCode.SelectedItem.ToString() == "M.Tech/MURP")
        {
            ddlsubcategory.Items.Clear();
            ddlsubcategory.Items.Add(new ListItem("SELECT", "0"));
            ddlsubcategory.Items.Add(new ListItem("MTECH", "MTECH"));
        }
    }
    protected void btnexport_Click(object sender, EventArgs e)
    {
        if (gvpayonline.Rows.Count > 0)
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=AdmissionPaymentDataExport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                //gvpayonline.AllowPaging = false;
                //this.BindGrid();

                gvpayonline.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in gvpayonline.HeaderRow.Cells)
                {
                    cell.BackColor = gvpayonline.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in gvpayonline.Rows)
                {
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = gvpayonline.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = gvpayonline.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                gvpayonline.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    DataTable dt;
    private void bindgrid()
    {
        if (paymenttype.SelectedValue.ToString() == "ONLINE")
        {
            if (ddlsubcategory.SelectedValue.ToString() != "")
            {
                qpart = " AND (PGResponse.AdditionalInfo3 = '" + StreamCode.SelectedValue.ToString() + "')";
            }
            dt = fnrev.SelectDatatable("SELECT REGISTRATION.AckNo AS ENROLLMENT_NO, REGISTRATION.TempRollNo AS ROLL_NO,PrePaymentDetails.SelectionRollNo as SELECTION_ROLL_NO," +
                " PrePaymentDetails.DOB, PrePaymentDetails.Receipt_Challan_No AS RECEIPT_CHALLAN_NO, PGResponse.CustomerId AS NITP_TXN_NO, PGResponse.txnReferenceNo AS TXN_REF_NO," +
                " PGResponse.bankReferenceNo AS BANK_REF_NO, PGResponse.txnAmount AS TXN_AMOUNT, PGResponse.txnDate AS TXN_DATE, PGResponse.authStatus AS STATUS_CODE FROM PrePaymentDetails " +
                " INNER JOIN PGResponse ON PrePaymentDetails.SelectionRollNo = PGResponse.AdditionalInfo1 INNER JOIN REGISTRATION ON " +
                " PrePaymentDetails.SelectionRollNo = REGISTRATION.SelectionExamRollNo WHERE (PGResponse.AdditionalInfo5 = 'ADMISSIONFEE') " +
                " AND (PGResponse.authStatus = '0300') AND (PGResponse.AdditionalInfo2 = '" + ddlsubcategory.SelectedValue.ToString() + "') " + qpart + "");
            gvpayonline.DataSource = dt;
            gvpayonline.DataBind();          

        }
        else if (paymenttype.SelectedValue.ToString() == "CHALLAN")
        {
            if (StreamCode.SelectedItem.ToString() == "M.Tech/MURP")
            {
                qpart = "AND (STREAM.StreamTypeCode IN ('02','04'))";
            }
            else if (StreamCode.SelectedItem.ToString() == "B.Tech")
            {
                qpart = "AND (STREAM.StreamTypeCode IN ('01'))";
            }
            if (StreamCode.SelectedItem.ToString() == "B.Arch")
            {
                qpart = "AND (STREAM.StreamTypeCode IN ('01'))";
            }
            dt = fnrev.SelectDatatable("SELECT REGISTRATION.AckNo AS ENROLLMENT_NO, REGISTRATION.TempRollNo AS ROLL_NO," +
                " PrePaymentDetails.SelectionRollNo as SELECTION_ROLL_NO, PrePaymentDetails.DOB, PrePaymentDetails.Receipt_Challan_No as " +
                " RECEIPT_CHALLAN_NO, PrePaymentDetails.ProcessDatetime AS PROCESSDATE, REGISTRATION.PaymentMode AS PAYMENT_MODE," +
                " REGISTRATION.Bank as BANK, REGISTRATION.AdmFeeAmt AS PAY_AMOUNT, REGISTRATION.paymentID AS CHALLAN_REF_NO, " +
                " REGISTRATION.paymentDate AS PAYMENT_DATE FROM PrePaymentDetails INNER JOIN REGISTRATION ON " +
                " PrePaymentDetails.SelectionRollNo = REGISTRATION.SelectionExamRollNo INNER JOIN STREAM ON " +
                " REGISTRATION.StreamCode = STREAM.StreamCode WHERE (PrePaymentDetails.AccountNo = 'NIL') AND " +
                " (REGISTRATION.AdmYear = '" + admyear.SelectedValue.ToString() + "') " + qpart + " AND (REGISTRATION.PaymentMode = 'E-Challan')");
            gvpayonline.DataSource = dt;
            gvpayonline.DataBind();
        }
        else if (paymenttype.SelectedValue.ToString() == "RETURN")
        {
            if (StreamCode.SelectedItem.ToString() == "M.Tech/MURP")
            {
                qpart = "AND (STREAM.StreamTypeCode IN ('02','04'))";
            }
            else if (StreamCode.SelectedItem.ToString() == "B.Tech")
            {
                qpart = "AND (STREAM.StreamTypeCode IN ('01'))";
            }
            if (StreamCode.SelectedItem.ToString() == "B.Arch")
            {
                qpart = "AND (STREAM.StreamTypeCode IN ('01'))";
            }
            dt = fnrev.SelectDatatable("SELECT REGISTRATION.AckNo AS ENROLLMENT_NO, REGISTRATION.TempRollNo AS ROLL_NO," +
                " PrePaymentDetails.SelectionRollNo as SELECTION_ROLL_NO, PrePaymentDetails.DOB, PrePaymentDetails.Receipt_Challan_No as " +
                " RECEIPT_CHALLAN_NO, PrePaymentDetails.ProcessDatetime AS PROCESSDATE,  " +
                "  PrePaymentDetails.AccountNo AS ACCOUNT_NO,PrePaymentDetails.IFSC, PrePaymentDetails.AccountHolderName AS AC_HOLDER_NAME, " +
                " PrePaymentDetails.branchname AS BRANCH_NAME, PrePaymentDetails.BranchDetails AS BRANCHDETAILS FROM PrePaymentDetails INNER JOIN REGISTRATION ON " +
                " PrePaymentDetails.SelectionRollNo = REGISTRATION.SelectionExamRollNo INNER JOIN STREAM ON " +
                " REGISTRATION.StreamCode = STREAM.StreamCode WHERE (PrePaymentDetails.AccountNo <> 'NIL') AND " +
                " (REGISTRATION.AdmYear = '" + admyear.SelectedValue.ToString() + "') " + qpart + " AND (REGISTRATION.PaymentMode = '---Select One---')");
            gvpayonline.DataSource = dt;
            gvpayonline.DataBind();

        }       

        
    }
}
