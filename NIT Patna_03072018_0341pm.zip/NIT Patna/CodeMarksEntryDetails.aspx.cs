using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
public partial class CodeMarksEntryDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "5")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
                ViewState.Add("EditMode", "false");
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }


            PopulateDDL popddl = new PopulateDDL();
            
            
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(ExamYear, "Year", "Select Year from Year where year >='2008'order by Year", "Year", "Year");
          //  ExamYear.Focus();
        }
        

    }

    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        RBHons.Checked = false;
        RBComp.Checked = false;
        RBSubs.Checked = false;
        RBPractH.Checked = false;
        RBPractS.Checked = false;
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        StreamCode.Focus();  
    }
    protected void RBHons_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Hons");
    }
    protected void RBPractH_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Hons");

    }
    protected void RBComp_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Comp");
    }
    protected void RBSubs_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Subs");
    }
    protected void RBPractS_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Subs");
    }
    
    private void GetPaperCode(string PaperType )
    {
        PopulateDDL popddl = new PopulateDDL();
        
       if (PaperType == "Hons")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", "Select PaperName,SubPaperCode from COURSEPAPERS Where StreamCode='" + StreamCode.SelectedValue + "' And StreamPartCode='" + StreamPart.SelectedValue + "' And SubCode='" + SubCode.SelectedValue + "' order by SubPaperCode", "PaperName", "SubPaperCode");
        }
        else if (PaperType == "Comp")
        {
            popddl.Popualate(Subject, "COMPOSITION", "Select Name,CompCode from COMPOSITION order by Name", "Name", "CompCode");
        }
        else if (PaperType == "Subs")
        {
            popddl.Popualate(Subject, "SUBJECT", "Select SubCode,SubjectName from SUBJECT Where StreamCode='" + StreamCode.SelectedValue + "' and subcode<>'" + SubCode.SelectedValue + "'  order by SubjectName", "SubjectName", "SubCode");
        }

        GetMarks();
        Subject.Focus();

    }
    protected void SubCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        RBHons.Checked = false;
        RBComp.Checked = false;
        RBSubs.Checked = false;
        RBPractH.Checked = false;
        RBPractS.Checked = false;
    }


    protected void Button1_Click(object sender, EventArgs e)
    {

        
        BindGrid();
        //if (MarksEntryGrid.Rows.Count > 0)
        {
            Panel3.Enabled = false;
            Panel2.Visible = true;
            MarksGrid.Visible = true;
            LblMsg2.Text = "";
            CompCode.Focus();
        }
    }
    void BindGrid()
    {
         char PaperType = 'P';
        if (RBHons.Checked) PaperType = 'H';
        else if (RBComp.Checked) PaperType = 'C';
        else if (RBSubs.Checked) PaperType = 'S';
        else if (RBPractH.Checked) PaperType = 'P';
        else if (RBPractS.Checked) PaperType = 'P';
        
        //UnivService.Service1 NicService = new UnivService.Service1();
        //string sql = "SELECT count(*) from exampaperdetail where univrollno in (SELECT UnivRollNo FROM EXAM WHERE ExamYear = '" + ExamYear.SelectedValue + "' and streampartcode='" + StreamPart.SelectedValue + "' and subcode='" + SubCode.SelectedValue + "') and streampartcode='" + StreamPart.SelectedValue + "' and SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "' And ExamYear = '" + ExamYear.SelectedValue + "'";
        //sql = NicService.GetNewCode(sql);
        //LblMsg.Text  = " Total candidate :- " + sql;
        //string roll="";
        ////if (RBCode.Checked )
        ////    roll = "CompCode";
        ////else
        //    roll = "UnivRollNo";

        string sql = "";

        DataSet ds = new DataSet();
        if (Operator.SelectedValue == "1")
            //sql = "SELECT " + roll + " UnivRollNo,CompCode , IsAppeared from exampaperdetail where univrollno in (SELECT UnivRollNo FROM EXAM WHERE ExamYear = '" + ExamYear.SelectedValue + "' and streampartcode='" + StreamPart.SelectedValue + "' and subcode='" + SubCode.SelectedValue + "') and streampartcode='" + StreamPart.SelectedValue + "' and SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "' And ExamYear = '" + ExamYear.SelectedValue + "' order by univrollno";
            sql = "SELECT ClassTest1 as Marks,CompCode from codemarks where ExamYear = '" + ExamYear.SelectedValue + "' and streampartcode='" + StreamPart.SelectedValue + "' and SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "' And ExamYear = '" + ExamYear.SelectedValue + "' and ClassTest1 is not Null order by EntryDate1 desc";

        else
            //sql = "SELECT  " + roll + "  UnivRollNo,CompCode, IsAppeared from exampaperdetail where univrollno in (SELECT UnivRollNo FROM EXAM WHERE ExamYear = '" + ExamYear.SelectedValue + "' and streampartcode='" + StreamPart.SelectedValue + "' and subcode='" + SubCode.SelectedValue + "') and streampartcode='" + StreamPart.SelectedValue + "' and SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "' And ExamYear = '" + ExamYear.SelectedValue + "' order by univrollno";
            sql = "SELECT ClassTest2 as Marks,CompCode from codemarks where ExamYear = '" + ExamYear.SelectedValue + "' and streampartcode='" + StreamPart.SelectedValue + "' and SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "' And ExamYear = '" + ExamYear.SelectedValue + "' and ClassTest2 is not Null order by EntryDate2 desc";

        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        
        
        MarksGrid.DataSource = ds;
        MarksGrid.DataBind();


 
    }


    protected int SaveMarks()
    {
        // 17 05 2010 check by nayak

        // set Papertype
        char PaperType = 'P';
        char opt = '1';
        string sql = ""; int n = 0;
   
        if (RBHons.Checked) PaperType = 'H';
        else if (RBComp.Checked) PaperType = 'C';
        else if (RBSubs.Checked) PaperType = 'S';
        else if (RBPractH.Checked) PaperType = 'P';
        else if (RBPractS.Checked) PaperType = 'P';

        if (Operator.SelectedValue == "1")            opt = '1';
        else            opt = '2';



        if(opt=='2')
            sql = "SELECT ClassTest1 from codemarks where ExamYear = '" + ExamYear.SelectedValue + "' and streampartcode='" + StreamPart.SelectedValue + "' and SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "' And ExamYear = '" + ExamYear.SelectedValue + "' and  CompCode='" + CompCode.Text.Trim() + "' "; //and ClassTest2 is not Null 
        else
            sql = "SELECT ClassTest1 from codemarks where ExamYear = '" + ExamYear.SelectedValue + "' and streampartcode='" + StreamPart.SelectedValue + "' and SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "' And ExamYear = '" + ExamYear.SelectedValue + "' and  CompCode='" + CompCode.Text.Trim() + "' and ClassTest1 is not Null ";
        
        
        UnivService.Service1 NicService = new UnivService.Service1();
        sql = NicService.GetNewCode(sql);         // Check Existing Entry By Operator

       //Conditions for operator 2 direct insert
        if (Operator.SelectedValue == "2" && sql == "error")
        {
            LblMsg2.Text = "Please Marks Entered by Operator1 ....";
            return 5;
        }


        //
        if (Operator.SelectedValue == "1" && sql == "error")
        {

            if (sql == "error") // insert into code marks -- not entered
            {
                try
                {
                    string[] col = new string[7];
                    string[] val = new string[7];
                    col[0] = "ExamYear";
                    col[1] = "StreamPartCode";
                    col[2] = "SubPaperCode";
                    col[3] = "PaperType";
                    col[4] = "CompCode";
                    col[5] = "ClassTest1";
                    col[6] = "opt1";

                    val[0] = ExamYear.Text;
                    val[1] = StreamPart.SelectedValue;
                    val[2] = Subject.SelectedValue;
                    val[3] = PaperType.ToString();
                    val[4] = CompCode.Text.Trim();
                    val[5] = MarksObtained.Text.Trim();
                    val[6] = Session["userid"].ToString();

                    UnivService.Service1 ss = new UnivService.Service1();
                    string abc = ss.SaveData("CodeMarks", col, val);
                    if (abc == "1")
                        return 1;
                    else
                        return -1;
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                    return 0;
                }
            }
            else
            {
                return 0;
            }


        }

        else
        {
            // found in opt1 , notfound in opt2 , found in opt2
            // update .. according to opt1 or opt2 

            SqlTransaction tran;
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
           
            con.Open();
            tran = con.BeginTransaction();
            cmd.Transaction = tran;

            try
            {
                if (opt == '1')
                    cmd.CommandText = "update CodeMarks set EntryDate1=getDate(),opt1= '" + Session["UserId"].ToString() + "', ClassTest1='" + MarksObtained.Text.Trim() + "' where examyear='" + ExamYear.SelectedValue + "' And streampartcode='" + StreamPart.SelectedValue + "' and  SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "' and CompCode='" + CompCode.Text.Trim() + "'";
                else if (opt == '2')
                    cmd.CommandText = "update CodeMarks set EntryDate2=getDate(),opt2= '" + Session["UserId"].ToString() + "', ClassTest2='" + MarksObtained.Text.Trim() + "' where examyear='" + ExamYear.SelectedValue + "' And streampartcode='" + StreamPart.SelectedValue + "' and  SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "' and CompCode='" + CompCode.Text.Trim() + "'";

                n = cmd.ExecuteNonQuery();

                tran.Commit();
                return n;
            }
            catch (Exception ex)
            {
                tran.Rollback();
                Response.Write(ex.Message);
                return n;
            }
        }

     

    }




    protected void BtnSave_Click(object sender, EventArgs e)
    {
        
        
        int flag=SaveMarks();
        if (flag == 1)
        {
            BindGrid();
            LblMsg2.Text = "Code marks is saved successfully for code - " + CompCode.Text + " - " + MarksObtained.Text.ToString();
            CompCode.Text = "";
            MarksObtained.Text = "";
            CompCode.Focus();
        }
        else if (flag == 5)
        {
           // LblMsg2.Text = "error... Please check code & marks";
            CompCode.Focus();
        }
        else if (flag == -1)
        {
            LblMsg2.Text = "error... Please check code & marks";
            CompCode.Focus();
        }
        else
        {
            LblMsg2.Text = "error... Please check code & marks";
            CompCode.Focus();
        }
      
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Panel3.Enabled = true;
        Panel2.Visible = false ;
        MarksGrid.Visible = false;
        LblMsg2.Text = ""; 

    }
    protected void Subject_SelectedIndexChanged(object sender, EventArgs e)
    {
        GetMarks();
    }
    protected void GetMarks()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        string sql = "";
        if (RBHons.Checked || RBPractH.Checked)
        {
            if (RBHons.Checked)
            {
                sql = "SELECT FullMarks from COURSEPAPERS where SubPapercode='" + Subject.SelectedValue + "'";
                sql = NicService.GetNewCode(sql);
                PaperMarks.Text = sql;
            }
            else
            {
                sql = "SELECT FullMarks from PracticalPAPERS where SubPapercode='" + Subject.SelectedValue + "'";
                sql = NicService.GetNewCode(sql);
                if (sql == "error")
                    PaperMarks.Text = "0";
                else
                    PaperMarks.Text = sql;
            }
        }


        else if (RBSubs.Checked || RBPractS.Checked)
        {
            if (RBSubs.Checked)
            {
                sql = "SELECT FullMarks from SUBSIDIARY where SubCode='" + Subject.SelectedValue + "'";
                sql = NicService.GetNewCode(sql);
                PaperMarks.Text = sql;
            }
            else
            {
                sql = "SELECT PrFullMarks from SUBSIDIARY where SubCode='" + Subject.SelectedValue + "'";
                sql = NicService.GetNewCode(sql);
                PaperMarks.Text = sql;
            }
        }
        else if (RBComp.Checked)
        {
            sql = "SELECT FullMarks from COMPOSITION where CompCode='" + Subject.SelectedValue + "'";
            sql = NicService.GetNewCode(sql);
            PaperMarks.Text = sql;
        }
            
    }
    protected void MarksGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        MarksGrid.PageIndex = e.NewPageIndex;
        // BindGrid();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        char PaperType = 'P';
        int n = 0;
        //sql = "SELECT compcode from exampaperdetail";
        if (RBHons.Checked) PaperType = 'H';
        else if (RBComp.Checked) PaperType = 'C';
        else if (RBSubs.Checked) PaperType = 'S';
        else if (RBPractH.Checked) PaperType = 'P';
        else if (RBPractS.Checked) PaperType = 'P';
        string d = "", m = "", y = "";
        d = Txtdt.Text.Substring(0, 2);
        m = Txtdt.Text.Substring(3, 2);
        y = Txtdt.Text.Substring(6, 4);



        CrystalDecisions.Shared.ParameterFields paramFields = new CrystalDecisions.Shared.ParameterFields();
        CrystalDecisions.Shared.ParameterField paramField = new CrystalDecisions.Shared.ParameterField();
        CrystalDecisions.Shared.ParameterDiscreteValue discreteVal = new CrystalDecisions.Shared.ParameterDiscreteValue();

        paramField.ParameterFieldName = "Title";
        discreteVal.Value = StreamCode.SelectedItem.Text + " - " +  Subject.SelectedItem.Text;
        paramField.CurrentValues.Add(discreteVal);
        paramFields.Add(paramField);

            CR.ReportSource = crs;
            CR.SelectionFormula = @"{CodeMarks.ExamYear}  = '" + ExamYear.SelectedValue + "' And {CodeMarks.StreamPartCode}  ='" + StreamPart.SelectedValue + "' And {CodeMarks.SubPaperCode}  ='" + Subject.SelectedValue + "' And {CodeMarks.PaperType}='" + PaperType.ToString() + "' And {CodeMarks.opt}='" + Session["userid"].ToString() + "' And {CodeMarks.EntryDate} in DateTime(" + y + "," + m + "," + d + ") to DateTime(" + y + "," + m + "," + (int.Parse (d)+1 )+ ")";
            CR.RefreshReport();
            CR.ParameterFieldInfo = paramFields;  
            CR.Visible = true;




    }
}
