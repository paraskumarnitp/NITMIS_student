
using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using CrystalDecisions.CrystalReports.Engine;
using System.Text;
using System.Text.RegularExpressions;

public partial class TRGeneration : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    DataTable dttrbtec;
    bool Check = false;
    DSTRBtec dstrrecord = new DSTRBtec();
    string papertype = "";
    int trcount;
    int yrvalue = 0;
    string prexamdate = "";
    
    string CA_MSM_TH = "", TH_ESM = "", TH_PMO = "", CA_MSM_PT = "", PT_ESM = "", PT_PMO = "", TOTAL_PMO = "", GRADE_POINT = "", ER_CREDIT = "", StudStatus = "";

    string GRADE = "", REMARKS = "";
    string semyear;
    int TPMOdivpart = 0;
    string ClassTest1, ClassTest2, TH_Attendance, Midsem, PR_Attendance, PracticalRecord, PRClassPerfor, Prpreendsemviva, UMC, THEndsem, PREndSem;
    string ThFMarks, PractFMarks, Credit;
    DataSet dsstudentreginfo; DataSet dsstudentregnc;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //Panel1.Visible = true;
            try
            {

                if ((Session["Role"].ToString() != "2") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
                if (Session["Role"].ToString() == "7")
                {                    
                    BtnGenerate.Visible = true;                    
                    ChkBoxReProcess.Visible = true;
                }
                else if (Session["Role"].ToString() == "14")
                {
                    BtnGenerate.Visible = true;
                    ChkBoxReProcess.Visible = true;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();

            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College where collcode in (select distinct collcode from exam) order by CollName", "CollName", "CollCode");
            popddl.Popualate(ExamYear, "Exam", "Select distinct ExamYear from Exam order by ExamYear", "ExamYear", "ExamYear");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from stream) order by StreamAbbr", "StreamAbbr", "StreamCode");
            Examsession.Items.Insert(0, new ListItem("--Select--", "0"));
            ExamYear.Items.Insert(0, new ListItem("--Select--", "0"));
            CourseValue();



        }
    }



    // Save TRprocess Function 
    protected string SaveTRProcesses(string CollCode, string ExamYear, string StreamCode, string StreamPartCode, string SubCode, string Remarks)
    {
        try
        {
            UnivService.Service1 NicService = new UnivService.Service1();
            string[] col = new string[8];
            string[] val = new string[8];
            string[] coltype = new string[8];

            for (int i = 0; i < 8; i++)
            {
                coltype[i] = "0";
            }

            col[0] = "CollCode";
            col[1] = "ExamYear";
            col[2] = "StreamCode";
            col[3] = "StreamPartCode";
            col[4] = "SubCode";
            col[5] = "ProcessingDate";
            col[6] = "Remarks";
            col[7] = "UserID";

            val[0] = CollCode;
            val[1] = ExamYear;
            val[2] = StreamCode;
            val[3] = StreamPartCode;
            val[4] = SubCode;
            val[5] = string.Format("{0:MM/dd/yyyy h:mm:ss}", System.DateTime.Now);
            val[6] = Remarks;
            val[7] = Session["UserId"].ToString();

            string SaveFlag = NicService.SaveDataUniCode("TRProcessed", col, val, coltype);

            if (SaveFlag == "1")
            {
                return "0";
            }
            else
            {
                return "-1";
            }
        }
        catch (Exception ex)
        {
            return "-1";
        }
    }
    // Check TR Processed or Not
    protected string CheckTRProcesses(string CollCode, string ExamYear, string StreamCode, string StreamPartCode, string SubCode)
    {
        string SQL = "", TRCollCode = "";
        if (CollCode == "ALL") TRCollCode = "ALL"; else TRCollCode = CollCode;

        SQL = "Select count(1) from TRProcessed where CollCode=" + CollCode + " and StreamCode=" + StreamCode + " and StreamPart=" + StreamPartCode + " and SubCode=" + SubCode + " and ExamYear=" + ExamYear + " ";

        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.CommandText = SQL;

        con.Open();
        int ResultCount = int.Parse(cmd.ExecuteScalar().ToString());
        con.Close();

        //UnivService.Service1 NICService = new UnivService.Service1();
        //string Result=NICService.GetNewCode(SQL);

        if (ResultCount >= 1)
        {
            return ResultCount.ToString();
        }
        else
        {
            return "-1";
        }

    }



    // Generate Button.....
    DataTable dtpaperc = new DataTable();
    protected void BtnGenerate_Click(object sender, EventArgs e)
    {

        System.Threading.Thread.Sleep(3000);
        LblMsg.Text = "";
        LblMsgDeleted.Text = "";
        Hashtable hashtable = new Hashtable();
        hashtable.Add("33",0);
        hashtable.Add("34",1);
        hashtable.Add("35",2);
        hashtable.Add("36",3);
        hashtable.Add("37",4);
        hashtable.Add("38",5);
        hashtable.Add("39",6);
        hashtable.Add("40",7);
        hashtable.Add("42", 9);
        hashtable.Add("43",8);
        hashtable.Add("41", 10);
        Hashtable hashMsc = new Hashtable();
        hashMsc.Add("08", 0);
        hashMsc.Add("09", 1);
        hashMsc.Add("10", 2);

       
        // Check TRReprocess required 
      
        Boolean TRReprocess; TRReprocess = false;
        if (ChkBoxReProcess.Checked == true) TRReprocess = true;

        UnivService.Service1 NicService = new UnivService.Service1();
        String TypeCode = NicService.GetNewCode("Select StreamTypeCode from Stream where StreamCode='" + StreamCode.SelectedValue + "' ");

        int numbers = int.Parse(Regex.Replace(StreamPart.SelectedItem.ToString(), "[^.0-9]", ""));
        if ((Examsession.SelectedValue.Substring(0, 7) == "JUL-DEC")  && numbers % 2 == 0)
        {
            numbers = numbers - 1;
        }

        yrvalue = int.Parse(Examsession.SelectedValue.Substring(8, 4)) - (numbers / 2);
        prexamdate = Examsession.SelectedItem.ToString().Substring(8, 4) + "-" + Examsession.SelectedItem.ToString().Substring(4, 3) + "-01 00:00:00.000";

        dtpaperc.Columns.Add("paperc");
        dtpaperc.Rows.Add("0088");
        dtpaperc.Rows.Add("0130");
        dtpaperc.Rows.Add("0605");
        dtpaperc.Rows.Add("0771");
        dtpaperc.Rows.Add("1434");
        dtpaperc.Rows.Add("0117");
        dtpaperc.Rows.Add("1286");
        dtpaperc.Rows.Add("1544");
        dtpaperc.Rows.Add("0068");
        dtpaperc.Rows.Add("1448");
        if (TypeCode == "01" && StreamCode.SelectedValue == "01")
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRBTec_ME();
                }
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRBTec_ME();
                }
            }
        }
        else if (TypeCode == "01" && StreamCode.SelectedValue == "02")
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRBTec_EE();
                }
                
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRBTec_EE();
                }
            }
        }
        else if (TypeCode == "01" && StreamCode.SelectedValue == "03")
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRBTec_CE();
                }
                
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRBTec_CE();
                }
                
            }
        }
        else if (TypeCode == "01" && StreamCode.SelectedValue == "04")
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRBTec_ECE();
                }
                
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRBTec_ECE();
                }
                
            }
        }
        else if (TypeCode == "01" && StreamCode.SelectedValue == "05")
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRBTec_Arc();
                }
                
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRBTec_Arc();
                }
                
            }
        }
        else if (TypeCode == "01" && StreamCode.SelectedValue == "06")
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                    " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRBTec_CSE();
                }
                
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRBTec_CSE();
                }
                
            }
        }
        else if (TypeCode == "01" && StreamCode.SelectedValue == "07")
        {
            
         if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRBTec_IT();
                }
                
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRBTec_IT();
                }
                
            }           

        } /* Code Start for TR Mtec */
        else if (TypeCode == "02" && StreamCode.SelectedValue == "21")
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                   " SplCode = '" + Splcode.SelectedValue + "' AND Examsession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_EE();
                }
                
            }
            else
            {
                Check = true;
                GenerateTRMTec_EE();
            }
        }
        else if (TypeCode == "02" && StreamCode.SelectedValue == "23")
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                   " SplCode = '" + Splcode.SelectedValue + "' AND Examsession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_CE();
                }
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_CE();
                }
            }
        }
        else if (TypeCode == "02" && StreamCode.SelectedValue == "26")
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                   " SplCode = '" + Splcode.SelectedValue + "' AND Examsession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_ME();
                }
                
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_ME();
                }
            }
        }
        else if (TypeCode == "02" && StreamCode.SelectedValue == "28")
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                   " SplCode = '" + Splcode.SelectedValue + "' AND Examsession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_CS();
                }
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_CS();
                }
            }
        }
        else if (TypeCode == "02" && StreamCode.SelectedValue == "29")
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                   " SplCode = '" + Splcode.SelectedValue + "' AND Examsession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_EC();
                }
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_EC();
                }
            }
        }
        else if (TypeCode == "02" && StreamCode.SelectedValue == "30")
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                   " SplCode = '" + Splcode.SelectedValue + "' AND Examsession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_MRUP();
                }
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_MRUP();
                }
            }
        }
        else if (TypeCode == "02" && StreamCode.SelectedValue == "31")
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                   " SplCode = '" + Splcode.SelectedValue + "' AND Examsession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_AR();
                }
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_AR();
                }
            }
        }
        else if (TypeCode == "02" && StreamCode.SelectedValue == "32")
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                   " SplCode = '" + Splcode.SelectedValue + "' AND Examsession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_IT();
                }
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_IT();
                }
            }
        }
        else if (TypeCode == "01" && hashMsc.Contains(StreamCode.SelectedValue))
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                   " SplCode = '" + Splcode.SelectedValue + "' AND Examsession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRMsc_All();
                }
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRBTec_SQSPL();
                }
                else
                {
                    GenerateTRMsc_All();
                }
            }
        }
        else if ((TypeCode == "04" || TypeCode == "01" || TypeCode == "02") && hashtable.Contains(StreamCode.SelectedValue))
        {
            if (TRReprocess == true)
            {
                int DelRec = fnrev.InsertUpdateDelete("DELETE fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                   " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                   " SplCode = '" + Splcode.SelectedValue + "' AND Examsession = '" + Examsession.SelectedItem.ToString() + "'");
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_DD();
                }
            }
            else
            {
                Check = true;
                if (Examsession.SelectedItem.ToString().IndexOf("SMR") != -1 || Examsession.SelectedItem.ToString().IndexOf("ADT") != -1)
                {
                    GenerateTRMTec_SQSPL();
                }
                else
                {
                    GenerateTRMTec_DD();
                }
            }
        }

    }


    protected void grading()
    {
        if (TOTAL_PMO != "")
        {
            //double p = double.Parse(TOTAL_PMO);
            if (double.Parse(TOTAL_PMO) >= 90)
            {
                GRADE = "A+";
                GRADE_POINT = "10";
                ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                REMARKS = "Excellent";
            }
            else if (double.Parse(TOTAL_PMO) >= 80 && double.Parse(TOTAL_PMO) < 90)
            {
                GRADE = "A";
                GRADE_POINT = "9";
                ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                REMARKS = "Very good";
            }
            else if (double.Parse(TOTAL_PMO) >= 70 && double.Parse(TOTAL_PMO) < 80)
            {
                GRADE = "B";
                GRADE_POINT = "8";
                ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                REMARKS = "Good";
            }
            else if (double.Parse(TOTAL_PMO) >= 60 && double.Parse(TOTAL_PMO) < 70)
            {
                GRADE = "C";
                GRADE_POINT = "7";
                ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                REMARKS = "Fair";
            }
            else if (double.Parse(TOTAL_PMO) >= 50 && double.Parse(TOTAL_PMO) < 60)
            {
                GRADE = "D";
                GRADE_POINT = "6";
                ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                REMARKS = "Average";
            }
            else if (double.Parse(TOTAL_PMO) < 50)
            {
                GRADE = "P";
                GRADE_POINT = "5";
                ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                if (papertype == "T")
                    REMARKS = "Pass in Theory";
                else if (papertype == "P")
                    REMARKS = "Pass in Practical";
                else
                    REMARKS = "Pass in both Theory & Practical";

            }

        }


    }

    protected void GenerateTRMsc_All()
    {
        
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
            " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
            " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
            " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
            " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND Exam.ExamSession  = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
            " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
            " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
            " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
            " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
            " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (Check == true)
        {
            // code for already proccessed.......
            DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                       " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                       " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
            if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
            {
                LblMsg.Text = "TR already proccessed for the above criteria.";
                return;
            }
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {
                //if (dsstudentreginfo.Tables[0].Rows[i]["Regno"].ToString() == "01201008638")
                //{
                //    string find = "ture";
                //}   
                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                     " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                     " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                     " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                     " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {

                    string SaveFlag = "";

                    string[] col = new string[15];
                    string[] val = new string[15];
                    string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString();
                    /*  string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                     string examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString(); */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "ExamSession"; val[14] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRBTec", col, val);
                    if (SaveFlag == "1")
                    {
                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
     "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
     "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
     "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
     " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
     " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
          " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();

                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            if (UMC != "" && UMC.IndexOf("DA") != -1)
                            {
                                ClassTest1 = "0";
                                ClassTest2 = "0";
                            }
                            else
                            {
                                ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                                ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";

                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H"))
                                {
                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,trbtec.SubPaperCode, " +
                                                                            " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                                                            " FROM TRBTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRBTec.SubPaperCode=cour.SubPaperCode Where  " +
                                                                            " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                                                            " TRBTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                                                            " TRBTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                                                            " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                                                            " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                                                            " FROM TRBTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                                                            " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                                                            " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                                                            " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }
                                        //else TH_ESM = TH_ESM;
                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }
                                        //else PT_ESM = PT_ESM;
                                    }
                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }
                            }
                            else
                            {
                                calculateCAMSM_END();

                            }


                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();

                            // Calculate endsem marks -------

                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();

                            }

                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }

                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");


                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }
                            if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRBTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                //string RegNo = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        trcount = dsstudentreginfo.Tables[0].Rows.Count;
                        LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }

    protected void GenerateTRBTec_Arc()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
            " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
            " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
            " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
            " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND Exam.ExamSession  = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
            " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
            " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
            " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
            " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
            " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (Check == true)
        {
            // code for already proccessed.......
            DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                       " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                       " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
            if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
            {
                LblMsg.Text = "TR already proccessed for the above criteria.";
                return;
            }
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {
                //if (dsstudentreginfo.Tables[0].Rows[i]["Regno"].ToString() == "01201008638")
                //{
                //    string find = "ture";
                //}   
                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                     " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                     " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                     " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                     " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {

                    string SaveFlag = "";

                    string[] col = new string[15];
                    string[] val = new string[15];
                   string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString(); 
                   /*  string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    string examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString(); */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "ExamSession"; val[14] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRBTec", col, val);
                    if (SaveFlag == "1")
                    {
                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
     "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
     "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
     "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
     " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
     " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
          " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();

                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            if (UMC != "" && UMC.IndexOf("DA") != -1)
                            {
                                ClassTest1 = "0";
                                ClassTest2 = "0";
                            }
                            else
                            {
                                ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                                ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";

                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H")
                                {
                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,trbtec.SubPaperCode, " +
                                                                            " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                                                            " FROM TRBTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRBTec.SubPaperCode=cour.SubPaperCode Where  " +
                                                                            " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                                                            " TRBTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                                                            " TRBTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                                                            " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                                                            " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                                                            " FROM TRBTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                                                            " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                                                            " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                                                            " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }
                                        //else TH_ESM = TH_ESM;
                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }
                                        //else PT_ESM = PT_ESM;
                                    }
                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }                                
                            }
                            else
                            {
                                calculateCAMSM_END();

                            }


                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();

                            // Calculate endsem marks -------

                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();

                            }

                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }

                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                                      
                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }
                            if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRBTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                //string RegNo = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        trcount = dsstudentreginfo.Tables[0].Rows.Count;
                        LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }
    
    protected void GenerateTRBTec_CE()
    {
     
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
            " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
            " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
            " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
            " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND Exam.ExamSession  = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
            " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
            " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
            " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
            " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
            " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (Check == true)
        {
            // code for already proccessed.......
            DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                       " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                       " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
            if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
            {
                LblMsg.Text = "TR already proccessed for the above criteria.";
                return;
            }
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {
                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " + 
                    " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                    " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                    " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " + 
                    " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
               
                //DataSet dsstudentpaperdetails = fnrev.SelectDataset("Select SubPaperCode,ExamType,DateOfExam,UMCode FRom EXAMPAPERDETAIL Where " +
                //     " RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                // " StreamPartCode ='" + StreamPart.SelectedValue + "' AND ExamYear = '" + ExamYear.SelectedItem + "' AND ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {

                    string SaveFlag = "";

                    string[] col = new string[15];
                    string[] val = new string[15];
                   string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString();
                 /*    string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    string examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString(); */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "ExamSession"; val[14] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRBTec", col, val);
                    if (SaveFlag == "1")
                    {
                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
     "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
     "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
     "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
     " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
     " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
          " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();

                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            if (UMC != "" && UMC.IndexOf("DA") != -1)
                            {
                                ClassTest1 = "0";
                                ClassTest2 = "0";
                            }
                            else
                            {
                                ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                                ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";

                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H")
                                {

                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,trbtec.SubPaperCode, " +
                                         " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                         " FROM TRBTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRBTec.SubPaperCode=cour.SubPaperCode Where  " +
                                         " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                         " TRBTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                         " TRBTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                         " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                         " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                         " FROM TRBTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                         " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                         " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                         " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }
                                        //else TH_ESM = TH_ESM;
                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }
                                        //else PT_ESM = PT_ESM;
                                    }
                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }                               
                            }
                            else
                            {
                                calculateCAMSM_END();

                            }

                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();
                            // Calculate endsem marks -------

                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();

                            }

                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            
                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");



                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }

                            if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRBTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                //string RegNo = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        trcount = dsstudentreginfo.Tables[0].Rows.Count;
                        LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }
    protected void GenerateTRBTec_ECE()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
            " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
            " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
            " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
            " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND Exam.ExamSession  = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
            " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
            " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
            " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
            " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
            " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (Check == true)
        {
            // code for already proccessed.......
            DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                       " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                       " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
            if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
            {
                LblMsg.Text = "TR already proccessed for the above criteria.";
                return;
            }
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {
                //if (dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() == "01201211649")
                //{
                //    string sfind = "break";
                //}
                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                     " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                     " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                     " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                     " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {

                    string SaveFlag = "";

                    string[] col = new string[15];
                    string[] val = new string[15];
                  string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString(); 
                    /*  string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    sring examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString(); */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "ExamSession"; val[14] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRBTec", col, val);
                    if (SaveFlag == "1")
                    {
                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
     "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
     "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
     "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
     " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
     " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
          " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();

                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            if (UMC != "" && UMC.IndexOf("DA") != -1)
                            {
                                ClassTest1 = "0";
                                ClassTest2 = "0";
                            }
                            else
                            {
                                ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                                ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";

                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H")
                                {
                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,trbtec.SubPaperCode, " +
                                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                        " FROM TRBTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRBTec.SubPaperCode=cour.SubPaperCode Where  " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                        " TRBTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                        " TRBTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                        " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                        " FROM TRBTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                        " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                        " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                 
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }
                                        //else TH_ESM = TH_ESM;
                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }
                                        //else PT_ESM = PT_ESM;
                                    }
                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }          
                            }
                            else
                            {
                                calculateCAMSM_END();
                            }

                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();

                            // Calculate endsem marks -------

                            if (TH_ESM.Trim() != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();

                            }

                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM.Trim() != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM.Trim() != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }

                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");



                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }

                            if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRBTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                //string RegNo = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        trcount = dsstudentreginfo.Tables[0].Rows.Count;
                        LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }
    protected void GenerateTRBTec_IT()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
            " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
            " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
            " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
            " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND Exam.ExamSession  = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
            " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
            " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
            " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
            " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
            " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {
            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (Check == true)
        {
            // code for already proccessed.......
            DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                       " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                       " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
            if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
            {
                LblMsg.Text = "TR already proccessed for the above criteria.";
                return;
            }
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {
            

                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                     " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                     " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                     " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                     " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {
                   
                    string SaveFlag = "";

                    string[] col = new string[15];
                    string[] val = new string[15];
                    string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString(); 
                  /*  string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    string examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString(); */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "ExamSession"; val[14] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRBTec", col, val);
                    if (SaveFlag == "1")
                    {
                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
     "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
     "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
     "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
     " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
     " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
          " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");

                       
                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();

                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            if (UMC != "" && UMC.IndexOf("DA") != -1)
                            {
                                ClassTest1 = "0";
                                ClassTest2 = "0";
                            }
                            else
                            {
                                ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                                ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";

                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H"))
                                {
                                   
                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,trbtec.SubPaperCode, " +
                                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                        " FROM TRBTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRBTec.SubPaperCode=cour.SubPaperCode Where  " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                        " TRBTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                        " TRBTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                        " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                        " FROM TRBTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                        " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                        " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }
                                        //else TH_ESM = TH_ESM;
                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }
                                        //else PT_ESM = PT_ESM;
                                    }
                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }          
                            }
                            else
                            {
                                calculateCAMSM_END();

                            }


                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();

                            // Calculate endsem marks -------

                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();

                            }

                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }

                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");


                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }

                            if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRBTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                //string RegNo = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        trcount = dsstudentreginfo.Tables[0].Rows.Count;
                        LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }
    protected void GenerateTRBTec_CSE()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
            " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
            " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
            " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
            " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND Exam.ExamSession  = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
            " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
            " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
            " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
            " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
            " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (Check == true)
        {
            // code for already proccessed.......
            DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                       " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                       " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
            if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
            {
                LblMsg.Text = "TR already proccessed for the above criteria.";
                return;
            }
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {

                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                     " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                     " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                     " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                     " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {

                    string SaveFlag = "";

                    string[] col = new string[15];
                    string[] val = new string[15];
                    string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString(); 
                  /*  string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    string examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString(); */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "ExamSession"; val[14] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRBTec", col, val);
                    if (SaveFlag == "1")
                    {
                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
     "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
     "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
     "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
     " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
     " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
          " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();

                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            if (UMC != "" && UMC.IndexOf("DA") != -1)
                            {
                                ClassTest1 = "0";
                                ClassTest2 = "0";
                            }
                            else
                            {
                                ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                                ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";

                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H")
                                {
                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,trbtec.SubPaperCode, " +
                                                                            " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                                                            " FROM TRBTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRBTec.SubPaperCode=cour.SubPaperCode Where  " +
                                                                            " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                                                            " TRBTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                                                            " TRBTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                                                            " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                                                            " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                                                            " FROM TRBTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                                                            " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                                                            " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                                                            " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }
                                        //else TH_ESM = TH_ESM;
                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }
                                        //else PT_ESM = PT_ESM;
                                    }
                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }          
                            }
                            else
                            {
                                calculateCAMSM_END();
                            }


                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();
                            // Calculate endsem marks -------

                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();

                            }

                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }

                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");



                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }
                            if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRBTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                //string RegNo = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        trcount = dsstudentreginfo.Tables[0].Rows.Count;
                        LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }

    protected void GenerateTRBTec_ME()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
            " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
            " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
            " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
            " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND Exam.ExamSession  = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
            " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
            " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
            " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
            " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
            " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (Check == true)
        {
            // code for already proccessed.......
            DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                       " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                       " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
            if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
            {
                LblMsg.Text = "TR already proccessed for the above criteria.";
                return;
            }
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {

                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                      " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                      " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                      " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                      " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {

                    string SaveFlag = "";

                    string[] col = new string[15];
                    string[] val = new string[15];
                    string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString();
                  /*  string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    string examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString(); */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "ExamSession"; val[14] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRBTec", col, val);
                    if (SaveFlag == "1")
                    {
                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
     "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
     "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
     "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
     " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
     " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
          " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();

                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            if (UMC != "" && UMC.IndexOf("DA") != -1)
                            {
                                ClassTest1 = "0";
                                ClassTest2 = "0";
                            }
                            else
                            {
                                ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                                ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";

                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H"))
                                {

                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,trbtec.SubPaperCode, " +
                                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                        " FROM TRBTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRBTec.SubPaperCode=cour.SubPaperCode Where  " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                        " TRBTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                        " TRBTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                        " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                        " FROM TRBTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                        " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                        " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }
                                        //else TH_ESM = TH_ESM;
                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }
                                        //else PT_ESM = PT_ESM;
                                    }
                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }          
                            }
                            else
                            {
                                calculateCAMSM_END();

                            }

                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();
                            
                            // Calculate endsem marks -------

                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();

                            }

                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            } 

                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");


                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }

                            if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRBTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                //string RegNo = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        trcount = dsstudentreginfo.Tables[0].Rows.Count;
                        LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }
    protected void GenerateTRBTec_EE()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
            " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
            " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
            " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
            " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND Exam.ExamSession  = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
            " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
            " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
            " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
            " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
            " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (Check == true)
        {
            // code for already proccessed.......
            DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                       " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                       " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
            if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
            {
                LblMsg.Text = "TR already proccessed for the above criteria.";
                return;
            }
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {
                //if (dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() == "01201400364")
                //{
                //    string sbreak = "break";
                //}

                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                     " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                     " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                     " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                     " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {

                    string SaveFlag = "";

                    string[] col = new string[15];
                    string[] val = new string[15];
                    string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString(); 
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "ExamSession"; val[14] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRBTec", col, val);
                    if (SaveFlag == "1")
                    {
                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
     "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
     "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
     "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
     " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
     " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
          " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();
                           
                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString().Trim();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            if (UMC != "" && UMC.IndexOf("DA") != -1)
                            {
                                ClassTest1 = "0";
                                ClassTest2 = "0";
                            }
                            else
                            {
                                ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                                ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString().Trim();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";

                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if ((dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N") || (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H"))
                                {

                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,trbtec.SubPaperCode, " +
                                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                        " FROM TRBTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRBTec.SubPaperCode=cour.SubPaperCode Where  " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                        " TRBTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                        " TRBTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                        " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                        " FROM TRBTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                        " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                        " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString().Trim();
                                            }
                                        }
                                      
                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString().Trim();
                                        }
                                        
                                    }
                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }          
                            }
                            else
                            {
                                calculateCAMSM_END();
                            }

                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();

                            // Calculate endsem marks -------

                            if (TH_ESM.Trim() != "" && TH_ESM.ToUpper().Trim() != "NULL")
                            {
                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();

                            }

                            if (PT_ESM.Trim() != "" && PT_ESM.ToUpper().Trim() != "NULL")
                            {
                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM.Trim() != "" && TH_ESM.ToUpper().Trim() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2013)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }

                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");



                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }

                            if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dspapermarks.Tables[0].Rows[0]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRBTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                //string RegNo = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        trcount = dsstudentreginfo.Tables[0].Rows.Count;
                        LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }

    protected void calculateCAMSM_END_NC()
    {
        // Calculate CA_MSM_TH

        if (ClassTest1.Trim() != "" && ClassTest1.ToUpper() != "NULL")
        {
            CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(ClassTest1)).ToString();
        }
        if (ClassTest2.Trim() != "" && ClassTest2.ToUpper() != "NULL")
        {
            CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(ClassTest2)).ToString();
        }
        if (Midsem.Trim() != "" && Midsem.ToUpper() != "NULL")
        {
            CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(Midsem)).ToString();
        }
        if (TH_Attendance.Trim() != "" && TH_Attendance.ToUpper() != "NULL")
        {
            CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(TH_Attendance)).ToString();
        }
        // For Check CA_MSM_TH value

        if (CA_MSM_TH.Trim() != "")
        {
            CA_MSM_TH = (Math.Round(decimal.Parse(CA_MSM_TH), 2)).ToString();
        }
        //TH_ESM = TH_ESM;

        // Calculate CA_MSM_PT

        if (PR_Attendance.Trim() != "" && PR_Attendance.ToUpper() != "NULL")
        {
            CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(PR_Attendance)).ToString();
        }
        if (PracticalRecord.Trim() != "" && PracticalRecord.ToUpper() != "NULL")
        {
            CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(PracticalRecord)).ToString();
        }
        if (PRClassPerfor.Trim() != "" && PRClassPerfor.ToUpper() != "NULL")
        {
            CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(PRClassPerfor)).ToString();
        }
        if (Prpreendsemviva.Trim() != "" && Prpreendsemviva.ToUpper() != "NULL")
        {
            CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(Prpreendsemviva)).ToString();
        }
        // For Check CA_MSM_PT value

        if (CA_MSM_PT.Trim() != "")
        {
            //CA_MSM_PT = Math.Round(CA_MSM_PT, 2);
            //CA_MSM_PT = String.Format("{0:0.00}", CA_MSM_PT);
            CA_MSM_PT = (Math.Round(decimal.Parse(CA_MSM_PT), 2)).ToString();
        }

        // Calculate PT_ESM

        //PT_ESM = PT_ESM;
    }
    protected void calculateCAMSM_END()
    {
        // Calculate CA_MSM_TH

        if (ClassTest1.Trim() != "" && ClassTest1.ToUpper() != "NULL")
        {
            CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(ClassTest1)).ToString();
        }
        if (ClassTest2.Trim() != "" && ClassTest2.ToUpper() != "NULL")
        {
            CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(ClassTest2)).ToString();
        }
        if (Midsem.Trim() != "" && Midsem.ToUpper() != "NULL")
        {
            CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(Midsem)).ToString();
        }
        if (TH_Attendance.Trim() != "" && TH_Attendance.ToUpper() != "NULL")
        {
            CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(TH_Attendance)).ToString();
        }
        // For Check CA_MSM_TH value
     
        if (CA_MSM_TH.Trim() != "")
        {
            CA_MSM_TH = (Math.Round(decimal.Parse(CA_MSM_TH), 2)).ToString();
        }
        //TH_ESM = TH_ESM;

        // Calculate CA_MSM_PT

        if (PR_Attendance.Trim() != "" && PR_Attendance.ToUpper() != "NULL")
        {
            CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(PR_Attendance)).ToString();
        }
        if (PracticalRecord.Trim() != "" && PracticalRecord.ToUpper() != "NULL")
        {
            CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(PracticalRecord)).ToString();
        }
        if (PRClassPerfor.Trim() != "" && PRClassPerfor.ToUpper() != "NULL")
        {
            CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(PRClassPerfor)).ToString();
        }
        if (Prpreendsemviva.Trim() != "" && Prpreendsemviva.ToUpper() != "NULL")
        {
            CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(Prpreendsemviva)).ToString();
        }
        // For Check CA_MSM_PT value
        if (CA_MSM_PT.Trim() != "")
        {
            //CA_MSM_PT = Math.Round(CA_MSM_PT, 2);
            //CA_MSM_PT = String.Format("{0:0.00}", CA_MSM_PT);
            CA_MSM_PT = (Math.Round(decimal.Parse(CA_MSM_PT), 2)).ToString();
        }

        // Calculate PT_ESM

        //PT_ESM = PT_ESM;
    }

    protected void checkCA_MSM()
    {
        if (ClassTest1.Trim() == "" && ClassTest2.Trim() == "" && Midsem.Trim() == "" && TH_Attendance.Trim() == "" && CA_MSM_TH == "0")
        {
            CA_MSM_TH = "";
        }
        if (PR_Attendance.Trim() == "" && PracticalRecord.Trim() == "" && PRClassPerfor.Trim() == "" && Prpreendsemviva.Trim() == "" && CA_MSM_PT == "0")
        {
            CA_MSM_PT = "";
        }
    }

    protected void gradecriteria()
    {
        if (papertype == "X")
        {
            if ((TH_PMO != "" && double.Parse(TH_PMO) < 33) || (PT_PMO != "" && double.Parse(PT_PMO) < 33))
            {
                GRADE = "F";
                GRADE_POINT = "0";
                ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                if (TH_PMO != "" && double.Parse(TH_PMO) < 33)
                    REMARKS = "Fail in Theory";
                else if (PT_PMO != "" && double.Parse(PT_PMO) < 33)
                    REMARKS = "Fail in Practical";
                else
                    REMARKS = "Fail in both Theory & Practical";
            }
            else
            {
                grading();
            }


        }
        else if (papertype == "T")
        {
            if (TH_PMO != "")
            {
                if (double.Parse(TH_PMO) < 33)
                {

                    GRADE = "F";
                    GRADE_POINT = "0";
                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                    REMARKS = "Fail in Theory";

                }
                else
                {
                    grading();
                }
            }

        }
        else if (papertype == "P")
        {
            if (PT_PMO != "")
            {
                if (double.Parse(PT_PMO) < 33)
                {
                    GRADE = "F";
                    GRADE_POINT = "0";
                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                    REMARKS = "Fail in Practical";

                }
                else
                {
                    grading();
                }
            }
        }
    }

    protected void gradecriteria_old()
    {
        if (papertype == "X")
        {

            if ((TH_PMO != "" && double.Parse(TH_PMO) < 35) || (PT_PMO != "" && double.Parse(PT_PMO) < 40))
            {
                GRADE = "F";
                GRADE_POINT = "0";
                ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                if (TH_PMO != "" && double.Parse(TH_PMO) < 35)
                    REMARKS = "Fail in Theory";
                else if (PT_PMO != "" && double.Parse(PT_PMO) < 40)
                    REMARKS = "Fail in Practical";
                else
                    REMARKS = "Fail in both Theory & Practical";
            }
            else
            {
                grading();
            }

        }
        else if (papertype == "T")
        {
            if (TH_PMO != "")
            {
                if (double.Parse(TH_PMO) < 35)
                {

                    GRADE = "F";
                    GRADE_POINT = "0";
                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                    REMARKS = "Fail in Theory";

                }
                else
                {
                    grading();
                }
            }
        }
        else if (papertype == "P")
        {
            if (PT_PMO != "")
            {
                if (double.Parse(PT_PMO) < 40)
                {
                    GRADE = "F";
                    GRADE_POINT = "0";
                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                    REMARKS = "Fail in Practical";

                }
                else
                {
                    grading();
                }
            }
        }
    }

    //grade code for Endsem blank for special case
    protected void gardespecial()
    {
        if (yrvalue >= 2013)
        {
            if ((TH_PMO != "" && double.Parse(TH_PMO) >= 33) || (PT_PMO != "" && double.Parse(PT_PMO) >= 33))
            {
                if (TH_ESM == "" && PT_ESM == "")
                {
                    GRADE = "I";
                    GRADE_POINT = "0";
                    ER_CREDIT = "0";
                    REMARKS = "Absent";
                }
            }
            else if (TH_PMO != "" && double.Parse(TH_PMO) >= 33)
            {
                if (TH_PMO == "")
                {
                    GRADE = "I";
                    GRADE_POINT = "0";
                    ER_CREDIT = "0";
                    REMARKS = "Absent";
                }
            }
            else if (PT_PMO != "" && double.Parse(PT_PMO) >= 33)
            {
                if (PT_PMO == "")
                {
                    GRADE = "I";
                    GRADE_POINT = "0";
                    ER_CREDIT = "0";
                    REMARKS = "Absent";
                }
            }

        }
        else
        {
            if ((TH_PMO != "" && double.Parse(TH_PMO) >= 35) || (PT_PMO != "" && double.Parse(PT_PMO) >= 40))
            {
                if (TH_ESM == "" && PT_ESM == "")
                {
                    GRADE = "I";
                    GRADE_POINT = "0";
                    ER_CREDIT = "0";
                    REMARKS = "Absent";
                }
            }
            else if (TH_PMO != "" && double.Parse(TH_PMO) >= 35)
            {
                if (TH_PMO == "")
                {
                    GRADE = "I";
                    GRADE_POINT = "0";
                    ER_CREDIT = "0";
                    REMARKS = "Absent";
                }
            }
            else if (PT_PMO != "" && double.Parse(PT_PMO) >= 40)
            {
                if (PT_PMO == "")
                {
                    GRADE = "I";
                    GRADE_POINT = "0";
                    ER_CREDIT = "0";
                    REMARKS = "Absent";
                }
            }
        }
    }

    /* Code for MTec TR PRocessing */
    protected void GenerateTRMTec_DD()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
                " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
                " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
                " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
                " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
                " Exam.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
        " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
        " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
        " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
        " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            if (Check == true)
            {
                // code for already proccessed.......
                DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                           " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                           " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
                {
                    LblMsg.Text = "TR already proccessed for the above criteria.";
                    return;
                }
            }
        }
        else
        {
            LblMsg.Text = "No Record(S) found for TR proccess.";
            return;
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {
                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                    " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                    " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                    " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                    " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {
                    string SaveFlag = "";

                    string[] col = new string[16];
                    string[] val = new string[16];
                    string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString();
                    /*  string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                     string examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();  */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "SplCode"; val[14] = Splcode.SelectedValue;
                    col[15] = "ExamSession"; val[15] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRMTec", col, val);
                    if (SaveFlag == "1")
                    {

                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
      "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
      "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
      "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
      " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
      " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
           " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();
                            ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                            ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";
                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H"))
                                {

                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,TRMTec.SubPaperCode, " +
                                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                        " FROM TRMTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRMTec.SubPaperCode=cour.SubPaperCode Where  " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                        " TRMTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                        " TRMTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                        " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                        " FROM TRMTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                        " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                        " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }

                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }

                                    }

                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }
                            }
                            else
                            {
                                calculateCAMSM_END();
                            }

                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();

                            // roundiind off end sem

                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }

                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");



                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRMTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }
    protected void GenerateTRMTec_EC()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
                " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
                " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
                " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
                " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
                " Exam.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
        " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
        " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
        " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
        " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            if (Check == true)
            {
                // code for already proccessed.......
                DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                           " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                           " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
                {
                    LblMsg.Text = "TR already proccessed for the above criteria.";
                    return;
                }
            }
        }
        else
        {
            LblMsg.Text = "No Record(S) found for TR proccess.";
            return;
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {
                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                    " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                    " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                    " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                    " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {
                    string SaveFlag = "";

                    string[] col = new string[16];
                    string[] val = new string[16];
                   string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString();
                   /*  string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    string examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();  */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "SplCode"; val[14] = Splcode.SelectedValue;
                    col[15] = "ExamSession"; val[15] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRMTec", col, val);
                    if (SaveFlag == "1")
                    {

                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
      "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
      "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
      "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
      " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
      " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
           " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();
                            ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                            ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";
                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H"))
                                {

                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,TRMTec.SubPaperCode, " +
                                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                        " FROM TRMTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRMTec.SubPaperCode=cour.SubPaperCode Where  " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                        " TRMTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                        " TRMTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                        " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                        " FROM TRMTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                        " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                        " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }

                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }

                                    }

                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }          
                            }
                            else
                            {
                                calculateCAMSM_END();
                            }

                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();

                            // roundiind off end sem

                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }

                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");



                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRMTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }
    protected void GenerateTRMTec_CE()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
                " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
                " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
                " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
                " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
                " Exam.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
        " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
        " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
        " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
        " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            if (Check == true)
            {
                // code for already proccessed.......
                DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                           " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                           " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
                {
                    LblMsg.Text = "TR already proccessed for the above criteria.";
                    return;
                }
            }
        }
        else
        {
            LblMsg.Text = "No Record(S) found for TR proccess.";
            return;
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {

                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                     " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                     " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                     " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                     " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {
                    string SaveFlag = "";

                    string[] col = new string[16];
                    string[] val = new string[16];
                    string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString();
                   /* string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    string examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString(); */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "SplCode"; val[14] = Splcode.SelectedValue;
                    col[15] = "ExamSession"; val[15] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRMTec", col, val);
                    if (SaveFlag == "1")
                    {

                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
      "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
      "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
      "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
      " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
      " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
           " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();
                            ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                            ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";
                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H"))
                                {

                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,TRMTec.SubPaperCode, " +
                                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                        " FROM TRMTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRMTec.SubPaperCode=cour.SubPaperCode Where  " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                        " TRMTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                        " TRMTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                        " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                        " FROM TRMTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                        " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                        " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }

                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }

                                    }
                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }          
                            }
                            else
                            {
                                calculateCAMSM_END();
                            }


                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();
                            // roundiind off end sem

                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {

                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();

                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {

                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            
                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRMTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }
    protected void GenerateTRMTec_ME()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
                " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
                " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
                " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
                " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
                " Exam.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
        " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
        " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
        " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
        " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            if (Check == true)
            {
                // code for already proccessed.......
                DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                           " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                           " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
                {
                    LblMsg.Text = "TR already proccessed for the above criteria.";
                    return;
                }
            }
        }
        else
        {
            LblMsg.Text = "No Record(S) found for TR proccess.";
            return;
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {
                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                    " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                    " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101'))  AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                    " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                    " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {
                    string SaveFlag = "";

                    string[] col = new string[16];
                    string[] val = new string[16];
                   string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString();
                /*     string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    string examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString(); */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "SplCode"; val[14] = Splcode.SelectedValue;
                    col[15] = "ExamSession"; val[15] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRMTec", col, val);
                    if (SaveFlag == "1")
                    {

                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
      "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
      "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
      "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
      " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
      " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
           " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();
                            ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                            ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";
                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H"))
                                {

                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,TRMTec.SubPaperCode, " +
                                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                        " FROM TRMTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRMTec.SubPaperCode=cour.SubPaperCode Where  " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                        " TRMTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                        " TRMTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                        " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                        " FROM TRMTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                        " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                        " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }

                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }

                                    }
                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }          
                            }
                            else
                            {
                                calculateCAMSM_END();
                            }


                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();
                            // roundiind off end sem

                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                               TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            
                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");


                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRMTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }     
    
    protected void GenerateTRMTec_CS()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
                " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
                " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
                " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
                " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
                " Exam.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
        " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
        " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
        " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
        " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            if (Check == true)
            {
                // code for already proccessed.......
                DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                           " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                           " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
                {
                    LblMsg.Text = "TR already proccessed for the above criteria.";
                    return;
                }
            }
        }
        else
        {
            LblMsg.Text = "No Record(S) found for TR proccess.";
            return;
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {
                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                     " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                     " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                     " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                     " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {
                    string SaveFlag = "";

                    string[] col = new string[16];
                    string[] val = new string[16];
                   string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString();
                   /*  string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    string examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString(); */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "SplCode"; val[14] = Splcode.SelectedValue;
                    col[15] = "ExamSession"; val[15] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRMTec", col, val);
                    if (SaveFlag == "1")
                    {

                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
      "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
      "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
      "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
      " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
      " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
           " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();
                            ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                            ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";
                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H"))
                                {

                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,TRMTec.SubPaperCode, " +
                                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                        " FROM TRMTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRMTec.SubPaperCode=cour.SubPaperCode Where  " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                        " TRMTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                        " TRMTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                        " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                        " FROM TRMTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                        " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                        " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }

                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }

                                    }

                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }          
                            }
                            else
                            {
                                calculateCAMSM_END();
                            }


                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();
                            // roundiind off end sem

                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            
                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");



                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRMTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }
   
    protected void GenerateTRMTec_EE()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
                " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
                " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
                " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
                " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
                " Exam.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
        " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
        " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
        " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
        " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            if (Check == true)
            {
                // code for already proccessed.......
                DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                           " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                           " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
                {
                    LblMsg.Text = "TR already proccessed for the above criteria.";
                    return;
                }
            }
        }
        else
        {
            LblMsg.Text = "No Record(S) found for TR proccess.";
            return;
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {
                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                    " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                    " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                    " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                    " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {
                    string SaveFlag = "";

                    string[] col = new string[16];
                    string[] val = new string[16];
                    string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString();
                /*    string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    string examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString(); */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "SplCode"; val[14] = Splcode.SelectedValue;
                    col[15] = "ExamSession"; val[15] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRMTec", col, val);
                    if (SaveFlag == "1")
                    {

                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
      "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
      "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
      "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
      " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
      " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
           " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();
                            ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                            ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";
                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H"))
                                {

                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,TRMTec.SubPaperCode, " +
                                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                        " FROM TRMTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRMTec.SubPaperCode=cour.SubPaperCode Where  " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                        " TRMTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                        " TRMTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                        " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                        " FROM TRMTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                        " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                        " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }

                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }

                                    }
                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }          
                            }
                            else
                            {
                                calculateCAMSM_END();
                            }


                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();
                            // roundiind off end sem

                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {

                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();

                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {

                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");


                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRMTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }
    
    protected void GenerateTRMTec_MRUP()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
                " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
                " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
                " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
                " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
                " Exam.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
        " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
        " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
        " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
        " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            if (Check == true)
            {
                // code for already proccessed.......
                DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                           " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                           " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
                {
                    LblMsg.Text = "TR already proccessed for the above criteria.";
                    return;
                }
            }
        }
        else
        {
            LblMsg.Text = "No Record(S) found for TR proccess.";
            return;
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {
                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                    " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                    " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                    " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                    " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {
                    string SaveFlag = "";

                    string[] col = new string[16];
                    string[] val = new string[16];
                   string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString();
                  /*   string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    string examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString(); */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "SplCode"; val[14] = Splcode.SelectedValue;
                    col[15] = "ExamSession"; val[15] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRMTec", col, val);
                    if (SaveFlag == "1")
                    {

                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
      "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
      "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
      "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
      " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
      " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
           " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();
                            ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                            ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";
                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H"))
                                {

                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,TRMTec.SubPaperCode, " +
                                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                        " FROM TRMTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRMTec.SubPaperCode=cour.SubPaperCode Where  " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                        " TRMTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                        " TRMTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                        " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                        " FROM TRMTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                        " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                        " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }

                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }

                                    }

                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }          
                            }
                            else
                            {
                                calculateCAMSM_END();
                            }


                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();

                            // roundiind off end sem

                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }


                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");


                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRMTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }
    protected void GenerateTRMTec_AR()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
                " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
                " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
                " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
                " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
                " Exam.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
        " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
        " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
        " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
        " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            if (Check == true)
            {
                // code for already proccessed.......
                DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                           " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                           " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
                {
                    LblMsg.Text = "TR already proccessed for the above criteria.";
                    return;
                }
            }
        }
        else
        {
            LblMsg.Text = "No Record(S) found for TR proccess.";
            return;
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {

                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                     " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                     " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                     " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                     " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {
                    string SaveFlag = "";

                    string[] col = new string[16];
                    string[] val = new string[16];
                   string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString();
                  /*   string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    string examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString(); */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "SplCode"; val[14] = Splcode.SelectedValue;
                    col[15] = "ExamSession"; val[15] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRMTec", col, val);
                    if (SaveFlag == "1")
                    {

                       DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
     "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
     "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
     "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
     " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
     " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
          " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();
                            ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                            ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";
                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H"))
                            {

                                DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,TRMTec.SubPaperCode, " +
                                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                        " FROM TRMTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRMTec.SubPaperCode=cour.SubPaperCode Where  " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                        " TRMTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                        " TRMTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                        " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                        " FROM TRMTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                        " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                        " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                if (dspreviousrec.Tables[0].Rows.Count > 0)
                                {
                                    CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                    CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                    if (TH_ESM == "")
                                    {
                                        if (UMC != "" && UMC.IndexOf("ES") != -1)
                                        {
                                            TH_ESM = "";

                                        }
                                        else
                                        {
                                            TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                        }
                                    }
                                    
                                    if (PT_ESM == "")
                                    {
                                        PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                    }
                                    
                                }

                                calculateCAMSM_END_NC();
                            }
                            else
                            {
                                calculateCAMSM_END();
                            }          
                            }
                            else
                            {
                                calculateCAMSM_END();
                            }

                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();

                            // roundiind off end sem

                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                
                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();

                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                
                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            
                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");


                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRMTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }
    
    protected void GenerateTRMTec_IT()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
                " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
                " REGISTRATION.Gender, EXAM.SubCode FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
                " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
                " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
                " Exam.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");

        // For Non collegiate
        dsstudentregnc = fnrev.SelectDataset("SELECT REGISTRATION.AdmYear, EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.CollCode, " +
        " REGISTRATION.StreamCode, EXAMPAPERDETAIL.StreamPartCode, EXAMPAPERDETAIL.ExamYear, REGISTRATION.ApplicantName, REGISTRATION.HindiName, " +
        " REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.Gender, REGISTRATION.SubCode FROM EXAMPAPERDETAIL INNER JOIN " +
        " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE REGISTRATION.StreamCode = '" + StreamCode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.StreamPartCode = '" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.EXAMTYPE IN ('N','B') AND " +
        " EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND " +
        " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
        if (dsstudentregnc.Tables[0].Rows.Count > 0)
        {

            dsstudentreginfo.Merge(dsstudentregnc.Tables[0]);
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            if (Check == true)
            {
                // code for already proccessed.......
                DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                           " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND " +
                           " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
                {
                    LblMsg.Text = "TR already proccessed for the above criteria.";
                    return;
                }
            }
        }
        else
        {
            LblMsg.Text = "No Record(S) found for TR proccess.";
            return;
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {
                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                    " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                    " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                    " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                    " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {
                    string SaveFlag = "";

                    string[] col = new string[16];
                    string[] val = new string[16];
                   string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString();
                   /*  string Examyear = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    string examtype = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString(); */
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "SplCode"; val[14] = Splcode.SelectedValue;
                    col[15] = "ExamSession"; val[15] = Examsession.SelectedItem.ToString();
                    SaveFlag = NicService.SaveData("TRMTec", col, val);
                    if (SaveFlag == "1")
                    {

                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
      "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
      "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndsem, " +
      "EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
      " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
      " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
           " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
      " AND (EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "')");


                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();
                            ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                            ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                TH_ESM = "";

                            }
                            else
                            {
                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndsem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();

                            PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";
                            // calculate CA_MSM_TH & CA_MSM_PT For non-collegiate---------------
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2014" || Examsession.SelectedItem.ToString() == "JAN-JUN_2015" || Examsession.SelectedItem.ToString() == "JUL-DEC_2015" || Examsession.SelectedItem.ToString() == "JAN-JUN_2016" || Examsession.SelectedItem.ToString() == "JUL-DEC_2016" || Examsession.SelectedItem.ToString() == "ADT-SEP_2016" || Examsession.SelectedItem.ToString() == "JAN-JUN_2017" || Examsession.SelectedItem.ToString() == "JUL-DEC_2017" || Examsession.SelectedItem.ToString() == "JAN-JUN_2018")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N" || (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H"))
                                {

                                    DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,TRMTec.SubPaperCode, " +
                                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                        " FROM TRMTec inner join NIT_patna.dbo.COURSEPAPERS cour on TRMTec.SubPaperCode=cour.SubPaperCode Where  " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                        " TRMTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                        " TRMTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                        " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                        " FROM TRMTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                        " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                        " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                    if (dspreviousrec.Tables[0].Rows.Count > 0)
                                    {
                                        CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                        CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (TH_ESM == "")
                                        {
                                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                                            {
                                                TH_ESM = "";

                                            }
                                            else
                                            {
                                                TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }

                                        if (PT_ESM == "")
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }

                                    }

                                    calculateCAMSM_END_NC();
                                }
                                else
                                {
                                    calculateCAMSM_END();
                                }          
                            }
                            else
                            {
                                calculateCAMSM_END();
                            }


                            // check CA_MSM_TH and CA_MSM_PT in both case--
                            checkCA_MSM();

                            // roundiind off end sem

                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                            }

                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");

                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();

                            }



                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++

                            if (CA_MSM_TH != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (TH_PMO != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                            }
                            if (ThFMarks != "")
                            {
                                TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                            }
                            if (CA_MSM_TH == "" && TH_ESM == "")
                            {
                                TH_PMO = "";
                            }
                            else
                            {
                                TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                            }


                            // Calculate PT_PMO ===========================

                            if (CA_MSM_PT != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                            }
                            if (PT_PMO != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                            }
                            if (PT_PMO != "" && PractFMarks != "")
                            {
                                PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                            }
                            if (CA_MSM_PT == "" && PT_ESM == "")
                            {
                                PT_PMO = "";
                            }
                            else
                            {
                                //PT_PMO = Math.Round(PT_PMO, 2);
                                PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                            }


                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (yrvalue >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            else
                            {
                                if (int.Parse(admyear) >= 2014)
                                {
                                    gradecriteria();
                                }
                                else
                                {
                                    gradecriteria_old();
                                }
                            }
                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");


                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {

                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";

                            }
                            else if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (Examsession.SelectedItem.ToString() == "JUL-DEC_2013")
                            {
                                if (StudStatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                                if (StudStatus == "A")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                if (astatus == "D")
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                    REMARKS = "Debarred";
                                }
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                                else
                                {
                                    GRADE = "X";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "";
                                }
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRMTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                }
            }
        }
    }
  
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        CourseValue();
        bindddlcoursespl();
    }
    protected void CourseValue()
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart, StreamPartCode from StreamPart where streamcode='" + StreamCode.SelectedValue + "' and streampartcode in (select distinct streampartcode from streampart) order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");


    }
    protected void CollChkBox_CheckedChanged(object sender, EventArgs e)
    {
        if (CollChkBox.Checked == true)
        {
            CollCode.Enabled = false;
            InstCode.Enabled = false;
        }
        else
        {
            CollCode.Enabled = true;
            InstCode.Enabled = true;
        }
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }

    protected void btnTrprint_Click(object sender, EventArgs e)
    {
        string grprint = "";
        if (rdbregular.Checked == true)
        {
            grprint = "R";
        }
        else if (rdbncblog.Checked == true)
        {
            grprint = "NB";
        }
        //string examsession = "";//(SUBSTRING(ExamSession,10,4) = '" + ExamYear.SelectedItem + "') and
        //DataSet dsexamsession = fnrev.SelectDataset("Select ExamSession from AssignCoursePaper Where SUBSTRING(ExamSession,9,4)='" + ExamYear.SelectedItem + "' and Semester ='" + StreamPart.SelectedItem + "'");
        //if (dsexamsession.Tables[0].Rows.Count > 0)
        //    examsession = dsexamsession.Tables[0].Rows[0]["ExamSession"].ToString();
        //else examsession = "";

        Response.Redirect("TRBTecPrint.aspx?sc=" + StreamCode.SelectedValue + "&spc=" + StreamPart.SelectedValue + "&ey=" + ExamYear.SelectedItem + "&prg=" + StreamCode.SelectedItem + "&sem=" + StreamPart.SelectedItem + "&exses=" + Examsession.SelectedItem.ToString() + "&splc=" + Splcode.SelectedValue + "&spart=" + StreamPart.SelectedItem.ToString() + "&grp=" + grprint);
        //ReportDocument crystalReport = new ReportDocument();
        //filldatatable();

        //crystalReport.Load(Server.MapPath("~/Report/TrbtecPrint.rpt"));

        //dstrrecord.Tables[0].Merge(dttrbtec);
        //crystalReport.SetDataSource(dstrrecord);
        //CR.ReportSource = crystalReport;
        //Panel1.Visible = true;
    }


    protected void bindddlcoursespl()
    {
        Functionreviseed appfn = new Functionreviseed();
        DataSet dscrsespl = appfn.SelectDataset(" SELECT Stream_Specialization.StreamCode, Stream_Specialization.SplCode, " + 
            " CourseSpecialization.SpDescription, CourseSpecialization.Spvalue, CourseSpecialization.SPCode FROM Stream_Specialization " + 
            " INNER JOIN CourseSpecialization ON Stream_Specialization.SplCode = CourseSpecialization.SPCode WHERE Stream_Specialization.StreamCode = " + 
            "'" + StreamCode.SelectedValue + "'");
        if (dscrsespl.Tables[0].Rows.Count > 0)
        {
            Splcode.Items.Clear();
            Splcode.DataSource = dscrsespl.Tables[0];
            Splcode.DataTextField = "SPCode";
            Splcode.DataValueField = "SPCode";
            Splcode.DataBind();
            Splcode.Items.Insert(0, "--Select--");
        }
        else
        {
            Splcode.Items.Clear();
            Splcode.Items.Insert(0, "NA");
        }
    }

    protected void btnfinaltr_Click(object sender, EventArgs e)
    {
       
        string streampart = StreamPart.SelectedValue;

        if (StreamPart.SelectedItem.ToString().IndexOf('A') > 0 || StreamPart.SelectedItem.ToString().IndexOf('B') > 0)
        {
            streampart = StreamPart.SelectedItem.ToString();
        }

        string Url = "TRBTecSummary.aspx?sc=" + StreamCode.SelectedValue + "&spc=" + streampart + "&ey=" + ExamYear.SelectedItem + "&prg=" + StreamCode.SelectedItem + "&sem=" + StreamPart.SelectedItem + "&exses=" + Examsession.SelectedValue;




        ScriptManager.RegisterStartupScript(this, typeof(string), "Open", "window.open('" + Url + "');", true);
        ////Response.Redirect("TRBTecSummary.aspx?sc=" + StreamCode.SelectedValue + "&spc=" + StreamPart.SelectedValue + "&ey=" + ExamYear.SelectedItem + "&prg=" + StreamCode.SelectedItem + "&sem=" + StreamPart.SelectedItem + "&exses=" + examsession);


    }

    protected void ExamYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(Examsession, "ExamPaperdetail", "Select Distinct ExamSession From EXAMPAPERDETAIL Where ExamYear = '" + ExamYear.SelectedItem.ToString() + "'", "ExamSession", "ExamSession");
    }

    bool checkTH = true; bool checkPT = true;
    protected void GenerateTRBTec_SQSPL()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
            " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
            " REGISTRATION.Gender, EXAM.SubCode,Exam.ExamType FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
            " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
            " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND EXAM.ExamSession = '" + Examsession.SelectedItem.ToString() + "' ");
        
        if (Check == true)
        {
            // code for already proccessed.......
            DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRBTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                       " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND TRBTec.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
            if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
            {
                LblMsg.Text = "TR already proccessed for the above criteria.";
                return;
            }
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {
                //if (dsstudentreginfo.Tables[0].Rows[i]["Regno"].ToString() == "01201400054")
                //{
                //    string find = "ture";
                //}

                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                    " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                    " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                    " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                    " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {
                    string SaveFlag = "";

                    string[] col = new string[15];
                    string[] val = new string[15];
                    string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString(); //suraj
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "ExamSession"; val[14] = Examsession.SelectedItem.ToString();

                    SaveFlag = NicService.SaveData("TRBTec", col, val);
                    if (SaveFlag == "1")
                    {
                        PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";
                        checkPT = true;
                        checkTH = true;
                      
                       
                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
     "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
     "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndSem, " +
     "EXAMPAPERDETAIL.Prpreendsemviva,EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
     " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
     " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
          " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
     " AND EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");

                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                           
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();
                            ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                            ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                THEndsem = "";
                                
                            }
                            else
                            {
                                THEndsem = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();
                              
                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {                                
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                            PREndSem = dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString();
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();


                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                //if (dsthfullmark.Tables[0].Rows.Count > 0)
                                //{
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();
                                //}
                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                //if (dsthfullmark.Tables[0].Rows.Count > 0)
                                //{
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();
                                //}

                            }

                            // Add For Spl Exam
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                            {

                            
                                DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,trbtec.SubPaperCode, " +
                                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                        " FROM TRBTec inner join COURSEPAPERS cour on TRBTec.SubPaperCode=cour.SubPaperCode Where  " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                        " TRBTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                        " TRBTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                        " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                        " FROM TRBTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                        " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                        " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                if (dspreviousrec.Tables[0].Rows.Count > 0)
                                {
                                    CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                    CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                        if (UMC != "" && UMC.IndexOf("ES") != -1)
                                        {
                                            TH_ESM = "";

                                        }
                                        else
                                        {

                                            TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                        }
                                        if (UMC != "" && UMC.IndexOf("ES") != -1)
                                        {
                                            PT_ESM = "";
                                        }
                                        else
                                        {
                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                        }
                                    
                                    //check For pass in Previous marks
                                    // Calculte TH_PMO -----------
                                         if (CA_MSM_TH != "")
                                        {
                                            TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                                        }
                                        if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                                        {
                                            TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                                        }
                                        if (TH_PMO != "")
                                        {
                                            TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                                        }
                                        if (ThFMarks != "")
                                        {
                                            TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                                        }
                                        if (CA_MSM_TH == "" && TH_ESM == "")
                                        {
                                            TH_PMO = "";
                                        }
                                        else
                                        {
                                            TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                            //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                                        }

                                        //Claculate PT_PMO ---------------
                                        if (CA_MSM_PT != "")
                                        {
                                            PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                                        }
                                        if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                                        {
                                            PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                                        }
                                        if (PT_PMO != "")
                                        {
                                            PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                                        }
                                        if (PT_PMO != "" && PractFMarks != "")
                                        {
                                            PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                                        }
                                        if (CA_MSM_PT == "" && PT_ESM == "")
                                        {
                                            PT_PMO = "";
                                        }
                                        else
                                        {
                                            //PT_PMO = Math.Round(PT_PMO, 2);
                                            PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                            //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                                        }

                                        if (int.Parse(admyear) >= 2013)
                                        {
                                            if (papertype == "X")
                                            {
                                                if ((TH_PMO != "" && double.Parse(TH_PMO) < 33))
                                                {
                                                    if ((dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == null) && UMC.IndexOf("ES") < 0)
                                                    {
                                                        TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                    }
                                                    else
                                                    {
                                                        //
                                                        TH_ESM = THEndsem;// dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();
                                                    }
                                                    if (PT_PMO != "" && double.Parse(PT_PMO) < 33)
                                                    {
                                                        if (dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == null)
                                                        {
                                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                        }
                                                        else
                                                        {
                                                            //
                                                            PT_ESM = PREndSem;// dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString();
                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (THEndsem != "")
                                                            TH_ESM = THEndsem;
                                                        if (PREndSem != "")
                                                            PT_ESM = PREndSem;
                                                    }

                                                }
                                                else
                                                {
                                                    if (TH_ESM == "")
                                                    {
                                                        TH_ESM = THEndsem; // dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();
                                                        checkTH = true;
                                                    }
                                                    else
                                                    {
                                                        checkTH = false;
                                                    }
                                                    if (PT_ESM == "")
                                                    {
                                                        PT_ESM = PREndSem; //dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString();
                                                        checkPT = true;
                                                    }
                                                    else
                                                    {
                                                        checkPT = false;
                                                    }

                                                    //checkTH = false;
                                                    //checkPT = false;
                                                }


                                            }
                                            else if (papertype == "T")
                                            {
                                                if (TH_PMO != "")
                                                {
                                                    if (double.Parse(TH_PMO) < 33)
                                                    {
                                                        if ((dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == null) && UMC.IndexOf("ES") < 0)
                                                        {
                                                            TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                        }
                                                        else
                                                        {
                                                            //
                                                            TH_ESM = THEndsem;// dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();
                                                        }

                                                    }
                                                    else
                                                    {
                                                        if (TH_ESM == "")
                                                        {
                                                            TH_ESM = THEndsem;// dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();
                                                            checkTH = true;
                                                        }
                                                        else
                                                        {
                                                            checkTH = false;
                                                        }
                                                    }

                                                }
                                                else
                                                {
                                                    TH_ESM = THEndsem;// dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                                                }

                                            }
                                            else if (papertype == "P")
                                            {
                                                if (PT_PMO != "")
                                                {
                                                    if (double.Parse(PT_PMO) < 33)
                                                    {
                                                        if (dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == null)
                                                        {
                                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                        }
                                                        else
                                                        {
                                                            PT_ESM = PREndSem;// dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString();
                                                        }

                                                    }
                                                    else
                                                    {
                                                        if (PT_ESM == "")
                                                        {
                                                            PT_ESM = PREndSem; // dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString();
                                                            checkPT = true;
                                                        }
                                                        else
                                                        {
                                                            checkPT = false;
                                                        }

                                                    }
                                                }
                                                else
                                                {

                                                    PT_ESM = PREndSem; // dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString();

                                                }
                                            }

                                        }
                                        else
                                        {
                                            if (papertype == "X")
                                            {
                                                if (TH_PMO != "" && double.Parse(TH_PMO) < 35)
                                                {
                                                    if ((dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == null) && UMC.IndexOf("ES") < 0)
                                                    {
                                                        TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                    }
                                                    else
                                                    {
                                                        TH_ESM = THEndsem; //dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();
                                                    }                                                   
                                                }
                                                else
                                                {
                                                    if (TH_ESM == "")
                                                    {
                                                        TH_ESM = THEndsem; // dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();
                                                        checkTH = true;
                                                    }
                                                    else
                                                    {
                                                        checkTH = false;
                                                    }
                                                    

                                                }
                                                if (PT_PMO != "" && double.Parse(PT_PMO) < 40)
                                                {
                                                    if (dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == null)
                                                    {
                                                        PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                    }
                                                    else
                                                    {
                                                        PT_ESM = PREndSem; // dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString();
                                                    }
                                                }
                                                else
                                                {
                                                    if (PT_ESM == "")
                                                    {
                                                        PT_ESM = PREndSem; //dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString();
                                                        checkPT = true;
                                                    }
                                                    else
                                                    {
                                                        checkPT = false;
                                                    }
                                                }

                                            }
                                            else if (papertype == "T")
                                            {
                                                if (TH_PMO != "")
                                                {
                                                    if (double.Parse(TH_PMO) < 35)
                                                    {
                                                        if ((dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == null) && UMC.IndexOf("ES") < 0)
                                                        {
                                                            TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                        }
                                                        else
                                                        {
                                                            TH_ESM = THEndsem; // dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();
                                                        }

                                                    }
                                                    else
                                                    {
                                                        if (TH_ESM == "")
                                                        {
                                                            TH_ESM = THEndsem; // dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();
                                                            checkTH = true;
                                                        }
                                                        else
                                                        {
                                                            checkTH = false;
                                                        }
                                                        //TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();
                                                        //checkTH = false;
                                                    }

                                                }
                                                else
                                                {
                                                    TH_ESM = THEndsem; // dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();
                                                }
                                            }
                                            else if (papertype == "P")
                                            {
                                                if (PT_PMO != "")
                                                {
                                                    if (double.Parse(PT_PMO) < 40)
                                                    {

                                                        if (dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == null)
                                                        {
                                                            PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                        }
                                                        else
                                                        {
                                                            PT_ESM = PREndSem; // dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString();
                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (PT_ESM == "")
                                                        {
                                                            PT_ESM = PREndSem; // dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString();
                                                            checkPT = true;
                                                        }
                                                        else
                                                        {
                                                            checkPT = false;
                                                        }
                                                        //PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString();
                                                        //checkPT = false;
                                                    }

                                                }
                                                else
                                                {
                                                    PT_ESM = PREndSem; // dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString();
                                                }
                                            }

                                        }
                                        DataTable dtpreviousumc = fnrev.SelectDatatable("SELECT UMCode FROM EXAMPAPERDETAIL WHERE (CAST(SUBSTRING(ExamSession, 5, 3) + SUBSTRING(ExamSession, 9, 4) AS " +
                                            " DATETIME) < '" + prexamdate + "') AND (StreamPartCode = '" + StreamPart.SelectedValue + "') AND (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') " +
                                            " AND (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by (CAST(SUBSTRING(ExamSession, 5, 3) + SUBSTRING(ExamSession, 9, 4) AS DATETIME)) DESC");
                                        if (dtpreviousumc.Rows.Count > 0)
                                        {
                                            if (dtpreviousumc.Rows[0]["UMCode"].ToString().IndexOf("ES") != -1)
                                            {
                                                checkTH = true;
                                                TH_ESM = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();
                                                //checkPT = true;
                                                //PT_ESM = dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString();
                                            }

                                        }

                                }
                                else
                                {
                                    TH_ESM = THEndsem;
                                    PT_ESM = PREndSem;
                                }
                            }


                            // Code For Improvement Registration Type -- H 

                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "H")
                            {
                                DataSet dspreviousrec = fnrev.SelectDataset("SELECT RegNo,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate,trbtec.SubPaperCode, " +
                                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point  ,Grade, ExamType, ExamSession " +
                                        " FROM TRBTec inner join COURSEPAPERS cour on TRBTec.SubPaperCode=cour.SubPaperCode Where  " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) < '" + prexamdate + "' AND " +
                                        " TRBTec.StreamPart = '" + StreamPart.SelectedValue + "' and RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' and " +
                                        " TRBTec.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' union SELECT RegNo," +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) as Examdate, SubPaperCode, CA_MSM_TH, " +
                                        " TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, Grade, ExamType, ExamSession " +
                                        " FROM TRBTec_old WHERE (StreamPart = '" + StreamPart.SelectedValue + "') AND " +
                                        " (RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
                                        " (SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') order by " +
                                        " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) DESC");
                                if (dspreviousrec.Tables[0].Rows.Count > 0)
                                {
                                    CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                    CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                    TH_ESM = THEndsem;
                                    if (PREndSem != "")
                                        PT_ESM = PREndSem;
                                    else
                                        PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                    checkTH = true;
                                    checkPT = true;
                                }                                
                                                                
                            }
                            
                            


                            // Calculate CA_MSM_TH
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (ClassTest1 != "" && ClassTest1.ToUpper() != "NULL")
                                {
                                    CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(ClassTest1)).ToString();
                                }
                                if (ClassTest2 != "" && ClassTest2.ToUpper() != "NULL")
                                {
                                    CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(ClassTest2)).ToString();
                                }
                                if (Midsem != "" && Midsem.ToUpper() != "NULL")
                                {
                                    CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(Midsem)).ToString();
                                }
                                if (TH_Attendance != "" && TH_Attendance.ToUpper() != "NULL")
                                {
                                    CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(TH_Attendance)).ToString();
                                }
                                // For Check CA_MSM_TH value
                                if (ClassTest1 == "" && ClassTest2 == "" && Midsem == "" && TH_Attendance == "")
                                {
                                    CA_MSM_TH = "";
                                }
                                else
                                {
                                    //CA_MSM_TH = Math.Round(CA_MSM_TH, 2);
                                    //CA_MSM_TH = String.Format("{0:0.00}", CA_MSM_TH);
                                    CA_MSM_TH = (Math.Round(decimal.Parse(CA_MSM_TH), 2)).ToString();
                                }

                                // Calculate THENDSEM

                                TH_ESM = THEndsem;
                                if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                                {
                                    //TH_ESM = Math.Round(TH_ESM, 2);
                                    //TH_ESM = String.Format("{0:0.00}", TH_ESM);
                                    TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();

                                }

                                // Calculate CA_MSM_PT

                                if (PR_Attendance != "" && PR_Attendance.ToUpper() != "NULL")
                                {
                                    CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(PR_Attendance)).ToString();
                                }
                                if (PracticalRecord != "" && PracticalRecord.ToUpper() != "NULL")
                                {
                                    CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(PracticalRecord)).ToString();
                                }
                                if (PRClassPerfor != "" && PRClassPerfor.ToUpper() != "NULL")
                                {
                                    CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(PRClassPerfor)).ToString();
                                }
                                if (Prpreendsemviva != "" && Prpreendsemviva.ToUpper() != "NULL")
                                {
                                    CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(Prpreendsemviva)).ToString();
                                }
                                // For Check CA_MSM_PT value
                                if (PR_Attendance == "" && PracticalRecord == "" && PRClassPerfor == "" && Prpreendsemviva == "")
                                {
                                    CA_MSM_PT = "";
                                }
                                else
                                {
                                    //CA_MSM_PT = Math.Round(CA_MSM_PT, 2);
                                    //CA_MSM_PT = String.Format("{0:0.00}", CA_MSM_PT);
                                    CA_MSM_PT = (Math.Round(decimal.Parse(CA_MSM_PT), 2)).ToString();
                                }

                                // Calculate PT_ESM

                                PT_ESM = PREndSem;
                                if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                                {
                                    //PT_ESM = Math.Round(PT_ESM, 2);
                                    //PT_ESM = String.Format("{0:0.00}", PT_ESM);
                                    PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                                }

                            }


                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++
                            if (checkTH == true)
                            {
                                TH_PMO = "0";
                                if (CA_MSM_TH != "")
                                {
                                    TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                                }
                                if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                                {
                                    TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                                }
                                if (TH_PMO != "")
                                {
                                    TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                                }
                                if (ThFMarks != "")
                                {
                                    TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                                }
                                if (CA_MSM_TH == "" && TH_ESM == "")
                                {
                                    TH_PMO = "";
                                }
                                else
                                {
                                    TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                    //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                                }
                            }

                            // Calculate PT_PMO ===========================
                            if (checkPT == true)
                            {
                                PT_PMO = "0";
                                if (CA_MSM_PT != "")
                                {
                                    PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                                }
                                if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                                {
                                    PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                                }
                                if (PT_PMO != "")
                                {
                                    PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                                }
                                if (PT_PMO != "" && PractFMarks != "")
                                {
                                    PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                                }
                                if (CA_MSM_PT == "" && PT_ESM == "")
                                {
                                    PT_PMO = "";
                                }
                                else
                                {
                                    //PT_PMO = Math.Round(PT_PMO, 2);
                                    PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                    //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                                }

                            }

                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                                
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (int.Parse(admyear) >= 2013)   //processing for new batch stuidents; admyear 2013 & onwards
                            {
                                if (papertype == "X")
                                {
                                    if ((TH_PMO != "" && double.Parse(TH_PMO) < 33) || (PT_PMO != "" && double.Parse(PT_PMO) < 33))
                                    {
                                        GRADE = "F";
                                        GRADE_POINT = "0";
                                        ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                        if (TH_PMO != "" && double.Parse(TH_PMO) < 33)
                                            REMARKS = "Fail in Theory";
                                        else if (PT_PMO != "" && double.Parse(PT_PMO) < 33)
                                            REMARKS = "Fail in Practical";
                                        else
                                            REMARKS = "Fail in both Theory & Practical";
                                    }
                                    else
                                    {
                                        grading();
                                    }


                                }
                                else if (papertype == "T")
                                {
                                    if (TH_PMO != "")
                                    {
                                        if (double.Parse(TH_PMO) < 33)
                                        {

                                            GRADE = "F";
                                            GRADE_POINT = "0";
                                            ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                            REMARKS = "Fail in Theory";

                                        }
                                        else
                                        {
                                            grading();
                                        }
                                    }

                                }
                                else if (papertype == "P")
                                {
                                    if (PT_PMO != "")
                                    {
                                        if (double.Parse(PT_PMO) < 33)
                                        {
                                            GRADE = "F";
                                            GRADE_POINT = "0";
                                            ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                            REMARKS = "Fail in Practical";

                                        }
                                        else
                                        {
                                            grading();
                                        }
                                    }
                                }
                                /* else if (papertype == "E")
                                 {
                                     if (TOTAL_PMO != "")
                                     {
                                         if (double.Parse(TOTAL_PMO) < 33)
                                         {
                                             GRADE = "F";
                                             GRADE_POINT = "0";
                                             ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                             REMARKS = "Fail in Paper";

                                         }
                                         else
                                         {
                                             grading();
                                         }
                                     }
                                 } */

                            }
                            else 
                            {
                                if (papertype == "X")
                                {
                                    if ((TH_PMO != "" && double.Parse(TH_PMO) < 35) || (PT_PMO != "" && double.Parse(PT_PMO) < 40))
                                    {
                                        GRADE = "F";
                                        GRADE_POINT = "0";
                                        ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                        if (TH_PMO != "" && double.Parse(TH_PMO) < 35)
                                            REMARKS = "Fail in Theory";
                                        else if (PT_PMO != "" && double.Parse(PT_PMO) < 40)
                                            REMARKS = "Fail in Practical";
                                        else
                                            REMARKS = "Fail in both Theory & Practical";
                                    }
                                    else
                                    {
                                        grading();
                                    }

                                }
                                else if (papertype == "T")
                                {
                                    if (TH_PMO != "")
                                    {
                                        if (double.Parse(TH_PMO) < 35)
                                        {

                                            GRADE = "F";
                                            GRADE_POINT = "0";
                                            ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                            REMARKS = "Fail in Theory";

                                        }
                                        else
                                        {
                                            grading();
                                        }
                                    }
                                }
                                else if (papertype == "P")
                                {
                                    if (PT_PMO != "")
                                    {
                                        if (double.Parse(PT_PMO) < 40)
                                        {
                                            GRADE = "F";
                                            GRADE_POINT = "0";
                                            ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                            REMARKS = "Fail in Practical";

                                        }
                                        else
                                        {
                                            grading();
                                        }
                                    }
                                }
                                
                            }
                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " + 
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");



                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {
                             
                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";
                                
                            }
                            else if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (astatus == "D" || astatus == "d")
                            {
                                GRADE = "X";
                                GRADE_POINT = "0";
                                ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                REMARKS = "Debarred";
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                GRADE = "X";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";
                                REMARKS = "";
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRBTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString()+ "'");
                            if (InsData == 0)
                            {
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        trcount = dsstudentreginfo.Tables[0].Rows.Count;
                        LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }
                    
                }
            }
        }
    }
  

    protected void GenerateTRMTec_SQSPL()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        dsstudentreginfo = fnrev.SelectDataset("SELECT Registration.admyear, EXAM.RegNo, EXAM.UnivRollNo, EXAM.CollCode, EXAM.StreamCode, EXAM.StreamPartCode, " +
            " EXAM.ExamYear, REGISTRATION.ApplicantName,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, " +
            " REGISTRATION.Gender, EXAM.SubCode,Exam.ExamType FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
            " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
            " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND REGISTRATION.SplCode = '" + Splcode.SelectedValue + "' AND EXAM.ExamSession = '" + Examsession.SelectedItem.ToString() + "' ");
       

        if (Check == true)
        {
            // code for already proccessed.......
            DataSet dsproccessed = fnrev.SelectDataset("Select distinct Regno fROM TRMTec WHERE ExamYear='" + ExamYear.SelectedItem + "' AND " +
                       " StreamPart = '" + StreamPart.SelectedValue + "' AND StreamCode ='" + StreamCode.SelectedValue + "' AND TRMtec.SplCode = '" + Splcode.SelectedValue + "' AND TRMTec.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
            if (dsproccessed.Tables[0].Rows.Count == dsstudentreginfo.Tables[0].Rows.Count)
            {
                LblMsg.Text = "TR already proccessed for the above criteria.";
                return;
            }
        }
        if (dsstudentreginfo.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
            {

                DataSet dsstudentpaperdetails = fnrev.SelectDataset("SELECT EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.DateofExam, " +
                    " EXAMPAPERDETAIL.UMCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                    " (COURSEPAPERS.PaperAbbr not in ('6GE106','6GE103','2AR119','4AR149','GE 106','GE106','GE103','GE105','1GE101')) AND (COURSEPAPERS.PaperAbbr not Like '%GE%') and EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                    " EXAMPAPERDETAIL.StreamPartCode ='" + StreamPart.SelectedValue + "' AND EXAMPAPERDETAIL.ExamYear = '" + ExamYear.SelectedItem + "' AND " +
                    " EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                for (int j = 0; j < dsstudentpaperdetails.Tables[0].Rows.Count; j++)
                {
                    string SaveFlag = "";

                    string[] col = new string[15];
                    string[] val = new string[15];
                    string admyear = dsstudentreginfo.Tables[0].Rows[i]["admyear"].ToString(); //suraj
                    col[0] = "CollCode"; val[0] = dsstudentreginfo.Tables[0].Rows[i]["CollCode"].ToString();
                    col[1] = "StreamCode"; val[1] = dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString();
                    col[2] = "StreamPart"; val[2] = dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString();
                    col[3] = "ExamYear"; val[3] = dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString();
                    col[4] = "ExamHeldDate"; val[4] = dsstudentpaperdetails.Tables[0].Rows[j]["DateOfExam"].ToString();
                    col[5] = "UnivRollNo"; val[5] = dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString();
                    col[6] = "EName"; val[6] = dsstudentreginfo.Tables[0].Rows[i]["ApplicantName"].ToString();
                    col[7] = "HName"; val[7] = dsstudentreginfo.Tables[0].Rows[i]["HindiName"].ToString();
                    col[8] = "FatherName"; val[8] = dsstudentreginfo.Tables[0].Rows[i]["FatherName"].ToString();
                    col[9] = "MotherName"; val[9] = dsstudentreginfo.Tables[0].Rows[i]["MotherName"].ToString();
                    col[10] = "Gender"; val[10] = dsstudentreginfo.Tables[0].Rows[i]["Gender"].ToString();
                    col[11] = "RegNo"; val[11] = dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString();
                    col[12] = "SubPaperCode"; val[12] = dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString();
                    col[13] = "ExamType"; val[13] = dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString();
                    col[14] = "ExamSession"; val[14] = Examsession.SelectedItem.ToString();

                    SaveFlag = NicService.SaveData("TRMTec", col, val);
                    if (SaveFlag == "1")
                    {
                        PT_PMO = "0"; TOTAL_PMO = "0"; CA_MSM_PT = "0"; TH_PMO = "0"; CA_MSM_TH = "0";
                        checkPT = true;
                        checkTH = true;
                      
                        DataSet dspapermarks = fnrev.SelectDataset("SELECT Exampaperdetail.papertype,EXAMPAPERDETAIL.StudentStatus,EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " +
     "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem,EXAMPAPERDETAIL.PR_Attendance, " +
     "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndSem, " +
     "EXAMPAPERDETAIL.Prpreendsemviva,EXAMPAPERDETAIL.Prpreendsemviva,ExamPaperdetail.UMCode FROM EXAMPAPERDETAIL " +
     " WHERE (EXAMPAPERDETAIL.RegNo='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "') AND " +
     " (EXAMPAPERDETAIL.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "') AND " +
          " (EXAMPAPERDETAIL.StreamPartCode = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "') " +
     " AND (EXAMPAPERDETAIL.ExamYear = '" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "') " +
     " AND EXAMPAPERDETAIL.ExamSession = '" + Examsession.SelectedItem.ToString() + "'");

                        if (dspapermarks.Tables[0].Rows.Count > 0)
                        {
                           
                            papertype = dspapermarks.Tables[0].Rows[0]["papertype"].ToString();
                            StudStatus = dspapermarks.Tables[0].Rows[0]["StudentStatus"].ToString();
                            ClassTest1 = dspapermarks.Tables[0].Rows[0]["ClassTest1"].ToString();
                            ClassTest2 = dspapermarks.Tables[0].Rows[0]["ClassTest2"].ToString();
                            TH_Attendance = dspapermarks.Tables[0].Rows[0]["TH_Attendance"].ToString();
                            UMC = dspapermarks.Tables[0].Rows[0]["UMCode"].ToString();
                            if (UMC != "" && UMC.IndexOf("ES") != -1)
                            {
                                THEndsem = "";

                            }
                            else
                            {
                                THEndsem = dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString();

                            }
                            if (UMC != "" && UMC.IndexOf("MS") != -1)
                            {
                                Midsem = "";
                            }
                            else
                            {
                                Midsem = dspapermarks.Tables[0].Rows[0]["Midsem"].ToString();
                            }
                                                      
                            PR_Attendance = dspapermarks.Tables[0].Rows[0]["PR_Attendance"].ToString();
                            // Viva = dspapermarks.Tables[0].Rows[0]["Viva"].ToString();
                            PracticalRecord = dspapermarks.Tables[0].Rows[0]["PracticalRecord"].ToString();
                            PRClassPerfor = dspapermarks.Tables[0].Rows[0]["PRClassPerfor"].ToString();
                            PREndSem = dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString();
                            Prpreendsemviva = dspapermarks.Tables[0].Rows[0]["Prpreendsemviva"].ToString();


                            // Retrieve Full Marks 
                            if (papertype == "X")
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, PRACTICALPAPERS.FullMarks AS PractFMarks, " +
                                  "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                  " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                //if (dsthfullmark.Tables[0].Rows.Count > 0)
                                //{
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["PractFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();
                                //}
                            }
                            else
                            {
                                DataSet dsthfullmark = fnrev.SelectDataset("SELECT COURSEPAPERS.FullMarks AS ThFMarks, " +
                               "COURSEPAPERS.Credit FROM COURSEPAPERS " +
                                 " WHERE COURSEPAPERS.SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                //if (dsthfullmark.Tables[0].Rows.Count > 0)
                                //{
                                ThFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                PractFMarks = dsthfullmark.Tables[0].Rows[0]["ThFMarks"].ToString();
                                Credit = dsthfullmark.Tables[0].Rows[0]["Credit"].ToString();
                                //}

                            }


                            // Add For Spl Exam
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "N")
                            {

                                DataSet dspreviousrec = fnrev.SelectDataset("with cte as (select UnivRollNo,der.StreamPart," +
                                    " CONVERT(int, LEFT(SUBSTRING(b.StreamPart, PATINDEX('%[0-9]%', b.StreamPart), 8000),PATINDEX('%[^0-9]%', " +
                                    " SUBSTRING(b.StreamPart, PATINDEX('%[0-9]%', b.StreamPart), 8000) + 'X') - 1)) AS semno,der.SubPaperCode," +
                                    " b.Credit,ER_CREDIT,Grade_Point,ROW_NUMBER() over (partition by RegNo,der.subpapercode order by " +
                                    " CAST(SUBSTRING(ExamSession,5,3)+ ExamYear AS DATETIME) desc) as lastrec,der.Grade,der.Total_PMO,der.EName," +
                                    " RegNo,der.CA_MSM_TH,der.TH_ESM,der.CA_MSM_PT,der.PT_ESM,ExamSession from (SELECT CollCode, TRMTec.StreamCode, " +
                                    " TRMTec.StreamPart,SplCode, ExamYear, ExamHeldDate, UnivRollNo,EName, HName, FatherName, MotherName, Gender, RegNo, " +
                                    " TRMTec.SubPaperCode, CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point ," + 
                                    " case when UPPER(Grade)='I' OR UPPER(Grade)='X' OR UPPER(Grade)='F' OR Grade='' then 0 else Credit end as   ER_CREDIT, " + 
                                    " Pass, Promoted, Failed, Grade, Remarks, ExamType, GrandTotal, TotalPercentage, ExamSession,audit  FROM TRMTec inner join " + 
                                    " NIT_patna.dbo.COURSEPAPERS cour on TRMTec.SubPaperCode=cour.SubPaperCode Where  ExamSession <> '" + Examsession.SelectedItem.ToString() + "' AND " +
                                    " TRMTec.StreamPart = '" + StreamPart.SelectedValue + "' union select * from NIT_patna.dbo.TRMTec_old Where  TRMTec_old.StreamPart = '" + StreamPart.SelectedValue + "' ) der inner join " + 
                                    " NIT_patna.dbo.COURSEPAPERS b on der.SubPaperCode=b.SubPaperCode) select TOP(1) CA_MSM_TH,TH_ESM,CA_MSM_PT,PT_ESM from cte where " + 
                                    "  RegNo = '" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND STREAMPART = '" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4) " +
                                " AS DATETIME) < '"+ prexamdate +"' order by CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4) AS" +
                                " DATETIME) desc");
                                if (dspreviousrec.Tables[0].Rows.Count > 0)
                                {
                                    CA_MSM_TH = dspreviousrec.Tables[0].Rows[0]["CA_MSM_TH"].ToString();
                                    CA_MSM_PT = dspreviousrec.Tables[0].Rows[0]["CA_MSM_PT"].ToString();
                                   
                                    //check For pass in Previous marks
                                    // Calculte TH_PMO -----------

                                    if (UMC != "" && UMC.IndexOf("ES") != -1)
                                    {
                                        TH_ESM = "";

                                    }
                                    else
                                    {

                                        TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                    }
                                    PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();

                                    if (CA_MSM_TH != "")
                                    {
                                        TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                                    }
                                    if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                                    {
                                        TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                                    }
                                    if (TH_PMO != "")
                                    {
                                        TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                                    }
                                    if (ThFMarks != "")
                                    {
                                        TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                                    }
                                    if (CA_MSM_TH == "" && TH_ESM == "")
                                    {
                                        TH_PMO = "";
                                    }
                                    else
                                    {
                                        TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                        //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                                    }

                                    //Claculate PT_PMO ---------------
                                    if (CA_MSM_PT != "")
                                    {
                                        PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                                    }
                                    if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                                    {
                                        PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                                    }
                                    if (PT_PMO != "")
                                    {
                                        PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                                    }
                                    if (PT_PMO != "" && PractFMarks != "")
                                    {
                                        PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                                    }
                                    if (CA_MSM_PT == "" && PT_ESM == "")
                                    {
                                        PT_PMO = "";
                                    }
                                    else
                                    {
                                        //PT_PMO = Math.Round(PT_PMO, 2);
                                        PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                        //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                                    }

                                    if (int.Parse(admyear) >= 2013)   //suraj: processing for new batch stuidents; admyear 2013 & onwards
                                    {
                                        if (papertype == "X")
                                        {
                                            if (TH_PMO != "" && double.Parse(TH_PMO) < 33) 
                                            {
                                                if ((dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == null) && UMC.IndexOf("ES") < 0)
                                                {
                                                    TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                }
                                                else
                                                {
                                                    TH_ESM = THEndsem; // dspapermarks.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                }
                                                if (PT_PMO != "" && double.Parse(PT_PMO) < 33)
                                                {
                                                    if (dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == null)
                                                    {
                                                        PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                    }
                                                    else
                                                    {
                                                        PT_ESM = PREndSem;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                if (TH_ESM == "")
                                                {
                                                    TH_ESM = THEndsem; // dspapermarks.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                    checkTH = true;
                                                }
                                                else
                                                {
                                                    checkTH = false;
                                                }
                                                if (PT_ESM == "")
                                                {
                                                    PT_ESM = PREndSem; //dspapermarks.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                    checkPT = true;
                                                }
                                                else
                                                {
                                                    checkPT = false;
                                                }
                                                //checkTH = false;
                                                //checkPT = false;
                                            }


                                        }
                                        else if (papertype == "T")
                                        {
                                            if (TH_PMO != "")
                                            {
                                                if (double.Parse(TH_PMO) < 33)
                                                {
                                                    if ((dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == null) && UMC.IndexOf("ES") < 0)
                                                    {
                                                        TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                    }
                                                    else
                                                    {
                                                        TH_ESM = THEndsem; // dspapermarks.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                    }

                                                }
                                                else
                                                {
                                                    if (TH_ESM == "")
                                                    {
                                                        TH_ESM = THEndsem;
                                                        checkTH = true;
                                                    }
                                                    else
                                                    {
                                                        checkTH = false;
                                                    }
                                                }

                                            }
                                            else
                                            {
                                                TH_ESM = THEndsem; // dspapermarks.Tables[0].Rows[0]["TH_ESM"].ToString();

                                            }

                                        }
                                        else if (papertype == "P")
                                        {
                                            if (PT_PMO != "")
                                            {
                                                if (double.Parse(PT_PMO) < 33)
                                                {
                                                    if (dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == null)
                                                    {
                                                        PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                    }
                                                    else
                                                    {
                                                        PT_ESM = PREndSem; //dspapermarks.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                    }

                                                }
                                                else
                                                {
                                                    if (PT_ESM == "")
                                                    {
                                                        PT_ESM = PREndSem; // dspapermarks.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                        checkPT = true;
                                                    }
                                                    else
                                                    {
                                                        checkPT = false;
                                                    }

                                                }
                                            }
                                            else
                                            {

                                                PT_ESM = PREndSem; //dspapermarks.Tables[0].Rows[0]["PT_ESM"].ToString();

                                            }
                                        }

                                    }
                                    else
                                    {
                                        if (papertype == "X")
                                        {
                                            if (TH_PMO != "" && double.Parse(TH_PMO) < 35) 
                                            {
                                                if ((dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == null) && UMC.IndexOf("ES") < 0)
                                                {
                                                    TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                }
                                                else
                                                {
                                                    TH_ESM = THEndsem; // dspapermarks.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                }
                                                if (PT_PMO != "" && double.Parse(PT_PMO) < 40)
                                                {
                                                    if (dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == null)
                                                    {
                                                        PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                    }
                                                    else
                                                    {
                                                        PT_ESM = PREndSem; // dspapermarks.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                if (TH_ESM == "")
                                                {
                                                    TH_ESM = THEndsem; // dspapermarks.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                    checkTH = true;
                                                }
                                                else
                                                {
                                                    checkTH = false;
                                                }
                                                if (PT_ESM == "")
                                                {
                                                    PT_ESM = PREndSem; //dspapermarks.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                    checkPT = true;
                                                }
                                                else
                                                {
                                                    checkPT = false;
                                                }
                                            
                                            }

                                        }
                                        else if (papertype == "T")
                                        {
                                            if (TH_PMO != "")
                                            {
                                                if (double.Parse(TH_PMO) < 35)
                                                {
                                                    if ((dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["THEndsem"].ToString() == null) && UMC.IndexOf("ES") < 0)
                                                    {
                                                        TH_ESM = dspreviousrec.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                    }
                                                    else
                                                    {
                                                        TH_ESM = THEndsem; // dspapermarks.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                    }

                                                }
                                                else
                                                {
                                                    if (TH_ESM == "")
                                                    {
                                                        TH_ESM = THEndsem;  //dspapermarks.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                        checkTH = true;
                                                    }
                                                    else
                                                    {
                                                        checkTH = false;
                                                    }
                                                    //TH_ESM = dspapermarks.Tables[0].Rows[0]["TH_ESM"].ToString();
                                                    //checkTH = false;
                                                }

                                            }
                                            else
                                            {
                                                TH_ESM = THEndsem; //dspapermarks.Tables[0].Rows[0]["TH_ESM"].ToString();
                                            }
                                        }
                                        else if (papertype == "P")
                                        {
                                            if (PT_PMO != "")
                                            {
                                                if (double.Parse(PT_PMO) < 40)
                                                {

                                                    if (dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == "" || dspapermarks.Tables[0].Rows[0]["PREndSem"].ToString() == null)
                                                    {
                                                        PT_ESM = dspreviousrec.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                    }
                                                    else
                                                    {
                                                        PT_ESM = PREndSem; //dspapermarks.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                    }
                                                }
                                                else
                                                {
                                                    if (PT_ESM == "")
                                                    {
                                                        PT_ESM = PREndSem; //dspapermarks.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                        checkPT = true;
                                                    }
                                                    else
                                                    {
                                                        checkPT = false;
                                                    }
                                                    //PT_ESM = dspapermarks.Tables[0].Rows[0]["PT_ESM"].ToString();
                                                    //checkPT = false;
                                                }

                                            }
                                            else
                                            {
                                                PT_ESM = PREndSem; //dspapermarks.Tables[0].Rows[0]["PT_ESM"].ToString();
                                            }
                                        }

                                    }

                                }
                                else
                                {
                                    TH_ESM = THEndsem;
                                    PT_ESM = PREndSem;
                                }
                            }


                            // Calculate CA_MSM_TH
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["ExamType"].ToString() == "B")
                            {
                                if (ClassTest1 != "" && ClassTest1.ToUpper() != "NULL")
                                {
                                    CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(ClassTest1)).ToString();
                                }
                                if (ClassTest2 != "" && ClassTest2.ToUpper() != "NULL")
                                {
                                    CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(ClassTest2)).ToString();
                                }
                                if (Midsem != "" && Midsem.ToUpper() != "NULL")
                                {
                                    CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(Midsem)).ToString();
                                }
                                if (TH_Attendance != "" && TH_Attendance.ToUpper() != "NULL")
                                {
                                    CA_MSM_TH = (float.Parse(CA_MSM_TH) + float.Parse(TH_Attendance)).ToString();
                                }
                                // For Check CA_MSM_TH value
                                if (ClassTest1 == "" && ClassTest2 == "" && Midsem == "" && TH_Attendance == "")
                                {
                                    CA_MSM_TH = "";
                                }
                                else
                                {
                                    //CA_MSM_TH = Math.Round(CA_MSM_TH, 2);
                                    //CA_MSM_TH = String.Format("{0:0.00}", CA_MSM_TH);
                                    CA_MSM_TH = (Math.Round(decimal.Parse(CA_MSM_TH), 2)).ToString();
                                }

                                // Calculate TH_ESM

                                TH_ESM = THEndsem;
                                if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                                {
                                    //TH_ESM = Math.Round(TH_ESM, 2);
                                    //TH_ESM = String.Format("{0:0.00}", TH_ESM);
                                    TH_ESM = (Math.Round(decimal.Parse(TH_ESM), 2)).ToString();

                                }

                                // Calculate CA_MSM_PT

                                if (PR_Attendance != "" && PR_Attendance.ToUpper() != "NULL")
                                {
                                    CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(PR_Attendance)).ToString();
                                }
                                if (PracticalRecord != "" && PracticalRecord.ToUpper() != "NULL")
                                {
                                    CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(PracticalRecord)).ToString();
                                }
                                if (PRClassPerfor != "" && PRClassPerfor.ToUpper() != "NULL")
                                {
                                    CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(PRClassPerfor)).ToString();
                                }
                                if (Prpreendsemviva != "" && Prpreendsemviva.ToUpper() != "NULL")
                                {
                                    CA_MSM_PT = (float.Parse(CA_MSM_PT) + float.Parse(Prpreendsemviva)).ToString();
                                }
                                // For Check CA_MSM_PT value
                                if (PR_Attendance == "" && PracticalRecord == "" && PRClassPerfor == "" && Prpreendsemviva == "")
                                {
                                    CA_MSM_PT = "";
                                }
                                else
                                {
                                    //CA_MSM_PT = Math.Round(CA_MSM_PT, 2);
                                    //CA_MSM_PT = String.Format("{0:0.00}", CA_MSM_PT);
                                    CA_MSM_PT = (Math.Round(decimal.Parse(CA_MSM_PT), 2)).ToString();
                                }

                                // Calculate PT_ESM

                                PT_ESM = PREndSem;
                                if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                                {
                                    //PT_ESM = Math.Round(PT_ESM, 2);
                                    //PT_ESM = String.Format("{0:0.00}", PT_ESM);
                                    PT_ESM = (Math.Round(decimal.Parse(PT_ESM), 2)).ToString();
                                }

                            }
                            // Calculate TH_PMO +++++++++++++++++++++++++++++++++
                            if (checkTH == true)
                            {
                                TH_PMO = "0";
                                if (CA_MSM_TH != "")
                                {
                                    TH_PMO = (float.Parse(TH_PMO) + float.Parse(CA_MSM_TH)).ToString();
                                }
                                if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                                {
                                    TH_PMO = (float.Parse(TH_PMO) + float.Parse(TH_ESM)).ToString();
                                }
                                if (TH_PMO != "")
                                {
                                    TH_PMO = (float.Parse(TH_PMO) * 100).ToString();
                                }
                                if (ThFMarks != "")
                                {
                                    TH_PMO = (float.Parse(TH_PMO) / int.Parse(ThFMarks)).ToString();

                                }
                                if (CA_MSM_TH == "" && TH_ESM == "")
                                {
                                    TH_PMO = "";
                                }
                                else
                                {
                                    TH_PMO = (Math.Round(decimal.Parse(TH_PMO), 2)).ToString();
                                    //TH_PMO = String.Format("{0:0.00}", TH_PMO);
                                }
                            }

                            // Calculate PT_PMO ===========================
                            if (checkPT == true)
                            {
                                PT_PMO = "0";
                                if (CA_MSM_PT != "")
                                {
                                    PT_PMO = (float.Parse(PT_PMO) + float.Parse(CA_MSM_PT)).ToString();
                                }
                                if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                                {
                                    PT_PMO = (float.Parse(PT_PMO) + float.Parse(PT_ESM)).ToString();
                                }
                                if (PT_PMO != "")
                                {
                                    PT_PMO = (float.Parse(PT_PMO) * 100).ToString();
                                }
                                if (PT_PMO != "" && PractFMarks != "")
                                {
                                    PT_PMO = (float.Parse(PT_PMO) / int.Parse(PractFMarks)).ToString();

                                }
                                if (CA_MSM_PT == "" && PT_ESM == "")
                                {
                                    PT_PMO = "";
                                }
                                else
                                {
                                    //PT_PMO = Math.Round(PT_PMO, 2);
                                    PT_PMO = (Math.Round(decimal.Parse(PT_PMO), 2)).ToString();
                                    //PT_PMO = String.Format("{0:0.00}", PT_PMO);
                                }

                            }

                            //calculation of Total_PMO

                            if (CA_MSM_TH != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_TH)).ToString();
                            }
                            if (TH_ESM != "" && TH_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(TH_ESM)).ToString();
                            }
                            if (CA_MSM_PT != "")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(CA_MSM_PT)).ToString();
                            }
                            if (PT_ESM != "" && PT_ESM.ToUpper() != "NULL")
                            {
                                TOTAL_PMO = (float.Parse(TOTAL_PMO) + float.Parse(PT_ESM)).ToString();
                            }

                            if (papertype == "X")
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);


                                if (TOTAL_PMO != "")
                                {
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }

                            }
                            else
                            {
                                if (ThFMarks != "" && ThFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(ThFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();
                                    //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                }
                                else if (PractFMarks != "" && PractFMarks.ToUpper() != "NULL")
                                {
                                    TPMOdivpart = (TPMOdivpart) + int.Parse(PractFMarks);
                                    TOTAL_PMO = ((float.Parse(TOTAL_PMO) / TPMOdivpart) * 100).ToString();


                                }


                            }

                            if (CA_MSM_TH == "" && TH_ESM == "" && CA_MSM_PT == "" && PT_ESM == "")
                            {
                                TOTAL_PMO = "";
                            }
                            else
                            {
                                //TOTAL_PMO = Math.Round(TOTAL_PMO, 2);
                                //TOTAL_PMO = String.Format("{0:0.00}", TOTAL_PMO);
                                TOTAL_PMO = (Math.Round(decimal.Parse(TOTAL_PMO), 2)).ToString();
                            }

                            if (yrvalue >= 2014)
                            {
                                gradecriteria();
                            }
                            else
                            {
                                gradecriteria_old();
                            }
                            UnivService.Service1 NicService1 = new UnivService.Service1();
                            string astatus = NicService1.GetNewCode("Select Status From Attendance Where " +
                                " UnivRollNo = '" + dsstudentreginfo.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' And " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND " +
                                " SubPaperCode = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");



                            DataRow[] drpaper = dtpaperc.Select("paperc = '" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                            if (drpaper.Length == 0)
                            {
                                if (papertype == "T" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Theory";
                                }
                                else if (papertype == "P" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent In Practical";
                                }
                                else if (papertype == "X" && TH_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                                else if (papertype == "X" && PT_ESM == "")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                    REMARKS = "Absent";
                                }
                            }
                            else
                            {
                                gardespecial();
                            }
                            if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("ES") >= 0)
                            {                                
                                GRADE = "I";
                                GRADE_POINT = "0";
                                ER_CREDIT = "0";
                            }
                            else if (dsstudentpaperdetails.Tables[0].Rows[j]["UMCode"].ToString().IndexOf("MS") >= 0)
                            {
                                if (GRADE == "F" || GRADE == "F*")
                                {
                                    GRADE = "I";
                                    GRADE_POINT = "0";
                                    ER_CREDIT = "0";
                                }
                            }
                            if (astatus == "D" || astatus == "d")
                            {
                                GRADE = "X";
                                GRADE_POINT = "0";
                                ER_CREDIT = (int.Parse(GRADE_POINT) * int.Parse(Credit)).ToString();
                                REMARKS = "Debarred";
                            }
                            if (CA_MSM_TH == "" && TH_ESM == "" && TH_PMO == "" && CA_MSM_PT == "" && PT_ESM == "" && PT_PMO == "" && TOTAL_PMO == "")
                            {
                                GRADE = "";
                                GRADE_POINT = "";
                                ER_CREDIT = "";
                                REMARKS = "";
                            }

                            int InsData = fnrev.InsertUpdateDelete("update TRMTec Set CA_MSM_PT='" + CA_MSM_PT + "',CA_MSM_TH='" + CA_MSM_TH + "'," +
                                " TH_ESM ='" + TH_ESM + "',Th_PMO='" + TH_PMO + "',Total_PMO='" + TOTAL_PMO + "',PT_PMO ='" + PT_PMO + "',PT_ESM='" + PT_ESM + "'," +
                                " Grade_Point='" + GRADE_POINT + "',ER_CREDIT='" + ER_CREDIT + "',Grade='" + GRADE + "',SplCode = '" + Splcode.SelectedItem.ToString() + "'," +
                                " Remarks='" + REMARKS + "',audit='0',Is_active='" + trstatus.SelectedValue.ToString() + "' Where RegNo ='" + dsstudentreginfo.Tables[0].Rows[i]["RegNo"].ToString() + "' AND " +
                                " StreamCode='" + dsstudentreginfo.Tables[0].Rows[i]["StreamCode"].ToString() + "' AND " +
                                " StreamPart='" + dsstudentreginfo.Tables[0].Rows[i]["StreamPartCode"].ToString() + "' AND " +
                                " ExamYear='" + dsstudentreginfo.Tables[0].Rows[i]["ExamYear"].ToString() + "' AND " +
                                " SubPaperCode ='" + dsstudentpaperdetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "' AND " +
                                " ExamSession = '" + Examsession.SelectedItem.ToString() + "'");
                            if (InsData == 0)
                            {
                                LblMsg.Text = "TR Generation process is terminated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else if (InsData == -1000)
                            {
                                LblMsg.Text = "TR Process for above Criteria is already generated!!!";
                                LblMsg.Visible = true;
                                LblMsg.Focus();
                            }
                            else
                            {
                                trcount = dsstudentreginfo.Tables[0].Rows.Count;
                                LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                                LblMsg.Visible = true;
                                TPMOdivpart = 0;
                                LblMsg.Focus();
                            }
                        }
                        //}

                    }
                    else
                    {
                        trcount = dsstudentreginfo.Tables[0].Rows.Count;
                        LblMsg.Text = "<b> TR Generation process is completed for " + trcount + " students. </b>";
                        LblMsg.Visible = true;
                        LblMsg.Focus();

                    }

                }
            }
        }
    }
    
}




