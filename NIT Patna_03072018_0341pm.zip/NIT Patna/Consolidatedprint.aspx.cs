using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using System.IO;

public partial class Consolidatedprint : System.Web.UI.Page
{
    ReportDocument rpt = new ReportDocument();
    Functionreviseed fn = new Functionreviseed();
    ReportDocument crystalReport = new ReportDocument();
    string streamcode, streampartcode, examyear, str, univrollno, crt, sem, stmtp,blk;
    protected void Page_Load(object sender, EventArgs e)
    {
        crt = Request.QueryString["crt"];
        streamcode = Request.QueryString["sc"];
        streampartcode = Request.QueryString["spc"];
        examyear = Request.QueryString["ey"];
        univrollno = Request.QueryString["urolno"];
        sem = Request.QueryString["sem"];
        stmtp = Request.QueryString["stmtp"];
        blk = Request.QueryString["blk"];
        btechgrade();
    }
    protected void Page_Unload(object sender, EventArgs e)
    {
        if (rpt != null)
        {
            rpt.Close();
            rpt.Dispose();
        }
    }
    protected void btechgrade()
    {
  
        rpt.Load(Server.MapPath("~/Report/Consoidatedmarks.rpt"));
        if (blk == "0")
            rpt.SetParameterValue(0,null );
        else
            rpt.SetParameterValue(0,streampartcode);
        //if (univrollno!="")
        
        //else
        //rpt.SetParameterValue(0, streampartcode);
        rpt.SetParameterValue(1, examyear);
        rpt.SetParameterValue(2, "R");
        rpt.SetParameterValue(3, univrollno);
        rpt.SetParameterValue(4, blk);

        System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
        doctoprint.PrinterSettings.PrinterName = "Microsoft XPS Document Writer";
        int i = 0;
        string filename = univrollno != "" ? univrollno : examyear;
        for (i = 0; i < doctoprint.PrinterSettings.PaperSizes.Count; i++)
        {
            int rawKind = 0;
            if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "consol")
            {
                rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                rpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
                break;
            }
        }
        MemoryStream oStream = new MemoryStream();
        oStream = (MemoryStream)rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
        Response.Clear();
        Response.Buffer = true;
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "inline;filename=" + filename + ".pdf");
        Response.BinaryWrite(oStream.ToArray());
        Response.End();
        //CrystalReportViewer1.ReportSource = rpt;



    }


}




    //protected void Page_LoadComplete(object sender, EventArgs e)
    //{
    //    CrystalReportViewer1.ReportSource = Session["btechgrage"];
    //}

