using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using System.IO;

public partial class ExamFormPrintOut : System.Web.UI.Page
{
    ReportDocument crystalreport = new ReportDocument();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (PreviousPage != null)
        {
            ContentPlaceHolder ct = (ContentPlaceHolder)PreviousPage.Master.FindControl("ContentPlaceHolder2");
            crystalreport.Load(Server.MapPath("~/Report/ExamFormPrint.rpt"));
            crystalreport.SetParameterValue(0, ((TextBox)ct.FindControl("TextBox1")).Text);
            crystalreport.SetParameterValue(1, ((DropDownList)ct.FindControl("ExamSession")).SelectedValue);
            Response.Write("<SCRIPT language=javascript>var  pdf=window.open('default.aspx','pdf','width=600,height=400');pdf.moveTo(0,0);</SCRIPT>");
            MemoryStream oStream = new MemoryStream();
            oStream = (MemoryStream)crystalreport.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
            Response.Clear();
            Response.Buffer = true;
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "inline;filename=" + ((TextBox)ct.FindControl("TextBox1")).Text + ".pdf");
            Response.BinaryWrite(oStream.ToArray());
            Response.End();
        }
    }
   
   // protected void btnSubmit_Click(object sender, EventArgs e)
   //{
   //    //string Url = "TRBTecSummary.aspx?sc=" + StreamCode.SelectedValue + "&spc=" + streampart + "&ey=" + ExamYear.SelectedItem + "&prg=" + StreamCode.SelectedItem + "&sem=" + StreamPart.SelectedItem + "&exses=" + examsession;



   //    //ScriptManager.RegisterStartupScript(this, typeof(string), "Open", "window.open('" + Url + "');", true);

   //    crystalreport.Load(Server.MapPath("~/Report/AdmitCard.rpt"));
   //    crystalreport.RecordSelectionFormula = "{AdmitGra.UnivRollNo}='" + txt_rollno.Text + "' and {AdmitGraPaper.ExamSession}='JAN-JUNE_2014' ";
   //    Response.Write("<SCRIPT language=javascript>var  pdf=window.open('default.aspx','pdf','width=600,height=400');pdf.moveTo(0,0);</SCRIPT>");
   //    MemoryStream oStream = new MemoryStream();
   //    oStream = (MemoryStream)crystalreport.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
   //    Response.Clear();
   //    Response.Buffer = true;
   //    Response.ContentType = "application/pdf";
   //    Response.AddHeader("content-disposition", "inline;");
   //    Response.BinaryWrite(oStream.ToArray());
   //    Response.End();
   //}
    protected void Page_Unload(object sender, EventArgs e)
    {
        if (crystalreport != null)
        {
            crystalreport.Close();
            crystalreport.Dispose();
        }
      
    }
    
}
