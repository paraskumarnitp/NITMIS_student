using System;
using System.Data;
using System.Data.OleDb;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class ProcessFinalTR : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();

            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College where collcode in (select distinct collcode from exam) order by CollName", "CollName", "CollCode");
            popddl.Popualate(ExamYear, "Exam", "Select distinct ExamYear from Exam order by ExamYear", "ExamYear", "ExamYear");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from exam) order by StreamAbbr", "StreamAbbr", "StreamCode");
    

        }
    }


    protected void BtnProcess_Click(object sender, EventArgs e)
    {
        SqlCommand SqlCmd = new SqlCommand();
        SqlConnection SqlCon = new SqlConnection();
        SqlCon.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlCon.Open();
        SqlCmd.Connection = SqlCon;
        SqlCmd.CommandType = CommandType.StoredProcedure;
        SqlCmd.CommandText = "ProcessFinalTR";
        SqlCmd.Parameters.Add(new SqlParameter("@CollCode", SqlDbType.Char, 3, "CollCode"));
        SqlCmd.Parameters.Add(new SqlParameter("@ExamYear", SqlDbType.Char, 4, "ExamYear"));
        SqlCmd.Parameters.Add(new SqlParameter("@StreamCode", SqlDbType.Char, 2, "StreamCode"));
        SqlCmd.Parameters[0].Value = CollCode.SelectedValue;
        SqlCmd.Parameters[1].Value = ExamYear.SelectedValue;
        SqlCmd.Parameters[2].Value = StreamCode.SelectedValue;
        int i = SqlCmd.ExecuteNonQuery();
        if (i > 0)
        {
            string msg = " Final TR is processed successfully";
            string popupScript = "<script language='javascript'>" +
                               " alert('Final TR is processed successfully ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);

        }
        else
        {
           string popupScript = "<script language='javascript'>" +
                               " alert('Error ocuured in processing...... ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
        }
        SqlCon.Close();
        SqlCon.Dispose();
        SqlCmd.Dispose();
    }
        
           
            
}
