using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.Collections.Generic;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

public partial class marksstatus : System.Web.UI.Page
{
    Functionreviseed fn = new Functionreviseed();
    PopulateDDL popddl = new PopulateDDL();
    DataSet dsmarksdata;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            
            try
            {

                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }

                ViewState.Add("EditMode", "false");

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }
            DataSet dsexamsession = fn.SelectDataset("Select Distinct Examsession,CAST(SUBSTRING(ExamSession,5,3)+ ExamYear AS DATETIME) as examdate From EXAMPAPERDETAIL order by CAST(SUBSTRING(ExamSession,5,3)+ ExamYear AS DATETIME) desc");
            ddlexamsession.DataSource = dsexamsession.Tables[0];
            ddlexamsession.DataTextField = "Examsession";
            ddlexamsession.DataValueField = "Examsession";
            ddlexamsession.DataBind();
            ddlexamsession.Items.Insert(0,new ListItem("--Select--","0"));
           
           
           //popddl.Popualate(ExamYear, "Year", "select distinct ExamSession from EXAMPAPERDETAIL order by ExamSession desc", "ExamSession", "ExamSession");

           
        }           

    }

    protected void btnsumit_Click(object sender, EventArgs e)
    {
        BindGridview();
    }
   
    protected void BindGridview()
    {
        DataSet dsparentmarks = new DataSet();
        dsparentmarks = fn.SelectDataset("SELECT EXAMPAPERDETAIL.UnivRollNo, COURSEPAPERS.PaperAbbr, " + 
            " CONVERT(float, ISNULL(COURSEPAPERS.FullMarks, 0)) + CONVERT(float,ISNULL(PRACTICALPAPERS.FullMarks, 0)) AS FULLMARKS, " + 
            " EXAMPAPERDETAIL.PaperType, EXAMPAPERDETAIL.StudentStatus, EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " + 
            " EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem, EXAMPAPERDETAIL.PR_Attendance, " + 
            " EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor, EXAMPAPERDETAIL.PREndSem,EXAMPAPERDETAIL.Prpreendsemviva," + 
            " EXAMPAPERDETAIL.ExamYear, EXAMPAPERDETAIL.ExamType FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON " + 
            " EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN STREAMPART ON " + 
            " EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode LEFT OUTER JOIN PRACTICALPAPERS ON " + 
            " COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE EXAMPAPERDETAIL.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "' " +
            " AND STREAMPART.StreamCode = '" + ddlprogram.SelectedValue + "' AND (EXAMPAPERDETAIL.StreamPartCode = '" + Streampart.SelectedValue + "')");
        gvParentGrid.DataSource = dsparentmarks.Tables[0];
        gvParentGrid.DataBind();

    }
    
    protected void ddlexamsession_SelectedIndexChanged(object sender, EventArgs e)
    {
        bindprogram();
    }

    private void bindsemester()
    {
        DataSet dssemester = fn.SelectDataset("SELECT DISTINCT STREAMPART.StreamPart, STREAMPART.StreamPartCode FROM EXAMPAPERDETAIL INNER JOIN " + 
                " STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode WHERE EXAMPAPERDETAIL.ExamSession = " + 
                " '" + ddlexamsession.SelectedItem.ToString() + "' AND STREAMPART.StreamCode = '" + ddlprogram.SelectedValue + "'" +
               " And EXAMPAPERDETAIL.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "' ");
        Streampart.DataSource = dssemester.Tables[0];
        Streampart.DataTextField = "StreamPart";
        Streampart.DataValueField = "StreamPartCode";
        Streampart.DataBind();
        Streampart.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    private void bindprogram()
    {
        DataSet dsprogarm = fn.SelectDataset("SELECT DISTINCT STREAM.StreamAbbr, STREAM.StreamCode FROM EXAMPAPERDETAIL INNER JOIN " + 
               " STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN STREAM ON " + 
               " STREAMPART.StreamCode = STREAM.StreamCode WHERE EXAMPAPERDETAIL.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "' order " + 
               " by StreamAbbr ");
        ddlprogram.DataSource = dsprogarm.Tables[0];
        ddlprogram.DataTextField = "StreamAbbr";
        ddlprogram.DataValueField = "StreamCode";
        ddlprogram.DataBind();
        ddlprogram.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void ddlprogram_SelectedIndexChanged(object sender, EventArgs e)
    {
        bindsemester();
    }
    
}
