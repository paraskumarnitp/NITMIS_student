using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

public partial class studentnoc : System.Web.UI.Page
{
    string sname = "", rollno = "", year = "", program = "", nocfor = "", place = "", peroid = "", refno = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "10") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }

                
                if (Session["refno"] != null)
                {
                    refno = Session["refno"].ToString();
                }
                if (Session["Sname"] != null)
                {
                    sname = Session["Sname"].ToString();
                }

                if (Session["rollno"] != null)
                {
                    rollno = Session["rollno"].ToString();
                }
                if (Session["year"] != null)
                {
                    year = Session["year"].ToString();
                }

                if (Session["program"] != null)
                {
                    program = Session["program"].ToString();
                }
                if (Session["nocfor"] != null)
                {
                    nocfor = Session["nocfor"].ToString();
                }
                if (Session["period"] != null)
                {
                    peroid = Session["period"].ToString();
                }
                if (Session["place"] != null)
                {
                    place = Session["place"].ToString();
                }


                ReportDocument myReportDocument = new ReportDocument();
                myReportDocument.Load(Server.MapPath("Report\\studentnoccertificate.rpt"));



                myReportDocument.SetParameterValue("Sname", sname);
                myReportDocument.SetParameterValue("RollNo", rollno);
                myReportDocument.SetParameterValue("year", year);
                myReportDocument.SetParameterValue("program", program);
                myReportDocument.SetParameterValue("nocfor", nocfor);
                myReportDocument.SetParameterValue("place", place);
                myReportDocument.SetParameterValue("period", peroid);
                myReportDocument.SetParameterValue("Refno", refno);
                Crystalnoccertificate.ReportSource = myReportDocument;
                Crystalnoccertificate.DisplayGroupTree = false;


                Crystalnoccertificate.HasToggleGroupTreeButton = false;
                Crystalnoccertificate.DataBind();

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
        }
    }
}
