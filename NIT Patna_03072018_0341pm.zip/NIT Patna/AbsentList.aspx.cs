using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class AbsentList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "3")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(Year, "Year", "Select Year from Year where year >= '2009' order by Year", "Year", "Year");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string sql = "SELECT EXAMPAPERDETAIL.RegNo, EXAMPAPERDETAIL.UnivRollNo, EXAM.StreamCode, EXAMPAPERDETAIL.StreamPartCode, " +
                     " EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.PaperType, EXAMPAPERDETAIL.IsAppeared, EXAMPAPERDETAIL.ExamYear, EXAM.CollCode " +
                     " FROM         EXAM INNER JOIN EXAMPAPERDETAIL ON EXAM.RegNo = EXAMPAPERDETAIL.RegNo AND EXAM.UnivRollNo = EXAMPAPERDETAIL.UnivRollNo AND " +
                     " EXAM.ExamYear = EXAMPAPERDETAIL.ExamYear AND EXAM.StreamPartCode = EXAMPAPERDETAIL.StreamPartCode " +
                     " WHERE     (EXAMPAPERDETAIL.IsAppeared = 'A' And EXAMPAPERDETAIL.ExamYear='"+Year.SelectedValue+"')";
        string[] col = new string[9];
        string[] val = new string[9];
        

        UnivService.Service1 ss = new UnivService.Service1();
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.Connection = con;
        con.Open();
        cmd.CommandText = "Delete From AbsentList";
        cmd.ExecuteNonQuery();
        cmd.CommandText = sql;
        SqlDataReader rd = cmd.ExecuteReader();
        col[0] = "RegNo";
        col[1] = "UnivRollNo";
        col[2] = "CollName";
        col[3] = "ExamYear";
        col[4] = "StreamCode";
        col[5] = "StreamPartCode";
        col[6] = "PaperName";
        col[7] = "ApplicantName";
        col[8] = "PaperType";
        while (rd.Read())
        {
            val[0] = rd["RegNo"].ToString();
            val[1] = rd["UnivRollNo"].ToString();
            val[2] = ss.GetNewCode("Select CollName From College Where CollCode='" + rd["CollCode"].ToString() + "'");
            val[3] = rd["ExamYear"].ToString();
            val[4] = rd["StreamCode"].ToString();
            val[5] = rd["StreamPartCode"].ToString();
            if (rd["PaperType"].ToString() == "H")
                val[6] = ss.GetNewCode("Select PaperAbbr From COURSEPAPERS Where SubPaperCode='" + rd["SubPaperCode"].ToString() + "'");
            else if (rd["PaperType"].ToString() == "C")
                val[6] = ss.GetNewCode("Select Abbr From COMPOSITION Where CompCode='" + rd["SubPaperCode"].ToString() + "'");
            else
                val[6] = ss.GetNewCode("Select SubAbbr From SUBJECT Where SubCode='" + rd["SubPaperCode"].ToString() + "'");

            val[7] = ss.GetNewCode("SElect ApplicantName From Registration Where RegNo='" + rd["RegNo"].ToString() + "'");
            val[8] = rd["PaperType"].ToString();

            string abc = ss.SaveData("AbsentList", col, val);

           
        }

        //

        CR.ReportSource = crs;
//        CR.SelectionFormula = @"{AbsentList.ExamYear}='" + Year.SelectedValue + "'";
        CR.RefreshReport();
        //
    }
}
