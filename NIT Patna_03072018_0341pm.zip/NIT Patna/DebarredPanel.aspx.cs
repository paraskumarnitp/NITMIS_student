using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Drawing;

public partial class DebarredPanel : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2" && Session["Role"].ToString() != "7" && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(drpexamsession, "EXAMPAPERDETAIL", "select DIStinct ExamSession from EXAMPAPERDETAIL", "ExamSession", "ExamSession");
            // select DIStinct ExamSession from EXAMPAPERDETAIL
            drpexamsession.Items.Insert(0, new ListItem("-Select--", "0"));

        }
    }
    protected void drpexamsession_SelectedIndexChanged(object sender, EventArgs e)
    {


        string query = "SELECT distinct STREAM.StreamAbbr,STREAM.StreamCode FROM STREAM INNER JOIN STREAMPART ON STREAM.StreamCode = STREAMPART.StreamCode INNER JOIN    EXAM ON STREAM.StreamCode = EXAM.StreamCode WHERE     (EXAM.ExamSession = '" + drpexamsession.SelectedValue.ToString() + "')";
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(drpProgram, "STREAM", query, "StreamAbbr", "StreamCode");
        drpProgram.Items.Insert(0, new ListItem("ALL", "0"));
        DrpSem.Items.Insert(0, new ListItem("ALL", "0"));
        ddlcourse.Items.Insert(0, new ListItem("ALL", "0"));
    }
    protected void drpProgram_SelectedIndexChanged(object sender, EventArgs e)
    {

        string query = "SELECT STREAMPART.StreamPart,STREAMPART.StreamPartCode FROM  STREAM INNER JOIN  STREAMPART ON STREAM.StreamCode = STREAMPART.StreamCode INNER JOIN   STREAMTYPE ON STREAM.StreamTypeCode = STREAMTYPE.StreamTypeCode where StreamAbbr='" + drpProgram.SelectedItem.ToString() + "' ";
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(DrpSem, "STREAMPART", query, "StreamPart", "StreamPartCode");
        DrpSem.Items.Insert(0, new ListItem("ALL", "0"));




    }
    protected void btnExit_Click(object sender, EventArgs e)
    {
        Response.Redirect("default.aspx");
    }
    protected void btnprocess_Click(object sender, EventArgs e)
    {
        string querypart = "";
        if (drpexamsession.SelectedValue.ToString() == "0")
        {
            lblmsg.Text = "Invalid ExamSession Selected";
            return;
        }
        if (drpProgram.SelectedValue.ToString() != "0")
        {
            querypart = " AND STREAMPART.StreamCode = '"+ drpProgram.SelectedValue.ToString() +"' ";            
        }
        if (DrpSem.SelectedValue.ToString() != "0")
        {
            querypart = querypart + " AND Attendance.StreamPartCode = '"+DrpSem.SelectedValue.ToString()+"' ";
        }
        if (ddlcourse.SelectedValue.ToString() != "0")
        {
            querypart = querypart + " AND COURSEPAPERS.PaperAbbr = '"+ddlcourse.SelectedValue.ToString()+"' ";
        }
        if (txtroll.Text.Trim() != "")
        {
            querypart = querypart + " AND Attendance.Univrollno = '"+ txtroll.Text.Trim() +"' ";
        }

        int value = fnrev.InsertUpdateDelete("UPDATE Attendance SET TheoryAttendance = CompiledAttendance.TClassAttend, " + 
            " ThMedRelaxation =CompiledAttendance.TMEDRElax, PracticalTotalCl =CompiledAttendance.PClassHeld, " + 
            " PracticalAttendance =CompiledAttendance.PClassAttend, PrMedRelaxation =CompiledAttendance.PMEDRElax, " + 
            " TheoryTotalCl =CompiledAttendance.TClassHeld, status = CASE WHEN Attendance.PaperType = 'P' THEN CASE WHEN " + 
            " (CONVERT(float,CompiledAttendance.PTAttendpercent) >= '75') THEN 'P' ELSE 'D' END WHEN Attendance.PaperType = 'T' THEN " + 
            " CASE WHEN (CONVERT(float,CompiledAttendance.ThAttendpercent) >= '75') THEN 'P' ELSE 'D' END WHEN ((Attendance.PaperType = 'X')) " + 
            " THEN CASE WHEN ((CONVERT(float,CompiledAttendance.PTAttendpercent) >= '75') AND (CONVERT(float,CompiledAttendance.ThAttendpercent) >= '75')) " + 
            " THEN 'P' ELSE 'D' END END FROM CompiledAttendance INNER JOIN Attendance ON CompiledAttendance.RegNo = Attendance.RegNo AND " + 
            " CompiledAttendance.SubPaperCode = Attendance.SubPaperCode AND CompiledAttendance.ExamSession = Attendance.ExamSession INNER JOIN " + 
            " STREAMPART ON Attendance.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN COURSEPAPERS ON Attendance.SubPaperCode = COURSEPAPERS.SubPaperCode " + 
            " WHERE (CompiledAttendance.ExamSession = '"+drpexamsession.SelectedValue.ToString()+"') " + querypart + "");

        if (value > 0)
        {
            lblmsg.Text = "Attendance Reprocessed.";
        }
        else
        {
            lblmsg.Text = "Attendance failed to Reprocessed.";

        }

    }
    protected void btndownload_Click(object sender, EventArgs e)
    {
        string querypart = "";
        if (drpexamsession.SelectedValue.ToString() == "0")
        {
            lblmsg.Text = "Invalid ExamSession Selected";
            return;
        }
        if (drpProgram.SelectedValue.ToString() != "0")
        {
            querypart = " AND STREAMPART.StreamCode = '" + drpProgram.SelectedValue.ToString() + "' ";
        }
        if (DrpSem.SelectedValue.ToString() != "0")
        {
            querypart = querypart + " AND Attendance.StreamPartCode = '" + DrpSem.SelectedValue.ToString() + "' ";
        }
        if (ddlcourse.SelectedValue.ToString() != "0")
        {
            querypart = querypart + " AND COURSEPAPERS.PaperAbbr = '" + ddlcourse.SelectedValue.ToString() + "' ";
        }
        if (txtroll.Text.Trim() != "")
        {
            querypart = querypart + " AND Attendance.Univrollno = '" + txtroll.Text.Trim() + "' ";
        }

        DataTable dtfeewaivedata = fnrev.SelectDatatable("SELECT ROW_NUMBER() OVER(ORDER BY (SELECT 1)) AS RowNumber,Attendance.UnivRollNo, REGISTRATION.ApplicantName, STREAMPART.StreamPart," + 
            " COURSEPAPERS.PaperAbbr, Attendance.TheoryTotalCl, Attendance.TheoryAttendance, Attendance.ExamType, Attendance.ThMedRelaxation," + 
            " Attendance.PracticalTotalCl, Attendance.PracticalAttendance, Attendance.PrMedRelaxation, Attendance.status FROM Attendance INNER JOIN " + 
            " STREAMPART ON Attendance.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN COURSEPAPERS ON Attendance.SubPaperCode = COURSEPAPERS.SubPaperCode " + 
            " INNER JOIN REGISTRATION ON Attendance.RegNo = REGISTRATION.RegNo WHERE (Attendance.ExamSession = '"+drpexamsession.SelectedValue.ToString()+"') "+ querypart +"");
        if (dtfeewaivedata.Rows.Count > 0)
        {
            GridView gvpayonline = new GridView();
            gvpayonline.DataSource = dtfeewaivedata;
            gvpayonline.DataBind();

            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=ExportAttendance.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                //gvpayonline.AllowPaging = false;
                //this.BindGrid();

                gvpayonline.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in gvpayonline.HeaderRow.Cells)
                {
                    cell.BackColor = gvpayonline.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in gvpayonline.Rows)
                {
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = gvpayonline.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = gvpayonline.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                gvpayonline.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }

          
        }
        else
            lblmsg.Text = "Records not Found.";
    }
    protected void DrpSem_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable dtcourses = fnrev.SelectDatatable("SELECT PaperAbbr,SubPaperCode FROM COURSEPAPERS WHERE StreamCode = '" + drpProgram.SelectedValue.ToString() + "' " +
            " and StreamPartCode = '" + DrpSem.SelectedValue.ToString() + "'");
        ddlcourse.DataSource = dtcourses;
        ddlcourse.DataTextField = "PaperAbbr";
        ddlcourse.DataValueField = "SubPaperCode";
        ddlcourse.DataBind();
        ddlcourse.Items.Insert(0, new ListItem("ALL", "0"));
    }
    protected void btnview_Click(object sender, EventArgs e)
    {
        string querypart = ""; string tablestring = "";
        if (drpexamsession.SelectedValue.ToString() == "0")
        {
            lblmsg.Text = "Invalid ExamSession Selected";
            return;
        }
        if (drpProgram.SelectedValue.ToString() != "0")
        {
            querypart = " AND STREAMPART.StreamCode = '" + drpProgram.SelectedValue.ToString() + "' ";
        }
        if (DrpSem.SelectedValue.ToString() != "0")
        {
            querypart = querypart + " AND Attendance.StreamPartCode = '" + DrpSem.SelectedValue.ToString() + "' ";
        }
        if (ddlcourse.SelectedValue.ToString() != "0")
        {
            querypart = querypart + " AND COURSEPAPERS.PaperAbbr = '" + ddlcourse.SelectedValue.ToString() + "' ";
        }
        if (txtroll.Text.Trim() != "")
        {
            querypart = querypart + " AND Attendance.Univrollno = '" + txtroll.Text.Trim() + "' ";
        }

        DataTable dtfeewaivedata = fnrev.SelectDatatable("SELECT ROW_NUMBER() OVER(ORDER BY (SELECT 1)) AS RowNumber,Attendance.UnivRollNo, REGISTRATION.ApplicantName, STREAMPART.StreamPart," + 
            " COURSEPAPERS.PaperAbbr, Attendance.TheoryTotalCl, Attendance.TheoryAttendance, Attendance.ExamType, Attendance.ThMedRelaxation," + 
            " Attendance.PracticalTotalCl, Attendance.PracticalAttendance, Attendance.PrMedRelaxation, Attendance.status FROM Attendance INNER JOIN " + 
            " STREAMPART ON Attendance.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN COURSEPAPERS ON Attendance.SubPaperCode = COURSEPAPERS.SubPaperCode " + 
            " INNER JOIN REGISTRATION ON Attendance.RegNo = REGISTRATION.RegNo WHERE (Attendance.ExamSession = '"+drpexamsession.SelectedValue.ToString()+"') "+ querypart +"");
        if (dtfeewaivedata.Rows.Count > 0)
        {

            for (int i = 0; i < dtfeewaivedata.Rows.Count; i++)
            {
                tablestring += "<tr>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["RowNumber"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["UnivRollNo"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["ApplicantName"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["StreamPart"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["PaperAbbr"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["TheoryTotalCl"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["TheoryAttendance"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["ThMedRelaxation"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["PracticalTotalCl"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["PracticalAttendance"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["PrMedRelaxation"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["status"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["ExamType"].ToString() + "</td>";
                tablestring += "</tr>";
            }
            tlist.InnerHtml = tablestring;
            Panel1.Visible = true;
        }
        else
        {
            tlist.InnerHtml = "";
            Panel1.Visible = false;
        }
    }
}
