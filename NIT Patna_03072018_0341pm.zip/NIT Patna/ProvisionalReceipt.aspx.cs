using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ProvisionalReceipt : System.Web.UI.Page
{
    Functionreviseed appfn = new Functionreviseed();
    UnivService.Service1 nic = new UnivService.Service1();
    string txnid = ""; string tmpID = ""; string tmpRoll = ""; string examsession = ""; public string tablerow = "";
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            try
            {
                //if (Session["Role"].ToString() != "8" && Session["Role"].ToString() != "18")
                //{
                //    Session["userName"] = null;
                //    FormsAuthentication.SignOut();
                //    Response.Redirect("default.aspx");
                //    return;
                //}
                if (Request.QueryString["tid"] != null)
                {
                    txnid = Request.QueryString["tid"].ToString();
                    examsession = Request.QueryString["es"].ToString();
                    tmpID = appfn.DecodeFrom64(Request.QueryString["candID"].ToString());
                    //if (tmpID.Length > 7)
                      //  tmpRoll = nic.GetNewCode("select distinct RegNo from EXAM where UnivRollNo='" + 1523006 + "'");
                        
                    bindvalues();
                }         
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

        }
    }
    protected void btnredgform_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    string adyear = ""; DataSet dstransaction = new DataSet();
    private void bindvalues()
    {
       // DateTime prexamdate = Convert.ToDateTime(appfn.DecodeFrom64(examsession.ToString()).Substring(8, 4) + "-" + appfn.DecodeFrom64(examsession.ToString()).Substring(4, 3) + "-01 00:00:00.000");
        
            dstransaction = appfn.SelectDataset("SELECT EXAM.PaymentId, EXAM.ExamFeeAmt, CONVERT(Varchar, EXAM.PaymentDate, 103) AS PayDate, " +
                " EXAM.ModeOfPayment, EXAM.Bank, EXAM.ExamSession, CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4)  AS DATETIME) AS sessiondate, REGISTRATION.ApplicantName, REGISTRATION.TempRollNo, STREAM.StreamAbbr, STREAMPART.StreamPart, " +
                " STREAM.StreamTypeCode, REGISTRATION.AdmYear,REGISTRATION.ActualAdmYear FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo " +
                " INNER JOIN STREAM ON EXAM.StreamCode = STREAM.StreamCode INNER JOIN STREAMPART ON EXAM.StreamPartCode = STREAMPART.StreamPartCode WHERE " +
                " EXAM.PaymentId = '" + appfn.DecodeFrom64(txnid.ToString()) + "' AND EXAM.ExamSession = '" + appfn.DecodeFrom64(examsession.ToString()) + "' " +
                " AND (UnivRollNo = '" + tmpID + "' OR REGISTRATION.RegNo = '" + tmpID + "')  order by ExamType DESC");
        
        //else
        //{
        //    dstransaction = appfn.SelectDataset("SELECT Phdregistration.PaymentId, Phdregistration.FeeAmount AS ExamFeeAmt,CONVERT(Varchar, " + 
        //        " Phdregistration.PaymentDate, 103) AS PayDate , Phdregistration.PaymentMode AS ModeOfPayment, Phdregistration.PayBank AS Bank, " + 
        //        " Phdregistration.ExamSession,  CAST(SUBSTRING(Phdregistration.ExamSession,5, 3) + SUBSTRING(Phdregistration.ExamSession, 9, 4) AS " + 
        //        " DATETIME) AS sessiondate, REGISTRATION.ApplicantName, REGISTRATION.TempRollNo, STREAM.StreamAbbr, Phdregistration.StreamPartCode AS StreamPart, " + 
        //        " STREAM.StreamTypeCode, REGISTRATION.AdmYear, REGISTRATION.ActualAdmYear FROM Phdregistration INNER JOIN STREAM ON Phdregistration.StreamCode = STREAM.StreamCode " +
        //        " INNER JOIN REGISTRATION ON Phdregistration.Regno = REGISTRATION.RegNo WHERE (Phdregistration.PaymentId = '" + appfn.DecodeFrom64(txnid.ToString()) + "') AND " +
        //        " (Phdregistration.ExamSession = '" + appfn.DecodeFrom64(examsession.ToString()) + "') AND (Phdregistration.UnivRollNo = '" + Session["Rollno"].ToString() + "') ORDER BY Phdregistration.RedgType DESC");
        //}
        //DataSet dstransaction = appfn.SelectDataset("SELECT EXAM.PaymentId, EXAM.ExamFeeAmt, CONVERT(Varchar, EXAM.PaymentDate, 103) AS PayDate, " +
        //   " EXAM.ModeOfPayment, EXAM.Bank, EXAM.ExamSession, REGISTRATION.ApplicantName, REGISTRATION.TempRollNo, STREAM.StreamAbbr, STREAMPART.StreamPart, STREAM.StreamTypeCode, REGISTRATION.AdmYear,REGISTRATION.ActualAdmYear " +
        //   " FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo INNER JOIN STREAM ON EXAM.StreamCode = STREAM.StreamCode INNER JOIN STREAMPART " +
        //   " ON EXAM.StreamPartCode = STREAMPART.StreamPartCode WHERE EXAM.PaymentId = '" + appfn.DecodeFrom64(txnid.ToString()) + "' AND EXAM.ExamSession = '" + appfn.DecodeFrom64(examsession.ToString()) + "'");
        if (dstransaction.Tables[0].Rows.Count > 0)
        {
            studname.Text = dstransaction.Tables[0].Rows[0]["ApplicantName"].ToString();
            rollno.Text = dstransaction.Tables[0].Rows[0]["TempRollNo"].ToString();
            branch.Text = dstransaction.Tables[0].Rows[0]["StreamAbbr"].ToString();
            semester1.Text = dstransaction.Tables[0].Rows[0]["StreamPart"].ToString();
            examsession1.Text = dstransaction.Tables[0].Rows[0]["ExamSession"].ToString();
            paystatus.Text = "SUCCESS";
            TransactionId1.Text = appfn.DecodeFrom64(txnid);
            gtotal.Text = dstransaction.Tables[0].Rows[0]["ExamFeeAmt"].ToString();
            if (dstransaction.Tables[0].Rows[0]["ActualAdmYear"].ToString() != "")
            {
                adyear = dstransaction.Tables[0].Rows[0]["ActualAdmYear"].ToString();
            }
            else
            {
                adyear = dstransaction.Tables[0].Rows[0]["AdmYear"].ToString();
            }
            string oddevenval = ""; 
            if (appfn.DecodeFrom64(examsession.ToString()).Substring(4, 3) == "DEC")
                oddevenval = "(Fee_Details.IsOdd = 1)";
            else
                oddevenval = "(Fee_Details.IsEven = 1)";

            DateTime comparedate = Convert.ToDateTime("2017-06-01 00:00:00.000");
             if (Convert.ToDateTime(dstransaction.Tables[0].Rows[0]["sessiondate"].ToString()) < comparedate)
            {
                DataTable dsfeedetails = appfn.SelectDatatable("SELECT Fee_Details.Description, Fee_Details.Amount FROM Feetype INNER JOIN  Fee_Details " +
                            " ON Feetype.ID = Fee_Details.Fee_Id WHERE (Feetype.StreamTypeCode = '" + dstransaction.Tables[0].Rows[0]["StreamTypeCode"].ToString() + "') AND  " + oddevenval + " AND " +
                            " (ISNULL(Feetype.FrmAdmYear, '1990') <= " + adyear + ")  AND (ISNULL(Feetype.ToAdmYear, year(getdate())) >= " + adyear + ")");
                //DataSet dsfeedetails = appfn.SelectDataset("SELECT Fee_Details.Description, Fee_Details.Amount FROM Feetype " +
                //    " INNER JOIN Fee_Details ON Feetype.ID = Fee_Details.Fee_Id WHERE (Feetype.StreamTypeCode = '" + dstransaction.Tables[0].Rows[0]["StreamTypeCode"].ToString() + "') AND " +
                //    " (Fee_Details.IsEven = 1) AND (ISNULL(Feetype.FrmAdmYear, '" + adyear + "') <= " + adyear + ") AND (ISNULL(Feetype.ToAdmYear, '" + adyear + "') >= " + adyear + ")");
                if (dsfeedetails.Rows.Count > 0)
                {
                    for (int t = 0; t < dsfeedetails.Rows.Count; t++)
                    {
                        tablerow = tablerow + "<tr class='item'><td>" + dsfeedetails.Rows[t]["Description"].ToString() + "</td><td>" + dsfeedetails.Rows[t]["Amount"].ToString() + "</td></tr>";
                    }                   
                }
            }
            else
            {
                string tmpSql = "SELECT FeeDeposited,Amount FROM DepositedFeeDetails d inner join EXAM e On d.UnivRollNo=e.UnivRollNo WHERE " +
                    " d.ExamSession = '" + appfn.DecodeFrom64(examsession.ToString()) + "' And (d.UnivRollNo = '" + tmpID + "' OR  e.RegNo='" + tmpID + "') ";
                DataTable dsfeedetails = appfn.SelectDatatable(tmpRoll);
                if (dsfeedetails.Rows.Count > 0)
                {
                    for (int t = 0; t < dsfeedetails.Rows.Count; t++)
                    {
                        tablerow = tablerow + "<tr class='item'><td>" + dsfeedetails.Rows[t]["FeeDeposited"].ToString() + "</td><td>" + dsfeedetails.Rows[t]["Amount"].ToString() + "</td></tr>";
                    }
                }
                DataTable FeeConcession = appfn.SelectDatatable("SELECT d.Remarks, Amount*-1 As Amount FROM FeeConcession d inner join EXAM e On d.UnivRollNo=e.UnivRollNo  WHERE d.ExamSession = '" + appfn.DecodeFrom64(examsession.ToString()) + "' And (d.UnivRollNo = '" + tmpID + "' OR  e.RegNo='" + tmpID + "')");
                if (FeeConcession.Rows.Count > 0)
                {
                    for (int y = 0; y < FeeConcession.Rows.Count; y++)
                    {
                        tablerow = tablerow + "<tr class='item'><td>" + FeeConcession.Rows[y]["Remarks"].ToString() + "</td><td>" + FeeConcession.Rows[y]["Amount"].ToString() + "</td></tr>";
                    }
                }
            }
        }
    }
}
