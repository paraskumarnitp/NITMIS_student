using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using CrystalDecisions.CrystalReports.Engine;
using System.Net;
public partial class Feedbackprint : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "4" && Session["Role"].ToString() != "7")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            frmdt.Attributes.Add("onKeyPress", "return onlyNumbers(this);");
            todt.Attributes.Add("onKeyPress", "return onlyNumbers(this);");
            frmdt.Text = DateTime.Now.ToString("01/MM/yyyy");
            todt.Text = DateTime.Now.ToString("dd/MM/yyyy");



        }

        //if (ViewState["feedback"] != null)
        //{
        //    feedback fdb = (feedback)ViewState["feedback"];
        //    ReportDocument rpt = new ReportDocument();
        //    rpt.Load(Server.MapPath("~/Report/feedbackprint.rpt"));
        //    rpt.SetDataSource(fdb);
        //    CrystalReportViewer1.ReportSource = rpt;
        //}
    }





    protected void ViewTR_Click(object sender, EventArgs e)
    {
        DataTable dt = fnrev.SelectDatatable("SELECT     userid, UserName, messagetype, message, convert(varchar,EntryDate,103) as Entrydate " +
                                               " FROM Feedback where EntryDate between "+
                                               "convert(datetime,'" + frmdt.Text + "',103) and convert(datetime,'" + todt.Text + "',103)");

        feedback fdb = new feedback();
        fdb.Tables[0].Merge(dt);
        ReportDocument rpt = new ReportDocument();
        rpt.Load(Server.MapPath( "~/Report/feedbackprint.rpt"));
        rpt.SetDataSource(fdb);
        Response.Write("<SCRIPT language=javascript>var  pdf=window.open('default.aspx','pdf','width=600,height=400');pdf.moveTo(0,0);</SCRIPT>");
        MemoryStream oStream = new MemoryStream();
        oStream = (MemoryStream)rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
        Response.Clear();
        Response.Buffer = true;
        Response.ContentType = "application/pdf";
        Response.BinaryWrite(oStream.ToArray());
        Response.End();



    }
}