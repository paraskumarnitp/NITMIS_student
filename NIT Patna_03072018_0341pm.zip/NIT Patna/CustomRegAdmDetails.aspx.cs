using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class CustomRegAdmDetails : System.Web.UI.Page
{
    string querypart = ""; string query = "";
    Functionreviseed fnrev = new Functionreviseed();
    PopulateDDL popddl = new PopulateDDL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //Session["checkclear"] = criteria;
            try
            {

                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "10") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }


            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }

            popddl.Popualate(ddlexamsession, "Year", "select distinct ExamSession from EXAM order by ExamSession desc", "ExamSession", "ExamSession");
            popddl.Popualate(ddlexamyear, "Year", "select distinct AdmYear from REGISTRATION WHERE AdmYear >= 2013 order by AdmYear desc", "AdmYear", "AdmYear");

            ddlexamsession.Items.Insert(0, new ListItem("--Select--", "00"));
            ddlexamyear.Items.Insert(0, new ListItem("--Select--", "00"));
            ddlexamsession.Enabled = false;
            ddlexamyear.Enabled = false;
            lstbregistration.Enabled = false;
            btnexportdata.Enabled = false;

        }
        
    }
    string category = "", redgtype = "", selctpart = ""; DataTable dtphddata = new DataTable();
    protected void btncoursesave_Click(object sender, EventArgs e)
    {
        LblMsg.Text = "";
        if ((!chkbug.Checked) && (!chkbpg.Checked) && (!chkbphd.Checked))
        {
            LblMsg.Text = "Please select atleast one criteria - UG/PG/PhD.";
            return;
        }
        if (chkbug.Checked)
        {
            category += "'01'";
        }
        if (chkbpg.Checked)
        {
            if (category == "")
                category += "'02','04'";
            else
                category += ",'02','04'";
        }
        if (chkbphd.Checked)
        {
            if (category == "")
                category += "'03'";
            else
                category += ",'03'";
        }
        if (rdbldatacriteria.SelectedValue.ToString() == "R")
        {
            if ((ddlexamsession.SelectedValue.ToString() == "00"))
            {
                LblMsg.Text = "Please select ExamSession";
                return;
            }          

            foreach (ListItem li in lstbregistration.Items)
            {
                if (li.Selected)
                {
                    if (li.Value == "Gender")
                    {
                        querypart = querypart + ",REGISTRATION." + li.Value;
                        selctpart = selctpart + "," + li.Value;
                    }
                    else if (li.Value == "PHCategory")
                    {
                        querypart = querypart + ",PHCategory." + li.Value;
                        selctpart = selctpart + "," + li.Value;
                    }
                    else
                    {
                        querypart = querypart + "," + li.Value;
                        selctpart = selctpart + "," + li.Value;
                    }
                }
            }
            
            
               
          

            if ((chkbr.Checked) && (chkbnc.Checked))
            {
                redgtype = "";
            }
            else
            {
                if (chkbr.Checked)
                {
                    redgtype = " WHERE lastrec = '1'";
                }
                if (chkbnc.Checked)
                {
                    redgtype = " WHERE lastrec <> '1'";
                }
            }
            //else
            //    category = "'01','02','03'";

          /*  query = "SELECT DISTINCT REGISTRATION.AckNo As EnrollmentNo, EXAM.UnivRollNo AS RollNo, REGISTRATION.ApplicantName," +
                " STREAM.StreamAbbr AS Program,EXAM.ExamFeeAmt,EXAM.PaymentId AS TXN_No, EXAM.PaymentDate, EXAM.PaymentDate2, " +
                " EXAM.ModeOfPayment, EXAM.Bank " + querypart + " FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo " +
                " INNER JOIN STREAM ON EXAM.StreamCode = STREAM.StreamCode INNER JOIN STREAMPART ON " +
                " EXAM.StreamPartCode = STREAMPART.StreamPartCode LEFT OUTER JOIN Religion ON " +
                " REGISTRATION.ReligionCode = Religion.ReligionCode LEFT OUTER JOIN PHCategory ON " +
                " REGISTRATION.PhCategory = PHCategory.PHCode LEFT OUTER JOIN CATEGORY ON " +
                " REGISTRATION.CastCode = CATEGORY.CategoryCode LEFT OUTER JOIN NATIONALITY ON " +
                " REGISTRATION.NationalityCode = NATIONALITY.NationalityCode WHERE " +
                " (EXAM.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "') AND (EXAM.Status <> 'DRAFT') AND STREAM.StreamTypeCode IN ("+category+")"; */

            query = "with cte as (SELECT REGISTRATION.AckNo As EnrollmentNo, EXAM.UnivRollNo AS RollNo, " +
                " REGISTRATION.ApplicantName, STREAM.StreamAbbr AS Program,EXAM.ExamFeeAmt,EXAM.PaymentId AS " +
                " TXN_No, EXAM.PaymentDate, EXAM.PaymentDate2, EXAM.ModeOfPayment, EXAM.Bank ,StreamPart,ExamType," +
                " ROW_NUMBER() over (partition by EXAM.RegNo order by CONVERT(int, LEFT(SUBSTRING(STREAMPART.StreamPart, " +
                " PATINDEX('%[0-9]%', STREAMPART.StreamPart), 8000), PATINDEX('%[^0-9]%', SUBSTRING(STREAMPART.StreamPart," +
                " PATINDEX('%[0-9]%', STREAMPART.StreamPart), 8000) + 'X') - 1)) desc) as lastrec" + querypart + " FROM EXAM INNER JOIN " +
                " REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo INNER JOIN STREAM ON EXAM.StreamCode = STREAM.StreamCode " +
                " INNER JOIN STREAMPART ON EXAM.StreamPartCode = STREAMPART.StreamPartCode LEFT OUTER JOIN Religion ON " +
                " REGISTRATION.ReligionCode = Religion.ReligionCode LEFT OUTER JOIN PHCategory ON " +
                " REGISTRATION.PhCategory = PHCategory.PHCode LEFT OUTER JOIN CATEGORY ON REGISTRATION.CastCode = CATEGORY.CategoryCode " +
                " LEFT OUTER JOIN NATIONALITY ON REGISTRATION.NationalityCode = NATIONALITY.NationalityCode WHERE (EXAM.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "') " +
                " AND (EXAM.Status <> 'DRAFT') AND STREAM.StreamTypeCode IN (" + category + ") and EXAM.ExamType IN ('R','N','H')) SELECT " +
                " EnrollmentNo,RollNo,ApplicantName,Program,ExamFeeAmt,TXN_No,PaymentDate,PaymentDate2,ModeOfPayment,Bank,StreamPart,ExamType " + selctpart + " FROm cte " + redgtype;

            dtphddata = fnrev.SelectDatatable("SELECT REGISTRATION.AckNo As EnrollmentNo, Phdregistration.UnivrollNo AS RollNo, " +
                " REGISTRATION.ApplicantName, STREAM.StreamAbbr AS Program, Phdregistration.FeeAmount AS ExamFeeAmt, Phdregistration.PaymentId AS TXN_No, " +
                " Phdregistration.PaymentDate, '' As PaymentDate2,Phdregistration.PaymentMode AS ModeOfPayment, Phdregistration.PayBank AS Bank, " +
                " Phdregistration.StreamPartCode AS StreamPart, Phdregistration.RedgType AS ExamType" + querypart + " FROM Phdregistration INNER JOIN REGISTRATION ON " +
                " Phdregistration.Regno = REGISTRATION.RegNo INNER JOIN STREAM ON Phdregistration.StreamCode = STREAM.StreamCode LEFT OUTER JOIN " +
                " Religion ON REGISTRATION.ReligionCode = Religion.ReligionCode LEFT OUTER JOIN PHCategory ON REGISTRATION.PhCategory = PHCategory.PHCode " +
                " LEFT OUTER JOIN CATEGORY ON REGISTRATION.CastCode = CATEGORY.CategoryCode LEFT OUTER JOIN NATIONALITY ON REGISTRATION.NationalityCode = " +
                " NATIONALITY.NationalityCode WHERE (Phdregistration.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "') AND (Phdregistration.Status <> 'DRAFT') AND STREAM.StreamTypeCode IN (" + category + ") and Phdregistration.RedgType IN ('R','N','H')");
        }
        else
        {
            if ((ddlexamyear.SelectedValue.ToString() == "00"))
            {
                LblMsg.Text = "Please select Admission Year.";
                return;
            }    
            foreach (ListItem li in lstbregistration.Items)
            {
                if (li.Selected)
                {
                    if (li.Value == "Gender")
                    {
                        querypart = querypart + ",REGISTRATION." + li.Value;
                    }
                    else if (li.Value == "PHCategory")
                    {
                        querypart = querypart + ",PHCategory." + li.Value;
                    }
                    else
                    {
                        querypart = querypart + "," + li.Value;
                    }
                }
            }

            query = "SELECT  REGISTRATION.AckNo AS EnrollmentNo, REGISTRATION.TempRollNo AS RollNo, REGISTRATION.ApplicantName AS Student_Name, " + 
                " REGISTRATION.FatherName, REGISTRATION.MotherName, STREAM.StreamAbbr AS Program, STREAMPART.StreamPart AS Semester, " + 
                " CourseSpecialization.SpDescription AS Specialization, REGISTRATION.PermanentAddress1 + ' ' + REGISTRATION.PermanentAddress2 AS " + 
                " Permanent_Address, DISTRICT.DistName AS Permanent_District, State.state AS Permanent_State, REGISTRATION.PermanentPinCode, " + 
                " REGISTRATION.PresentAddress1 + ' ' + REGISTRATION.PresentAddress2 AS Present_Address, DISTRICT_1.DistName AS Present_District, " + 
                " State_1.state AS Present_State, REGISTRATION.PresentPinCode, REGISTRATION.CourseSession, REGISTRATION.AdmFeeAmt AS Admission_Fee_Amount, " + 
                " REGISTRATION.paymentID AS TXN_No, REGISTRATION.paymentDate AS PaymentDate, REGISTRATION.AllIndiaRank, REGISTRATION.CatogaryRank, " + 
                " REGISTRATION.QualifingExam, REGISTRATION.AdmissionDate, REGISTRATION.PaymentMode, REGISTRATION.Bank, REGISTRATION.AdmissionBranch, " +
                " REGISTRATION.SelectionExamRollNo " + querypart + " FROM State RIGHT OUTER JOIN DISTRICT ON State.StateCode = DISTRICT.StateCode RIGHT OUTER " + 
                " JOIN DISTRICT AS DISTRICT_1 LEFT OUTER JOIN State AS State_1 ON DISTRICT_1.StateCode = State_1.StateCode RIGHT OUTER JOIN NATIONALITY RIGHT OUTER JOIN " + 
                " REGISTRATION INNER JOIN STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode INNER JOIN STREAMPART ON REGISTRATION.StreamPartCode = STREAMPART.StreamPartCode " + 
                " ON NATIONALITY.NationalityCode = REGISTRATION.NationalityCode ON DISTRICT_1.DistCode = REGISTRATION.PresentDistrictCode ON DISTRICT.DistCode = REGISTRATION.PermanentDistCode " + 
                " LEFT OUTER JOIN CATEGORY ON REGISTRATION.CastCode = CATEGORY.CategoryCode LEFT OUTER JOIN PHCategory ON REGISTRATION.PhCategory = PHCategory.PHCode LEFT OUTER JOIN Religion ON " + 
                " REGISTRATION.ReligionCode = Religion.ReligionCode LEFT OUTER JOIN CourseSpecialization ON REGISTRATION.SplCode = CourseSpecialization.SPCode WHERE " + 
                " (REGISTRATION.AdmYear = '" + ddlexamyear.SelectedItem.ToString() + "') AND (ISNULL(REGISTRATION.MigrationStatus,'N') = 'N') AND (STREAM.StreamTypeCode IN (" + category + "))";

            
            
            //FROM NATIONALITY INNER JOIN REGISTRATION INNER JOIN STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode " + 
            //    " INNER JOIN STREAMPART ON REGISTRATION.StreamPartCode = STREAMPART.StreamPartCode ON NATIONALITY.NationalityCode = REGISTRATION.NationalityCode " + 
            //    " LEFT OUTER JOIN State INNER JOIN DISTRICT ON State.StateCode = DISTRICT.StateCode INNER JOIN DISTRICT AS DISTRICT_1 ON " + 
            //    " State.StateCode = DISTRICT_1.StateCode INNER JOIN State AS State_1 ON State.StateCode = State_1.StateCode AND " + 
            //    " DISTRICT_1.StateCode = State_1.StateCode ON REGISTRATION.PresentDistrictCode = DISTRICT_1.DistCode AND " + 
            //    " REGISTRATION.PermanentDistCode = DISTRICT.DistCode LEFT OUTER JOIN CATEGORY ON REGISTRATION.CastCode = CATEGORY.CategoryCode " + 
            //    " LEFT OUTER JOIN PHCategory ON REGISTRATION.PhCategory = PHCategory.PHCode LEFT OUTER JOIN Religion ON " + 
            //    " REGISTRATION.ReligionCode = Religion.ReligionCode LEFT OUTER JOIN CourseSpecialization ON REGISTRATION.SplCode = CourseSpecialization.SPCode " +
            //    " WHERE (REGISTRATION.AdmYear = '') AND (REGISTRATION.MigrationStatus <> 'Y')  AND STREAM.StreamTypeCode IN (" + category + ")";
        }
        if (query != "")
        {
            DataSet dsexportexcel = fnrev.SelectDataset(query);
            if (rdbldatacriteria.SelectedValue.ToString() == "R")
            {
                dsexportexcel.Tables[0].Merge(dtphddata);
            }
            if (dsexportexcel.Tables[0].Rows.Count > 0)
            {
                //Create a dummy GridView
                GridView GridView1 = new GridView();
                GridView1.AllowPaging = false;
                GridView1.DataSource = dsexportexcel.Tables[0];
                GridView1.DataBind();
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=Academic_Exported_Data_" + DateTime.Now.Date + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                for (int i = 0; i < GridView1.Rows.Count; i++)
                {
                    //Apply text style to each Row
                    GridView1.Rows[i].Attributes.Add("class", "textmode");

                }
                GridView1.RenderControl(hw);
                //style to format numbers to string
                string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
    }
    protected void rdbldatacriteria_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rdbldatacriteria.SelectedValue.ToString() == "R")
        {
            ddlexamsession.Enabled = true;
            ddlexamyear.Enabled = false;
            lstbregistration.Enabled = true;
            btnexportdata.Enabled = true;
            chkbr.Checked = false; chkbnc.Checked = false; chkbpg.Checked = false; chkbug.Checked = false;
            chkbphd.Checked = false; chkbnc.Enabled = true; chkbr.Enabled = true; 
        }
        else
        {
            ddlexamsession.Enabled = false;
            ddlexamyear.Enabled = true;
            lstbregistration.Enabled = true;
            btnexportdata.Enabled = true;
            chkbr.Checked = false; chkbnc.Checked = false; chkbpg.Checked = false; chkbug.Checked = false;
            chkbphd.Checked = false; chkbnc.Enabled = false; chkbr.Enabled = false; 
        }
    }   
}
