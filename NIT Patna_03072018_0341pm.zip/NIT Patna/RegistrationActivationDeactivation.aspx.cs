using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class RegistrationActivationDeactivation : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblfine.Visible = false;
        txtfine.Visible = false;

        lblindfine.Visible = false;
        txtindfine.Visible = false;
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "10"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
        }
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(Year3, "Year", "Select Year from Year where year > '2016'order by Year", "Year", "Year");
        Year3.Text = System.DateTime.Now.Year.ToString();



    }
    protected void month1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (month1.SelectedIndex == 1)
        {
            month2.SelectedIndex = 1;
        }
        else if (month1.SelectedIndex == 2)
        {
            month2.SelectedIndex = 2;
        }
        else
        {
            month2.SelectedIndex = 0;
        }

        bindpredata();
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        int i=0;
        decimal amount;
        string session = month1.SelectedItem.ToString() + "-" + month2.SelectedItem.ToString() + "_" + Year3.SelectedItem.ToString();
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.Connection = con;

        //date panel

           DateTime todate = DateTime.Parse(Convert.ToDateTime(txtstartdate.Text).ToShortDateString());
            DateTime fromdate = DateTime.Parse(Convert.ToDateTime(txtenddate.Text).ToShortDateString());

           try
           {
               if (fromdate > todate)
               {
                   DateTime frmdat = Convert.ToDateTime(txtstartdate.Text.Trim());
                   string sdate = frmdat.ToString("yyyy-MM-dd");
                   frmdat = Convert.ToDateTime(txtenddate.Text.Trim());
                   string edate = frmdat.ToString("yyyy-MM-dd");
                   con.Open();
                   string query = "insert into registrationActivate(examsession,regtype,stratdate,enddate,amount,cid,ctime,Extended) values('" + session + "','Default','" + sdate + "','" + edate + "',0,'" + Session["userid"].ToString() + "',GetDate(),'N')";
                   cmd.CommandText = query;
                    i = cmd.ExecuteNonQuery();
                   con.Close();
                 

               }
               else
               {
                   lblmsg.Text = "End Date Should be Greater than Start Date.";
               }
           }
           catch (Exception ex)
           {
           }


        //late fine panel1

           if (txtstartdate2.Text.Length != 0)
           {

               if (txtenddate2.Text.Length > 0 && txtamout2.Text.Length > 0)
               {


                   todate = DateTime.Parse(Convert.ToDateTime(txtenddate.Text).ToShortDateString());
                   fromdate = DateTime.Parse(Convert.ToDateTime(txtstartdate2.Text).ToShortDateString());


                   try
                   {

                       if (fromdate > todate)
                       {
                           todate = DateTime.Parse(Convert.ToDateTime(txtstartdate2.Text).ToShortDateString());
                           fromdate = DateTime.Parse(Convert.ToDateTime(txtenddate2.Text).ToShortDateString());
                           amount = Convert.ToDecimal(txtamout2.Text);

                           DateTime frmdat = Convert.ToDateTime(txtstartdate2.Text.Trim());
                           string sdate = frmdat.ToString("yyyy-MM-dd");
                           frmdat = Convert.ToDateTime(txtenddate2.Text.Trim());
                           string edate = frmdat.ToString("yyyy-MM-dd");
                           con.Open();
                           if (fromdate > todate)
                           {
                               string query = "insert into registrationActivate(examsession,regtype,stratdate,enddate,amount,cid,ctime,Extended) values('" + session + "','With Fine ','" + sdate + "','" + edate + "'," + amount + ",'" + Session["userid"].ToString() + "',GetDate(),'N')";
                               cmd.CommandText = query;
                            i = cmd.ExecuteNonQuery();
                           }
                           else
                           {
                               lblmsg.Text = "End Date Should be Greater than Start Date.";
                           }
                           con.Close();

                       }
                       else
                       {
                           lblmsg.Text = "End Date Should be Greater than Start Date.";

                       }
                   }
                   catch (Exception ex)
                   {
                   }
               }
               else
               {
                   lblmsg.Text = "End Date and Amount not be Empty";
               }

           }
           


        //late fine panel2
           if (txtstartdate3.Text.Length != 0)
           {

               if (txtenddate3.Text.Length > 0 && Ttxtamout4.Text.Length > 0)
               {



                   todate = DateTime.Parse(Convert.ToDateTime(txtenddate2.Text).ToShortDateString());
                   fromdate = DateTime.Parse(Convert.ToDateTime(txtstartdate3.Text).ToShortDateString());


                   try
                   {

                       if (fromdate > todate)
                       {
                           todate = DateTime.Parse(Convert.ToDateTime(txtstartdate3.Text).ToShortDateString());
                           fromdate = DateTime.Parse(Convert.ToDateTime(txtenddate3.Text).ToShortDateString());


                           DateTime frmdat = Convert.ToDateTime(txtstartdate3.Text.Trim());
                           string sdate = frmdat.ToString("yyyy-MM-dd");
                           frmdat = Convert.ToDateTime(txtenddate3.Text.Trim());
                           string edate = frmdat.ToString("yyyy-MM-dd");
                           amount = Convert.ToDecimal(Ttxtamout4.Text);
                           con.Open();
                           if (fromdate > todate)
                           {
                               string query = "insert into registrationActivate(examsession,regtype,stratdate,enddate,amount,cid,ctime,Extended) values('" + session + "','With Fine ','" + sdate + "','" + edate + "'," + amount + ",'" + Session["userid"].ToString() + "',GetDate(),'N')";
                               cmd.CommandText = query;
                             i = cmd.ExecuteNonQuery();
                           }
                           else
                           {
                               lblmsg.Text = "End Date Should be Greater than Start Date.";
                           }
                           con.Close();

                       }
                       else
                       {
                           lblmsg.Text = "End Date Should be Greater than Start Date.";
                       }
                   }
                   catch (Exception ex)
                   {
                   }
               }
     
               else
           {
           lblmsg.Text = "End Date and Amount not be Empty";
           }
    }
          

        //late fine panel3

           if (txtstartdate4.Text.Length != 0)
           {

               if (txtenddate4.Text.Length > 0 && txtamout5.Text.Length > 0)
               {
                   todate = DateTime.Parse(Convert.ToDateTime(txtenddate3.Text).ToShortDateString());
                   fromdate = DateTime.Parse(Convert.ToDateTime(txtstartdate4.Text).ToShortDateString());


                   try
                   {

                       if (fromdate > todate)
                       {
                           todate = DateTime.Parse(Convert.ToDateTime(txtstartdate4.Text).ToShortDateString());
                           fromdate = DateTime.Parse(Convert.ToDateTime(txtenddate4.Text).ToShortDateString());


                           DateTime frmdat = Convert.ToDateTime(txtstartdate4.Text.Trim());
                           string sdate = frmdat.ToString("yyyy-MM-dd");
                           frmdat = Convert.ToDateTime(txtenddate4.Text.Trim());
                           string edate = frmdat.ToString("yyyy-MM-dd");
                           amount = Convert.ToDecimal(txtamout5.Text);
                           con.Open();
                           if (fromdate > todate)
                           {
                               string query = "insert into registrationActivate(examsession,regtype,stratdate,enddate,amount,cid,ctime,Extended) values('" + session + "','With Fine ','" + sdate + "','" + edate + "'," + amount + ",'" + Session["userid"].ToString() + "',GetDate(),'N')";
                               cmd.CommandText = query;
                              i = cmd.ExecuteNonQuery();
                           }
                           else
                           {
                               lblmsg.Text = "End Date Should be Greater than Start Date.";
                           }

                           con.Close();

                       }
                       else
                       {
                           lblmsg.Text = "End Date Should be Greater than Start Date.";

                       }
                     
                   }
                   catch (Exception ex)
                   {
                   }
               }
               else
               {
                   lblmsg.Text = "End Date and Amount not be Empty";

               }
           }


           if (i > 0)
           {
               lblmsg.Text = "Information Saved Sucessfully!!!!!";

           }




    }


    protected void rdoindiextend_CheckedChanged(object sender, EventArgs e)
    {
        Panel7.Visible = false;
        Panel8.Visible = true;
    }
    protected void rdoextend_CheckedChanged1(object sender, EventArgs e)
    {
        Panel7.Visible = true;
        Panel8.Visible = false;
    }
    protected void rdoexwithfine_CheckedChanged(object sender, EventArgs e)
    {
        lblfine.Visible = true;
        txtfine.Visible = true;
    }
    protected void rdoexwithoutfine_CheckedChanged(object sender, EventArgs e)
    {
        lblfine.Visible = false;
        txtfine.Visible = false;

    }
    protected void rdoexiwithfine_CheckedChanged(object sender, EventArgs e)
    {
        lblindfine.Visible = true;
        txtindfine.Visible = true;
    }
    protected void rdoexiwithoutfine_CheckedChanged(object sender, EventArgs e)
    {
        lblindfine.Visible = false;
        txtindfine.Visible = false;
    }
    protected void btnextend_Click(object sender, EventArgs e)
    {
        int i = 0;
        decimal amount;
        string session = month1.SelectedItem.ToString() + "-" + month2.SelectedItem.ToString() + "_" + Year3.SelectedItem.ToString();
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.Connection = con;
                         
        // fot individual
        if (rdoindiextend.Checked)
        {
            if (rdoexiwithfine.Checked)
            {
                amount = Convert.ToDecimal(txtindfine.Text);

                string query = "insert into registrationExtend(Rollno,ExamSession,regtype,amount,cid,ctime,Extended) values('" + txtroll.Text.Trim() + "','" + session + "','With Fine '," + amount + ",'" + Session["userid"].ToString() + "',GetDate())";
                cmd.CommandText = query;
                con.Open();
                i = cmd.ExecuteNonQuery();
                con.Close();
            }
            else if (rdoexiwithoutfine.Checked)
            {
                string query = "insert into registrationExtend(Rollno,ExamSession,regtype,amount,cid,ctime,Extended) values('" + txtroll.Text.Trim() + "','" + session + "','Default',0,'" + Session["userid"].ToString() + "',GetDate())";
                cmd.CommandText = query;
                con.Open();
                i = cmd.ExecuteNonQuery();
                con.Close();
            }
        }
            // for exam date extended
        else if (rdoextend.Checked )
        {
            DateTime enddate = Convert.ToDateTime(txtexenddate.Text.Trim());
            string edate = enddate.ToString("yyyy-MM-dd");
    
            if (rdoexwithfine.Checked)
            {
               amount = Convert .ToInt32(txtfine .Text.Trim());
               string query = "insert into registrationActivate(examsession,regtype,stratdate,enddate,amount,cid,ctime,Extended) values('" + session + "','With Fine ','','" + edate + "'," + amount + ",'" + Session["userid"].ToString() + "',GetDate(),'Y')";
                cmd.CommandText = query;
                con.Open();
                i = cmd.ExecuteNonQuery();
                con.Close();

            }
            else if (rdoexwithoutfine.Checked)
            {
                string query = "insert into registrationActivate(examsession,regtype,stratdate,enddate,amount,cid,ctime,Extended) values('" + session + "','Without Fine ','','" + edate + "',0,'" + Session["userid"].ToString() + "',GetDate(),'Y')";
                cmd.CommandText = query;
                con.Open();
                i = cmd.ExecuteNonQuery();
                con.Close();
            }
        }


    }

    private void bindpredata()
    {
        string session = month1.SelectedItem.ToString() + "-" + month2.SelectedItem.ToString() + "_" + Year3.SelectedItem.ToString();
        DataTable dtactivationdata = fnrev.SelectDatatable("SELECT id,ExamSession,regtype,convert(varchar,stratdate,103) As stratdate,convert(varchar,enddate,103) As enddate,amount FROM registrationActivate WHERE ExamSession = '" + session + "' order by amount");
        if (dtactivationdata.Rows.Count > 0)
        {
            for (int i = 0; i < dtactivationdata.Rows.Count; i++)
            {
                if (i == 0)
                {
                    txtstartdate.Text = dtactivationdata.Rows[i]["stratdate"].ToString();
                    txtenddate.Text = dtactivationdata.Rows[i]["enddate"].ToString();
                }
                else if (i == 1)
                {
                    txtstartdate2.Text = dtactivationdata.Rows[i]["stratdate"].ToString();
                    txtenddate2.Text = dtactivationdata.Rows[i]["enddate"].ToString();
                    txtamout2.Text = dtactivationdata.Rows[i]["amount"].ToString();
                }
                else if (i == 2)
                {
                    txtstartdate3.Text = dtactivationdata.Rows[i]["stratdate"].ToString();
                    txtenddate3.Text = dtactivationdata.Rows[i]["enddate"].ToString();
                    Ttxtamout4.Text = dtactivationdata.Rows[i]["amount"].ToString();
                }
                else if (i == 3)
                {
                    txtstartdate4.Text = dtactivationdata.Rows[i]["stratdate"].ToString();
                    txtenddate4.Text = dtactivationdata.Rows[i]["enddate"].ToString();
                    txtamout5.Text = dtactivationdata.Rows[i]["amount"].ToString();
                }

            }


        }
        
    }
    protected void Year3_SelectedIndexChanged(object sender, EventArgs e)
    {
        bindpredata();
    }
}

    
