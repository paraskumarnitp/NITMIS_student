using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.Reporting.WebForms; 

public partial class RegIndexRegister : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "3")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(Year, "Year", "Select Year from Year where year >= '2008' order by Year", "Year", "Year");
            popddl.Popualate(CollName, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
        }

        

    }
    protected void BtnView_Click(object sender, EventArgs e)
    {



        
        Panel1.Visible = true;
        
        if (RadioButton1.Checked)//registered
        {
            CR.ReportSource = crs;
            CR.SelectionFormula = @"{REGISTRATION.RegNo}<>'' And {REGISTRATION.RegYear}='" + Year.SelectedValue + "' And {REGISTRATION.CollCode}='" + CollName.SelectedValue + "'";
              
        }
        else if (RadioButton2.Checked)//rejected
        {
            CR.ReportSource = crs3; 
            CR.SelectionFormula = @"isnull({REGISTRATION.RegNo})  And {REGISTRATION.RegYear}='" + Year.SelectedValue + "' And {REGISTRATION.CollCode}='" + CollName.SelectedValue + "'";
        }
        else if (RadioButton3.Checked)//all 
        {
            CR.ReportSource = crs;
            CR.SelectionFormula = " {REGISTRATION.RegYear}='" + Year.SelectedValue + "' And {REGISTRATION.CollCode}='" + CollName.SelectedValue + "'";
        }
        else if (RadioButton4.Checked)//all for univ.
        {
            CR.ReportSource = crs2;
            CR.SelectionFormula = " {REGISTRATION.RegYear}='" + Year.SelectedValue + "'";
        }
        else if (RadioButton5.Checked)// Reg Fee Details
        {
            CR.ReportSource = crs4;
            CR.SelectionFormula = " {REGISTRATION.RegYear}='" + Year.SelectedValue + "' And {REGISTRATION.CollCode}='" + CollName.SelectedValue + "'";
        }
        

        
        CR.RefreshReport();
       
        

        //ReportParameter[] rp;
        //rp = new ReportParameter[1];
        ////rp = new ReportParameter[2];
        //rp[0] = new ReportParameter("year", Year.SelectedValue);
        //if (RadioButton1.Checked)
        //{
        //    RV.ServerReport.ReportPath = "/UniversityReport/RegIndexRegister";
        //    RV.ServerReport.SetParameters(rp);

        //}
        //else if (RadioButton2.Checked)//rejected
        //{
        //    RV.ServerReport.ReportPath = "/UniversityReport/RejectedIndexRegister";
        //    RV.ServerReport.SetParameters(rp);

        //}
        //else//all
        //{
        //    RV.ServerReport.ReportPath = "/UniversityReport/AllIndexRegister";
        //    RV.ServerReport.SetParameters(rp);

        //}
            
    }
    protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollName.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollName.SelectedIndex = 0;
        }
    }
    protected void CollName_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollName.SelectedValue.ToString();
    }
}
