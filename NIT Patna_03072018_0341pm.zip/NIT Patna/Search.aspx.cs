using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class Search : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() == "")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        GridBind(); 
        
    }

    void GridBind()
    {
        Panel2.Visible = true;
        DataSet ds = new DataSet();
        
        if ( (TxtRegNo.Text.Trim()=="") && (TxtSidNo.Text.Trim()==""))
        {
            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "SELECT AckNo,RegNo,ApplicantName,FatherName,DOB,StreamCode,CollCode,CourseSession,RegYear FROM REGISTRATION where ApplicantName like '%" + TxtName.Text.Trim() + "%'  ORDER BY CollCode, RegYear");
        }
        else if ((TxtName.Text.Trim() == "") && (TxtSidNo.Text.Trim() == ""))

        {

            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "SELECT AckNo,RegNo,ApplicantName,FatherName,DOB,StreamCode,CollCode,CourseSession,RegYear FROM REGISTRATION where Regno like '%" + TxtRegNo.Text.Trim() + "%'  ORDER BY CollCode, RegYear");
        }

        else if ((TxtName.Text.Trim() == "") && (TxtRegNo.Text.Trim() == ""))
        {

            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "SELECT AckNo,RegNo,ApplicantName,FatherName,DOB,StreamCode,CollCode,CourseSession,RegYear FROM REGISTRATION where ackno like '%" + TxtSidNo.Text.Trim() + "%'  ORDER BY CollCode, RegYear");
        }

        else
        {
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "SELECT AckNo,RegNo,ApplicantName,FatherName,DOB,StreamCode,CollCode,CourseSession,RegYear FROM REGISTRATION where ApplicantName like '%" + TxtName.Text.Trim() + "%' OR Regno like '%" + TxtRegNo.Text.Trim() + "%' OR ackno='%" + TxtSidNo.Text.Trim() + "%' ORDER BY CollCode, RegYear");
        }
        
        
        SearchView.PageSize = int.Parse(DDLDisplay.SelectedValue.ToString());
        SearchView.DataSource = ds;
        SearchView.DataBind();

    }

    protected void SearchView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        SearchView.PageIndex = e.NewPageIndex;
        GridBind();
    }
}
