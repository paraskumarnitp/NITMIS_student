using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.Collections.Generic;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Text.RegularExpressions;

public partial class MarksEntryDetails2 : System.Web.UI.Page
{
    ReportDocument crystalReport = new ReportDocument();
    string criteria = "false";
    string Subcode;
    DataSet dsmarksdata;
    Functionreviseed fn = new Functionreviseed();
    string ThFMarks, PractFMarks;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            Session["checkclear"] = criteria;
            try
            {

                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "9") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "15"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }

                ViewState.Add("EditMode", "false");

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }


            UnivService.Service1 NicService = new UnivService.Service1();
            int status = Convert.ToInt32(NicService.GetNewCode("select count(Enabled) from Faculty_paper_a where Userid='" + Session["userid"] + "' and Enabled='Y'"));

            if (status <= 0)
            {

                string msg = "Marks Entry has been DISABLED by Exam Section, NIT Patna. Please contact Exam Section, NIT Patna !!!";
                string popupScript = "<script language='javascript'>" +
                                   " alert('" + msg + " ')" +
                                    "</script>";
                Page.RegisterClientScriptBlock("PopupScript", popupScript);
                Response.Redirect("home.aspx");
                return;
            }
            else
            {
                string strrole = "";
                if (Session["Role"].ToString() == "9")
                    strrole = " and UserId='" + Session["UserId"].ToString() + "'";

                PopulateDDL popddl = new PopulateDDL();


                popddl.Popualate(ExamYear, "Year", "select distinct ExamSession from Faculty_paper_a where is_active='Y'  order by ExamSession desc", "ExamSession", "ExamSession");
                ExamYear.Items.Insert(0, new ListItem("--Select--", "00"));
                StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
                StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
                splcode.Items.Insert(0, new ListItem("--Select--", "00"));
                Subject.Items.Insert(0, new ListItem("--Select--", "00"));
            }
            //  ExamYear.Focus();
        }      

    }

    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        MTheory.Checked = false;
        // RBComp.Checked=false ;
        //MElective.Checked=false ;
        //MThPr.Checked=false ;
        MPrac.Checked = false;
        StreamPart.Items.Clear();
        Subject.Items.Clear();
        splcode.Items.Clear();
        string strrole = "";
        if (Session["Role"].ToString() == "9" || Session["Role"].ToString() == "13")
            strrole = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";
        PopulateDDL popddl = new PopulateDDL();
        string strspecilaization = "SELECT     CourseSpecialization.SpDescription, CourseSpecialization.SPCode " +
                                   " FROM Faculty_paper_a INNER JOIN COURSEPAPERS ON " +
                                   " Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " +
                                   " CourseSpecialization ON Faculty_paper_a.Splcode = CourseSpecialization.SPCode " +
                                   " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                                   " and COURSEPAPERS.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                                   " GROUP BY CourseSpecialization.SpDescription, CourseSpecialization.SPCode " +
                                   " order by CourseSpecialization.SPCode ";

        popddl.Popualate(splcode, "Specialization", strspecilaization, "SpDescription", "SPCode");
        string strstreampart = "SELECT     STREAMPART.StreamPart,STREAMPART.StreamPartCode " +
                             " FROM         COURSEPAPERS AS COURSEPAPERS_1 INNER JOIN " +
                             " STREAMPART ON COURSEPAPERS_1.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN " +
                             " Faculty_paper_a INNER JOIN " +
                             " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode ON COURSEPAPERS_1.PaperAbbr = COURSEPAPERS.PaperAbbr " +
                             " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                             " and (Faculty_paper_a.splcode='" + splcode.SelectedValue + "') and STREAMPART.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                             " GROUP BY STREAMPART.StreamPartCode, STREAMPART.StreamPart " +
                             " order by StreamPart";


        popddl.Popualate(StreamPart, "StreamPart", strstreampart, "StreamPart", "StreamPartCode");
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
        StreamCode.Focus();
    }
    protected void MTheory_CheckedChanged(object sender, EventArgs e)
    {
        Subject.Items.Clear();
        if (Viva.Checked != true)
            GetPaperCode("T");
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
    }
    //protected void MThPr_CheckedChanged(object sender, EventArgs e)
    //{
    //    GetPaperCode("X");

    //}
    ///*protected void RBComp_CheckedChanged(object sender, EventArgs e)
    //{
    //    GetPaperCode("Comp");
    //}*/
    //protected void MElective_CheckedChanged(object sender, EventArgs e)
    //{
    //    GetPaperCode("E");
    //}
    protected void MPrac_CheckedChanged(object sender, EventArgs e)
    {
        Subject.Items.Clear();
        GetPaperCode("P");
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
    }

    private void GetPaperCode(string PaperType)
    {

        string Querystr = "";
        string queryjoin = "";

        //if (StreamPart.SelectedItem.ToString().IndexOf('A') > 0 || StreamPart.SelectedItem.ToString().IndexOf('B') > 0)
        //{
        //    Querystr = " (COURSEPAPERS.StreamPart = '" + StreamPart.SelectedItem.ToString() + "')";
        //    queryjoin = "COURSEPAPERS_1.PaperAbbr = COURSEPAPERS.PaperAbbr";
        //}
        //else
        //{
        Querystr = " (COURSEPAPERS.StreamPartCode='" + StreamPart.SelectedValue + "')";
        queryjoin = "COURSEPAPERS_1.SubPaperCode = COURSEPAPERS.SubPaperCode";
        //}

        string strrole = "";
        if (Session["Role"].ToString() == "9")
            strrole = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";

        string strcourse = "SELECT     COURSEPAPERS.PaperAbbr " +
                           " FROM         Faculty_paper_a INNER JOIN COURSEPAPERS AS COURSEPAPERS_1 ON " +
                           " Faculty_paper_a.SubPaperCode = COURSEPAPERS_1.SubPaperCode INNER JOIN COURSEPAPERS " +
                            " ON " + queryjoin + " INNER JOIN " +
                            " EXAMPAPERDETAIL ON COURSEPAPERS.SubPaperCode = EXAMPAPERDETAIL.SubPaperCode " +
                          " WHERE     (Faculty_paper_a.Is_Active = 'Y')   And (Faculty_paper_a.splcode = '" + splcode.SelectedValue + "') " + strrole +
                          " and" + Querystr + " and  (EXAMPAPERDETAIL.ExamSession='" + ExamYear.SelectedValue + "') and ";

        string querypart = " GROUP BY COURSEPAPERS.PaperAbbr ORDER BY COURSEPAPERS.PaperAbbr ";

        PopulateDDL popddl = new PopulateDDL();
        UnivService.Service1 NicService = new UnivService.Service1();
        Subcode = NicService.GetNewCode("select subcode from subject where streamcode='" + StreamCode.SelectedValue + "'");


        if (PaperType == "T")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "(COURSEPAPERS.PaperTypeCode='02' or COURSEPAPERS.PaperTypeCode='04') and (Faculty_paper_a.PaperType='T' or Faculty_paper_a.PaperType is null)" + querypart, "PaperAbbr", "PaperAbbr");
        }
        else if (PaperType == "X")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "PaperTypeCode='04'" + querypart, "PaperAbbr", "PaperAbbr");
        }
        else if (PaperType == "P")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "(COURSEPAPERS.PaperTypeCode='01' or COURSEPAPERS.PaperTypeCode='04') and (Faculty_paper_a.PaperType='P' or Faculty_paper_a.PaperType is null)" + querypart, "PaperAbbr", "PaperAbbr");
        }
        else if (PaperType == "E")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "PaperTypeCode='03'" + querypart, "PaperAbbr", "PaperAbbr");
        }

        //  GetMarks();
        Subject.Focus();
    }
    /*protected void SubCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        MTheory.Checked = false;
     //   RBComp.Checked = false;
        MElective.Checked = false;
        MThPr.Checked = false;
        MPrac.Checked = false;
        Subject.Items.Clear();
    }*/

    bool HasRecords(DataSet dataSet)
    {
        foreach (DataTable dt in dataSet.Tables) if (dt.Rows.Count > 0) return true;
        return false;
    }
    String papertype;
    // bool checkclear = false;
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Panel3.Enabled = true;

        panelinterthpract.Visible = false;

        savecommandgr8.Visible = false;
        MTheory.Checked = false;
        MPrac.Checked = false;
        PaperMarks.Text = "";
        //SelectedPaperList.Items.Clear();
        //criteria = "true";
        //Session["checkclear"] = criteria;
        //string sess = Session["checkclear"].ToString();
        dsmarksdata = null;
        Gr8.DataSource = dsmarksdata;
        Gr8.DataBind();
        btnprint.Visible = false;
        //Gr8.Columns.Clear();
        // Gr8.EmptyDataText = "";
        LblMsg.Text = "";
        //criteria = "false";
        //Session["checkclear"] = criteria;
        //sess = Session["checkclear"].ToString();
    }



    protected void MarksGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        // MarksGrid.PageIndex = e.NewPageIndex;
        // BindGrid();
    }
    //protected void Button2_Click(object sender, EventArgs e)
    //{
    //    //if (RBComp.Checked || MElective.Checked || MPrac.Checked)
    //        if ( MElective.Checked || MPrac.Checked)
    //    {
    //        SelectedPaperList.Items.Add(StreamPart.SelectedValue + "-" + Subject.SelectedValue + "(" + StreamCode.SelectedItem.Text + "-" + StreamPart.SelectedItem.Text + "-" + Subject.SelectedItem.Text + ")");
    //    }
    //}



    //protected void Button3_Click(object sender, EventArgs e)
    //{
    //    SelectedPaperList.Items.Clear();
    //}

    int l, rcount;

    int Insdata;

    protected void Button1_Click(object sender, EventArgs e)
    {

        bindgrid();

        if (Internal.Checked == true && MTheory.Checked == true)
        {
            Panel3.Enabled = false;

            //code for grid internal .....

        }
        else if (Internal.Checked == true && MPrac.Checked == true)
        {
            Panel3.Enabled = false;

        }

        else if (EndSem.Checked == true && MTheory.Checked == true)
        {
            Panel3.Enabled = false;

        }
        else if (EndSem.Checked == true && MPrac.Checked == true)
        {
            Panel3.Enabled = false;

        }

        else if (Viva.Checked == true && MTheory.Checked == true)
        {
            Panel3.Enabled = false;

        }
        else if (Viva.Checked == true && MPrac.Checked == true)
        {
            Panel3.Enabled = false;

        }


    }
    string ct1absent = "", ct2absent = "", ctabsentvalue = "";
    protected void Gr8_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

        // Code for check absent in ct1 and ct2------
        ct1absent = Convert.ToString(((CheckBox)Gr8.Rows[e.RowIndex].FindControl("chkct1absent")).Checked);

        ct2absent = Convert.ToString(((CheckBox)Gr8.Rows[e.RowIndex].FindControl("chkct2absent")).Checked);
        if (Internal.Checked == true)
        {
            if (ct1absent == "True" && ct2absent == "True")
            {
                ctabsentvalue = "A-CT";
            }
            else if (ct1absent == "True" && ct2absent == "False")
            {
                ctabsentvalue = "A-CT1";
            }
            else if (ct2absent == "True" && ct1absent == "False")
            {
                ctabsentvalue = "A-CT2";
            }
        }
        string univroll = Convert.ToString(((Label)Gr8.Rows[e.RowIndex].FindControl("Labelregno")).Text);
        string ct1 = Convert.ToString(((TextBox)Gr8.Rows[e.RowIndex].FindControl("thprClasstest1")).Text);
        string ct2 = Convert.ToString(((TextBox)Gr8.Rows[e.RowIndex].FindControl("thprClasstest2")).Text);
        string midsem = Convert.ToString(((TextBox)Gr8.Rows[e.RowIndex].FindControl("thprmidsem")).Text);

        string thendsem = Convert.ToString(((TextBox)Gr8.Rows[e.RowIndex].FindControl("txtendsemth")).Text);
        string abstatus = Convert.ToString(((Label)Gr8.Rows[e.RowIndex].FindControl("lblabsent")).Text);
        string checkvalue = Convert.ToString(((CheckBox)Gr8.Rows[e.RowIndex].FindControl("ckhabsent")).Checked);
        if (EndSem.Checked == true)
        {
            if (abstatus == "" && checkvalue == "True")
            {
                abstatus = "AE";
            }
            else if (abstatus == "AM" && checkvalue == "True")
            {
                abstatus = "A";
            }
        }
        else if (Internal.Checked == true)
        {
            if (abstatus == "" && checkvalue == "True")
            {
                abstatus = "AM";
            }
            else if (abstatus == "AM" && checkvalue == "True")
            {
                abstatus = "A";
            }
        }

        string prrecd = Convert.ToString(((TextBox)Gr8.Rows[e.RowIndex].FindControl("Practicalrecord1")).Text);
        string prclperfrecd = Convert.ToString(((TextBox)Gr8.Rows[e.RowIndex].FindControl("Practclassperformance1")).Text);
        string prendsemviva = Convert.ToString(((TextBox)Gr8.Rows[e.RowIndex].FindControl("PracticalPreendsemviva1")).Text);
        string PREndSem = Convert.ToString(((TextBox)Gr8.Rows[e.RowIndex].FindControl("txtendsempr")).Text);



        string Querystr = "";

        if (StreamPart.SelectedItem.ToString().IndexOf('A') > 0 || StreamPart.SelectedItem.ToString().IndexOf('B') > 0)
        {
            Querystr = " (COURSEPAPERS.StreamPart = '" + StreamPart.SelectedItem.ToString() + "')";

        }
        else
        {
            Querystr = " (COURSEPAPERS.StreamPartCode='" + StreamPart.SelectedValue + "')";

        }


        int Insdata = fn.InsertUpdateDelete("Update EXAMPAPERDETAIL set ClassTest1='" + ct1 + "', ClassTest2='" + ct2 + "', IsAppeared='" + ctabsentvalue + "', " +
            " Midsem='" + midsem + "',THEndsem = '" + thendsem + "', StudentStatus = '" + abstatus + "', PracticalRecord='" + prrecd + "', " +
            " PrClassPerfor='" + prclperfrecd + "', Prpreendsemviva='" + prendsemviva + "', PREndSem = '" + PREndSem + "', opt1='" + Session["UserId"].ToString() + "'," +
            " EntryDate2 = getdate() FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode " +
            " WHERE EXAMPAPERDETAIL.UnivRollNo = '" + univroll + "' AND " +
            " COURSEPAPERS.PaperAbbr = '" + Subject.SelectedValue + "' AND EXAMPAPERDETAIL.ExamSession = '" + ExamYear.SelectedValue + "' AND" + Querystr);



        if (Insdata == 0)
        {
            string msg = " Could Not Saved!!!. ";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
        }
        else
        {
            string msg = " Marks Saved!!!. ";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            //int l = e.RowIndex + 1;


        }
    }

    protected void Subject_SelectedIndexChanged(object sender, EventArgs e)
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        if (MTheory.Checked == true)
            PaperMarks.Text = NicService.GetNewCode("select FullMarks from Coursepapers where PaperAbbr='" + Subject.SelectedValue + "' and StreamPartCode='" + StreamPart.SelectedValue + "'");
        else
            PaperMarks.Text = NicService.GetNewCode("select case when (COURSEPAPERS.PaperTypeCode='01') then " +
                              " COURSEPAPERS.FullMarks else PRACTICALPAPERS.FullMarks end as FullMarks FROM         COURSEPAPERS LEFT OUTER JOIN " +
                              " PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode  where Coursepapers.PaperAbbr='" + Subject.SelectedValue + "' and Coursepapers.StreamPartCode='" + StreamPart.SelectedValue + "'");                
    }

    protected void bindgrid()
    {
        if (MTheory.Checked == true)
        {
            papertype = "(EXAMPAPERDETAIL.papertype='T' OR EXAMPAPERDETAIL.papertype='X') ";
        }
        //else if (MThPr.Checked == true)
        //{
        //    papertype = "X";
        //}
        else if (MPrac.Checked == true)
        {
            papertype = "(EXAMPAPERDETAIL.papertype='P' OR EXAMPAPERDETAIL.papertype='X')";
        }
        ViewState["papertype"] = papertype;

        string Querystr = "(COURSEPAPERS.StreamPartCode='" + StreamPart.SelectedValue.ToString() + "')";

        // removed code for group wise diaplay in marks entry -----------

        /*if (StreamPart.SelectedItem.ToString().IndexOf('A') > 0 || StreamPart.SelectedItem.ToString().IndexOf('B') > 0)
        {
            Querystr = " (COURSEPAPERS.StreamPart = '" + StreamPart.SelectedItem.ToString() + "' )";
        }
        else
        {
            Querystr = "(COURSEPAPERS.StreamPartCode='" + StreamPart.SelectedValue + "')";

        } */
        string joins = "";
        if (Session["Role"].ToString() == "9")
        {
            joins = " AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";
        }
        string strexamtype = "";
        if (Internal.Checked == true || Viva.Checked == true)
        {
            strexamtype = " AND (EXAMPAPERDETAIL.ExamType!='N') ";
        }
        else
        {
            strexamtype = " AND ((Attendance.status='P' and EXAMPAPERDETAIL.ExamType!='N') or (Attendance.status is null and EXAMPAPERDETAIL.ExamType IN ('H','N'))) ";
        }

        string stry = MTheory.Checked == true ? "T" : "P";
        if (Internal.Checked == true || EndSem.Checked == true || Viva.Checked == true)
        {
            /*dsmarksdata = fn.SelectDataset("WITH cte AS (SELECT EXAMPAPERDETAIL.UnivRollNo, EXAMPAPERDETAIL.ClassTest1, EXAMPAPERDETAIL.ClassTest2, " +
                " EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem, EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor, EXAMPAPERDETAIL.PREndSem, " +
                " EXAMPAPERDETAIL.Prpreendsemviva, EXAMPAPERDETAIL.StudentStatus, REGISTRATION.AdmYear, STREAM.StreamTypeCode, EXAMPAPERDETAIL.ExamType, " +
                " Faculty_paper_a.Is_Active, Faculty_paper_a.PaperType, Faculty_paper_a.UserId FROM REGISTRATION INNER JOIN EXAMPAPERDETAIL INNER JOIN " +
                " COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode ON REGISTRATION.RegNo = EXAMPAPERDETAIL.RegNo INNER JOIN STREAM ON " +
                " REGISTRATION.StreamCode = STREAM.StreamCode LEFT OUTER JOIN Attendance ON EXAMPAPERDETAIL.RegNo = Attendance.RegNo AND EXAMPAPERDETAIL.StreamPartCode = " +
                " Attendance.StreamPartCode AND EXAMPAPERDETAIL.SubPaperCode = Attendance.SubPaperCode AND EXAMPAPERDETAIL.ExamSession = Attendance.ExamSession " +
                " INNER JOIN Faculty_paper_a ON COURSEPAPERS.SubPaperCode = Faculty_paper_a.SubPaperCode AND Faculty_paper_a.ExamSession = EXAMPAPERDETAIL.ExamSession " +
                " AND Faculty_paper_a.Splcode = ISNULL(REGISTRATION.SplCode, '00') WHERE (EXAMPAPERDETAIL.ExamSession = '" + ExamYear.SelectedValue + "') AND (COURSEPAPERS.PaperAbbr = '" + Subject.SelectedValue + "') " +
                " AND (ISNULL(REGISTRATION.SplCode, '00') = '" + splcode.SelectedValue + "') AND " + Querystr + " AND " + papertype + " " +
                " AND (Attendance.status = 'P') AND (EXAMPAPERDETAIL.ExamType <> 'N') OR (EXAMPAPERDETAIL.ExamSession = '" + ExamYear.SelectedValue + "') AND (COURSEPAPERS.PaperAbbr = '" + Subject.SelectedValue + "') " +
                " AND (ISNULL(REGISTRATION.SplCode, '00') = '00') AND " + Querystr + " AND " + papertype + " " +
                " AND (Attendance.status IS NULL) AND (EXAMPAPERDETAIL.ExamType = 'N')) SELECT UnivRollNo, ClassTest1, ClassTest2, Midsem, THEndsem, PracticalRecord, " +
                " PRClassPerfor, PREndSem, Prpreendsemviva, StudentStatus, AdmYear, StreamTypeCode, ExamType FROM cte AS cte_1 WHERE (Is_Active = 'Y') AND " +
                " (ISNULL(PaperType, 'T') = 'T') AND (UserId = 'fc005')");*/

            dsmarksdata = fn.SelectDataset(" with cte as (SELECT  EXAMPAPERDETAIL.UnivRollNo, EXAMPAPERDETAIL.ClassTest1, EXAMPAPERDETAIL.ClassTest2, EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem, " +
                             " EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor, EXAMPAPERDETAIL.PREndSem, EXAMPAPERDETAIL.Prpreendsemviva, " +
                             " EXAMPAPERDETAIL.StudentStatus, REGISTRATION.AdmYear, STREAM.StreamTypeCode,EXAMPAPERDETAIL.ExamType,EXAMPAPERDETAIL.Grade " +
                             " FROM         REGISTRATION INNER JOIN " +
                             " EXAMPAPERDETAIL INNER JOIN " +
                             " COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode ON REGISTRATION.RegNo = EXAMPAPERDETAIL.RegNo INNER JOIN " +
                             " STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode LEFT OUTER JOIN " +
                            " Attendance ON EXAMPAPERDETAIL.RegNo = Attendance.RegNo AND EXAMPAPERDETAIL.StreamPartCode = Attendance.StreamPartCode AND  " +
                            " EXAMPAPERDETAIL.SubPaperCode = Attendance.SubPaperCode AND EXAMPAPERDETAIL.ExamSession = Attendance.ExamSession " +
                             " INNER JOIN Faculty_paper_a on  COURSEPAPERS.SubPaperCode=Faculty_paper_a.subpapercode and Faculty_paper_a.examsession=EXAMPAPERDETAIL.ExamSession and Faculty_paper_a.splcode=ISNULL(REGISTRATION.SplCode,'00') " +
                            " WHERE EXAMPAPERDETAIL.ExamSession = '" + ExamYear.SelectedValue + "' AND " +
                            " COURSEPAPERS.PaperAbbr = '" + Subject.SelectedValue + "' AND ISNULL(REGISTRATION.SplCode,'00')='" + splcode.SelectedValue + "' and Faculty_paper_a.Is_Active='Y' and case when Faculty_paper_a.PaperType IS not null then Faculty_paper_a.PaperType else '" + stry + "' end ='" + stry + "' AND " +
                            Querystr + joins + " AND " + papertype + strexamtype + " ) SELECT * FROM CTE order by Univrollno");
            if (dsmarksdata.Tables[0].Rows.Count > 0)
            {
                btnprint.Visible = true;
                panelinterthpract.Visible = true;
                savecommandgr8.Visible = true;
                Gr8.DataSource = dsmarksdata.Tables[0];
                Gr8.DataBind();
                LblMsg.Text = "";

            }
            else
            {
                LblMsg.Text = "<b style=" + "Font-size:13px;" + ">Record(S) not found according to above criteria!";
            }
        }

    }
    //protected void Gr8_RowCreated(object sender, GridViewRowEventArgs e)
    //{


    //}

    protected void Gr8_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //string sess = Session["checkclear"].ToString();
        //if ( Session["checkclear"].ToString() == "false")
        //{

        if (dsmarksdata != null)
        {
            //if (e.Row.DataItemIndex > -2)
            //{
            if (Gr8.Rows.Count >= 0)
            {
                if (Internal.Checked == true && MTheory.Checked == true)
                {

                    Panel3.Enabled = false;
                    e.Row.Cells[7].Visible = false;
                    e.Row.Cells[8].Visible = false;
                    e.Row.Cells[9].Visible = false;
                    e.Row.Cells[10].Visible = false;
                    e.Row.Cells[11].Visible = false;
                    e.Row.Cells[12].Visible = false;
                    e.Row.Cells[14].Visible = false;

                }

                else if (Internal.Checked == true && MPrac.Checked == true)
                {
                    Panel3.Enabled = false;
                    e.Row.Cells[2].Visible = false;
                    e.Row.Cells[3].Visible = false;
                    e.Row.Cells[4].Visible = false;
                    e.Row.Cells[5].Visible = false;
                    e.Row.Cells[6].Visible = false;
                    e.Row.Cells[7].Visible = false;
                    e.Row.Cells[8].Visible = false;
                    e.Row.Cells[11].Visible = false;
                    e.Row.Cells[12].Visible = false;
                    e.Row.Cells[13].Visible = false;
                    e.Row.Cells[14].Visible = false;
                }
                else if (EndSem.Checked == true && MTheory.Checked == true)
                {
                    Panel3.Enabled = false;
                    e.Row.Cells[2].Visible = true;
                    e.Row.Cells[2].Enabled = false;
                    e.Row.Cells[3].Visible = false;
                    e.Row.Cells[4].Visible = true;
                    e.Row.Cells[4].Enabled = false;
                    e.Row.Cells[5].Visible = false;
                    e.Row.Cells[6].Visible = true;
                    e.Row.Cells[6].Enabled = false;
                    e.Row.Cells[8].Visible = false;
                    e.Row.Cells[9].Visible = false;
                    e.Row.Cells[10].Visible = false;
                    e.Row.Cells[11].Visible = false;
                    e.Row.Cells[12].Visible = false;
                    e.Row.Cells[14].Visible = true;
                }
                //else if (EndSem.Checked == true && MThPr.Checked == true)
                //{
                //    Panel3.Enabled = false;
                //    e.Row.Cells[2].Visible = false;
                //    e.Row.Cells[3].Visible = false;
                //    e.Row.Cells[4].Visible = false;
                //    e.Row.Cells[6].Visible = false;
                //    e.Row.Cells[7].Visible = false;
                //    e.Row.Cells[8].Visible = false;
                //    e.Row.Cells[9].Visible = false;
                //}
                else if (EndSem.Checked == true && MPrac.Checked == true)
                {
                    Panel3.Enabled = false;
                    e.Row.Cells[2].Visible = false;
                    e.Row.Cells[3].Visible = false;
                    e.Row.Cells[4].Visible = false;
                    e.Row.Cells[5].Visible = false;
                    e.Row.Cells[6].Visible = false;
                    e.Row.Cells[7].Visible = false;
                    e.Row.Cells[8].Visible = false;
                    e.Row.Cells[9].Visible = false;
                    e.Row.Cells[10].Visible = false;
                    e.Row.Cells[11].Visible = false;
                    e.Row.Cells[13].Visible = false;
                    e.Row.Cells[14].Visible = true;

                }
                else if (Viva.Checked == true && MTheory.Checked == true)
                {
                    Panel3.Enabled = false;
                    e.Row.Cells[2].Visible = false;
                    e.Row.Cells[3].Visible = false;
                    e.Row.Cells[4].Visible = false;
                    e.Row.Cells[5].Visible = false;
                    e.Row.Cells[6].Visible = false;
                    e.Row.Cells[7].Visible = false;
                    e.Row.Cells[8].Visible = false;
                    e.Row.Cells[9].Visible = false;
                    e.Row.Cells[10].Visible = false;
                }
                else if (Viva.Checked == true && MPrac.Checked == true)
                {
                    Panel3.Enabled = false;
                    e.Row.Cells[2].Visible = false;
                    e.Row.Cells[3].Visible = false;
                    e.Row.Cells[4].Visible = false;
                    e.Row.Cells[5].Visible = false;
                    e.Row.Cells[6].Visible = false;
                    e.Row.Cells[7].Visible = false;
                    e.Row.Cells[8].Visible = false;
                    e.Row.Cells[9].Visible = false;
                    e.Row.Cells[10].Visible = false;
                    e.Row.Cells[12].Visible = false;
                    e.Row.Cells[13].Visible = false;
                    e.Row.Cells[14].Visible = true;
                }


            }
            //}
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string examsess = "01-" + ExamYear.SelectedValue.Substring(4, 3) + "-" + ExamYear.SelectedValue.Substring(8, 4);
                DataRowView rowView = (DataRowView)e.Row.DataItem;
                double totalmarks = string.IsNullOrEmpty(PaperMarks.Text) ? 0 : double.Parse(PaperMarks.Text);
                int admYear = int.Parse(rowView["AdmYear"].ToString());
                if (rowView["ExamType"].ToString() == "N")
                {
                    string regNo;
                    string examSession;
                    if (rowView["StreamTypeCode"].ToString() != "02")
                    {
                        regNo = (string)fn.singlevalue("select distinct regNo from cgpa where UnivRollNo='" + rowView["UnivRollNo"].ToString() + "'");
                        examSession = (string)fn.singlevalue("select ExamSession from TrBtec a inner join CoursePapers b on a.subpapercode=b.subpapercode where b.PaperAbbr='" + Subject.SelectedValue + "' and examtype in ('B') and  RegNo='" + regNo + "'");
                    }
                    else
                    {
                        regNo = (string)fn.singlevalue("select distinct regNo from cgpa_Mtec where UnivRollNo='" + rowView["UnivRollNo"].ToString() + "'");
                        examSession = (string)fn.singlevalue("select ExamSession from TrMtec a inner join CoursePapers b on a.subpapercode=b.subpapercode where b.PaperAbbr='" + Subject.SelectedValue + "' AND examtype in ('B')  and RegNo='" + regNo + "'");
                    }
                    if (examSession == null)
                    {
                        examSession = ExamYear.SelectedValue;
                    }



                    int numbers = int.Parse(Regex.Replace(StreamPart.SelectedItem.ToString(), "[^.0-9]", ""));
                    if (((examSession.Substring(0, 7) == "JUL-DEC") && numbers % 2 == 0) || (examSession.Substring(0, 7) == "SMR-JUL") && numbers % 2 != 0)
                    {
                        numbers = numbers + 1;
                    }


                    admYear = int.Parse(examSession.Substring(8, 4)) - (numbers / 2);
                }
                if (rowView["ExamType"].ToString() == "B")
                {
                    int numbers = int.Parse(Regex.Replace(StreamPart.SelectedItem.ToString(), "[^.0-9]", ""));
                    if (((ExamYear.SelectedValue.Substring(0, 7) == "JUL-DEC") && numbers % 2 == 0) || (ExamYear.SelectedValue.Substring(0, 7) == "SMR-JUL") && numbers % 2 != 0)
                    {
                        numbers = numbers + 1;
                    }


                    admYear = int.Parse(ExamYear.SelectedValue.Substring(8, 4)) - (numbers / 2);
                }
                if (MTheory.Checked == true)
                {

                    //shivam 22-05-2014
                    if (Subject.SelectedValue == "AR 141A" || Subject.SelectedValue == "AR 151A" || Subject.SelectedValue == "AR 161A" || Subject.SelectedValue == "AR 171A" || Subject.SelectedValue == "AR 181A" || Subject.SelectedValue == "EE 2235" || Subject.SelectedValue == "EE 1815" || Subject.SelectedValue == "ME 1412")
                    {
                        CompareValidator cmpValidator = new CompareValidator();
                        if (admYear >= 2014 || (admYear == 2013 && (rowView["StreamTypeCode"].ToString() != "02") && Convert.ToDateTime(examsess) > Convert.ToDateTime("01-JUL-2014")))
                        {
                            cmpValidator = (CompareValidator)e.Row.FindControl("cmclstest1");
                            double clstest = totalmarks * 0.5;
                            cmpValidator.ValueToCompare = clstest.ToString();
                            cmpValidator.ErrorMessage = "Cant be Greater than " + clstest.ToString();
                            cmpValidator = (CompareValidator)e.Row.FindControl("cmpclstst2");
                            cmpValidator.ValueToCompare = clstest.ToString();
                            cmpValidator.ErrorMessage = "Cant be Greater than " + clstest.ToString();
                        }
                        else
                        {
                            cmpValidator = (CompareValidator)e.Row.FindControl("cmclstest1");
                            double clstest = totalmarks * 0.45;
                            cmpValidator.ValueToCompare = clstest.ToString();
                            cmpValidator.ErrorMessage = "Cant be Greater than " + clstest.ToString();
                            cmpValidator = (CompareValidator)e.Row.FindControl("cmpclstst2");
                            cmpValidator.ValueToCompare = clstest.ToString();
                            cmpValidator.ErrorMessage = "Cant be Greater than " + clstest.ToString();

                        }

                        double midsem = totalmarks * 0.00;
                        cmpValidator = (CompareValidator)e.Row.FindControl("cmpthmidsem");
                        cmpValidator.ValueToCompare = midsem.ToString();
                        cmpValidator.ErrorMessage = "Cant be Greater than " + midsem.ToString();
                        midsem = totalmarks * 0.00;
                        cmpValidator = (CompareValidator)e.Row.FindControl("cmpthendsem");
                        cmpValidator.ValueToCompare = midsem.ToString();
                        cmpValidator.ErrorMessage = "Cant be Greater than " + midsem.ToString();



                    }
                    else
                    {
                        CompareValidator cmpValidator = (CompareValidator)e.Row.FindControl("cmclstest1");
                        double clstest = totalmarks * 0.05;
                        cmpValidator.ValueToCompare = clstest.ToString();
                        cmpValidator.ErrorMessage = "Cant be Greater than " + clstest.ToString();
                        cmpValidator = (CompareValidator)e.Row.FindControl("cmpclstst2");
                        cmpValidator.ValueToCompare = clstest.ToString();
                        cmpValidator.ErrorMessage = "Cant be Greater than " + clstest.ToString();
                        if ((admYear == 2013 && ((rowView["StreamTypeCode"].ToString() != "02")) && Convert.ToDateTime(examsess) > Convert.ToDateTime("01-JUL-2014")) || (admYear >= 2014))
                        {
                            double midsem = totalmarks * 0.20;
                            cmpValidator = (CompareValidator)e.Row.FindControl("cmpthmidsem");
                            cmpValidator.ValueToCompare = midsem.ToString();
                            cmpValidator.ErrorMessage = "Cant be Greater than " + midsem.ToString();
                            midsem = totalmarks * 0.70;
                            cmpValidator = (CompareValidator)e.Row.FindControl("cmpthendsem");
                            cmpValidator.ValueToCompare = midsem.ToString();
                            cmpValidator.ErrorMessage = "Cant be Greater than " + midsem.ToString();

                        }
                        else if (admYear == 2013 && (rowView["StreamTypeCode"].ToString() != "02") && Convert.ToDateTime(examsess) <= Convert.ToDateTime("01-JUL-2014"))
                        {
                            double midsem = totalmarks * 0.20;
                            cmpValidator = (CompareValidator)e.Row.FindControl("cmpthmidsem");
                            cmpValidator.ValueToCompare = midsem.ToString();
                            cmpValidator.ErrorMessage = "Cant be Greater than " + midsem.ToString();
                            midsem = totalmarks * 0.60;
                            cmpValidator = (CompareValidator)e.Row.FindControl("cmpthendsem");
                            cmpValidator.ValueToCompare = midsem.ToString();
                            cmpValidator.ErrorMessage = "Cant be Greater than " + midsem.ToString();

                        }
                        else
                        {
                            double midsem = totalmarks * 0.30;
                            cmpValidator = (CompareValidator)e.Row.FindControl("cmpthmidsem");
                            cmpValidator.ValueToCompare = midsem.ToString();
                            cmpValidator.ErrorMessage = "Cant be Greater than " + midsem.ToString();
                            midsem = totalmarks * 0.50;
                            cmpValidator = (CompareValidator)e.Row.FindControl("cmpthendsem");
                            cmpValidator.ValueToCompare = midsem.ToString();
                            cmpValidator.ErrorMessage = "Cant be Greater than " + midsem.ToString();


                        }
                    }

                }
                else
                {
                    double pracrec = 0.10 * totalmarks;
                    double excep = 0.30 * totalmarks;
                    double disertation = 0 * totalmarks;
                    double ptendsem = totalmarks * 0.50;
                    if ((admYear == 2013 && (rowView["StreamTypeCode"].ToString() != "02")) || (admYear >= 2014))
                    {
                        ptendsem = totalmarks * 0.60;
                        if (Convert.ToDateTime(examsess) > Convert.ToDateTime("01-JUL-2014"))
                        {
                            pracrec = 0.15 * totalmarks;
                            excep = 0.10 * totalmarks;
                        }
                    } // For Industrial Training
                    if (Subject.SelectedValue == "IT 1784" || Subject.SelectedValue == "CS 1724" || Subject.SelectedValue == "ME 1739" || Subject.SelectedValue == "AR 191A" || Subject.SelectedValue == "9AR192")
                    {
                        pracrec = totalmarks * 0;
                        excep = totalmarks * 0;
                        ptendsem = totalmarks * 1.00;
                    }

                    CompareValidator cmpValidator = (CompareValidator)e.Row.FindControl("cmpprrec");
                    cmpValidator.ValueToCompare = pracrec.ToString();
                    cmpValidator.ErrorMessage = "Cant be Greater than " + pracrec.ToString();

                    cmpValidator = (CompareValidator)e.Row.FindControl("cmpprclsperf");
                    cmpValidator.ValueToCompare = pracrec.ToString();
                    cmpValidator.ErrorMessage = "Cant be Greater than " + pracrec.ToString();


                    cmpValidator = (CompareValidator)e.Row.FindControl("cmpprendsem");
                    cmpValidator.ValueToCompare = ptendsem.ToString();
                    cmpValidator.ErrorMessage = "Cant be Greater than " + ptendsem.ToString();


                    //coursepaper added : = AR 1A1A // For Projects
                    if ((Subject.SelectedValue == "CS 1827") || (Subject.SelectedValue == "EC 2261") || (Subject.SelectedValue == "IT 1883") || (Subject.SelectedValue == "CS 2493") || Subject.SelectedValue == "EE 1882" || Subject.SelectedValue == "EE 1884" || Subject.SelectedValue == "EE 2493" || Subject.SelectedValue == "EE 2494" || Subject.SelectedValue == "EC 2463" || Subject.SelectedValue == "EC 2493" || Subject.SelectedValue == "CS 2291" || Subject.SelectedValue == "CE 1830" || Subject.SelectedValue == "CE 2490" || Subject.SelectedValue == "CE 2420" || Subject.SelectedValue == "AR 1A51" || Subject.SelectedValue == "ME 2478" || Subject.SelectedValue == "AR 2492" || Subject.SelectedValue == "EE 2391" || Subject.SelectedValue == "EE 2390" || Subject.SelectedValue == "CE 2318" || Subject.SelectedValue == "CE 2319" || Subject.SelectedValue == "CS 1723" || Subject.SelectedValue == "IT 1782" || Subject.SelectedValue == "IT 2310" || Subject.SelectedValue == "CS 2392" || Subject.SelectedValue == "ME 1738" || Subject.SelectedValue == "CE 1729" || Subject.SelectedValue == "EE 1781" || Subject.SelectedValue == "EE 1780" || Subject.SelectedValue == "AR 2391" || Subject.SelectedValue == "IT 1681" || Subject.SelectedValue == "IT 2413" || Subject.SelectedValue == "IT 2412" || Subject.SelectedValue == "CS 2494" || Subject.SelectedValue == "EC 1818" || Subject.SelectedValue == "EC694" || Subject.SelectedValue == "EC695" || Subject.SelectedValue == "AR 1A1A")
                    {
                        cmpValidator = (CompareValidator)e.Row.FindControl("cmppracendsem");
                        cmpValidator.ValueToCompare = excep.ToString();
                        cmpValidator.ErrorMessage = "Cant be Greater than " + excep.ToString();

                    } // INdustrial training
                    else if (Subject.SelectedValue == "IT 1784" || Subject.SelectedValue == "CS 1724" || Subject.SelectedValue == "ME 1739" || Subject.SelectedValue == "AR 191A")
                    {

                        cmpValidator = (CompareValidator)e.Row.FindControl("cmppracendsem");
                        cmpValidator.ValueToCompare = pracrec.ToString();
                        cmpValidator.ErrorMessage = "Cant be Greater than " + pracrec.ToString();
                    }
                    else if (Subject.SelectedValue == "ME 2377" || Subject.SelectedValue == "ME 2376" || Subject.SelectedValue == "ME 2479")
                    {
                        cmpValidator = (CompareValidator)e.Row.FindControl("cmpprrec");
                        cmpValidator.ValueToCompare = disertation.ToString();
                        cmpValidator.ErrorMessage = "Cant be Greater than " + disertation.ToString();

                        cmpValidator = (CompareValidator)e.Row.FindControl("cmpprclsperf");
                        cmpValidator.ValueToCompare = disertation.ToString();
                        cmpValidator.ErrorMessage = "Cant be Greater than " + disertation.ToString();
                        pracrec = 0.50 * totalmarks;
                        cmpValidator = (CompareValidator)e.Row.FindControl("cmppracendsem");
                        cmpValidator.ValueToCompare = pracrec.ToString();
                        cmpValidator.ErrorMessage = "Cant be Greater than " + pracrec.ToString();

                        cmpValidator = (CompareValidator)e.Row.FindControl("cmpprendsem");
                        cmpValidator.ValueToCompare = pracrec.ToString();
                        cmpValidator.ErrorMessage = "Cant be Greater than " + pracrec.ToString();
                    }
                    else
                    {
                        pracrec = 0.10 * totalmarks;
                        cmpValidator = (CompareValidator)e.Row.FindControl("cmppracendsem");
                        cmpValidator.ValueToCompare = pracrec.ToString();
                        cmpValidator.ErrorMessage = "Cant be Greater than " + pracrec.ToString();
                    }

          


                }
            }
        }
        //else if (checkclear == false)
        //{

        //}
    }


    protected void Internal_CheckedChanged(object sender, EventArgs e)
    {
        Subject.Items.Clear();
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));

    }
    protected void EndSem_CheckedChanged(object sender, EventArgs e)
    {
        Subject.Items.Clear();
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
    }
    protected void Viva_CheckedChanged(object sender, EventArgs e)
    {
        Subject.Items.Clear();
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
    }
    protected void btnprint_Click(object sender, EventArgs e)
    {
        if (MTheory.Checked == true)
        {
            papertype = "(EXAMPAPERDETAIL.papertype='T' OR EXAMPAPERDETAIL.papertype='X') ";
        }
        //else if (MThPr.Checked == true)
        //{
        //    papertype = "X";
        //}
        else if (MPrac.Checked == true)
        {
            papertype = "(EXAMPAPERDETAIL.papertype='P' OR EXAMPAPERDETAIL.papertype='X')";
        }

        string Querystr = "";
        if (StreamPart.SelectedItem.ToString().IndexOf('A') > 0 || StreamPart.SelectedItem.ToString().IndexOf('B') > 0)
        {
            Querystr = " (COURSEPAPERS.StreamPart = '" + StreamPart.SelectedItem.ToString() + "')";

        }
        else
        {
            Querystr = " (COURSEPAPERS.StreamPartCode='" + StreamPart.SelectedValue + "')";

        }

        string strexamtype = "";

        if (Internal.Checked == true || Viva.Checked == true)
        {
            strexamtype = " AND (EXAMPAPERDETAIL.ExamType!='N') ";
        }
        else
        {
            strexamtype = " AND ((Attendance.status='P' and EXAMPAPERDETAIL.ExamType!='N') or (Attendance.status is null and EXAMPAPERDETAIL.ExamType='N')) ";
        }
        string joins = "";
        if (Session["Role"].ToString() == "9")
        {
            joins = " AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";
        }
        string stry = MTheory.Checked == true ? "T" : "P";

        DataSet dsmarksprint = new DataSet();
        string query1 = "SELECT EXAMPAPERDETAIL.UnivRollNo, EXAMPAPERDETAIL.THEndsem, EXAMPAPERDETAIL.StudentStatus As Absent, " +
                " EXAMPAPERDETAIL.PREndSem,EXAMPAPERDETAIL.ClassTest1, EXAMPAPERDETAIL.ClassTest2, EXAMPAPERDETAIL.Midsem, " +
                " EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor, EXAMPAPERDETAIL.Prpreendsemviva," +
                " EXAMPAPERDETAIL.ExamSession, EXAMPAPERDETAIL.ExamYear, STREAM.StreamAbbr, COURSEPAPERS.StreamPart , " +
                " COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName, COURSEPAPERS.FullMarks AS ThFM, COURSEPAPERS.Credit, " +
                " COURSEPAPERS.L, COURSEPAPERS.T, COURSEPAPERS.P, PRACTICALPAPERS.FullMarks AS PtFM " +
                " FROM         EXAMPAPERDETAIL inner join REGISTRATION ON REGISTRATION.RegNo = EXAMPAPERDETAIL.RegNo INNER JOIN " +
                " COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " +
                " STREAM ON COURSEPAPERS.StreamCode = STREAM.StreamCode  LEFT OUTER JOIN " +
                " Attendance ON EXAMPAPERDETAIL.ExamSession = Attendance.ExamSession AND " +
                " EXAMPAPERDETAIL.UnivRollNo = Attendance.UnivRollNo AND  " +
                " EXAMPAPERDETAIL.SubPaperCode = Attendance.SubPaperCode AND EXAMPAPERDETAIL.RegNo = Attendance.RegNo LEFT OUTER JOIN " +
                " PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                " INNER JOIN Faculty_paper_a on  COURSEPAPERS.SubPaperCode=Faculty_paper_a.subpapercode and Faculty_paper_a.examsession=EXAMPAPERDETAIL.ExamSession and isnull(REGISTRATION.SplCode,'00')= Faculty_paper_a.splcode " +
                " WHERE (EXAMPAPERDETAIL.ExamSession = '" + ExamYear.SelectedItem + "') AND isnull(REGISTRATION.SplCode,'00')='" + splcode.SelectedValue + "' and Faculty_paper_a.Is_Active='Y' and case when Faculty_paper_a.PaperType IS not null then Faculty_paper_a.PaperType else '" + stry + "' end ='" + stry + "' AND " +
                "  (COURSEPAPERS.PaperAbbr = '" + Subject.SelectedValue + "') AND " + papertype + " AND " + Querystr + joins + strexamtype;



        if (EndSem.Checked == true && MTheory.Checked == true)
        {
            papertype = "T";

            crystalReport.Load(Server.MapPath("~/Report/rptMarksPrint.rpt"));
            dsmarksentry objdsmentry = GetData(query1);
            crystalReport.SetDataSource(objdsmentry);
            crystalReport.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, false, "ExportedReport");

        }
        else if (EndSem.Checked == true && MPrac.Checked == true)
        {
            papertype = "P";

            crystalReport.Load(Server.MapPath("~/Report/rptMarksPrint2.rpt"));
            dsmarksentry objdsmentry = GetData(query1);
            crystalReport.SetDataSource(objdsmentry);
            crystalReport.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, false, "ExportedReport");
        }
        else if (Internal.Checked == true && MTheory.Checked == true)
        {
            papertype = "T";

            crystalReport.Load(Server.MapPath("~/Report/rptMarksPrint3.rpt"));
            dsmarksentry objdsmentry = GetData(query1);
            crystalReport.SetDataSource(objdsmentry);
            crystalReport.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, false, "ExportedReport");
        }
        else if (Internal.Checked == true && MPrac.Checked == true)
        {
            papertype = "P";

            crystalReport.Load(Server.MapPath("~/Report/rptMarksPrint4.rpt"));
            dsmarksentry objdsmentry = GetData(query1);
            crystalReport.SetDataSource(objdsmentry);
            crystalReport.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, false, "ExportedReport");
        }
        else if (Viva.Checked == true && MPrac.Checked == true)
        {
            papertype = "P";

            crystalReport.Load(Server.MapPath("~/Report/rptMarksPrint5.rpt"));
            dsmarksentry objdsmentry = GetData(query1);
            crystalReport.SetDataSource(objdsmentry);
            crystalReport.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, false, "ExportedReport");
        }
    }
    protected void Page_Unload(object sender, EventArgs e)
    {
        if (crystalReport != null)
        {
            crystalReport.Close();
            crystalReport.Dispose();
        }

    }
    private dsmarksentry GetData(string query)
    {
        string conString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlCommand cmd = new SqlCommand(query);
        using (SqlConnection con = new SqlConnection(conString))
        {
            using (SqlDataAdapter sda = new SqlDataAdapter())
            {
                cmd.Connection = con;

                sda.SelectCommand = cmd;
                using (dsmarksentry objdsmentry = new dsmarksentry())
                {
                    sda.Fill(objdsmentry, "DataTable1");
                    return objdsmentry;
                }
            }
        }
    }


    protected void splcode_SelectedIndexChanged(object sender, EventArgs e)
    {
        MTheory.Checked = false;
        // RBComp.Checked=false ;
        //MElective.Checked = false;
        //MThPr.Checked = false;
        MPrac.Checked = false;

        //shivam - 23-04-2014
        StreamPart.Items.Clear();
        Subject.Items.Clear();

        string strrole = "";
        if (Session["Role"].ToString() == "9")
            strrole = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";

        PopulateDDL popddl = new PopulateDDL();

        string strstreampart = "SELECT     STREAMPART.StreamPart,STREAMPART.StreamPartCode " +
                              " FROM         COURSEPAPERS AS COURSEPAPERS_1 INNER JOIN " +
                              " STREAMPART ON COURSEPAPERS_1.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN " +
                              " Faculty_paper_a INNER JOIN " +
                              " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode ON COURSEPAPERS_1.PaperAbbr = COURSEPAPERS.PaperAbbr " +
                              " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                              " and (Faculty_paper_a.splcode='" + splcode.SelectedValue + "') and STREAMPART.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                              " GROUP BY STREAMPART.StreamPartCode, STREAMPART.StreamPart " +
                              " order by StreamPart";


        popddl.Popualate(StreamPart, "StreamPart", strstreampart, "StreamPart", "StreamPartCode");
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
        splcode.Focus();


    }

    double totalpmo; string GRADE = "";
    protected void btnsave_Click(object sender, EventArgs e)
    {
        for (int i = 0; i <= Gr8.Rows.Count - 1; i++)
        {

            // Code for check absent in ct1 and ct2------
            ct1absent = Convert.ToString(((CheckBox)Gr8.Rows[i].FindControl("chkct1absent")).Checked);

            ct2absent = Convert.ToString(((CheckBox)Gr8.Rows[i].FindControl("chkct2absent")).Checked);
            if (Internal.Checked == true)
            {
                if (ct1absent == "True" && ct2absent == "True")
                {
                    ctabsentvalue = "A-CT";
                }
                else if (ct1absent == "True" && ct2absent == "False")
                {
                    ctabsentvalue = "A-CT1";
                }
                else if (ct2absent == "True" && ct1absent == "False")
                {
                    ctabsentvalue = "A-CT2";
                }
            }
            string univroll = Convert.ToString(((Label)Gr8.Rows[i].FindControl("Labelregno")).Text);
            string ct1 = Convert.ToString(((TextBox)Gr8.Rows[i].FindControl("thprClasstest1")).Text);
            string ct2 = Convert.ToString(((TextBox)Gr8.Rows[i].FindControl("thprClasstest2")).Text);
            string midsem = Convert.ToString(((TextBox)Gr8.Rows[i].FindControl("thprmidsem")).Text);

            string thendsem = Convert.ToString(((TextBox)Gr8.Rows[i].FindControl("txtendsemth")).Text);
            string abstatus = Convert.ToString(((Label)Gr8.Rows[i].FindControl("lblabsent")).Text);
            string checkvalue = Convert.ToString(((CheckBox)Gr8.Rows[i].FindControl("ckhabsent")).Checked);
            if (EndSem.Checked == true)
            {
                if (abstatus == "" && checkvalue == "True")
                {
                    abstatus = "AE";
                }
                else if (abstatus == "AM" && checkvalue == "True")
                {
                    abstatus = "A";
                }
            }
            else if (Internal.Checked == true)
            {
                if (abstatus == "" && checkvalue == "True")
                {
                    abstatus = "AM";
                }
                else if (abstatus == "AM" && checkvalue == "True")
                {
                    abstatus = "A";
                }
            }

            string prrecd = Convert.ToString(((TextBox)Gr8.Rows[i].FindControl("Practicalrecord1")).Text);
            string prclperfrecd = Convert.ToString(((TextBox)Gr8.Rows[i].FindControl("Practclassperformance1")).Text);
            string prendsemviva = Convert.ToString(((TextBox)Gr8.Rows[i].FindControl("PracticalPreendsemviva1")).Text);
            string PREndSem = Convert.ToString(((TextBox)Gr8.Rows[i].FindControl("txtendsempr")).Text);



            string Querystr = "";

            if (StreamPart.SelectedItem.ToString().IndexOf('A') > 0 || StreamPart.SelectedItem.ToString().IndexOf('B') > 0)
            {
                Querystr = " (COURSEPAPERS.StreamPart = '" + StreamPart.SelectedItem.ToString() + "')";

            }
            else
            {
                Querystr = " (COURSEPAPERS.StreamPartCode='" + StreamPart.SelectedValue + "')";

            }


            int Insdata = fn.InsertUpdateDelete("Update EXAMPAPERDETAIL set ClassTest1='" + ct1 + "', ClassTest2='" + ct2 + "',IsAppeared='" + ctabsentvalue + "', " +
                " Midsem='" + midsem + "',THEndsem = '" + thendsem + "', StudentStatus = '" + abstatus + "', PracticalRecord='" + prrecd + "', " +
                " PrClassPerfor='" + prclperfrecd + "', Prpreendsemviva='" + prendsemviva + "', PREndSem = '" + PREndSem + "', opt1='" + Session["UserId"].ToString() + "'," +
                " EntryDate2 = getdate() FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                " WHERE EXAMPAPERDETAIL.UnivRollNo = '" + univroll + "' AND " +
                " COURSEPAPERS.PaperAbbr = '" + Subject.SelectedValue + "' AND EXAMPAPERDETAIL.ExamSession = '" + ExamYear.SelectedValue + "' AND" + Querystr);

            // Code For Calculate grade ---- Manish 18/05/2018

            DataTable dtstudmarks = fn.SelectDatatable("SELECT EXAMPAPERDETAIL.UnivRollNo, EXAMPAPERDETAIL.PaperType, COALESCE (NULLIF (EXAMPAPERDETAIL.ClassTest1, ''), '0') AS CT1, COALESCE (NULLIF (EXAMPAPERDETAIL.ClassTest2, ''), '0') " +
                " AS CT2, COALESCE (NULLIF (EXAMPAPERDETAIL.TH_Attendance, ''), '0') AS TH_ATTEND, COALESCE (NULLIF (EXAMPAPERDETAIL.Midsem, ''), '0') AS MIDSEM, " +
                " COALESCE (NULLIF (EXAMPAPERDETAIL.THEndsem, ''), '') AS TH_ESM, (CONVERT(float, COALESCE (NULLIF (EXAMPAPERDETAIL.ClassTest1, ''), '0')) + CONVERT(float, " +
                " COALESCE (NULLIF (EXAMPAPERDETAIL.ClassTest2, ''), '0')) + CONVERT(float, COALESCE (NULLIF (EXAMPAPERDETAIL.TH_Attendance, ''), '0')) + CONVERT(float, " +
                " COALESCE (NULLIF (EXAMPAPERDETAIL.Midsem, ''), '0')) + CONVERT(float, COALESCE (NULLIF (EXAMPAPERDETAIL.THEndsem, ''), '0'))) * 100 AS SUB_TH_PMO, " +
                " COALESCE (NULLIF (EXAMPAPERDETAIL.PR_Attendance, ''), '0') AS PT_ATTEND, COALESCE (NULLIF (EXAMPAPERDETAIL.PracticalRecord, ''), '0') AS PT_RECORD, " +
                " COALESCE (NULLIF (EXAMPAPERDETAIL.PRClassPerfor, ''), '0') AS PT_CLPERFORM, COALESCE (NULLIF (EXAMPAPERDETAIL.PREndSem, ''), '0') AS PT_ESM, " +
                " COALESCE (NULLIF (EXAMPAPERDETAIL.Prpreendsemviva, ''), '0') AS PT_VIVA, (CONVERT(float, COALESCE (NULLIF (EXAMPAPERDETAIL.PR_Attendance, ''), '0')) + CONVERT(float, " +
                " COALESCE (NULLIF (EXAMPAPERDETAIL.PracticalRecord, ''), '0')) + CONVERT(float, COALESCE (NULLIF (EXAMPAPERDETAIL.PRClassPerfor, ''), '0')) + CONVERT(float, " +
                " COALESCE (NULLIF (EXAMPAPERDETAIL.PREndSem, ''), '0')) + CONVERT(float, COALESCE (NULLIF (EXAMPAPERDETAIL.Prpreendsemviva, ''), '0'))) * 100 AS SUB_PT_PMO, " +
                " EXAMPAPERDETAIL.UMCode, EXAMPAPERDETAIL.ExamType, REGISTRATION.AdmYear, EXAMPAPERDETAIL.SubPaperCode FROM EXAMPAPERDETAIL INNER JOIN REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo INNER JOIN " + 
                " COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                " WHERE (EXAMPAPERDETAIL.UnivRollNo = '" + univroll + "') AND (EXAMPAPERDETAIL.ExamSession = '" + ExamYear.SelectedValue + "') AND (COURSEPAPERS.PaperAbbr = '"+ Subject.SelectedValue.ToString()+"')");
            if (dtstudmarks.Rows.Count > 0)
            {
                GRADE = "";
                if ((dtstudmarks.Rows[0]["ExamType"].ToString() == "R") || (dtstudmarks.Rows[0]["ExamType"].ToString() == "B"))
                {
                    DataTable dtthfullmark = fn.SelectDatatable("SELECT COURSEPAPERS.FullMarks AS ThFMarks, ISNULL(PRACTICALPAPERS.FullMarks,'1') AS PractFMarks, " +
                                "COURSEPAPERS.Credit FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                                " WHERE COURSEPAPERS.SubPaperCode = '" + dtstudmarks.Rows[0]["SubPaperCode"].ToString() + "'");
                    if (dtthfullmark.Rows.Count > 0)
                    {
                        if (dtstudmarks.Rows[0]["TH_ESM"].ToString() != "")
                        {
                            double thpmo = Convert.ToDouble(dtstudmarks.Rows[0]["SUB_TH_PMO"].ToString()) / Convert.ToDouble(dtthfullmark.Rows[0]["ThFMarks"].ToString());
                            double ptpmo = Convert.ToDouble(dtstudmarks.Rows[0]["SUB_PT_PMO"].ToString()) / Convert.ToDouble(dtthfullmark.Rows[0]["PractFMarks"].ToString());
                            totalpmo = thpmo + ptpmo;
                            if (Convert.ToInt32(dtstudmarks.Rows[0]["AdmYear"].ToString()) >= 2013)
                            {
                                gradecriteria(dtstudmarks.Rows[0]["PaperType"].ToString(), thpmo.ToString(), ptpmo.ToString(), totalpmo.ToString());
                            }
                            else
                            {
                                gradecriteria_old(dtstudmarks.Rows[0]["PaperType"].ToString(), thpmo.ToString(), ptpmo.ToString(), totalpmo.ToString());
                            }
                        }
                        else
                        {
                            GRADE = "";
                        }
                       Insdata = fn.InsertUpdateDelete("Update EXAMPAPERDETAIL set Grade ='" + GRADE + "' WHERE EXAMPAPERDETAIL.UnivRollNo = '" + univroll + "' AND " +
                          " SubPaperCode = '" + dtstudmarks.Rows[0]["SubPaperCode"].ToString() + "' AND EXAMPAPERDETAIL.ExamSession = '" + ExamYear.SelectedValue + "'");
                      

                    }

                }
            }


            ctabsentvalue = "";

            if (Insdata == 0)
            {
                string msg = " Could Not Saved!!!. ";
                string popupScript = "<script language='javascript'>" +
                                   " alert('" + msg + " ')" +
                                    "</script>";
                Page.RegisterStartupScript("PopupScript", popupScript);
            }
            else
            {
                string msg = " Marks Saved!!!. ";
                string popupScript = "<script language='javascript'>" +
                                   " alert('" + msg + " ')" +
                                    "</script>";
                Page.RegisterStartupScript("PopupScript", popupScript);
                //int l = e.RowIndex + 1;


            }
        }
        bindgrid();
    }

    private void gradecriteria(string papertype, string TH_PMO, string PT_PMO, string TOTAL_PMO)
    {
        if (papertype == "X")
        {
            if ((TH_PMO != "" && double.Parse(TH_PMO) < 33) || (PT_PMO != "" && double.Parse(PT_PMO) < 33))
            {
                GRADE = "F";             
            }
            else
            {
                grading(TOTAL_PMO);
            }


        }
        else if (papertype == "T")
        {
            if (TH_PMO != "")
            {
                if (double.Parse(TH_PMO) < 33)
                {
                    GRADE = "F";
                }
                else
                {
                    grading(TOTAL_PMO);
                }
            }

        }
        else if (papertype == "P")
        {
            if (PT_PMO != "")
            {
                if (double.Parse(PT_PMO) < 33)
                {
                    GRADE = "F";               
                }
                else
                {
                    grading(TOTAL_PMO);
                }
            }
        }
    }

    protected void gradecriteria_old(string papertype, string TH_PMO, string PT_PMO, string TOTAL_PMO)
    {
        if (papertype == "X")
        {
            if ((TH_PMO != "" && double.Parse(TH_PMO) < 35) || (PT_PMO != "" && double.Parse(PT_PMO) < 40))
            {
                GRADE = "F";               
            }
            else
            {
                grading(TOTAL_PMO);
            }

        }
        else if (papertype == "T")
        {
            if (TH_PMO != "")
            {
                if (double.Parse(TH_PMO) < 35)
                {
                    GRADE = "F";                  
                }
                else
                {
                    grading(TOTAL_PMO);
                }
            }
        }
        else if (papertype == "P")
        {
            if (PT_PMO != "")
            {
                if (double.Parse(PT_PMO) < 40)
                {
                    GRADE = "F";
                }
                else
                {
                    grading(TOTAL_PMO);
                }
            }
        }
    }

    protected void grading(string TOTALPMO)
    {
        if (TOTALPMO != "")
        {
            //double p = double.Parse(TOTAL_PMO);
            if (double.Parse(TOTALPMO) >= 90)
            {
                GRADE = "A+";               
            }
            else if (double.Parse(TOTALPMO) >= 80 && double.Parse(TOTALPMO) < 90)
            {
                GRADE = "A";               
            }
            else if (double.Parse(TOTALPMO) >= 70 && double.Parse(TOTALPMO) < 80)
            {
                GRADE = "B";             
            }
            else if (double.Parse(TOTALPMO) >= 60 && double.Parse(TOTALPMO) < 70)
            {
                GRADE = "C";               
            }
            else if (double.Parse(TOTALPMO) >= 50 && double.Parse(TOTALPMO) < 60)
            {
                GRADE = "D";              
            }
            else if (double.Parse(TOTALPMO) < 50)
            {
                GRADE = "P";             
            }

        }
    }


    protected void ExamYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        string strstream = "SELECT     STREAM.StreamAbbr, STREAM.StreamCode FROM Faculty_paper_a INNER JOIN " +
                  " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " +
                  " STREAM ON COURSEPAPERS.StreamCode = STREAM.StreamCode " +
                  " Where Faculty_paper_a.Is_Active='Y' and Faculty_paper_a.examsession='" + ExamYear.SelectedValue + "'" +
                  " GROUP BY STREAM.StreamAbbr, STREAM.StreamCode order by StreamAbbr ";

        StreamCode.Items.Clear();
        popddl.Popualate(StreamCode, "Stream", strstream, "StreamAbbr", "StreamCode");
        StreamCode.Items.Insert(0, new ListItem("--Select--", "0"));
    }


}
