using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class DuplicateRegistration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

        }
    }
    protected void BtnView_Click(object sender, EventArgs e)
    {
        BindGrid();
        if (DuplicateView.Rows.Count > 0)
        {
            LblMsg.Visible = true;
            LblMsg.Text = " Total Record Found =  " + DuplicateView.Rows.Count.ToString();
            Panel1.Visible = true;
        }
        else
        {
            LblMsg.Visible = true;
            LblMsg.Text = "No Records Found";
            Panel1.Visible = false;
        }

    }
   
    void BindGrid()
    {
        DataSet ds = new DataSet();

        if (FName.Checked == false)
        {

            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select row_number() OVER (ORDER BY  " + OrderBy.SelectedValue + "  ASC) AS SLNo,ApplicantName,DOB,FatherName,count(1) as count from registration where migrationstatus='N' group by applicantname,fathername,dob having count(applicantname)>1 order by  '" + OrderBy.SelectedValue + "' ");
            //DuplicateView.Columns.Add(CreateBoundField("FatherName","Father Name"));
            
        }
        else
        {
            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select row_number() OVER (ORDER BY  " + OrderBy.SelectedValue + "  ASC) AS SLNo,ApplicantName,DOB,count(1) as count from registration where migrationstatus='N' group by applicantname,dob having count(applicantname)>1 order by  '" + OrderBy.SelectedValue + "' ");
            //DuplicateView.Columns.RemoveAt(5);

        }

        DuplicateView.DataSource = ds;
        DuplicateView.DataBind();
       


    }
    protected void DuplicateView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        DuplicateView.PageIndex = e.NewPageIndex;
        BindGrid();
    }
    protected void DuplicateView_SelectedIndexChanged(object sender, EventArgs e)
    {

        DetailView.Visible = true;
        DetailGrid();
    
    }



    void DetailGrid()
    {
        DataSet ds = new DataSet();

        if (FName.Checked == false)
        {

            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select row_number() OVER (ORDER BY ackno  ASC) AS slno,ackno,regno,registrationdate,streamcode,collcode,CollegeAdmissionDate,coursesession,regyear from registration where applicantname='" + DuplicateView.SelectedRow.Cells[2].Text + "' and fathername='" + DuplicateView.SelectedRow.Cells[3].Text + "' and dob='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(DuplicateView.SelectedRow.Cells[4].Text)) + "'");
        }

        else
        {

            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select row_number() OVER (ORDER BY ackno  ASC) AS slno,ackno,regno,registrationdate,streamcode,collcode,CollegeAdmissionDate,coursesession,regyear from registration where applicantname='" + DuplicateView.SelectedRow.Cells[2].Text + "' and dob='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(DuplicateView.SelectedRow.Cells[3].Text)) + "'");
        }


        DetailView.DataSource = ds;
        DetailView.DataBind();
    }

    //public BoundField CreateBoundField(string DataField,string HeaderText)
    //{

    //    BoundField eColumn = new BoundField();
    //    eColumn.DataField = DataField;
    //    eColumn.HeaderText = HeaderText;
    //   // eColumn.ItemStyle.CssClass = ApplyColumnStyling(eColumn); //apply css class or just set the width
    //    return eColumn;
    //}



   

}
