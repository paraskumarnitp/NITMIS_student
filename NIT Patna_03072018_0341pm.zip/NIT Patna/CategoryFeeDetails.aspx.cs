using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Drawing;

public partial class CategoryFeeDetails : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnexport);
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "17" && Session["Role"].ToString() != "16" && Session["Role"].ToString() != "10")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
                bindexamSession();
                paymenttype.Items.Insert(0, new ListItem("ALL", "0"));
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

        }
    }
    string querypart = "";
    protected void btnview_Click(object sender, EventArgs e)
    {
        bindgrid();
    }
    protected void btnexport_Click(object sender, EventArgs e)
    {
        if (paymenttype.SelectedValue.ToString() == "0")
        {
            querypart = "";
        }
        else
        {
            querypart = "AND (STREAM.StreamCode = '" + paymenttype.SelectedValue.ToString() + "') ";
        }

        if (StreamCode.SelectedValue.ToString() == "0")
        {
            querypart = querypart + "";
        }
        else
            querypart = querypart + " AND CategoryFeeSettings.FeeCategoryType = '" + StreamCode.SelectedItem.ToString() + "'";

        DataTable dtfeewaivedata = fnrev.SelectDatatable("SELECT ROW_NUMBER() OVER(ORDER BY (SELECT 1)) AS RowNumber, REGISTRATION.AckNo AS EnrollmentNo, FeeConcession.UnivRollNo AS RollNo, " +
            " REGISTRATION.ApplicantName AS StudentName, STREAM.StreamAbbr AS Program, FeeConcession.ExamSession, FeeConcession.Amount AS " +
            " DeductedAmount, FeeConcession.Remarks, CategoryFeeSettings.FeeCategoryType FROM FeeConcession INNER JOIN REGISTRATION ON " +
            " FeeConcession.RegNo = REGISTRATION.RegNo INNER JOIN STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode LEFT OUTER JOIN " +
            " CategoryFeeSettings ON FeeConcession.RegNo = CategoryFeeSettings.RegNo AND FeeConcession.ExamSession = CategoryFeeSettings.ExamSession " +
            " WHERE (FeeConcession.Remarks <> 'PHD PartTime Internal Program') AND (FeeConcession.ExamSession = '" + admyear.SelectedItem.ToString() + "') " +
            " " + querypart + " ORDER BY Program, RollNo");
        if (dtfeewaivedata.Rows.Count > 0)
        {
            GridView gvpayonline = new GridView();
            gvpayonline.DataSource = dtfeewaivedata;
            gvpayonline.DataBind();

            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=AdmissionPaymentDataExport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                //gvpayonline.AllowPaging = false;
                //this.BindGrid();

                gvpayonline.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in gvpayonline.HeaderRow.Cells)
                {
                    cell.BackColor = gvpayonline.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in gvpayonline.Rows)
                {
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = gvpayonline.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = gvpayonline.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                gvpayonline.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
    }


    private void bindgrid()
    {
        if (paymenttype.SelectedValue.ToString() == "0")
        {
            querypart = "";
        }
        else
        {
            querypart = "AND (STREAM.StreamCode = '"+ paymenttype.SelectedValue.ToString() +"') ";
        }

        if (StreamCode.SelectedValue.ToString() == "0")
        {
            querypart = querypart + "";
        }
        else
            querypart = querypart + " AND CategoryFeeSettings.FeeCategoryType = '" + StreamCode.SelectedItem.ToString() + "'";

        DataTable dtfeewaivedata = fnrev.SelectDatatable("SELECT ROW_NUMBER() OVER(ORDER BY (SELECT 1)) AS RowNumber, REGISTRATION.AckNo AS EnrollmentNo, FeeConcession.UnivRollNo AS RollNo, " +
            " REGISTRATION.ApplicantName AS StudentName, STREAM.StreamAbbr AS Program, FeeConcession.ExamSession, FeeConcession.Amount AS " +
            " DeductedAmount, FeeConcession.Remarks, CategoryFeeSettings.FeeCategoryType FROM FeeConcession INNER JOIN REGISTRATION ON " +
            " FeeConcession.RegNo = REGISTRATION.RegNo INNER JOIN STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode LEFT OUTER JOIN " +
            " CategoryFeeSettings ON FeeConcession.RegNo = CategoryFeeSettings.RegNo AND FeeConcession.ExamSession = CategoryFeeSettings.ExamSession " +
            " WHERE (FeeConcession.Remarks <> 'PHD PartTime Internal Program') AND (FeeConcession.ExamSession = '"+ admyear.SelectedItem.ToString() +"') " +
            " "+ querypart +" ORDER BY Program, RollNo");
        if (dtfeewaivedata.Rows.Count > 0)
        {
            string tablestring = "";

            for (int i = 0; i < dtfeewaivedata.Rows.Count; i++)
            {
                tablestring += "<tr>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["RowNumber"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["EnrollmentNo"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["RollNo"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["StudentName"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["Program"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["ExamSession"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["DeductedAmount"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["Remarks"].ToString() + "</td>";
                tablestring += "<td>" + dtfeewaivedata.Rows[i]["FeeCategoryType"].ToString() + "</td>";
                //tablestring += "<td><a href=\"\\FarmerRedg.aspx?fi=" + dtgrid.Rows[i]["FarmerId"].ToString() + " >View/Edit </a></td>";
                tablestring += "</tr>";
            }
            tlist.InnerHtml = tablestring;
        }
        else
            tlist.InnerHtml = "";
    }

    protected void ddlprogramtype_SelectedIndexChanged(object sender, EventArgs e)
    {
        string query = "";
        paymenttype.Items.Clear();
        if (ddlprogramtype.SelectedValue.ToString() == "0")
        {
            query = "SELECT StreamCode, StreamAbbr AS StreamName, StreamTypeCode FROM STREAM WHERE StreamCode <> '00'";            
        }
        else if (ddlprogramtype.SelectedValue.ToString() == "UG")
        {
            query = "SELECT StreamCode, StreamAbbr AS StreamName, StreamTypeCode FROM STREAM WHERE StreamCode <> '00' And StreamTypeCode = '01'";           
        }
        else
        {   
            query = "SELECT StreamCode, StreamAbbr AS StreamName, StreamTypeCode FROM STREAM WHERE StreamCode <> '00' And StreamTypeCode IN ('02','04')";           
        }
        DataTable dtprogram = fnrev.SelectDatatable(query);
        paymenttype.DataSource = dtprogram;
        paymenttype.DataTextField = "StreamName";
        paymenttype.DataValueField = "StreamTypeCode";
        paymenttype.DataBind();
        paymenttype.Items.Insert(0, new ListItem("ALL", "0"));

    }

    private void bindexamSession()
    {
        DataTable dtexamSession = fnrev.SelectDatatable("SELECT DISTINCT ExamSession FROm FeeConcession");
        admyear.DataSource = dtexamSession;
        admyear.DataValueField = "ExamSession";
        admyear.DataTextField = "ExamSession";
        admyear.DataBind();
    }
}
