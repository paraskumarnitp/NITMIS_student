using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class RegExamDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)

        {
            string AckNo = Request.QueryString["AckNo"];
            LblAckNo.Text="Acknowledgement No. = "+AckNo;
            ViewState.Add("AckNo", AckNo); 
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(UnivCode1, "University", "Select UnivName,UnivCode from University order by UnivName", "UnivName", "UnivCode");
            popddl.Popualate(UnivCode, "University", "Select UnivName,UnivCode from University order by UnivName", "UnivName", "UnivCode");
            popddl.Popualate(ExamCode1, "ExamName", "Select ExamName, ExamCode from ExamName order by ExamName", "ExamName", "ExamCode");
            popddl.Popualate(ExamCode, "ExamName", "Select ExamName, ExamCode from ExamName order by ExamName", "ExamName", "ExamCode");
            
            
           
        }


    }
    protected void Btnsave_Click(object sender, EventArgs e)
    {
        
        if (ExamCode1.SelectedValue.Trim ()!= "0")
        {
            if (UnivCode1.SelectedValue.Trim () == "0")
            {
                string msg = " Please Select Univ./Board Name";
                string popupScript = "<script language='javascript'>" +
                                   " alert('" + msg + " ')" +
                                    "</script>";
                Page.RegisterStartupScript("PopupScript", popupScript);
                UnivCode1.Focus();
                return;
            }
            else
            {

                string SaveFlag = "";
                string[] col = new string[7];
                string[] val = new string[7];

                col[0] = "AckNo";
                col[1] = "ExamCode";
                col[2] = "UnivCode";
                col[3] = "CollCode";
                col[4] = "PassYear";
                col[5] = "RollNo";
                col[6] = "Division";

                val[0] = ViewState["AckNo"].ToString();
                val[1] = ExamCode1.SelectedValue;
                val[2] = UnivCode1.SelectedValue;
                val[3] = CollCode1.Text.Trim();
                val[4] = PassYear1.Text.Trim();
                val[5] = RollNo1.Text.Trim();
                val[6] = Division1.SelectedValue;

                UnivService.Service1 ss = new UnivService.Service1();
               string  abc = ss.SaveData("PreRegQualification", col, val);

                if (abc == "1")
                {
                    LblMsg.Text = " Exam Detail is saved Successfully for ACk No. = " + val[0];
                     //Page.RegisterStartupScript(@"startup", @"<script>altert('New User Id is " + val[0] + "');</script>");
                    CollCode1.Text = "";
                    PassYear1.Text = "";
                    RollNo1.Text = "";
                    ExamCode1.Focus(); 


                }
                else
                {
                    LblMsg.Text = abc.ToString();
                }

            }

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (ExamCode.SelectedValue.Trim() != "0")
        {
            if (UnivCode.SelectedValue.Trim() == "0")
            {
                string msg = " Please Select Univ./Board Name";
                string popupScript = "<script language='javascript'>" +
                                   " alert('" + msg + " ')" +
                                    "</script>";
                Page.RegisterStartupScript("PopupScript", popupScript);
                UnivCode.Focus();
                return;
            }
            else
            {

                string SaveFlag = "";
                string[] col = new string[9];
                string[] val = new string[9];

                col[0] = "AckNo";
                col[1] = "ExamCode";
                col[2] = "UnivCode";
                col[3] = "CollCode";
                col[4] = "PassYear";
                col[5] = "RollNo";
                col[6] = "Division";
                col[7] = "MigrationNo";
                col[8] = "MigrationIssueDate";

                val[0] = ViewState["AckNo"].ToString();
                val[1] = ExamCode.SelectedValue;
                val[2] = UnivCode.SelectedValue;
                val[3] = CollCode.Text.Trim();
                val[4] = PassYear.Text.Trim();
                val[5] = RollNo.Text.Trim();
                val[6] = Division.SelectedValue;
                val[7] = MigrationNo.Text.Trim();
                val[8] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(MigrationIssueDate.Text)); 

                UnivService.Service1 ss = new UnivService.Service1();
                string abc = ss.SaveData("PreRegMigration", col, val);

                if (abc == "1")
                {
                    LblMsg.Text = " Migration Detail is saved Successfully for ACk No. = " + val[0];
                    
                    CollCode.Text = "";
                    PassYear.Text = "";
                    RollNo.Text = "";
                    MigrationNo.Text = ""; 
                    MigrationIssueDate.Text = ""; 
                    ExamCode1.Focus();


                }
                else
                {
                    LblMsg.Text = abc.ToString();
                }

            }

        }
    }
}
