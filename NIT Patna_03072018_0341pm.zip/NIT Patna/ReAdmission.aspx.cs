using System;
using System.IO;
using System.Data;
using System.Data.SqlClient ;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.SessionState;
using System.Web.Caching;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class ReAdmission : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "5")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CastCode, "Category", "Select Category,CategoryCode from Category order by Category", "Category", "CategoryCode");
            popddl.Popualate(PermanentDistCode, "District", "Select DistName,DistCode from District order by DistName", "DistName", "DistCode");
            popddl.Popualate(PresentDistrictCode, "District", "Select DistName,DistCode from District order by DistName", "DistName", "DistCode");
            popddl.Popualate(NationalityCode, "Nationality", "Select Nationality,NationalityCode from Nationality order by Nationality", "Nationality", "NationalityCode");
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(Year1, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(Year2, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(ReligionCode, "Religion", "Select * from Religion order by ReligionCode", "Religion", "ReligionCode");
           // popddl.Popualate(ExamCode1, "ExamName", "Select ExamName, ExamCode from ExamName order by ExamName", "ExamName", "ExamCode");
           // popddl.Popualate(UnivCode1, "University", "Select UnivName,UnivCode from University order by UnivName", "UnivName", "UnivCode");
            RegNo.Focus(); 
        }

    }
    protected void BtnReg_Click(object sender, EventArgs e)
    {
        string AckNo = "";
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        SqlDataReader reader;
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        con.Open();
        cmd.CommandText ="Select ACkNO from Registration Where RegNo='"+RegNo.Text  +"'";
        reader = cmd.ExecuteReader();
        if (reader.HasRows == false)
        {
            reader.Close();
            con.Close();
            LblMsg.Text = " Please Check Registration no";
            Panel2.Visible = false;
            RegNo.Focus();
            return;

        }
        else
        {
            reader.Read(); 
            AckNo = reader["AckNo"].ToString();
        }
        reader.Close();
        con.Close();
        ImageUpload imgUpload = new ImageUpload();
        string strFileName = imgUpload.Image_Load(AckNo);
        
        //Image1.ImageUrl = strFileName;
        //Response.Write(strFileName.ToString());


        if (strFileName.ToString().Contains("temp"))
        {


            string photo = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/temp.jpg";

            string strRightNow = "";
            string IUrl = "";

            strRightNow = System.DateTime.Now.ToString("ddMMyyyyHHmmss");
            IUrl = photo + "?img=" + strRightNow;

            Image3.ImageUrl = IUrl;
            Image3.DataBind();
            

        }
        else if (strFileName.ToString().Contains("UploadPhoto"))
        {

            Image3.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadPhoto.JPG";
            Image3.DataBind();

        }

        else
        {
            LblMsg.Text = "Error" + strFileName;
            //Response.Write("Error");
            //Response.Write(strFileName);
        }

      
        HPaper.Items.Clear();
        SPaper.Items.Clear();
        CompPaper.Items.Clear();   
       
        

        cmd.Connection = con;
        cmd.CommandText = " select RegNo,ApplicantName,HindiName,FatherName,MotherName,DOB,Gender,MaritalStatus,BloodGroup,EmailId,ContactNo,CastCode,NationalityCode," +
            "CollCode,CollegeAdmissionDate,RollNo,CourseSession,PermanentAddress1,PermanentAddress2,PermanentDistCode,PermanentPinCode,PresentAddress1,PresentAddress2,PresentDistrictCode,PresentPinCode," +
            "RegFeeAmt,SCBNo,SCBDate,ReligionCode,RegFormNo,StreamCode,CourseSession,SubCombCode,StreamPartCode, SubCode  from Registration where AckNo='" + AckNo + "'";
        
        con.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            reader.Read();
            
            ApplicantName.Text = reader["ApplicantName"].ToString();
            HindiName.Text = reader["HindiName"].ToString();
            FatherName.Text = reader["FatherName"].ToString();
            MotherName.Text = reader["MotherName"].ToString();
            DOB.Text = string.Format ("{0:dd/MM/yyyy}",Convert.ToDateTime (reader["DOB"]));
            ReligionCode.SelectedValue = reader["ReligionCode"].ToString();
            if (reader["Gender"].ToString() == "M")
                GenderM.Checked = true;
            else
                GenderF.Checked = true;
            MaritalStatus.SelectedValue = reader["MaritalStatus"].ToString();
            if (reader["BloodGroup"].ToString() != "")
            {
                BloodGroup.SelectedValue = reader["BloodGroup"].ToString();
            }
            EmailId.Text = reader["EmailId"].ToString();
            ContactNo.Text = reader["ContactNo"].ToString();
            CastCode.SelectedValue = reader["CastCode"].ToString();
            CollCode.Text = reader["CollCode"].ToString();
            CollegeAdmissionDate.Text = string.Format ("{0:dd/MM/yyyy}",Convert.ToDateTime (reader["CollegeAdmissionDate"]));
            RollNo.Text = reader["RollNo"].ToString();
            PermanentAddress1.Text = reader["PermanentAddress1"].ToString();
            PermanentAddress2.Text = reader["PermanentAddress2"].ToString();
            PermanentDistCode.SelectedValue = reader["PermanentDistCode"].ToString();
            PermanentPinCode.Text = reader["PermanentPinCode"].ToString();
            PresentAddress1.Text = reader["PresentAddress1"].ToString();
            PresentAddress2.Text = reader["PresentAddress2"].ToString();
            PresentDistrictCode.SelectedValue = reader["PresentDistrictCode"].ToString();
            PresentPinCode.Text = reader["PresentPinCode"].ToString();
            CollegeAdmissionDate.Text = string.Format ("{0:dd/MM/yyyy}",Convert.ToDateTime (reader["CollegeAdmissionDate"]));
           // RegFeeAmt.Text = reader["RegFeeAmt"].ToString();
           // SCBNo.Text = reader["SCBNo"].ToString();
           // SCBDate.Text = string.Format ("{0:dd/MM/yyyy}",Convert.ToDateTime (reader["SCBDate"]));
           // RegFormNo.Text = reader["RegFormNo"].ToString();
            StreamCode.SelectedValue = reader["StreamCode"].ToString();
            Year1.Text = (reader["CourseSession"].ToString()).Substring(0, 4);
            Year2.Text = (reader["CourseSession"].ToString()).Substring(5, 4);
            GetSubComb(reader["SubCombCode"].ToString());

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");

            string spc = reader["StreamPartCode"].ToString();
           
            if (spc!="")
            {
                StreamPart.SelectedValue = reader["StreamPartCode"].ToString();
            }
            else
            {
                StreamPart.SelectedIndex = 0;
                
            }

            popddl.Popualate(SubCode, "Subject", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
             spc= reader["SubCode"].ToString();
             if (spc != "")
            {
                SubCode.SelectedValue = reader["SubCode"].ToString();
            }
            else
            {
               SubCode.SelectedIndex = 0;
            }
            

           
            

           
            //reader.Close();
            //cmd.CommandText = " select ExamCode,UnivCode,CollCode,PassYear,RollNo,Division from PREREGQUALIFICATION where AckNo='" + AckNo + "'";
            //reader = cmd.ExecuteReader();
            //if (reader.HasRows)
            //{
            //    reader.Read();
            //    ExamCode1.SelectedValue = reader["ExamCode"].ToString();
            //    UnivCode1.SelectedValue = reader["UnivCode"].ToString();
            //    CollCode1.Text = reader["CollCode"].ToString();
            //    PassYear1.Text = reader["PassYear"].ToString();
            //    RollNo1.Text = reader["RollNo"].ToString();
            //    Division1.SelectedValue = reader["Division"].ToString();

            //}
            
            // if migarated student
            reader.Close(); 
            //cmd.CommandText = "select MigrationNo,MigrationIssueDate from PREREGMIGRATION where AckNo='" + AckNo + "'";
            //reader = cmd.ExecuteReader();
            //if (reader.HasRows)
            //{
            //    reader.Read();
            //    MigrationNo.Text = reader["MigrationNo"].ToString();
            //    MigrationIssueDate.Text =string.Format ("{0:dd/MM/yyyy}",Convert.ToDateTime ( reader["MigrationIssueDate"].ToString()));
            //    Panel4.Visible = true;
            //}
            //else
            //    Panel4.Visible = false; 
 

            reader.Close(); 
            con.Close();

            
            LblMsg.Text = "";
            
            Panel2.Visible = true;
            //Panel3.Visible = true;
        }
        else
        {
            LblMsg.Text = " Please check Ack no.";
            
            Panel2.Visible = false;
            
            RegNo.Focus(); 
        }

    }



    protected void BtnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            

            //----Subject Comb Code
            string CourseComb = "C(";
            //Composition
            for (int i = 0; i < CompPaper.Items.Count; i++)
            {
                if (CompPaper.Items[i].Selected)
                {
                    CourseComb += CompPaper.Items[i].Value + ",";
                }
            }
            //Honours Paper
            CourseComb = CourseComb.Substring(0, CourseComb.Length - 1);
            CourseComb += ")+H(";
            for (int i = 0; i < HPaper.Items.Count; i++)
            {
                if (HPaper.Items[i].Selected)
                {
                    CourseComb += HPaper.Items[i].Value + ",";
                }
            }
            //Sunsidiary Paper
            CourseComb = CourseComb.Substring(0, CourseComb.Length - 1);
            CourseComb += ")+S(";
            for (int i = 0; i < SPaper.Items.Count; i++)
            {
                if (SPaper.Items[i].Selected)
                {
                    CourseComb += SPaper.Items[i].Value + ",";
                }
            }
            CourseComb = CourseComb.Substring(0, CourseComb.Length - 1);
            CourseComb += ")";
            //---SubCom Code
            
            // Transfer old registration data into Re-Admission table
            string sql="insert into ReAdmission (RegNo,StreamCode,StreamPartCode,CollCode,SubCode,CollegeAdmissionDate,RollNo,CourseSession,SubCombCode)"+
                       " select RegNo,StreamCode,StreamPartCode,CollCode,SubCode,CollegeAdmissionDate,RollNo,CourseSession,SubCombCode from Registration where Regno='"+RegNo.Text  +"'";

            string abc = " update Registration  set StreamCode='" + StreamCode.SelectedValue +
                       "', CollCode='" + CollCode.SelectedValue +
                       "', CollegeAdmissionDate='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(CollegeAdmissionDate.Text)) +
                       "', RollNo='" + RollNo.Text.Trim() +
                       "', CourseSession='" + Year1.Text + "-" + Year2.Text +
                        "', StreamPartCode='" + StreamPart.SelectedValue +
                        "', SubCode ='" + SubCode.SelectedValue +
                        "', SubCombCode='" + CourseComb +
                        "' where RegNo='" + RegNo.Text   + "'";
            UnivService.Service1 ss = new UnivService.Service1();
            sql = ss.GetNewCode(sql);
            abc = ss.UpdateData(abc);
            
            if (abc.ToString() == "ok")
            {

                LblMsg.Text = " Record is updated successfully.";


            }
            else
                LblMsg.Text = abc.ToString();
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");


        PopulateList poplist = new PopulateList();
        poplist.Popualate(CompPaper , "COMPOSITION", "Select CompCode,Name from COMPOSITION  order by Name", "Name", "CompCode");
        StreamCode.Focus();
        SubCode_SelectedIndexChanged(sender, e);


    }
    protected void ExamCode1_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateList poplist = new PopulateList();
        //poplist.Popualate(CompPaper, "COMPOSITION", "Select Name,CompCode from COMPOSITION order by Name", "Name", "CompCode");
        poplist.Popualate(HPaper, "COURSEPAPERS", "Select PaperName,SubPaperCode from COURSEPAPERS Where StreamCode='" + StreamCode.SelectedValue + "' And StreamPartCode='" + StreamPart.SelectedValue + "' And SubCode='" + SubCode.SelectedValue + "' order by SubPaperCode", "PaperName", "SubPaperCode");
        //ExamCode1.Focus();
    }
    protected void SubCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateList poplist = new PopulateList();
        poplist.Popualate(HPaper, "COURSEPAPERS", "Select PaperName,SubPaperCode from COURSEPAPERS Where StreamCode='" + StreamCode.SelectedValue + "' And StreamPartCode='" + StreamPart.SelectedValue + "' And SubCode='" + SubCode.SelectedValue + "' order by SubPaperCode", "PaperName", "SubPaperCode");
        poplist.Popualate(SPaper, "SUBJECT", "Select SubCode,SubjectName from SUBJECT Where StreamCode='" + StreamCode.SelectedValue + "' and subcode<>'" + SubCode.SelectedValue + "'  order by SubjectName", "SubjectName", "SubCode");     
        SubCode.Focus(); 

    }

    protected void GetSubComb( string s)
    {
        // Get Subject Combination

        string c = "", h = "", su = "", papercode = "";
        string[] PaperCode = new string[15];
        int i;
        for (i = 0; i < 15; i++)
            PaperCode[i] = "";

        int noofpaper = 0;
        PopulateList poplist = new PopulateList();
        //comp

        if (s.IndexOf('H') - 4 > 0)
        {
            c = s.Substring(2, s.IndexOf('H') - 4);
            for (i = 0; i < c.Length; i++)
            {
                if (c.Substring(i, 1) != ",")
                    papercode = papercode + c.Substring(i, 1);
                else
                {
                    PaperCode[noofpaper] = papercode;
                    noofpaper++;
                    papercode = "";
                }
            }
            PaperCode[noofpaper] = papercode;
            noofpaper++;
        }

        // set Composition paper name in composition paperlist box
        string sql = "";
        for (i = 0; i < noofpaper; i++)
        {
            sql += "CompCode='" + PaperCode[i] + "' OR ";
        }

        if (sql.Length > 3)
        {
            sql = sql.Substring(0, sql.Length - 3);
            sql = "Select Name,compCode from COMPOSITION Where " + sql;
            poplist.Popualate(CompPaper, "COMPOSITION", sql, "Name", "CompCode");
            for (i = 0; i < CompPaper.Items.Count; i++)
            {
                CompPaper.Items[i].Selected = true;  
            }
        }

        //honours
        //hon



        if ((s.IndexOf('S') - (s.IndexOf('H') + 4)) > 0)
        {
            h = s.Substring(s.IndexOf('H') + 2, s.IndexOf('S') - (s.IndexOf('H') + 4));

            papercode = "";
            for (i = 0; i < h.Length; i++)
            {


                if (h.Substring(i, 1) != ",")
                    papercode = papercode + h.Substring(i, 1);
                else
                {
                    PaperCode[noofpaper] = papercode;
                    noofpaper++;
                    papercode = "";
                }
            }
            PaperCode[noofpaper] = papercode;
            noofpaper++;

        }
        // set honours paper name in honours paperlist box
        sql = "";
        for (i = 0; i < noofpaper; i++)
        {
            sql += "SubPaperCode='" + PaperCode[i] + "' OR ";
        }

        if (sql.Length > 3)
        {
            sql = sql.Substring(0, sql.Length - 3);
            sql = "Select PaperName,SubPaperCode from COURSEPAPERS Where " + sql;
            poplist.Popualate(HPaper, "COURSEPAPERS", sql, "PaperName", "SubPaperCode");
            for (i = 0; i < HPaper.Items.Count; i++)
            {
                 //HPaper.SelectedIndex = i;
                 HPaper.Items[i].Selected = true; 
            }
        }

        //sub
        noofpaper = 0; sql = "";

        if ((s.Length - (s.IndexOf('S') + 3)) > 0)
        {
            su = s.Substring(s.IndexOf('S') + 2, s.Length - (s.IndexOf('S') + 3));

            papercode = "";
            for (i = 0; i < su.Length; i++)
            {


                if (su.Substring(i, 1) != ",")
                    papercode = papercode + su.Substring(i, 1);
                else
                {
                    PaperCode[noofpaper] = papercode;
                    noofpaper++;
                    papercode = "";
                }
            }
            PaperCode[noofpaper] = papercode;
            noofpaper++;
        }

        // set subsidiary paper name in subsidiary paperlist box

        sql = "";
        for (i = 0; i < noofpaper; i++)
        {
            sql += "SubCode='" + PaperCode[i] + "' OR ";
        }
        if (sql.Length > 3)
        {
            sql = sql.Substring(0, sql.Length - 3);
            sql = "Select SubCode,SubjectName from SUBJECT Where " + sql;
            poplist.Popualate(SPaper, "SUBJECT", sql, "SubjectName", "SubCode");
            for (i = 0; i < SPaper.Items.Count; i++)
            {
             
                SPaper.Items[i].Selected = true;
            }
        }



        //------------ End Of Subject Combination
    }
   
}


