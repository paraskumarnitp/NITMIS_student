using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Microsoft.Reporting.WebForms;
public partial class coursepaperCriteriadetails : System.Web.UI.Page
{
    Functionreviseed dut = new Functionreviseed();
    string streamcode = "";
   string  coursetttle = "";
      string   coursecode = "";
    string sem = "";
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Request.QueryString["streamcode"] != null)
        {
            streamcode = Request.QueryString["streamcode"];
        }
          

            if (!IsPostBack)
            {
               
                setData();
            }
        
    }


    public void setData()
    {
        
       // dut.singlevalue(cmssemester, "COURSEPAPERS", "select distinct STREAMPART,STREAMcode from COURSEPAPERS where StreamCode='" + streamcode + "'", "STREAMPART", "STREAMcode");
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(cmbexamsession, "EXAMPAPERDETAIL", "select DIStinct ExamSession from EXAMPAPERDETAIL", "ExamSession", "ExamSession");

            //select distinct STREAMPART from COURSEPAPERS where StreamCode='05'
     //      popddl.Popualate(cmssemester, "COURSEPAPERS", "select distinct STREAMPART,STREAMcode from COURSEPAPERS where StreamCode='" + streamcode + "'", "STREAMPART", "STREAMcode");
       //     cmssemester.Items.Insert(0, new ListItem("ALL", "00"));

            string query = "select distinct STREAMPART,STREAMcode from COURSEPAPERS where StreamCode='" + streamcode + "'";
            string conString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
           while (dr.Read())
            {
             //   coursetttle = dr[0].ToString();
               // coursecode = dr[1].ToString();

                cmssemester.Items.Add(dr[0].ToString());
            }
            cmssemester.Items.Insert(0, new ListItem("ALL", "00"));
            con.Close();

    }
    protected void btngetdetails_Click(object sender, EventArgs e)
    {

       

       bindData();


    }


    public void bindData()
    {
        try
        {
            string qur = "";
            string query1 = "";
            string query = "SELECT STREAM ,streamAbbr from STREAM where stream<>'--select--' and StreamCode='" + streamcode.Trim() + "'";



            if (cmssemester.SelectedItem.ToString().Equals("ALL"))
            {
                qur = "SELECT ROW_NUMBER()OVER(ORDER BY  COURSEPAPERS.PaperAbbr ASC) as 'SerialNO',  COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName," +
                        "COURSEPAPERS.Credit, COURSEPAPERS.L, COURSEPAPERS.T, COURSEPAPERS.P " +
                        "FROM CourseCodeOfferedDetail INNER JOIN   COURSEPAPERS ON CourseCodeOfferedDetail.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                        "INNER JOIN  CoursePaperOfferedType ON CourseCodeOfferedDetail.OfferedTypeId = CoursePaperOfferedType.Id   WHERE     (CourseCodeOfferedDetail.CourseCodeOfferedId IN  (SELECT     Id  FROM          CourseCodeOffered  WHERE      (ExamSession = '" + cmbexamsession.SelectedItem.ToString() + "')  and StreamCode='" + streamcode.Trim() + "') ) order by COURSEPAPERS.PaperAbbr";
                qur = "SELECT ROW_NUMBER()OVER(ORDER BY  COURSEPAPERS.PaperAbbr ASC) as 'SerialNO', STREAMPART,  COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName,     COURSEPAPERS.Credit, COURSEPAPERS.L, COURSEPAPERS.T, COURSEPAPERS.P ,sum(cast(COURSEPAPERS.P as int))as Total  FROM CourseCodeOfferedDetail INNER JOIN   COURSEPAPERS ON CourseCodeOfferedDetail.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN  CoursePaperOfferedType ON CourseCodeOfferedDetail.OfferedTypeId = CoursePaperOfferedType.Id   WHERE     (CourseCodeOfferedDetail.CourseCodeOfferedId IN  (SELECT     Id  FROM          CourseCodeOffered  WHERE      (ExamSession = '" + cmbexamsession.SelectedItem.ToString() + "')   and StreamCode='" + streamcode.Trim() + "') )  group by PaperAbbr,PaperName,Credit,L,T,P,STREAMPART order by COURSEPAPERS.PaperAbbr";
 

                query1 = "SELECT  COURSEPAPERS.PaperAbbr ,COURSEPAPERS.PaperName,COURSEPAPERS.StreamCode,COURSEPAPERS.StreamPart,   COURSEPAPERS.Credit as Credit1, COURSEPAPERS.L as L1,COURSEPAPERS.T as T1, COURSEPAPERS.P as P1 FROM  COURSEPAPERS INNER JOIN   MasterCoursePaper ON COURSEPAPERS.MasterPaperId = MasterCoursePaper.Id where IsOpenElective='1' and StreamCode='" + streamcode.Trim() + "'  order by PaperAbbr";

            }
            else
            {
                qur = "SELECT ROW_NUMBER()OVER(ORDER BY  COURSEPAPERS.PaperAbbr ASC) as 'SerialNO',  COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName," +
                                        "COURSEPAPERS.Credit, COURSEPAPERS.L, COURSEPAPERS.T, COURSEPAPERS.P " +
                                        "FROM CourseCodeOfferedDetail INNER JOIN   COURSEPAPERS ON CourseCodeOfferedDetail.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                                        "INNER JOIN  CoursePaperOfferedType ON CourseCodeOfferedDetail.OfferedTypeId = CoursePaperOfferedType.Id   WHERE     (CourseCodeOfferedDetail.CourseCodeOfferedId IN  (SELECT     Id  FROM          CourseCodeOffered  WHERE      (ExamSession = '" + cmbexamsession.SelectedItem.ToString() + "') and STREAMPART='" + cmssemester.SelectedItem.ToString().Trim() + "'  and StreamCode='" + streamcode.Trim() + "') ) order by COURSEPAPERS.PaperAbbr";

               query1 = "SELECT  COURSEPAPERS.PaperAbbr ,COURSEPAPERS.PaperName,COURSEPAPERS.StreamCode,COURSEPAPERS.StreamPart,   COURSEPAPERS.Credit as Credit1, COURSEPAPERS.L as L1,COURSEPAPERS.T as T1, COURSEPAPERS.P as P1 FROM  COURSEPAPERS INNER JOIN   MasterCoursePaper ON COURSEPAPERS.MasterPaperId = MasterCoursePaper.Id where IsOpenElective='1' and StreamCode='" + streamcode.Trim() + "' and STREAMPART='" + cmssemester.SelectedItem.ToString().Trim() + "' order by PaperAbbr";



     //    query1 = "SELECT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName, COURSEPAPERS.Credit AS Credit1, COURSEPAPERS.L AS L1, COURSEPAPERS.T AS T1, COURSEPAPERS.P AS P1   FROM      COURSEPAPERS INNER JOIN MasterCoursePaper ON COURSEPAPERS.MasterPaperId = MasterCoursePaper.Id INNER JOIN  CourseCodeOffered ON MasterCoursePaper.Id = CourseCodeOffered.Id WHERE     (MasterCoursePaper.IsOpenElective = '1') AND (COURSEPAPERS.StreamCode = '" + streamcode.Trim() + "') AND (COURSEPAPERS.StreamPart = '" + cmssemester.SelectedItem.ToString().Trim() + "') AND  (CourseCodeOffered.ExamSession = '" + cmssemester.SelectedItem.ToString().Trim() + "') ORDER BY COURSEPAPERS.PaperAbbr";


            
            }

           
         
            string conString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

            SqlConnection con = new SqlConnection(conString);
            DataSet ds = new DataSet();
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                coursetttle = dr[0].ToString();
                coursecode = dr[1].ToString();


            }
            con.Close();

            SqlDataAdapter sda = new SqlDataAdapter(qur, con);

            SqlDataAdapter sda1 = new SqlDataAdapter(query1,con);

            DataTable dt = new DataTable("CourseDetails_DataTable1");
            sda.Fill(dt);

            DataTable dt1 = new DataTable("CourseDetails_DataTable2");
           sda1.Fill(dt1);
            

            ds.Tables.Add(dt);
           ds.Tables.Add(dt1);
            
            if (dt.Rows.Count > 0)
            {
                ReportViewer2.ProcessingMode = ProcessingMode.Local;
                ReportViewer2.LocalReport.ReportPath = Server.MapPath("~/CoursePaperdetailsReport.rdlc");
                ReportParameter[] param = new ReportParameter[3];
                //   param[0] = new ReportParameter("prmstreamcode", Label1.Text);

                param[0] = new ReportParameter("prmcoursecode", coursecode);
                param[1] = new ReportParameter("prmcoursetitle", coursetttle);
                param[2] = new ReportParameter("Semester", cmssemester.SelectedItem.ToString());
                ReportViewer2.LocalReport.SetParameters(param);

                ReportDataSource datasource = new ReportDataSource("CourseDetails_DataTable1", dt);
                ReportDataSource datasource1 = new ReportDataSource("CourseDetails_DataTable2", dt1);
                ReportViewer2.LocalReport.DataSources.Clear();
                ReportViewer2.LocalReport.DataSources.Add(datasource);
                ReportViewer2.LocalReport.DataSources.Add(datasource1);

            }
            else
            {

                ReportViewer2.ProcessingMode = ProcessingMode.Local;
                ReportViewer2.LocalReport.ReportPath = Server.MapPath("~/CoursePaperdetailsReport.rdlc");
                ReportParameter[] param = new ReportParameter[3];
                //   param[0] = new ReportParameter("prmstreamcode", Label1.Text);
                param[0] = new ReportParameter("prmcoursecode", coursecode);
                param[1] = new ReportParameter("prmcoursetitle", coursetttle);
                param[2] = new ReportParameter("Semester", cmssemester.SelectedItem.ToString());
                ReportViewer2.LocalReport.SetParameters(param);

                ReportDataSource datasource = new ReportDataSource("CourseDetails_DataTable1", dt);
                ReportDataSource datasource1 = new ReportDataSource("CourseDetails_DataTable2", dt1);
                ReportViewer2.LocalReport.DataSources.Clear();
                ReportViewer2.LocalReport.DataSources.Add(datasource);
                ReportViewer2.LocalReport.DataSources.Add(datasource1);

            }
        }
        catch (Exception ex)
        {

        }

    }


}
