using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Drawing;
public partial class DSCSetting : System.Web.UI.Page
{
    static int flag = 0,flag1=0;
  
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
    
        grdmember.Visible = false;
        GridView1.Visible = false;
        grddsc.Visible = false;
        btok.Visible = false;
        popupcontent.Visible = false;
        try
        {
            //if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "9") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "15"))
            //{
            //    Session["userName"] = null;
            //    FormsAuthentication.SignOut();
            //    Response.Redirect("default.aspx");
            //    return;
            //}
        }
        catch (Exception ex)
        {
            Response.Redirect("default.aspx");

        }
        if (IsPostBack)
        {
            grdmember.Visible = false;
            grddsc.Visible = true;
            GridView1.Visible = false;
            if (rdoInternal.Checked && flag == 1)
            {
                bindData();
                grddsc.Visible = true;
               // grdexternal.Visible = false;
                grdmember.Visible = false;
              
                
            }
            if (rdoExternal.Checked && flag1 == 1)
            {
                bindexternal();
                grddsc.Visible = false;
              //  grdexternal.Visible = true;
                grdmember.Visible = false;
              
                
            }
           
            flag = 0;
            flag1 = 0;
            bindmember();
            
           // grddsc.Visible = false;
            //grdexternal.Visible = false;
        }

    }


    public void bindData1()
    {
        try
        {


            String query = "SELECT    UserId,UserName,Designation,ContactNo,EmailId,Department.Name FROM   LogIn INNER JOIN" +
                " Department ON LogIn.DepartmentId = Department.Id WHERE     (LogIn.Userrole IN ('9', '13')) ";

            DataTable dtmis = fnrev.SelectDatatable(query);

            grddsc.DataSource = dtmis;
            grddsc.DataBind();



        }
        catch (Exception ex)
        {

        }

    }

    public void bindData()
    {
        try
        {


            String query = "SELECT UserId,UserName,Designation,ContactNo,EmailId,Department.Name FROM LogIn INNER JOIN" +
                " Department ON LogIn.DepartmentId = Department.Id WHERE (LogIn.Userrole IN ('9', '13')) and UserId NOT IN (SELECT DISTINCT userid FROM dscsetting) AND userid not like '%DEMO%'";

            DataTable dtmis = fnrev.SelectDatatable(query);

            grddsc.DataSource = dtmis;
            grddsc.DataBind();


        }
        catch (Exception ex)
        {

        }


    }

    public void bindexternal()
    {
        try
        {


            String query = "select  id,userid,name,Organization ,department,membertype,loginid,ContactNo,EmailId from dscsetting  where membertype='EXTERNAL'"; 
            DataTable dtmis = fnrev.SelectDatatable(query);

           // grdexternal.DataSource = dtmis;
            //grdexternal.DataBind();

           
        }
        catch (Exception ex)
        {

        }
    }

    public void bindmember()
    {
        try
        {
            if (rdoInternal.Checked)
            {

                String query = "select  id,userid,name,Organization ,department,membertype,loginid,ContactNo,EmailId,case when(is_Active='1') then 'Y' else 'N' END as 'Active/Dective'  from dscsetting  where membertype='INTERNAL' ";
                DataTable dtmis = fnrev.SelectDatatable(query);

                //grdmember1.DataSource = dtmis;
              //  grdmember1.DataBind();

                GridView1.DataSource = dtmis;
                GridView1.DataBind();
                grdmember.Visible = false;
                GridView1.Visible = true;
                grddsc.Visible = false;
            }
            else if(rdoExternal.Checked)
            {

                String query = "select  id,userid,name,Organization ,department,membertype,loginid,ContactNo,EmailId,case when(is_Active='1') then 'Y' else 'N' END as 'Active/Dective' from dscsetting  where membertype='EXTERNAL' ";
                DataTable dtmis = fnrev.SelectDatatable(query);

                grdmember.DataSource = dtmis;
                grdmember.DataBind();
               // grdmember1.Visible = false;
                grdmember.Visible = true;
                GridView1.Visible = false;
                grddsc.Visible = false;
            }
        }
        catch (Exception ex)
        {

        }

    }

    protected void btnView_Click(object sender, EventArgs e)
    {

        if (rdoInternal.Checked)
        {
            bindData();
          //  grdexternal.Visible = false;
            grddsc.Visible = true;
            grdmember.Visible = false;
            btok.Visible = true;
            GridView1.Visible = false;
        }
        else if (rdoExternal.Checked)
        {
            popupcontent.Visible = true;
           // bindexternal();
           // grdexternal.Visible = false;
            grddsc.Visible = false;
            grdmember.Visible = false;
            btok.Visible = false;
            GridView1.Visible = false;
        }
    }
    protected void grddsc_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        if (rdoInternal.Checked)
        {
            grddsc.PageIndex = e.NewPageIndex;
            bindData1();
            GridView1.Visible = false;
            grdmember.Visible = false;
            grddsc.Visible = true;
        }




    }
    protected void rdoIntenal_CheckedChanged(object sender, EventArgs e)
    {
        grdmember.Visible = false;
        
        GridView1.Visible = false;
    }
    protected void rdoExternal_CheckedChanged(object sender, EventArgs e)
    {
        grdmember.Visible = false;
     
        GridView1.Visible = false;
    }
    //protected void btnOk_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        flag = 1;


    //        String query = "SELECT    UserId,UserName,Designation,ContactNo,EmailId,Department.Name FROM   LogIn INNER JOIN" +
    //            " Department ON LogIn.DepartmentId = Department.Id WHERE     (LogIn.Userrole IN ('9', '13')) and username like('" + txtname.Text.Trim() + "%') ";

    //        DataTable dtmis = fnrev.SelectDatatable(query);

    //        grddsc.DataSource = dtmis;
    //        grddsc.DataBind();
           

    //    }
    //    catch (Exception ex)
    //    {

    //    }

    //    grddsc.Visible = true;
    //    grdmember.Visible = false;
    //    GridView1.Visible = false;

    //}

    protected void AddExternal_Click(object sender, EventArgs e)
    {
        popupcontent.Visible = true;
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        grdmember.Visible = false;
        popupcontent.Visible = false;
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {

      
        string uname = txtname1.Text.Trim();
        string org = txtorgname.Text.Trim();
        string dept = txtdept.Text.Trim();
        string contact = txtcontact.Text.Trim();
        string email = txtemail.Text.Trim();


     
        string query1 = "INSERT INTO dscsetting(name,userid,ContactNo,EmailId,Organization,department,membertype,loginid) VALUES  ('" + uname + "','Ex001','" + contact + "','" + email + "','" + org + "','" + dept + "','EXTERNAL','" + Session["UserId"].ToString() + "')";

        int result = fnrev.InsertUpdateDelete(query1);
        if (result == 0)
        {
            lblpopupmsg.Text = "Failed to add External Member, Try Again.";
            return;
        }
        else if (result == -1000)
        {
            lblpopupmsg.Text = "This Member Already exist.";
            
            //ClientScript.RegisterClientScriptBlock(this.GetType(), "CHANAKYA", script.ToString());
            return;
        }
        else        
        {
            txtname1.Text = "";
            txtorgname.Text = "";
            txtdept.Text = "";
            txtcontact.Text = "";
            txtemail.Text = "";
            // bindexternal();

            popupcontent.Visible = true;
            grdmember.Visible = false;
            lblpopupmsg.Text = "Member has been created successfully.";
          
            //ClientScript.RegisterClientScriptBlock(this.GetType(), "CHANAKYA", script.ToString());
            return;
            
        }
        
    }
    protected void btok_Click(object sender, EventArgs e)
    {
        int i = 0;
        CheckBox cb = new CheckBox();
        Label info;
        string uid, name,mobile,email,dept;
        foreach (GridViewRow GR in grddsc.Rows)
        {
            if (GR.RowType == DataControlRowType.DataRow)
            {
                cb = (CheckBox)GR.FindControl("CheckBox1");
             if (cb.Checked)
                {
                    info = (Label)GR.FindControl("lblmemberid");
                    uid = info.Text;
                    info = (Label)GR.FindControl("lblName");
                    name = info.Text;
                    info = (Label)GR.FindControl("lblMobile");
                    mobile = info.Text;
                    info = (Label)GR.FindControl("lblEmail");
                    email = info.Text;
                    info = (Label)GR.FindControl("lblDepartment");
                     dept = info.Text;

                     string strConnString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
                     SqlConnection con = new SqlConnection(strConnString);
                     con.Open();
                     SqlCommand cmd = new SqlCommand("select userid from dscsetting where  userid='" + uid + "'",con);
                     SqlDataReader dr = cmd.ExecuteReader();
                     if (dr.Read ())
                     {
                        
                     }

                     else
                     {
                         string query1 = "INSERT INTO dscsetting(name,userid,ContactNo,EmailId,Organization,department,membertype,loginid) VALUES  ('" + name + "','" + uid + "','" + mobile + "','" + email + "','NIT PATNA','" + dept + "','INTERNAL','" + Session["UserId"].ToString() + "')";

                         i = fnrev.InsertUpdateDelete(query1);
                     }
                     con.Close();
                   

               }
                //        //here you write your code
            }

        }
        if(i>0)
        Label1.Text = "Saved Sucessfully!";
        grdmember.Visible = false;
        GridView1.Visible = false;
    }
    protected void btnshow_Click(object sender, EventArgs e)
    {



        bindmember();
        //grdmember.Visible = false;
        //grddsc.Visible = false;
        //grdexternal.Visible = false;


    }
    protected void grdmember_SelectedIndexChanged(object sender, EventArgs e)
    {


        foreach (GridViewRow row in grdmember.Rows)
        {
            if (row.RowIndex == grdmember.SelectedIndex)
            {
                row.BackColor = ColorTranslator.FromHtml("#A1DCF2");
            }
            else
            {
                row.BackColor = ColorTranslator.FromHtml("#FFFFFF");
            }
        }


    }
    protected void grdmember1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //string query1 = "";

        // memid = (grdmember1.SelectedRow.FindControl("lbltmemberid1") as Label).Text;
     
        //String query = "SELECT is_Active from  dscsetting where   userid='" + memid.Trim() + "' ";

        //DataTable dtmis = fnrev.SelectDatatable(query);
        //string isactive = dtmis.Rows[0]["is_Active"].ToString();
        //if (isactive.Equals("1"))
        //{

        //   query1 = "update dscsetting set is_Active='0' where userid='"+memid.Trim()+"'";
        //    (grdmember1.SelectedRow.FindControl("linkactdac1") as LinkButton).Text = "Deactive";
        //    fnrev.InsertUpdateDelete(query1);
          
        //}
        //else
        //{
        //    query1 = "update dscsetting set is_Active='1' where userid='" + memid.Trim()+ "'";
        //    (grdmember1.SelectedRow.FindControl("linkactdac1") as LinkButton).Text = "Active";
        //    fnrev.InsertUpdateDelete(query1);
            
        //}
       



    }


   
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {


       
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

             
        }


    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int rowIndex = Convert.ToInt32(e.CommandArgument);
        string query1 = "";
        //Reference the GridView Row.
        GridViewRow row = GridView1.Rows[rowIndex];
        Label memid = (row.FindControl("lbltmemberid1") as Label);
        string memberid1 = memid.Text;

        String query = "select is_Active from dscsetting where userid ='" + memberid1 + "'  ";
        DataTable dtmis = fnrev.SelectDatatable(query);

        string isactive = dtmis.Rows[0]["is_Active"].ToString();
        if (isactive.Equals("1"))
        {
            query1 = "update dscsetting set is_Active='0' where userid='" + memberid1.Trim() + "'";
            fnrev.InsertUpdateDelete(query1);

            foreach (GridViewRow row1 in GridView1.Rows)
            {
                if (row1.RowIndex == GridView1.SelectedIndex)
                {
                 
                    row1.BackColor = ColorTranslator.FromHtml("#FFFFFF");
                }
                
            }
        }
        else
        {
            query1 = "update dscsetting set is_Active='1' where userid='" + memberid1.Trim() + "'";
            fnrev.InsertUpdateDelete(query1);
            foreach (GridViewRow row1 in GridView1.Rows)
            {
                if (row1.RowIndex == GridView1.SelectedIndex)
                {

                    row1.BackColor = ColorTranslator.FromHtml("#A1DCF2");
                }

            }
           
        }

        //Access Cell values.
        
    }
    protected void grdmember_RowDataBound(object sender, GridViewRowEventArgs e)
    {





    }

 
    protected void grdmember_RowCommand1(object sender, GridViewCommandEventArgs e)
    {


        int rowIndex = Convert.ToInt32(e.CommandArgument);
        string query1 = "";
        //Reference the GridView Row.
        GridViewRow row = grdmember.Rows[rowIndex];
        Label memid = (row.FindControl("lbltmemberid") as Label);
        string memberid1 = memid.Text;

        String query = "select is_Active from dscsetting where id ='" + memberid1 + "'  ";
        DataTable dtmis = fnrev.SelectDatatable(query);

        string isactive = dtmis.Rows[0]["is_Active"].ToString();
        if (isactive.Equals("1"))
        {
            query1 = "update dscsetting set is_Active='0' where id='" + memberid1.Trim() + "'";
            fnrev.InsertUpdateDelete(query1);

            foreach (GridViewRow row1 in grdmember.Rows)
            {
                if (row1.RowIndex == grdmember.SelectedIndex)
                {

                    row1.BackColor = ColorTranslator.FromHtml("#FFFFFF");
                }

            }
        }
        else
        {
            query1 = "update dscsetting set is_Active='1' where id='" + memberid1.Trim() + "'";
            fnrev.InsertUpdateDelete(query1);
            foreach (GridViewRow row1 in grdmember.Rows)
            {
                if (row1.RowIndex == grdmember.SelectedIndex)
                {

                    row1.BackColor = ColorTranslator.FromHtml("#A1DCF2");
                }

            }

        }
    }
}

    

