using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
public partial class Composition : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["Role"].ToString() != "1")
            {
                Session["userName"] = null;
                FormsAuthentication.SignOut();
                Response.Redirect("default.aspx");
            }
            ViewState.Add("EditMode", "false");
        }

    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {
        string abc = "";
        Panel2.Visible = false;
        if (ViewState["EditMode"].ToString () == "false")
        {
            string[] col = new string[5];
            string[] val = new string[5];
            col[0]="Compcode";
            col[1] = "Name";
            col[2] = "Abbr";
            col[3] = "FullMarks";
            col[4] = "PassMarks";
            Panel2.Visible = false;
            val[1] = Name.Text.Trim();
            val[2] = Abbr.Text.Trim();
            val[3] = FullMarks.Text.Trim();
            val[4] = PassMarks.Text.Trim(); 

            UnivService.Service1 ss = new UnivService.Service1();
            string SQL = "SELECT     ISNULL(MAX(ABS(CompCode)), '0') + 1 AS NewCategoryCode FROM COMPOSITION";
            string NewCompCode = ss.GetNewCode(SQL);
            NewCompCode = string.Format("{0:D2}", Convert.ToInt16(NewCompCode));

            val[0] = NewCompCode;
            
            abc = ss.SaveData("Composition", col, val);

            if (abc == "1")
            {
                LblMsg.Text = " Composition paper is saved successfully. Paper Code= " + NewCompCode;
                string popupScript = "<script language='javascript'>" +
                                " alert('Composition paper is saved successfully. Paper Code=   " + NewCompCode + " ')" +
                                 "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);

                Name.Text = "";
                Abbr.Text = "";
                PassMarks.Text = "";
                FullMarks.Text = ""; 
                Name.Focus();

            }
            else
            {
                LblMsg.Text = abc.ToString();
            }
        }
        else
        {
            
            UnivService.Service1 ss = new UnivService.Service1();
            abc = " update composition set Name='" + Name.Text + "', Abbr='"+Abbr.Text  +"', FullMarks='"+FullMarks.Text  +"', PassMarks='"+PassMarks.Text  +"' where Compcode='" + CompositionView.SelectedRow.Cells[1].Text+"'";
            abc = ss.UpdateData(abc);
            if (abc.ToString() == "ok")
            {
                ViewState.Add("EditMode", "false");
                LblMsg.Text = " Record is updated successfully.";
                Name.Text = "";
                Abbr.Text = "";
                FullMarks.Text = "";
                PassMarks.Text = ""; 
                Name.Focus();

            }
            else
                LblMsg.Text = abc.ToString();

        }



    }
    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        Panel2.Visible = true;
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select * from Composition order by CompCode");
        CompositionView.DataSource = ds;
        CompositionView.DataBind(); 
        
    }
   
    protected void CateGoryView_SelectedIndexChanged(object sender, EventArgs e)
    {
        Name.Text = CompositionView.SelectedRow.Cells[2].Text.ToString();
        Abbr.Text = CompositionView.SelectedRow.Cells[3].Text.ToString(); ;
        FullMarks.Text = CompositionView.SelectedRow.Cells[4].Text.ToString();
        PassMarks.Text = CompositionView.SelectedRow.Cells[5].Text.ToString();

        ViewState.Add("EditMode", "true");
        Name.Focus(); 
        


    }


    
    //protected void GridView1_RowCommand(object sender,GridViewCommandEventArgs e)
    //    {
    //        if (e.CommandName == "Delete1")
    //        {
    //            // get the categoryCode of the clicked row
    //            //int categoryID = Convert.ToInt32(e.CommandArgument);
                
    //            UnivService.Service1 ss = new UnivService.Service1();
    //            string abc = " delete from category where CategoryCode='" + e.CommandArgument.ToString() + "'";
    //            abc = ss.UpdateData(abc);
    //            if (abc.ToString() == "ok")
    //            {

    //                LblMsg.Text = " Record is deleted successfully.";
    //                CategoryNm.Text = "";
    //                    DataSet ds = new DataSet();
    //                    ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select * from Category order by CategoryCode");
    //                    CateGoryView.DataSource = ds;
    //                    CateGoryView.DataBind();
    //                CategoryNm.Focus();
    //                //LblMsg.Text = "";
    //            }
    //            else
    //                LblMsg.Text = abc.ToString();

    //        }
            
    //    }
    
}
