using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Net;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;


public partial class OptEntryAdmList : System.Web.UI.Page
{
   static int ch1 = 0,ch2=0,ch3=0,ch4=0;
  


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "10")&& (Session["Role"].ToString() != "16"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
          int CurrentYear = System.DateTime.Now.Year;
            LblMsg2.Visible = false;
            PopulateDDL popddl = new PopulateDDL();

            popddl.Popualate(Year1, "Year", "Select Year from Year where year >2010 and year<='"+CurrentYear+"'  order by Year", "Year", "Year");

        
        }

        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        BindGrid();
        Button2.Visible = true;
    }
    protected void OptEntryAdmListView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        // handle for next page
        OptEntryAdmListView.PageIndex = e.NewPageIndex;

        BindGrid();
    }

    protected void BindGrid()
    {
        try
        {
             LblMsg2.Visible = false;

            string sql = "";
            UnivService.Service1 NicService = new UnivService.Service1();
            string count="";
            string prog = "";
            if (DropDownList1.SelectedValue == "0") //B.tech
                prog = "01,02,03,04,06,07";
            else if (DropDownList1.SelectedValue == "1")//M.Tech
                prog = "21,23,26,28,29,32";
            else if (DropDownList1.SelectedValue == "2")//B.Arch
                prog = "05";
            else if (DropDownList1.SelectedValue == "3")//MURP
                prog = "30";

                             
            
            
            if (ch1 == 1 && ch2 == 1 && ch3 == 1 && ch4 == 1)
            {
                count = NicService.GetNewCode("select count(ackno) from registration where  streamcode in ('" + prog + "') and streamcode='" + DropDownList2.SelectedValue + "' and Gender='" + DDGender.SelectedValue + "' and CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'");
                sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
      " WHERE  streamcode in ('" + prog + "') and R.streamcode='" + DropDownList2.SelectedValue + "' and Gender='" + DDGender.SelectedValue + "' and R.CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'";
        
            }
             else if (ch1 == 1 && ch2 == 1 && ch3 == 1)
             {

                 count = NicService.GetNewCode("select count(ackno) from registration where streamcode in ('" + prog + "') and streamcode='" + DropDownList2.SelectedValue + "' and CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'");
                 sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
       " WHERE  streamcode in ('" + prog + "') and R.streamcode='" + DropDownList2.SelectedValue + "' and R.CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'";
             }
             else if (ch1 == 1 && ch2 == 1 && ch4 == 1)
             {
                 count = NicService.GetNewCode("select count(ackno) from registration where streamcode in ('" + prog + "') and streamcode='" + DropDownList2.SelectedValue + "' and Gender='" + DDGender.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'");
                 sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
       " WHERE streamcode in ('" + prog + "') and R.streamcode='" + DropDownList2.SelectedValue + "' and R.Gender='" + DDGender.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'";
             }
             else if (ch1 == 1 && ch3 == 1 && ch4 == 1)
             {

                 count = NicService.GetNewCode("select count(ackno) from registration where streamcode in ('" + prog + "') and Gender='" + DDGender.SelectedValue + "' and CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'");
                 sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
       " WHERE  streamcode in ('" + prog + "') and Gender='" + DDGender.SelectedValue + "' and R.CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'";
             }
             else if (ch2 == 1 && ch3 == 1 && ch4 == 1)
             {
                 count = NicService.GetNewCode("select count(ackno) from registration where streamcode='" + DropDownList2.SelectedValue + "' and Gender='" + DDGender.SelectedValue + "' and CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'");
                 sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
       " WHERE R.streamcode='" + DropDownList2.SelectedValue + "' and Gender='" + DDGender.SelectedValue + "' and R.CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'";
             }

             else if (ch1 == 1 && ch2 == 1)
             {
                 count = NicService.GetNewCode("select count(ackno) from registration where  streamcode in ('" + prog + "') and streamcode='" + DropDownList2.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'");
                 sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
       " WHERE  R.streamcode in ('" + prog + "') and R.streamcode='" + DropDownList2.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'";


             }
             else if (ch1 == 1 && ch3 == 1)
             {
                 count = NicService.GetNewCode("select count(ackno) from registration where streamcode in ('" + prog + "') and  CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'");
                 sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
       " WHERE streamcode in ('" + prog + "') and R.CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'";
             }
             else if (ch1 == 1 && ch4 == 1)
             {
                 count = NicService.GetNewCode("select count(ackno) from registration where  streamcode in ('" + prog + "') and  Gender='" + DDGender.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'");
                 sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
       " WHERE  streamcode in ('" + prog + "') and  R.Gender='" + DDGender.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'";
             }
             else if (ch2 == 1 && ch3 == 1)
             {
                 count = NicService.GetNewCode("select count(ackno) from registration where streamcode='" + DropDownList2.SelectedValue + "' and CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'");
                 sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
       " WHERE R.streamcode='" + DropDownList2.SelectedValue + "' and R.CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'";
             }
             else if (ch2 == 1 && ch4 == 1)
             {
                 count = NicService.GetNewCode("select count(ackno) from registration where streamcode='" + DropDownList2.SelectedValue + "' and Gender='" + DDGender.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'");
                 sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
       " WHERE R.streamcode='" + DropDownList2.SelectedValue + "' and R.Gender='" + DDGender.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'";
             }
             else if (ch3 == 1 && ch4 == 1)
             {
                 count = NicService.GetNewCode("select count(ackno) from registration where Gender='" + DDGender.SelectedValue + "' and CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'");
                 sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
       " WHERE Gender='" + DDGender.SelectedValue + "' and R.CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'";

             }
            else if (ch1 == 1)
            {
                
                count = NicService.GetNewCode("select count(ackno) from registration where streamcode in ('"+prog+"') and AdmYear='" + Year1.SelectedValue + "'");
                sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
      " WHERE R.streamcode  in ('" + prog + "') and AdmYear='" + Year1.SelectedValue + "'";
            }
            else if (ch2 == 1)
            {
                count = NicService.GetNewCode("select count(ackno) from registration where streamcode='" + DropDownList2.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'");
                sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
      " WHERE R.streamcode='" + DropDownList2.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'";
            }
            else if(ch3==1)
            {
                count = NicService.GetNewCode("select count(ackno) from registration where CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'");
                sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
      " WHERE R.CastCode='" + DropDownList3.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'";
            }
            else if (ch4 == 1)
            {
                count = NicService.GetNewCode("select count(ackno) from registration where Gender='" + DDGender.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'");
                sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
      " WHERE R.Gender='" + DDGender.SelectedValue + "' and AdmYear='" + Year1.SelectedValue + "'";
            }        
           
           
            else {
                count = NicService.GetNewCode("select count(ackno) from registration where AdmYear='" + Year1.SelectedValue + "'");
                sql = "select row_number() OVER (ORDER BY R.Streamcode ASC)AS Count,AckNo,ApplicantName,Stream,AdmYear from registration R inner join Stream S on R.StreamCode=S.StreamCode" +
      " WHERE  AdmYear='" + Year1.SelectedValue + "'";
        
            }

            DataSet ds = new DataSet();
            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);

            OptEntryAdmListView.DataSource = ds;
            OptEntryAdmListView.DataBind();

            if (OptEntryAdmListView.Rows.Count.ToString() == "0")
            {
                LblMsg2.Visible = true;
                LblMsg2.Text = " No Records found...";
            }
            else
            {
                LblMsg2.Visible = true;
                LblMsg2.Text = " Total No. Of Students:" + count;
            }

        }
        catch (Exception ex)
        {
            LblMsg2.Visible = true;
            LblMsg2.Text = " Please Select Date";
        }
    }
   
    protected void Button2_Click(object sender, EventArgs e)
    {
      //  string name = "'"+DropDownList2.SelectedItem + "::"+ Year1.SelectedItem +"'";

        string name = "'" + Year1.SelectedItem + "'";
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename='"+name+"'.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        OptEntryAdmListView.AllowPaging = false;
        //OptEntryAdmListView.DataBind();
        BindGrid();
        OptEntryAdmListView.RenderControl(hw);
        OptEntryAdmListView.HeaderRow.Style.Add("width", "300px");
        OptEntryAdmListView.HeaderRow.Style.Add("font-size", "10px");
        OptEntryAdmListView.Style.Add("text-decoration", "none");
        OptEntryAdmListView.Style.Add("font-family", "Arial, Helvetica, sans-serif;");
        OptEntryAdmListView.Style.Add("font-size", "8px");
        StringReader sr = new StringReader(sw.ToString());
        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        htmlparser.Parse(sr);
        pdfDoc.Close();
        Response.Write(pdfDoc);
        Response.End();

      }
    public override void VerifyRenderingInServerForm(Control control)
    {

      
        /* Verifies that the control is rendered */
    }

    protected void CBclg_CheckedChanged(object sender, EventArgs e)
    {
        if (CBclg.Checked == true)
        {
            DropDownList1.Enabled = true;
            DropDownList1.ForeColor = System.Drawing.Color.Blue;
            ch1 = 1;
        }
        else
        { 
            DropDownList1.Enabled = false;
            DropDownList1.ForeColor = System.Drawing.Color.Gray; 
            ch1 = 0;
        }

        
    }
    protected void CBbranch_CheckedChanged(object sender, EventArgs e)
    {
        if (CBbranch.Checked == true)
        {
            DropDownList2.Enabled = true;
            DropDownList2.ForeColor = System.Drawing.Color.Blue;
            ch2 = 1;
        }
        else
        { 
            DropDownList2.Enabled = false;
            DropDownList2.ForeColor = System.Drawing.Color.Gray;
            ch2 = 0;
        }
    }
    protected void CBcategory_CheckedChanged(object sender, EventArgs e)
    {
        if (CBcategory.Checked == true)
        {
            DropDownList3.Enabled = true;
            DropDownList3.ForeColor = System.Drawing.Color.Blue;
            ch3 = 1;
        }
        else
        { 
            DropDownList3.Enabled = false;
            DropDownList3.ForeColor = System.Drawing.Color.Gray;

            ch3 = 0;
        }
    }
    protected void CBGender_CheckedChanged(object sender, EventArgs e)
    {
        if (CBGender.Checked == true)
        {
            DDGender.Enabled = true;
            DDGender.ForeColor = System.Drawing.Color.Blue;
            ch4 = 1;
        }
        else
        {
            DDGender.Enabled = false;
            DDGender.ForeColor =System.Drawing.Color.Gray;
            ch4 = 0;
            DDGender.SelectedValue = "";
        }
    }
}
