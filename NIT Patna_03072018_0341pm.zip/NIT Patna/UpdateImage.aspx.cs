using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.Data.SqlClient;


public partial class UpdateImage : System.Web.UI.Page
{
    static HttpPostedFile File1;
    static Int32 contentlength;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "10"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
        }
        

    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        try
        {
            lblmsg.Text = "";
        
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

            DataTable dt = new DataTable();
            con.Open();
            cmd.CommandText = "SELECT PHOTO FROM REGISTRATION WHERE Ackno='" + TempRollNo.Text.Trim() + "'";
        
            SqlDataAdapter adap1 = new SqlDataAdapter();
            cmd.Connection = con;
            adap1.SelectCommand = cmd;
            adap1.Fill(dt);

            
            if (dt.Rows.Count > 0)
            {
                lblmsg.Text = "";
                Image1.ImageUrl = "~/ImageHandler.aspx?AckNo=" + TempRollNo.Text.Trim();
                imgUpload.Visible = true;
                BtnUpdate.Visible = true;
              
                Image2.Visible = false;
                //div1.Style["background-image"] = Page.ResolveUrl(Image1.ImageUrl);
                //div1.Visible = false;
            }
            else
            {
                lblmsg.Text = "ACkNo Not Found";
                Image1.ImageUrl = "";
                imgUpload.Visible = false;
                BtnUpdate.Visible = false;
                Image2.Visible = false;
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = "Error!" + " Error message: " + ex.Message;
        }
        
    }

    
    protected void BtnUpdate_Click(object sender, EventArgs e)
    {
       // Image2.ImageUrl = Image1.ImageUrl;
        //div1.Visible = true;
        Image2.Visible = false;
        Byte[] imgByte = null;
        FileUpload img = (FileUpload)imgUpload;
        File1 = imgUpload.PostedFile;
        contentlength = File1.ContentLength;
        imgByte = new Byte[contentlength];
        File1.InputStream.Read(imgByte, 0, contentlength);

        // img size checking ------------
        if (imgByte.Length == 0)
        { lblmsg.Text = "Please Select Image"; return; }
     
        ImageUpload ImgUpld = new ImageUpload();

        string result = ImgUpld.UpdateImage(imgByte.Length, imgByte, TempRollNo.Text.Trim());
        if (result != "1")
        {
            lblmsg.Text = "Image can not be saved as '" + result + "'";
        }
        else
        {
            //Image2.Visible = true;
            lblmsg.Text = "Image Updated ";
        }
    }
}
