using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using System.Collections.Generic;

public partial class Promotion : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    int foryear1, foryear2, foryear3, foryear4; string PromotionStatus = "", CurrentYear = "";
    DataTable dtpromotion = new DataTable();
    DataRow[] currentsem;
    IEnumerable<int> semdivison;
    int completingyear,completedyear,ProbationCount,ProbationStatus;
    int ERCredit1 = 0, SCredit1 = 0, ERCredit2 = 0, SCredit2 = 0, ERCredit3 = 0, SCredit3 = 0, ERCredit4 = 0, SCredit4 = 0;
    protected void btngenerate_Click(object sender, EventArgs e)
    {
        dtpromotion.Columns.Add("UnivrollNo");
        dtpromotion.Columns.Add("CURRENT_SEM");
        dtpromotion.Columns.Add("TOTAL_CREDIT_YEAR_1");
        dtpromotion.Columns.Add("TOTAL_ERCREDIT_YEAR_1");
        dtpromotion.Columns.Add("TOTAL_CREDIT_YEAR_2");
        dtpromotion.Columns.Add("TOTAL_ERCREDIT_YEAR_2");
        dtpromotion.Columns.Add("TOTAL_CREDIT_YEAR_3");
        dtpromotion.Columns.Add("TOTAL_ERCREDIT_YEAR_3");
        dtpromotion.Columns.Add("TOTAL_CREDIT_YEAR_4");
        dtpromotion.Columns.Add("TOTAL_ERCREDIT_YEAR_4");
        dtpromotion.Columns.Add("MAX_PROBATION_COUNT");
        dtpromotion.Columns.Add("LAST_PROBATION_COUNT");
        dtpromotion.Columns.Add("ADM_YEAR");
        dtpromotion.Columns.Add("Status");

        DataSet dsstudentlist = fnrev.SelectDataset("SELECT DISTINCT EXAMPAPERDETAIL.RegNo,REGISTRATION.RegYear,REGISTRATION.AdmYear FROM EXAMPAPERDETAIL INNER JOIN " + 
                     " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo INNER JOIN STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode " + 
                     " INNER JOIN STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode WHERE (CAST(SUBSTRING(EXAMPAPERDETAIL.ExamSession, 5, 3) + " +
                     " EXAMPAPERDETAIL.ExamYear AS DATETIME) BETWEEN '2015-12-01 00:00:00.000' AND '2016-07-01 00:00:00.000') AND (STREAM.StreamTypeCode = '01') and AdmYear >= '2013' "); 
       /* DataSet dsstudentlist = fnrev.SelectDataset("SELECT DISTINCT EXAMPAPERDETAIL.RegNo, REGISTRATION.AdmYear FROM EXAMPAPERDETAIL INNER JOIN " + 
                     " REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo INNER JOIN STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode " +
                     " INNER JOIN STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode WHERE EXAMPAPERDETAIL.ExamSession = 'SMR-JUL_2015'  AND (STREAM.StreamTypeCode = '01')"); */
        if (dsstudentlist.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentlist.Tables[0].Rows.Count; i++)
            {
                //if (dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() == "01201112738")
                //{
                //    string sfind = "true";
                //}
                CurrentYear = ""; PromotionStatus = ""; int papercount = 0;
                string rollno = dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString();
                //if (dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() == "01201500029")
                //{
                //    string find = "student";
                //}
               DataSet Ruledetails = fnrev.SelectDataset("SELECT Promotion.Id, Promotion.Year_From, Promotion.Year_To, " +
                        " Promotion.StreamTypeCode, Promotion.Credit_Threshold, Promotion.Max_Probation, PromotionCriteria.PaperTypeCode, " +
                        " PromotionCriteria.Credit, PromotionCriteria.PaperCount, Operator.Name, Operator.Symbol FROM Promotion INNER JOIN " +
                        " PromotionCriteria ON Promotion.Id = PromotionCriteria.Promotion_Id INNER JOIN Operator ON PromotionCriteria.Operator = Operator.Id " +
                        " Where Year_From <= '" + dsstudentlist.Tables[0].Rows[i]["AdmYear"].ToString() + "' and ISNULL(Year_To,'" + dsstudentlist.Tables[0].Rows[i]["AdmYear"].ToString() + "') >= " +
                        " '" + dsstudentlist.Tables[0].Rows[i]["AdmYear"].ToString() + "'");
                    if (Ruledetails.Tables[0].Rows.Count > 0)
                    {
                        bool statevalue = false;
                        int maxsem = Int32.Parse(fnrev.singlevalue("Select MAX(semno) as maxsem From CGPA Where RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "'").ToString());
                        DataSet dsstudrecord = fnrev.SelectDataset("Select SUM(Credit) as Credit, SUM(ER_CREDIT) As ERCredit " +
                            " From cgpa WHere RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "'");
                        int nextsem = maxsem - 1;
                        DataSet dsstudpaper = fnrev.SelectDataset("SELECT cgpa.semno, COUNT(cgpa.SubPaperCode) AS papercount FROM " +
                            " cgpa INNER JOIN COURSEPAPERS ON cgpa.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE (cgpa.Credit " + Ruledetails.Tables[0].Rows[0]["Symbol"].ToString() + "  " + Ruledetails.Tables[0].Rows[0]["Credit"].ToString() + ") AND " +
                            " (cgpa.Grade NOT IN ('F', 'F*', 'I', 'X')) AND (cgpa.RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "') and (COURSEPAPERS.PaperTypeCode " +
                            " IN ('0" + Ruledetails.Tables[0].Rows[0]["PaperTypeCode"].ToString() + "','04')) and (semno = '" + maxsem + "' or semno = '" + nextsem + "') GROUP BY cgpa.semno ");
                        if (dsstudpaper.Tables[0].Rows.Count > 0)
                        {

                            for (int y = 0; y < dsstudpaper.Tables[0].Rows.Count; y++)
                            {
                                if (Int32.Parse(dsstudpaper.Tables[0].Rows[y]["papercount"].ToString()) >= 2)
                                    papercount += 1;
                            }
                        }
                           /* if (maxsem <= 2)
                            {
                                completingyear = Convert.ToInt32(dsstudentlist.Tables[0].Rows[i]["AdmYear"].ToString()) + 1;
                            }
                            else if (maxsem <= 4)
                            {
                                completingyear = Convert.ToInt32(dsstudentlist.Tables[0].Rows[i]["AdmYear"].ToString()) + 2;
                            }
                            else if (maxsem <= 6)
                            {
                                completingyear = Convert.ToInt32(dsstudentlist.Tables[0].Rows[i]["AdmYear"].ToString()) + 3;
                            }
                            else if (maxsem <= 8)
                            {
                                completingyear = Convert.ToInt32(dsstudentlist.Tables[0].Rows[i]["AdmYear"].ToString()) + 4;
                            }
                            ProbationCount = DateTime.Now.Year - completingyear; */
                            if ((Math.Round((Convert.ToDouble(dsstudrecord.Tables[0].Rows[0]["Credit"].ToString()) * 0.75)) <= Convert.ToDouble(dsstudrecord.Tables[0].Rows[0]["ERCredit"].ToString())) && (papercount >= 2))
                            {
                               statevalue = true;
                            }
                            else statevalue = false;

                            if (statevalue == true)
                            {
                               PromotionStatus = "Promoted";
                            }
                            else 
                            {
                               // DataTable dsyear = fnrev.SelectDatatable("Select semno,SUBSTRING(ExamSession,9,4) as examyear From cgpa Where RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "' group by Semno,SUBSTRING(ExamSession,9,4)");
                                //DataTable dsyear = fnrev.SelectDatatable("SELECT TRBTec.ExamYear,CONVERT(int, LEFT(SUBSTRING(b.StreamPart, PATINDEX('%[0-9]%', b.StreamPart), 8000), PATINDEX('%[^0-9]%', " + 
                                //    " SUBSTRING(b.StreamPart, PATINDEX('%[0-9]%', b.StreamPart), 8000) + 'X') - 1)) AS semno FROM TRBTec INNER JOIN STREAMPART AS b ON TRBTec.StreamPart = b.StreamPartCode " +
                                //    " WHERE (TRBTec.RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "') GROUP BY TRBTec.ExamYear,CONVERT(int, LEFT(SUBSTRING(b.StreamPart, PATINDEX('%[0-9]%', b.StreamPart), 8000), PATINDEX('%[^0-9]%', " + 
                                //    " SUBSTRING(b.StreamPart, PATINDEX('%[0-9]%', b.StreamPart), 8000) + 'X') - 1))");

                                DataTable dsyear = fnrev.SelectDatatable("SELECT Distinct ExamYear,CONVERT(int, LEFT(SUBSTRING(b.StreamPart, PATINDEX('%[0-9]%', b.StreamPart), 8000), PATINDEX('%[^0-9]%', " + 
                                    " SUBSTRING(b.StreamPart, PATINDEX('%[0-9]%', b.StreamPart), 8000) + 'X') - 1)) AS semno FROM TRBTec INNER JOIN STREAMPART AS b " +
                                    " ON TRBTec.StreamPart = b.StreamPartCode WHERE (TRBTec.RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "') and ISNUll(Is_active,'Y') = 'Y' UNION SELECT Distinct ExamYear,CONVERT(int, LEFT(SUBSTRING(b.StreamPart, PATINDEX('%[0-9]%', " + 
                                    " b.StreamPart), 8000), PATINDEX('%[^0-9]%', SUBSTRING(b.StreamPart, PATINDEX('%[0-9]%', b.StreamPart), 8000) + 'X') - 1)) AS semno FROM TRBTec_old INNER JOIN " +
                                    " STREAMPART AS b ON TRBTec_old.StreamPart = b.StreamPartCode WHERE (TRBTec_old.RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "') and ISNUll(Is_active,'Y') = 'Y' ");
                                if (dsyear.Rows.Count > 0)
                                {
                                   
                                   string yr1 = "semno=" + maxsem;
                                   int maxyear = Convert.ToInt32(dsyear.Compute("MAX(examyear)", yr1).ToString());
                                   int minyear = Convert.ToInt32(dsyear.Compute("MIN(examyear)", yr1).ToString());
                                   int prob1 = maxyear - minyear;
                                   int prob2 = 0;
                                   if (maxsem > 1)
                                   {
                                       string regno = dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString();
                                       yr1 = "semno=" + (maxsem - 1).ToString();
                                       maxyear = Convert.ToInt32(dsyear.Compute("MAX(examyear)", yr1).ToString());
                                       minyear = Convert.ToInt32(dsyear.Compute("MIN(examyear)", yr1).ToString());
                                       prob2 = maxyear - minyear;
                                   }

                                   if (prob1 == 0 || prob2 == 0) 
                                    {
                                        PromotionStatus = "Not Promoted";
                                    }
                                   else
                                        PromotionStatus = "Canceled";
                                    
                                    
                                   /* if (ProbationCount == 0)
                                    {
                                        PromotionStatus = "Not Promoted";
                                    }
                                    else if (ProbationCount >= 1)
                                        PromotionStatus = "Canceled"; */
                                }
                            }
                             
                       

                        string Rollno = fnrev.singlevalue("Select TempRollNo From Registration Where RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "'").ToString();
                        string Sem = fnrev.singlevalue("Select MAX(semno) From cgpa Where RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "'").ToString();
                        dtpromotion.Rows.Add(Rollno, Sem, dsstudrecord.Tables[0].Rows[0]["Credit"].ToString(), dsstudrecord.Tables[0].Rows[0]["ERCredit"].ToString(), "", "", "", "", "", "", ProbationStatus, ProbationCount, dsstudentlist.Tables[0].Rows[i]["AdmYear"].ToString(),
                            PromotionStatus);

                    }
                    else
                    {
                    
                    }


                    
                
                
            }
            // Code for Export
            if (dtpromotion.Rows.Count > 0)
            {
                string consString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
                using (SqlConnection con = new SqlConnection(consString))
                {
                    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con))
                    {
                        //Set the database table name
                        sqlBulkCopy.DestinationTableName = "dbo.ExportData";


                        //[OPTIONAL]: Map the DataTable columns with that of the database table
                        sqlBulkCopy.ColumnMappings.Add("UnivrollNo", "UnivrollNo");
                        sqlBulkCopy.ColumnMappings.Add("CURRENT_SEM", "CURRENT_SEM");
                        sqlBulkCopy.ColumnMappings.Add("TOTAL_CREDIT_YEAR_1", "TOTAL_CREDIT_YEAR_1");
                        sqlBulkCopy.ColumnMappings.Add("TOTAL_ERCREDIT_YEAR_1", "TOTAL_ERCREDIT_YEAR_1");
                        sqlBulkCopy.ColumnMappings.Add("TOTAL_CREDIT_YEAR_2", "TOTAL_CREDIT_YEAR_2");
                        sqlBulkCopy.ColumnMappings.Add("TOTAL_ERCREDIT_YEAR_2", "TOTAL_ERCREDIT_YEAR_2");
                        sqlBulkCopy.ColumnMappings.Add("TOTAL_CREDIT_YEAR_3", "TOTAL_CREDIT_YEAR_3");
                        sqlBulkCopy.ColumnMappings.Add("TOTAL_ERCREDIT_YEAR_3", "TOTAL_ERCREDIT_YEAR_3");
                        sqlBulkCopy.ColumnMappings.Add("TOTAL_CREDIT_YEAR_4", "TOTAL_CREDIT_YEAR_4");
                        sqlBulkCopy.ColumnMappings.Add("TOTAL_ERCREDIT_YEAR_4", "TOTAL_ERCREDIT_YEAR_4");
                        sqlBulkCopy.ColumnMappings.Add("MAX_PROBATION_COUNT", "MAX_PROBATION_COUNT");
                        sqlBulkCopy.ColumnMappings.Add("LAST_PROBATION_COUNT", "LAST_PROBATION_COUNT");
                        sqlBulkCopy.ColumnMappings.Add("ADM_YEAR", "ADM_YEAR");
                        sqlBulkCopy.ColumnMappings.Add("Status", "Status");
                        con.Open();
                        sqlBulkCopy.WriteToServer(dtpromotion);
                        con.Close();
                    }
                }

            }

           
        }
    }

    protected void distributions()
    {
        if (int.Parse(currentsem[0][0].ToString().Trim()) <= 2)
        {
            semdivison = new int[] {2};
        }
        else if (int.Parse(currentsem[0][0].ToString().Trim()) <= 4)
        {
            semdivison = new int[] { 2 ,4};
        }
        else if (int.Parse(currentsem[0][0].ToString().Trim()) <= 6)
        {
            semdivison = new int[] { 2, 4 ,6};
        }
        else if (int.Parse(currentsem[0][0].ToString().Trim()) <= 8)
        {
            semdivison = new int[] { 2, 4, 6, 8 };
        }
    }

    protected void btncgpa_Click(object sender, EventArgs e)
    {
        DataSet dsRegistrationdata = fnrev.SelectDataset(" SELECT ExportData.UnivrollNo, ExportData.CURRENT_SEM, ExportData.ADM_YEAR, REGISTRATION.RegNo " + 
            " FROM ExportData INNER JOIN REGISTRATION ON ExportData.UnivrollNo = REGISTRATION.TempRollNo");
        if (dsRegistrationdata.Tables[0].Rows.Count > 0)
        {
            for (int y = 0; y < dsRegistrationdata.Tables[0].Rows.Count; y++)
            {
                DataSet cgpa = fnrev.SelectDataset("SELECT SUM(CONVERT(float, Credit)) AS CumPapercredit, SUM(CONVERT(float, ER_CREDIT)) AS CumER_CREDIT," +
                    " SUM(CONVERT(float, Grade_Point)) AS CUM_GradePoint, ROUND(CASE WHEN SUM(Credit) = SUM(ER_CREDIT) THEN " +
                    " SUM(CONVERT(float, Grade_Point)) / SUM(CONVERT(float, ER_CREDIT)) ELSE NULL END, 2) AS CGPA, CASE WHEN SUM(Credit) = SUM(ER_CREDIT) " +
                    " THEN 'P' ELSE 'F' END AS Status FROM cgpa WHERE (semno BETWEEN '1' AND '" + dsRegistrationdata.Tables[0].Rows[y]["CURRENT_SEM"].ToString() + "') AND " +
                    " (RegNo = '" + dsRegistrationdata.Tables[0].Rows[y]["RegNo"].ToString() + "') and CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4) AS DATETIME) >= '" + dsRegistrationdata.Tables[0].Rows[y]["ADM_YEAR"].ToString() + "-12-01'");
                if (cgpa.Tables[0].Rows.Count > 0)
                {
                    int insrec = fnrev.InsertUpdateDelete("UPDATE ExportData SET CumPapercredit ='" + cgpa.Tables[0].Rows[0]["CumPapercredit"].ToString() + "', " +
                        " CumER_CREDIT ='" + cgpa.Tables[0].Rows[0]["CumER_CREDIT"].ToString() + "', CUM_GradePoint ='" + cgpa.Tables[0].Rows[0]["CUM_GradePoint"].ToString() + "'," +
                        " CGPA ='" + cgpa.Tables[0].Rows[0]["CGPA"].ToString() + "', PassingStatus ='" + cgpa.Tables[0].Rows[0]["Status"].ToString() + "' " +
                        " Where Univrollno = '" + dsRegistrationdata.Tables[0].Rows[y]["UnivrollNo"].ToString() + "'");
                }
            }
        }
    }

    string pgprostatus = "";
    string pgcurrentsem = "";
    DataTable dtpgpromotion = new DataTable();
    protected void Category_Click(object sender, EventArgs e)
    {
        dtpgpromotion.Columns.Add("RegNo");
        dtpgpromotion.Columns.Add("CurrentSEM");
        dtpgpromotion.Columns.Add("Status");
        DataSet dsstudent = fnrev.SelectDataset("SELECT DISTINCT EXAMPAPERDETAIL.RegNo FROM EXAMPAPERDETAIL INNER JOIN REGISTRATION ON " + 
            " EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo INNER JOIN STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode WHERE " + 
            " (CAST(SUBSTRING(EXAMPAPERDETAIL.ExamSession, 5, 3) + EXAMPAPERDETAIL.ExamYear AS DATETIME) BETWEEN '2015-12-01 00:00:00.000' AND " + 
            " '2016-07-01 00:00:00.000') AND (STREAM.StreamTypeCode = '02')");
        if (dsstudent.Tables[0].Rows.Count > 0)
        {
            for (int t = 0; t < dsstudent.Tables[0].Rows.Count; t++)
            {
                // code for get current sem
                pgcurrentsem = fnrev.singlevalue("Select MAX(semno) from cgpa_Mtec Where RegNo = '" + dsstudent.Tables[0].Rows[t]["RegNo"].ToString() + "'").ToString();
                if (pgcurrentsem == "1")
                {
                    pgprostatus = "PROMOTED";
                }
                else if (pgcurrentsem == "2")
                {
                    pgprostatus = "PROMOTED";
                }
                else if (pgcurrentsem == "3")
                {
                    //code for check dissertation and all paper passed or not
                    int failpapercount = int.Parse(fnrev.singlevalue("Select COUNT(SubPaperCode) from cgpa_Mtec Where Regno = '" + dsstudent.Tables[0].Rows[t]["RegNo"].ToString() + "' and Grade IN ('F','F*','I','X')").ToString());
                    if (failpapercount > 0)
                    {
                        pgprostatus = "NOT PROMOTED";
                    }
                    else
                    {
                        pgprostatus = "PROMOTED";
                    }
                }
                else if (pgcurrentsem == "4")
                {
                    int failpapercount = int.Parse(fnrev.singlevalue("Select COUNT(SubPaperCode) from cgpa_Mtec Where Regno = '" + dsstudent.Tables[0].Rows[t]["RegNo"].ToString() + "' and Grade IN ('F','F*','I','X')").ToString());
                    if (failpapercount > 0)
                    {
                        pgprostatus = "NOT PROMOTED";
                    }
                    else
                    {
                        int disfailcount = int.Parse(fnrev.singlevalue("SELECT COUNT(cgpa_Mtec.SubPaperCode) AS disfailcount FROM cgpa_Mtec INNER JOIN COURSEPAPERS " + 
                            " ON cgpa_Mtec.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE (cgpa_Mtec.Regno = '" + dsstudent.Tables[0].Rows[t]["RegNo"].ToString() + "') AND " + 
                            " (cgpa_Mtec.Grade IN ('F', 'F*', 'I', 'X')) and (COURSEPAPERS.PaperName LIKE '%Dissertation%')").ToString());
                        if (disfailcount > 0)
                        {
                            pgprostatus = "NOT PROMOTED";
                        }
                        else
                        {
                            pgprostatus = "PROMOTED";
                        }
                    }
                }

                dtpgpromotion.Rows.Add(dsstudent.Tables[0].Rows[t]["RegNo"].ToString(),pgcurrentsem, pgprostatus);
            }

            if (dtpgpromotion.Rows.Count > 0)
            {
                string consString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
                using (SqlConnection con = new SqlConnection(consString))
                {
                    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con))
                    {
                        //Set the database table name
                        sqlBulkCopy.DestinationTableName = "dbo.ExportPgprodata";


                        //[OPTIONAL]: Map the DataTable columns with that of the database table
                        sqlBulkCopy.ColumnMappings.Add("RegNo", "RegNo");
                        sqlBulkCopy.ColumnMappings.Add("CurrentSEM", "CurrentSEM");
                        sqlBulkCopy.ColumnMappings.Add("Status", "Status");
                        con.Open();
                        sqlBulkCopy.WriteToServer(dtpgpromotion);
                        con.Close();
                    }
                }
            }

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DataSet dsRegistrationdata = fnrev.SelectDataset(" SELECT RegNo, CurrentSEM, Status, CumPapercredit, CumER_CREDIT, CUM_GradePoint, CGPA, PassingStatus FROM ExportPgprodata");
        if (dsRegistrationdata.Tables[0].Rows.Count > 0)
        {
            for (int y = 0; y < dsRegistrationdata.Tables[0].Rows.Count; y++)
            {
                DataSet cgpa = fnrev.SelectDataset("SELECT SUM(CONVERT(float, Credit)) AS CumPapercredit, SUM(CONVERT(float, ER_CREDIT)) AS CumER_CREDIT," +
                    " SUM(CONVERT(float, Grade_Point)) AS CUM_GradePoint, ROUND(CASE WHEN SUM(Credit) = SUM(ER_CREDIT) THEN " +
                    " SUM(CONVERT(float, Grade_Point)) / SUM(CONVERT(float, ER_CREDIT)) ELSE NULL END, 2) AS CGPA, CASE WHEN SUM(Credit) = SUM(ER_CREDIT) " +
                    " THEN 'P' ELSE 'F' END AS Status FROM cgpa_Mtec WHERE (semno BETWEEN '1' AND '" + dsRegistrationdata.Tables[0].Rows[y]["CurrentSEM"].ToString() + "') AND " +
                    " (RegNo = '" + dsRegistrationdata.Tables[0].Rows[y]["RegNo"].ToString() + "')");
                if (cgpa.Tables[0].Rows.Count > 0)
                {
                    int insrec = fnrev.InsertUpdateDelete("UPDATE ExportPgprodata SET CumPapercredit ='" + cgpa.Tables[0].Rows[0]["CumPapercredit"].ToString() + "', " +
                        " CumER_CREDIT ='" + cgpa.Tables[0].Rows[0]["CumER_CREDIT"].ToString() + "', CUM_GradePoint ='" + cgpa.Tables[0].Rows[0]["CUM_GradePoint"].ToString() + "'," +
                        " CGPA ='" + cgpa.Tables[0].Rows[0]["CGPA"].ToString() + "', PassingStatus ='" + cgpa.Tables[0].Rows[0]["Status"].ToString() + "' " +
                        " Where Regno = '" + dsRegistrationdata.Tables[0].Rows[y]["RegNo"].ToString() + "'");
                }
            }
        }
    }
}



/*
  DataSet dsstudrecord = fnrev.SelectDataset("Select Semno,SUM(Credit) as Credit, SUM(ER_CREDIT) As ERCredit " +
                            " From cgpa WHere RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "'  Group by Semno");
                        DataSet dsstudpaper = fnrev.SelectDataset("SELECT cgpa.semno, COUNT(cgpa.SubPaperCode) AS papercount FROM " +
                            " cgpa INNER JOIN COURSEPAPERS ON cgpa.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE (cgpa.Credit " + Ruledetails.Tables[0].Rows[0]["Symbol"].ToString() + "  " + Ruledetails.Tables[0].Rows[0]["Credit"].ToString() + ") AND " +
                            " (cgpa.Grade NOT IN ('F', 'F*', 'I', 'X')) AND (cgpa.RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "') and (COURSEPAPERS.PaperTypeCode " +
                            " IN ('0" + Ruledetails.Tables[0].Rows[0]["PaperTypeCode"].ToString() + "','04'))  GROUP BY cgpa.semno ");
                        DataSet dssemyear = fnrev.SelectDataset("Select semno,MAX(SUBSTRING(ExamSession,9,4)) As Year From CGPA Where RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "' Group BY semno ");
                        CurrentYear = fnrev.singlevalue("Select MAX(ExamYear) As CurrentYear From Exampaperdetail Where RegNo  ='" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "'").ToString();
                        currentsem = dsstudrecord.Tables[0].Select("semno= MAX(semno)");
                        distributions();                        
                        if (dsstudrecord.Tables[0].Rows.Count > 0)
                        {
                            string promotion1 = "", promotion2 = "", promotion3 = "", promotion4 = "";
                            ERCredit1 = 0; SCredit1 = 0; ERCredit2 = 0; SCredit2 = 0; ERCredit3 = 0; SCredit3 = 0; ERCredit4 = 0; SCredit4 = 0;
                            ProbationCount = 0; ProbationStatus = 0; bool papercount = false;
                            foreach (int d in semdivison)
                            {
                                if (d == 2)
                                {
                                    DataRow[] drs = dssemyear.Tables[0].Select("semno <= 2","semno DESC");
                                    completingyear = int.Parse(dsstudentlist.Tables[0].Rows[i]["AdmYear"].ToString()) + 1;
                                    if (drs.Length < 2)
                                    {
                                        completedyear = int.Parse(drs[0][1].ToString()) + 1;
                                    }
                                    else completedyear = int.Parse(drs[0][1].ToString());

                                    if (completingyear == completedyear)
                                    {
                                        ProbationCount = 0;
                                    }
                                    else
                                    {
                                        ProbationCount = completedyear - completingyear;
                                        ProbationStatus = completedyear - completingyear;
                                    }

                                    // code for check percentage criteria

                                    DataRow[] dr1 = dsstudrecord.Tables[0].Select("Semno = '1'  OR Semno = '2'");
                                    if (dr1.Length > 0)
                                    {
                                        if (dr1.Length == 1)
                                        {
                                            DataRow u = dsstudrecord.Tables[0].NewRow();
                                            u[0] = "2"; u[1] = "0"; u[2] = "0";
                                            dsstudrecord.Tables[0].Rows.InsertAt(u, 1);
                                            dr1 = dsstudrecord.Tables[0].Select("Semno = '1'  OR Semno = '2'");
                                        }
                                        SCredit1 = int.Parse(dr1[0][1].ToString()) + int.Parse(dr1[1][1].ToString());
                                        foryear1 = (int)((double)SCredit1 * 0.75);
                                        ERCredit1 = int.Parse(dr1[0][2].ToString()) + int.Parse(dr1[1][2].ToString());
                                        if (foryear1 <= ERCredit1)
                                        {
                                            DataRow[] drth1 = dsstudpaper.Tables[0].Select("Semno = '1'  OR Semno = '2'");
                                            if (drth1.Length > 0)
                                            {
                                                if (drth1.Length == 1)
                                                {
                                                   // drth1[1][0] = "2"; drth1[1][1] = "0";
                                                    DataRow d1 = dsstudpaper.Tables[0].NewRow();
                                                    d1[0] = "2"; d1[1] = "0";
                                                    dsstudpaper.Tables[0].Rows.InsertAt(d1, 1);
                                                    drth1 = dsstudpaper.Tables[0].Select("Semno = '1'  OR Semno = '2'");
                                                }

                                                string v1 = drth1[0][1].ToString();
                                                if (v1 == "" || v1 == null)
                                                    v1 = "0";
                                                string v2 = drth1[1][1].ToString();
                                                if (v2 == "" || v2 == null)
                                                    v2 = "0";
                                                if (int.Parse(v1) >= 2 && int.Parse(v2) >= 2)
                                                {
                                                    promotion1 = "Pass";
                                                    papercount = true;
                                                }
                                                else
                                                {
                                                    promotion1 = "Not Promoted";
                                                    papercount = false;
                                                }

                                            }

                                        }


                                    }
                                }
                                else if (d == 4)
                                {
                                    DataRow[] drs = dssemyear.Tables[0].Select("semno <= 4", "semno DESC");
                                    completingyear = int.Parse(dsstudentlist.Tables[0].Rows[i]["AdmYear"].ToString()) + 2;
                                    if (drs.Length < 2)
                                    {
                                        completedyear = int.Parse(drs[0][1].ToString()) + 1;
                                    }
                                    else completedyear = int.Parse(drs[0][1].ToString());

                                    if (completingyear == completedyear)
                                    {
                                        ProbationCount = ProbationCount + 0;
                                    }
                                    else
                                    {
                                        ProbationCount = ProbationCount + (completedyear - completingyear);
                                        ProbationStatus = completedyear - completingyear;
                                    }

                                    DataRow[] dr2 = dsstudrecord.Tables[0].Select("Semno = '3'  OR Semno = '4'");
                                    if (dr2.Length > 0)
                                    {
                                        if (dr2.Length == 1)
                                        {
                                            //dr2[1][0] = "4"; dr2[1][1] = "0"; dr2[1][2] = "0";
                                            DataRow u = dsstudrecord.Tables[0].NewRow();
                                            u[0] = "4"; u[1] = "0"; u[2] = "0";
                                            dsstudrecord.Tables[0].Rows.InsertAt(u, 1);
                                            dr2 = dsstudrecord.Tables[0].Select("Semno = '3'  OR Semno = '4'");
                                        }

                                        SCredit2 = int.Parse(dr2[0][1].ToString()) + int.Parse(dr2[1][1].ToString()) + SCredit1;
                                        foryear2 = (int)((double)SCredit2 * 0.75);
                                        ERCredit2 = int.Parse(dr2[0][2].ToString()) + int.Parse(dr2[1][2].ToString()) + ERCredit1;
                                        if (foryear2 <= ERCredit2)
                                        {
                                            DataRow[] drth2 = dsstudpaper.Tables[0].Select("Semno = '3'  OR Semno = '4'");
                                            if (drth2.Length > 0)
                                            {
                                                if (drth2.Length == 1)
                                                {
                                                   // drth2[1][0] = "4"; drth2[1][1] = "0";
                                                    DataRow d1 = dsstudpaper.Tables[0].NewRow();
                                                    d1[0] = "2"; d1[1] = "0";
                                                    dsstudpaper.Tables[0].Rows.InsertAt(d1, 1);
                                                    drth2 = dsstudpaper.Tables[0].Select("Semno = '3'  OR Semno = '4'");
                                                }
                                                string v1 = drth2[0][1].ToString();
                                                if (v1 == "" || v1 == null)
                                                    v1 = "0";
                                                string v2 = drth2[1][1].ToString();
                                                if (v2 == "" || v2 == null)
                                                    v2 = "0";
                                                if (int.Parse(v1) >= 2 && int.Parse(v2) >= 2 && papercount == true)
                                                {
                                                    promotion2 = "Pass";
                                                    papercount = true;
                                                }
                                                else
                                                {
                                                    promotion2 = "Not Promoted";
                                                    papercount = false;
                                                }
                                            }

                                        }

                                    }
                                }
                                else if (d == 6)
                                {
                                    DataRow[] drs = dssemyear.Tables[0].Select("semno <= 6", "semno DESC");
                                    completingyear = int.Parse(dsstudentlist.Tables[0].Rows[i]["AdmYear"].ToString()) + 3;
                                    if (drs.Length < 2)
                                    {
                                        completedyear = int.Parse(drs[0][1].ToString()) + 1;
                                    }
                                    else completedyear = int.Parse(drs[0][1].ToString());
                                    if (completingyear == completedyear)
                                    {
                                        ProbationCount = ProbationCount + 0;
                                    }
                                    else
                                    {
                                        ProbationCount = ProbationCount + (completedyear - completingyear);
                                        ProbationStatus = completedyear - completingyear; 
                                    }

                                    DataRow[] dr3 = dsstudrecord.Tables[0].Select("Semno = '5'  OR Semno = '6'");
                                    if (dr3.Length > 0)
                                    {
                                        if (dr3.Length == 1)
                                        {
                                            //dr3[1][0] = "6"; dr3[1][1] = "0"; dr3[1][2] = "0";
                                            DataRow u = dsstudrecord.Tables[0].NewRow();
                                            u[0] = "6"; u[1] = "0"; u[2] = "0";
                                            dsstudrecord.Tables[0].Rows.InsertAt(u, 1);
                                            dr3 = dsstudrecord.Tables[0].Select("Semno = '5'  OR Semno = '6'");
                                        }

                                        SCredit3 = int.Parse(dr3[0][1].ToString()) + int.Parse(dr3[1][1].ToString()) + SCredit2;
                                        foryear3 = (int)((double)SCredit3 * 0.75);
                                        ERCredit3 = int.Parse(dr3[0][2].ToString()) + int.Parse(dr3[1][2].ToString()) + ERCredit2;
                                        if (foryear3 <= ERCredit3)
                                        {
                                            DataRow[] drth3 = dsstudpaper.Tables[0].Select("Semno = '5'  OR Semno = '6'");
                                            if (drth3.Length > 0)
                                            {
                                                if (drth3.Length == 1)
                                                {
                                                   // drth3[1][0] = "6"; drth3[1][1] = "0";
                                                    DataRow d1 = dsstudpaper.Tables[0].NewRow();
                                                    d1[0] = "6"; d1[1] = "0";
                                                    dsstudpaper.Tables[0].Rows.InsertAt(d1, 1);
                                                    drth3 = dsstudpaper.Tables[0].Select("Semno = '5'  OR Semno = '6'");
                                                }
                                                string v1 = drth3[0][1].ToString();
                                                if (v1 == "" || v1 == null)
                                                    v1 = "0";
                                                string v2 = drth3[1][1].ToString();
                                                if (v2 == "" || v2 == null)
                                                    v2 = "0";
                                                if (int.Parse(v1) >= 2 && int.Parse(v2) >= 2 && papercount == true)
                                                {
                                                    promotion3 = "Pass";
                                                    papercount = true;
                                                }
                                                else
                                                {
                                                    promotion3 = "Not Promoted";
                                                    papercount = false;
                                                }
                                            }

                                        }

                                    }
                                }
                                else if (d == 8)
                                {
                                    DataRow[] drs = dssemyear.Tables[0].Select("semno <= 8", "semno DESC");
                                    completingyear = int.Parse(dsstudentlist.Tables[0].Rows[i]["AdmYear"].ToString()) + 3;
                                    if (drs.Length < 2)
                                    {
                                        completedyear = int.Parse(drs[0][1].ToString()) + 1;
                                    }
                                    else completedyear = int.Parse(drs[0][1].ToString());
                                    if (completingyear == completedyear)
                                    {
                                        ProbationCount = ProbationCount + 0;
                                    }
                                    else
                                    {
                                        ProbationCount = ProbationCount + (completedyear - completingyear);
                                        ProbationStatus = completedyear - completingyear;
                                    }

                                    DataRow[] dr4 = dsstudrecord.Tables[0].Select("Semno = '7'  OR Semno = '8'");
                                    if (dr4.Length > 0)
                                    {
                                        if (dr4.Length == 1)
                                        {
                                           // dr4[1][0] = "8"; dr4[1][1] = "0"; dr4[1][2] = "0";
                                            DataRow u = dsstudrecord.Tables[0].NewRow();
                                            u[0] = "8"; u[1] = "0"; u[2] = "0";
                                            dsstudrecord.Tables[0].Rows.InsertAt(u, 1);
                                            dr4 = dsstudrecord.Tables[0].Select("Semno = '7'  OR Semno = '8'");
                                        }

                                        SCredit4 = int.Parse(dr4[0][1].ToString()) + int.Parse(dr4[1][1].ToString());
                                        foryear4 = (int)((double)SCredit4 * 0.75);
                                        ERCredit4 = int.Parse(dr4[0][2].ToString()) + int.Parse(dr4[1][2].ToString());
                                        if (foryear4 <= ERCredit4)
                                        {
                                            DataRow[] drth4 = dsstudpaper.Tables[0].Select("Semno = '7'  OR Semno = '8'");
                                            if (drth4.Length > 0)
                                            {
                                                if (drth4.Length == 1)
                                                {
                                                  //  drth4[1][0] = "8"; drth4[1][1] = "0";
                                                    DataRow d1 = dsstudpaper.Tables[0].NewRow();
                                                    d1[0] = "8"; d1[1] = "0";
                                                    dsstudpaper.Tables[0].Rows.InsertAt(d1, 1);
                                                    drth4 = dsstudpaper.Tables[0].Select("Semno = '7'  OR Semno = '8'");
                                                }
                                                string v1 = drth4[0][1].ToString();
                                                if (v1 == "" || v1 == null)
                                                    v1 = "0";
                                                string v2 = drth4[1][1].ToString();
                                                if (v2 == "" || v2 == null)
                                                    v2 = "0";
                                                if (int.Parse(v1) >= 2 && int.Parse(v2) >= 2)
                                                {
                                                    promotion4 = "Pass";
                                                }
                                                else
                                                {
                                                    promotion4 = "Not Promoted";
                                                }

                                            }

                                        }

                                    }
                                }
                            }     
                            

                            DataRow[] drmaxsem = dsstudrecord.Tables[0].Select("semno= MAX(semno)");
                            if (drmaxsem.Length > 0)
                            {
                                if (int.Parse(drmaxsem[0][0].ToString()) <= 2)
                                {
                                    if (promotion1 == "Pass" && ProbationCount <= 8)
                                    {
                                        PromotionStatus = "Promoted";
                                        
                                    }
                                    else
                                    {
                                        if (ProbationCount <= 8)
                                        {
                                            if (ProbationStatus >= 1)
                                            {
                                                PromotionStatus = "Canceled";
                                            }
                                            else PromotionStatus = "Not Promoted";

                                            
                                        }
                                        else PromotionStatus = "Canceled";
                                    }
                                }
                                else if (int.Parse(drmaxsem[0][0].ToString()) <= 4)
                                {
                                    if (papercount == true && promotion2 == "Pass" && ProbationCount <= 8)
                                    {
                                        PromotionStatus = "Promoted";

                                    }
                                    else
                                    {
                                        if (ProbationCount <= 8)
                                        {
                                            if (ProbationStatus >= 1)
                                            {
                                                PromotionStatus = "Canceled";
                                            }
                                            else PromotionStatus = "Not Promoted";


                                        }
                                        else PromotionStatus = "Canceled";
                                    }
                                   
                                }
                                else if (int.Parse(drmaxsem[0][0].ToString()) <= 6)
                                {
                                    if (papercount == true && promotion3 == "Pass" && ProbationCount <= 8)
                                    {
                                        PromotionStatus = "Promoted";

                                    }
                                    else
                                    {
                                        if (ProbationCount <= 8)
                                        {
                                            if (ProbationStatus >= 1)
                                            {
                                                PromotionStatus = "Canceled";
                                            }
                                            else PromotionStatus = "Not Promoted";


                                        }
                                        else PromotionStatus = "Canceled";
                                    }                                  
                                }
                                else if (int.Parse(drmaxsem[0][0].ToString()) <= 8)
                                {
                                    if (promotion1 == "Pass" && promotion2 == "Pass" && promotion3 == "Pass" && promotion4 == "Pass" && ProbationCount <= 8)
                                    {
                                        PromotionStatus = "Promoted";

                                    }
                                    else
                                    {
                                        if (ProbationCount <= 8)
                                        {
                                            if (ProbationStatus >= 1)
                                            {
                                                PromotionStatus = "Canceled";
                                            }
                                            else PromotionStatus = "Not Promoted";


                                        }
                                        else PromotionStatus = "Canceled";
                                    }                                    
                                }
                                else
                                {
                                    PromotionStatus = "PenDing";
                                }
                            }

                           // string Rollno = fnrev.singlevalue("Select TempRollNo From Registration Where RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "'").ToString();
                            
                            string Rollno = fnrev.singlevalue("Select TempRollNo From Registration Where RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "'").ToString();
                            string Sem = fnrev.singlevalue("Select MAX(semno) From cgpa Where RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "'").ToString();
                            dtpromotion.Rows.Add(Rollno, Sem, SCredit1, ERCredit1, SCredit2, ERCredit2, SCredit3, ERCredit3, SCredit4, ERCredit4,ProbationCount,ProbationStatus, dsstudentlist.Tables[0].Rows[i]["AdmYear"].ToString(),
                                PromotionStatus);
                            //dtpromotion.Rows.Add(Rollno, Sem, "", "", "", "", "", "", "", "", dsstudentlist.Tables[0].Rows[i]["AdmYear"].ToString(), PromotionStatus);
                        }

*/