using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class Relief : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
                ViewState.Add("EditMode", "false");
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }


            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(ExamYear, "Year", "Select Year from Year where year >'2008'order by Year", "Year", "Year");
            ExamYear.Focus();
        }
    }
    
    protected void RBHons_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Hons");

    }
    protected void RBPractH_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Hons");
    }
    protected void RBSubs_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Subs");
    }
    protected void RBPractS_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Subs");
    }
    protected void RBComp_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Comp");
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        StreamCode.Focus();  

    }
    protected void SubCode_SelectedIndexChanged(object sender, EventArgs e)
    {

    }


    private void GetPaperCode(string PaperType)
    {
        PopulateDDL popddl = new PopulateDDL();

        if (PaperType == "Hons")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", "Select PaperName,SubPaperCode from COURSEPAPERS Where StreamCode='" + StreamCode.SelectedValue + "' And StreamPartCode='" + StreamPart.SelectedValue + "' And SubCode='" + SubCode.SelectedValue + "' order by SubPaperCode", "PaperName", "SubPaperCode");
        }
        else if (PaperType == "Comp")
        {
            popddl.Popualate(Subject, "COMPOSITION", "Select Name,CompCode from COMPOSITION order by Name", "Name", "CompCode");
        }
        else if (PaperType == "Subs")
        {
            popddl.Popualate(Subject, "SUBJECT", "Select SubCode,SubjectName from SUBJECT Where StreamCode='" + StreamCode.SelectedValue + "' and subcode<>'" + SubCode.SelectedValue + "'  order by SubjectName", "SubjectName", "SubCode");
        }


        Subject.Focus();

    }

    protected void BtnRelief_Click(object sender, EventArgs e)
    {
            string abc = "";
            LblTotal.Text = "";
            LblMsg.Text= ""; 
            string[] col = new string[12];
            string[] val = new string[12];
            col[0] = "ExamYear";
            col[1] = "StreamCode";
            col[2] = "StreamPartCode";
            col[3] = "SubPaperCode";
            col[4] = "PaperType";
            col[5] = "LetterNo";
            col[6] = "OrderDate";
            col[7] = "OfficerName";
            col[8] = "Designation";
            col[9] = "Remarks";
            col[10] = "ReliefMarks";
            col[11] = "UserId";
          
 
            val[0] = ExamYear.SelectedValue.ToString();
            val[1] = StreamCode.SelectedValue.ToString();
            val[2] = StreamPart.SelectedValue.ToString();
            val[3] = Subject.SelectedValue.ToString();
            if (RBHons.Checked)
                val[4] = "H";
            else if (RBPractH.Checked || RBPractS.Checked)
                val[4] = "P";
            else if (RBSubs.Checked)
                val[4] = "S";
            else if (RBComp.Checked)
                val[4] = "C";
            val[5] = LetterNo.Text.Trim();
            val[6] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(OrderDate.Text));  
            val[7] = OfficerName.Text.Trim();
            val[8] = Designation.Text.Trim();
            val[9] = Remarks.Text.Trim();
            val[10] = ReliefMarks.Text.Trim();
            val[11] = Session["UserId"].ToString(); 
        

            UnivService.Service1 ss = new UnivService.Service1();

            abc = ss.GetNewCode("select count (*) from exampaperdetail where streampartcode='" + StreamPart.SelectedValue + "' And SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + val[4] + "' And ExamYear='" + ExamYear.SelectedValue + "'");
            LblTotal.Text = " Total Candidate = " + abc;
            if (int.Parse(abc) <= 0)
            {
                LblMsg.Text = "Please Check Relief Marks Entry.";
                return;
            }
      
            abc = ss.SaveData("Relief", col, val);

            if (abc == "1")
            {
                ss.UpdateData("update ExampaPerDetail set ClassTest1=ClassTest1+"+ReliefMarks.Text +", ClassTest2=ClassTest2+"+ReliefMarks.Text   +" where streampartcode='" + StreamPart.SelectedValue + "' And SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + val[4] + "' And ExamYear='" + ExamYear.SelectedValue + "'");
                LblMsg.Text = " Relief Marks is  saved successfully." ;
                
                ReliefMarks.Text = ""; 
                


            }
            else
            {
                LblMsg.Text = abc.ToString();
            }
        
    }
}
