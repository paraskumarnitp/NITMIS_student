using System;
using System.IO;
using System.Data;
using System.Data.SqlClient ;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class RegistrationEntry : System.Web.UI.Page
{
    static HttpPostedFile File1;
    static Int32 contentlength;
   

    Functionreviseed fn = new Functionreviseed();

    protected void Page_Load(object sender, EventArgs e)
    {

       if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "4")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CastCode, "Category", "Select Category,CategoryCode from Category order by CategoryCode", "Category", "CategoryCode");
            popddl.Popualate(State1, "State", "Select State,StateCode from State order by State", "State", "StateCode");
            State1.SelectedValue = "05";//Default Bihar 
            popddl.Popualate(State2, "State", "Select State,StateCode from State order by State", "State", "StateCode");
            State2.SelectedValue = "05";//Default Bihar 
            
            popddl.Popualate(PermanentDistCode, "District", "Select DistName,DistCode from District Where StateCode='"+State1.SelectedValue +"' order by DistName", "DistName", "DistCode");
            popddl.Popualate(PresentDistrictCode, "District", "Select DistName,DistCode from District Where StateCode='" + State2.SelectedValue + "' order by DistName", "DistName", "DistCode");
            
            popddl.Popualate(NationalityCode, "Nationality", "Select Nationality,NationalityCode from Nationality order by Nationality", "Nationality", "NationalityCode");
            popddl.Popualate(ReligionCode, "Religion", "Select * from Religion order by ReligionCode", "Religion", "ReligionCode");
            //popddl.Popualate(UnivCode1, "University", "Select UnivName,UnivCode from University order by UnivName", "UnivName", "UnivCode");
            //popddl.Popualate(LCollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            //popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            //popddl.Popualate(CollCode1, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            //popddl.Popualate(LExamCode, "ExamName", "Select ExamName, ExamCode from ExamName order by ExamName", "ExamName", "ExamCode");
           // popddl.Popualate(ExamCode1, "ExamName", "Select ExamName, ExamCode from ExamName order by ExamName", "ExamName", "ExamCode");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            //popddl.Popualate(LPassYear, "Year", "Select Year from Year order by Year", "Year", "Year");
            //popddl.Popualate(MPassYear, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(Year1, "Year", "Select Year from Year where year >'2008'order by Year", "Year", "Year");
            popddl.Popualate(Year2, "Year", "Select Year from Year where year > '2008'order by Year", "Year", "Year");
            popddl.Popualate(ExamCode1, "ExamName", "Select ExamName, ExamCode from ExamName where examcode='01' order by ExamName", "ExamName", "ExamCode");
            popddl.Popualate(ExamCode2, "ExamName", "Select ExamName, ExamCode from ExamName where examcode='04' order by ExamName", "ExamName", "ExamCode");
            popddl.Popualate(ExamCode3, "ExamName", "Select ExamName, ExamCode from ExamName where examcode not in ('01','04') order by ExamName", "ExamName", "ExamCode");
    
            //PopulateList poplist = new PopulateList();
            //poplist.Popualate(CompPaper, "COMPOSITION", "Select Name,CompCode from COMPOSITION order by Name", "Name", "CompCode");
           
            Year1.Text = System.DateTime.Now.Year.ToString();
            Year2.Text = System.DateTime.Now.Year.ToString();
            RegYear.Text = System.DateTime.Now.Year.ToString();

            NationalityCode.SelectedIndex = 2; // default selection - INDIAN
            ReligionCode.SelectedIndex = 0; // default selection - MUSLIM
            //CastCode.Text = "General (UR)";
            //HindiName.Focus();
           
            HindiName.Focus();

            //ExamPercentage.Attributes.Add("onkeydown", "if(event.which || event.keyCode)" + "{if ((event.which == 9) || (event.keyCode == 9)) " + "{document.getElementById('" + SCBNo.ClientID + "').focus();return false;}} else {return true}; ");
        }

        ContactNo.Attributes.Add("onKeyPress", "return onlyNumbers(this);");
        DOB.Attributes.Add("onKeyPress", "return onlyNumbers(this);");
        CollegeAdmissionDate.Attributes.Add("onKeyPress", "return onlyNumbers(this);");
        PassYear1.Attributes.Add("onKeyPress", "return onlyNumbers(this);");
        PassYear2.Attributes.Add("onKeyPress", "return onlyNumbers(this);");
        PassYear3.Attributes.Add("onKeyPress", "return onlyNumbers(this);");
        PassYear4.Attributes.Add("onKeyPress", "return onlyNumbers(this);");
        PassYear5.Attributes.Add("onKeyPress", "return onlyNumbers(this);");
        SCBDate.Attributes.Add("onKeyPress", "return onlyNumbers(this);");
        ApplicantName.Attributes.Add("onKeyPress", "return SetImg(this);");



        HindiName.Attributes.Add("onKeyPress", "return ValidateAlpha(this);");
        ApplicantName.Attributes.Add("onKeyPress", "return ValidateAlpha(this);");
        MOIdentification.Attributes.Add("onKeyPress", "return ValidateAlpha(this);");
        FatherName.Attributes.Add("onKeyPress", "return ValidateAlpha(this);");
        MotherName.Attributes.Add("onKeyPress", "return ValidateAlpha(this);");

      
    }
    protected void DoBtn_Click(object sender, EventArgs e)
    {
        PresentAddress1.Text = PermanentAddress1.Text;
        PresentAddress2.Text = PermanentAddress2.Text;
        PresentDistrictCode.Text = PermanentDistCode.Text;
        PresentPinCode.Text = PermanentPinCode.Text;
        PresentPinCode.Focus();
    }

    protected void Savepreregqualification(string Newackno)
    {
        DataTable dtreg = new DataTable();
        dtreg.Columns.Add("ackno", typeof(string));
        // -----------------------dtreg.Columns.Add("regno", typeof(string));
        dtreg.Columns.Add("examname", typeof(string));
        dtreg.Columns.Add("collname", typeof(string));
        dtreg.Columns.Add("mainsubject", typeof(string));
        dtreg.Columns.Add("passyear", typeof(string));
        dtreg.Columns.Add("marks", typeof(string));
        // -------------------------dtreg.Columns.Add("division", typeof(string));

        if (ExamCode1.SelectedValue =="01" && CollCode1.Text.Trim().ToString() != "" && PassYear1.Text.Trim().ToString() != "")
        {
            dtreg.Rows.Add(Newackno, ExamCode1.SelectedItem, CollCode1.Text.Trim().ToString(), Subject1.Text.Trim().ToString(), PassYear1.Text.Trim().ToString

(), marks1.Text.Trim().ToString());
        }


        if (ExamCode2.SelectedValue =="04" && CollCode2.Text.Trim().ToString() != "" && PassYear2.Text.Trim().ToString() != "")
        {
            dtreg.Rows.Add(Newackno, ExamCode2.SelectedItem, CollCode2.Text.Trim().ToString(), Subject2.Text.Trim().ToString(), PassYear2.Text.Trim().ToString

(), marks2.Text.Trim().ToString());


        }


        if (ExamCode3.SelectedIndex != 0 && CollCode3.Text.Trim().ToString() != "" && PassYear3.Text.Trim().ToString() != "")
        {

            dtreg.Rows.Add(Newackno, ExamCode3.SelectedItem, CollCode3.Text.Trim().ToString(), Subject3.Text.Trim().ToString(), PassYear3.Text.Trim().ToString

       (), marks3.Text.Trim().ToString());

        }


        if (ExamCode4.Text.Trim().ToString() != "" && CollCode4.Text.Trim().ToString() != "" && PassYear4.Text.Trim().ToString() != "")
        {

            dtreg.Rows.Add(Newackno, ExamCode4.Text.Trim(), CollCode4.Text.Trim().ToString(), Subject4.Text.Trim().ToString(), PassYear4.Text.Trim().ToString

        (), marks4.Text.Trim().ToString());

        }


        if (ExamCode5.Text.Trim().ToString() != "" && CollCode5.Text.Trim().ToString() != "" && PassYear5.Text.Trim().ToString() != "")
        {
            dtreg.Rows.Add(Newackno, ExamCode5.Text.Trim(), CollCode5.Text.Trim().ToString(), Subject5.Text.Trim().ToString(), PassYear5.Text.Trim().ToString

(), marks5.Text.Trim().ToString());


        }



        if (dtreg.Rows.Count > 0)
        {
            for (int i = 0; i < dtreg.Rows.Count; i++)
            {
                int insdata = fn.InsertUpdateDelete("INSERT INTO PREREGQUALIFICATION(AckNo,ExamName, CollName, MainSubject, PassYear, Marks ) VALUES ('" + dtreg.Rows

[i]["ackno"] + "','" + dtreg.Rows[i]["examname"] + "','" + dtreg.Rows[i]["collname"] + "','" + dtreg.Rows[i]["mainsubject"] + "','" + dtreg.Rows[i]["passyear"] +

"','" + dtreg.Rows[i]["marks"] + "')");

            }
        }
    }

  /*  protected void btnPreview_Click(object sender, EventArgs e)
    {
        //save file in folder
        if (imgUpload.PostedFile.ContentType.ToLower().StartsWith
                ("image") && imgUpload.HasFile)
        {
            string savelocation = Server.MapPath("Image/");
            string fileExtention = System.IO.Path.GetExtension(imgUpload.FileName);
            //creating filename to avoid file name conflicts.
            string fileName = Guid.NewGuid().ToString();
            string file = fileName + fileExtention;
            //saving file in savedImage folder.
            string savePath = savelocation + fileName + fileExtention;
            imgUpload.SaveAs(savePath);
            string photo = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/" + file;

            Image1.ImageUrl = photo;
            Image1.DataBind();
        }
    
    }*/




  /*protected void btnPreview_Click(object sender, EventArgs e)
    {
        if (imgUpload.PostedFile.FileName != "")
        {
            LblPhoto.Text = "";
            Session["ImageBytes"] = imgUpload.FileBytes;
            Image1.ImageUrl = "~/ImageHandler.ashx";
        }
        else
        {
            LblPhoto.Text = "Please Select Image"; return;
        }
    }*/ 
    




 /*   protected void btnimageupload_Click(object sender, EventArgs e)
    {
        if (imgUpload.HasFile == true)
        {
            filename1 = Path.GetFullPath(imgUpload.PostedFile.FileName);
            string photo = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/temp.jpg";
            //string photo = Request.(imgUpload.PostedFile.FileName);
            Image1.ImageUrl = photo;
            Image1.DataBind();
           // filename1 = "";
          //Path.g
        }
    
    }   */

    
  /*  protected void SaveExamDetail(string ackno)
    {

        try
        {
            string[] col = new string[9];
            string[] val = new string[9];

            col[0] = "AckNo";
            col[1] = "ExamCode";
            col[2] = "UnivCode";
            col[3] = "CollCode";
            col[4] = "PassYear";
            col[5] = "RollNo";
            col[6] = "Division";
            col[7] = "ExamPercentage";
            col[8] = "MainSubject";

            val[0] = ackno;
            val[1] = ExamCode1.SelectedValue;
            val[2] = UnivCode1.SelectedValue;
            val[3] = CollCode1.Text.Trim();
            val[4] = PassYear1.Text.Trim();
            val[5] = RollNo1.Text.Trim();
            val[6] = Division1.SelectedValue;
            val[7]=ExamPercentage.Text ;
            val[8]=MainSubject.Text.Trim();  

            UnivService.Service1 ss = new UnivService.Service1();
            string abc = ss.SaveData("PreRegQualification", col, val);
            //save Mig. No & Mig. Date
            if (CheckBox1.Checked == true)
            {
                string[] col1 = new string[3];
                string[] val1 = new string[3];

                col1[0] = "AckNo";
                col1[1] = "MigrationNo";
                col1[2] = "MigrationIssueDate";

                val1[0] = ackno;
                val1[1] = MigrationNo.Text.Trim();
                val1[2] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(MigrationIssueDate.Text));
                abc = ss.SaveData("PreRegMigration", col1, val1);
                
            }
            
        }
        catch (Exception ex)
        {
        }
                 

        
    }          */



    protected void SaveReg()
    {

        try
        {
            // Check duplicate Entry of Form (On RegForm , Collcode and Stream Code)                     

            SqlConnection con = new SqlConnection();
            SqlDataReader rd;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;
             UnivService.Service1 NicService = new UnivService.Service1();
            string clgcode ="";
            clgcode= NicService.GetNewCode("select collcode from college");
            string regformno = CastCode.SelectedValue + txtAllIndiaRank.Text.Trim() + PermanentDistCode.SelectedValue;



            cmd.CommandText = "select AckNo from Registration where Admformno='" + regformno + "' AND CollCode='"+clgcode+"'";
            con.Open();
            rd = cmd.ExecuteReader();
                if (rd.HasRows)
                {
                    rd.Read();
                    string msg = " Pls Check Entry Form. This Form has already entered whose Enrollment No is -" + rd["AckNo"].ToString();
                    LblMsg.Text = msg;
                    LblMsg2.Text = msg;
                    string popupScript = "<script language='javascript'>" +
                                       " alert('" + msg + " ')" +
                                        "</script>";
                    Page.RegisterStartupScript("PopupScript", popupScript);
                    //rd.Read();
                    rd.Close();
                    con.Close();
                    HindiName.Focus();
                    return;
                }
                else
                {
                    //rd.Read();
                    rd.Close();
                    con.Close();
                }


            // Check duplicate Entry of Form (On Name , Father Name and DOB)   

            if (ChkBoxDuplicate.Checked == false)
            {
                cmd.CommandText = "select Count(1) from Registration where ApplicantName='" + ApplicantName.Text.Trim() + "' and FatherName='" + FatherName.Text.Trim() + "' and DOB='" + string.Format("{0:MM/dd/yyyy }", Convert.ToDateTime(DOB.Text.Trim())) + "' ";
                con.Open();

                int TotDupCount = int.Parse(cmd.ExecuteScalar().ToString());
                    if (TotDupCount > 0)
                    {
                        string msg = " This Record may already exist. Do You want to save this record ?  ";
                        LblMsg.Text = msg;
                        LblMsg2.Text = msg;

                        string popupScript = "<script language='javascript'>" +
                                           " alert('" + msg + " ')" +
                                            "</script>";
                        Page.RegisterStartupScript("PopupScript", popupScript);

                        con.Close();
                        // visible the check box
                        ChkBoxDuplicate.Visible = true;

                        HindiName.Focus();
                        return;
                    }

                    else
                    {
                        con.Close();
                    }
            }
            else
            {
                ChkBoxDuplicate.Checked = false;
                ChkBoxDuplicate.Visible = false;
            }


            // validating examcode & univcode---------------

           /* if (ExamCode1.SelectedValue.Trim() == "0")
            {
                string msg = " Please Select Exam Name";
                string popupScript = "<script language='javascript'>" +
                                   " alert('" + msg + " ')" +
                                    "</script>";
                Page.RegisterStartupScript("PopupScript", popupScript);
                ExamCode1.Focus();
                return;
            }
            else if (UnivCode1.SelectedValue.Trim() == "0")
            {
                string msg = " Please Select Univ./Board Name";
                string popupScript = "<script language='javascript'>" +
                                   " alert('" + msg + " ')" +
                                    "</script>";
                Page.RegisterStartupScript("PopupScript", popupScript);
                UnivCode1.Focus();
                return;
            }*/

            string SaveFlag = "";

            // saving in table -------------------------------

            string[] col = new string[46];
            string[] val = new string[46];
            string[] coltype = new string[46];
            for (int i = 0; i < 46; i++)
                coltype[i] = "0";
            coltype[0] = "1";

           

            // Colume Variable--Field Name
            col[0] = "HindiName"; val[0] = HindiName.Text.Trim();
            col[1] = "ApplicantName"; val[1] = ApplicantName.Text.Trim();
            ApplicantName.Text = (ApplicantName.Text.Trim()).ToUpper();

            col[2] = "DOB"; val[2] = string.Format("{0:MM/dd/yyyy }", Convert.ToDateTime(DOB.Text.Trim()));
            col[3] = "FatherName"; val[3] = FatherName.Text = FatherName.Text.Trim();
            col[4] = "MotherName"; val[4] = MotherName.Text = MotherName.Text.Trim();
            col[5] = "Gender"; if (GenderM.Checked == true) val[5] = "M"; else val[5] = "F";
            col[6] = "CastCode"; val[6] = CastCode.SelectedValue;
            col[7] = "MaritalStatus"; val[7] = MaritalStatus.SelectedValue;
            col[8] = "NationalityCode"; val[8] = NationalityCode.SelectedValue;
            col[9] = "PermanentAddress1"; val[9] = PermanentAddress1.Text.Trim();
            col[10] = "PermanentAddress2"; val[10] = PermanentAddress2.Text.Trim();
            col[11] = "PermanentDistCode"; val[11] = PermanentDistCode.SelectedValue;
            col[12] = "PermanentPinCode"; val[12] = PermanentPinCode.Text.Trim();
            col[13] = "PresentAddress1"; val[13] = PresentAddress1.Text.Trim();
            col[14] = "PresentAddress2"; val[14] = PresentAddress2.Text.Trim();
            col[15] = "PresentDistrictCode"; val[15] = PresentDistrictCode.SelectedValue;
            col[16] = "PresentPinCode"; val[16] = PresentPinCode.Text.Trim();
            col[17] = "AdmFormNo"; val[17] = regformno;
            col[18] = "CollCode"; val[18] = clgcode;
            col[19] = "CourseSession"; val[19] = Year1.SelectedValue + "-" + Year2.SelectedValue;
            col[20] = "AdmissionDate"; val[20] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(CollegeAdmissionDate.Text.ToString()));
            col[21] = "StreamCode"; val[21] = StreamCode.SelectedValue.ToString();
            col[22] = "paymentid"; val[22] = SCBNo.Text.Trim();
            col[23] = "AdmFeeAmt"; val[23] = RegFeeAmt.Text.Trim();
            col[24] = "paymentDate"; val[24] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(SCBDate.Text.Trim()));
            col[25] = "UserId"; val[25] = Session["UserId"].ToString();
            col[26] = "EntryOptDateTime"; val[26] = string.Format("{0:MM/dd/yyyy h:mm:ss}", System.DateTime.Now);
            col[27] = "AckNo";
            col[28] = "ReligionCode"; val[28] = ReligionCode.SelectedValue;
            string tmpRNo = StreamCode.SelectedValue + txtYearAppeared.Text.Trim() + txtSelectionExamRollNo.Text.Trim(); 
            col[29] = "TempRollNo"; val[29] = tmpRNo;
            string spart = "";
            spart = NicService.GetNewCode("Select streampartcode from streampart where streamcode='" + StreamCode.SelectedValue + "' and streampart='sem 1'");
            col[30] = "StreamPartCode"; val[30] = spart;
            string scode = "";
            scode = NicService.GetNewCode("Select subcode from subject where streamcode='" + StreamCode.SelectedValue + "'");
            col[31] = "SubCode"; val[31] = scode;
            col[32] = "AdmYear"; val[32] = RegYear.Text.Trim();
            col[33] = "BloodGroup"; val[33] = BloodGroup.SelectedValue;
            col[34] = "EmailId"; val[34] = EmailId.Text.Trim();
            col[35] = "ContactNo"; val[35] = ContactNo.Text.Trim();
            //col[37] = "RegNo"; 
            col[36] = "ExamAppeared"; val[36] = ddlExamAppeared.SelectedValue.ToString();
            col[37] = "YearAppeared"; val[37] = txtYearAppeared.Text.Trim();
            col[38] = "SelectionExamRollNo"; val[38] = txtSelectionExamRollNo.Text.Trim();
            col[39] = "AllIndiaRank"; val[39] = txtAllIndiaRank.Text.Trim();
            col[40] = "SelectionExamScore"; val[40] = txtExamScore.Text.Trim();
            col[41] = "QualifingExam"; val[41] = txtQualifingExamDegree.Text.Trim();
            col[42] = "paymentmode"; val[42] = ddlPaymentMode.SelectedItem.ToString();
            col[43] = "admissionbranch"; val[43] = StreamCode.SelectedItem.ToString();
            col[44] = "Bank"; val[44] = txtBank.Text.Trim();
            col[45] = "RegYear"; val[45] = RegYear.Text.Trim();
        

            //UnivService.Service1 NicService = new UnivService.Service1();
            //string Year = System.DateTime.Now.Year.ToString();
            //Year = Year.Substring(2, 2);

            string Year = RegYear.Text.Substring(2, 2); // getting Value from RegYear Text Box
            string SQL = "SELECT     ISNULL(MAX(ABS(SUBSTRING(AckNo, 8, 11))), '0') + 1 AS VarAckNo FROM  REGISTRATION WHERE     SUBSTRING(AckNo, 1, 2) = '" + Year + "' and collcode='"+clgcode+"' and streamcode='" + StreamCode.SelectedValue + "'";
            string NewAckNo = NicService.GetNewCode(SQL);
            // SID Format
            NewAckNo = Year + clgcode + StreamCode.SelectedValue + string.Format("{0:D4}", Convert.ToInt32(NewAckNo));

            val[27] = NewAckNo;
            //----Subject Comb Code
           // string CourseComb = "C(";
            //Composition
          /*  for (int i = 0; i < CompPaper.Items.Count; i++)
            {
                if (CompPaper.Items[i].Selected)
                {

                    CourseComb += CompPaper.Items[i].Value + ",";
                }

            }*/

            //Honours Paper
          //  CourseComb = CourseComb.Substring(0, CourseComb.Length - 1);

         //   CourseComb += ")+H(";

        /*    for (int i = 0; i < HPaper.Items.Count; i++)
            {
                if (HPaper.Items[i].Selected)
                {
                    CourseComb += HPaper.Items[i].Value + ",";
                }

            }*/

            //Sunsidiary Paper
          /*  CourseComb = CourseComb.Substring(0, CourseComb.Length - 1);
            CourseComb += ")+S(";

            for (int i = 0; i < SPaper.Items.Count; i++)
            {
                if (SPaper.Items[i].Selected)
                {
                    CourseComb += SPaper.Items[i].Value + ",";
                }

            }

            CourseComb = CourseComb.Substring(0, CourseComb.Length - 1);
            CourseComb += ")";*/

            //---SubCom Code

          //  col[30] = "SubCombCode";
           // val[30] = CourseComb;

            SaveFlag = NicService.SaveDataUniCode("Registration", col, val, coltype);

            if (SaveFlag == "1")
            {

                ViewState.Add("AckNo", NewAckNo);
                //Page.RegisterStartupScript(@"startup", @"<script>altert('New User Id is " + val[0] + "');</script>");

               // SaveExamDetail(NewAckNo);
                Savepreregqualification(NewAckNo);
                LblMsgRemarks.Text = "";
                // call function DocumnetRequired before displaying .....
                if (RBDocN.Checked == true)
                    DocumentNotAvailable(NewAckNo);

              /*  if (oldRegY.Checked == true)
                    OldRegRenewal(NewAckNo);*///suraj

                LblMsg.Text = " Registration Inserted Successfully:: ___Enrollment No.: " + NewAckNo + " _____Roll No.:"+ tmpRNo + "_____Admission Form No: "+ regformno;
                LblMsg2.Text = " Registration Inserted Successfully:: ___Enrollment No.: " + NewAckNo + "_____Roll No.:" + tmpRNo + "_____Admission Form No: " + regformno;
                NewAck.Text = NewAckNo;

              /*  HindiName.Text = "";
                ApplicantName.Text = "";
                FatherName.Text = "";
                MotherName.Text = "";
                DOB.Text = "";
                txtYearAppeared.Text = "";
                txtSelectionExamRollNo.Text = "";
                txtAllIndiaRank.Text = "";
                txtQualifingExamDegree.Text = "";
                txtExamScore.Text = ""; */


                HindiName.Focus();

                //---------------- updated on 10 feb 2011

                RBDocY.Checked = true;
                RBDocY_CheckedChanged(null, EventArgs.Empty);
                RBDocN.Checked = false;

             /*   oldRegY.Checked = false;
                oldRegY_CheckedChanged(null, EventArgs.Empty);
                oldRegN.Checked = true;*/ //suraj

                
             //   if (oldRegText.Enabled == true)
                 //   val[37] = oldRegText.Text=oldRegText.Text.Trim();

                //DocRemarks.Enabled = false;
                //----------------------------

                CheckBox2.Checked = false;
                CheckBox2_CheckedChanged(null, EventArgs.Empty);


                // save image and display

                //ImageUpload imgUpload = new ImageUpload();
                //string strFileName = imgUpload.ImageSave(File1, NewAckNo );
                // string strFileName = "";
                // Image1.ImageUrl = strFileName;


                if (imgUpload.PostedFile.FileName != "")
                {
                    Byte[] imgByte = null;
                    FileUpload img = (FileUpload)imgUpload;
                    File1 = imgUpload.PostedFile; contentlength = File1.ContentLength;
                    imgByte = new Byte[contentlength];
                    File1.InputStream.Read(imgByte, 0, contentlength);
                    
                    // img size checking ------------
                    if (imgByte.Length == 0)
                    { LblPhoto.Text = "Please Select Image"; return; }

                    ImageUpload ImgUpld = new ImageUpload();

                    string result = ImgUpld.UpdateImage(imgByte.Length, imgByte, NewAckNo.Trim());

                   Image1.ImageUrl = "~/ImageHandler.aspx?AckNo=" + NewAckNo.Trim();

                   // Image1.ImageUrl = Path.GetFullPath(imgUpload.PostedFile.FileName);
                    if (result != "1")
                    {
                        LblPhoto.Text = "Image can not be saved as '" + result + "'";
                    }
                    else
                    {
                        LblPhoto.Text = "Image Updated ";
                    }
                    
                            
              }
                else
                {
                    Image1.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadPhoto.JPG";
                    Image1.DataBind();

                }

                //signature uploading

                if (signUpload.PostedFile.FileName != "")
                {
                    Byte[] imgByte = null;
                    FileUpload img = (FileUpload)signUpload;
                    File1 = signUpload.PostedFile; contentlength = File1.ContentLength;
                    imgByte = new Byte[contentlength];
                    File1.InputStream.Read(imgByte, 0, contentlength);

                    // img size checking ------------
                    if (imgByte.Length == 0)
                    { LblPhoto.Text = "Please Select Image of signature"; return; }

                    ImageUpload signUpld = new ImageUpload();

                    string result = signUpld.UpdateSign(imgByte.Length, imgByte, NewAckNo.Trim());

                    Image2.ImageUrl = "~/SignHandler.aspx?AckNo=" + NewAckNo.Trim();

                    // Image1.ImageUrl = Path.GetFullPath(imgUpload.PostedFile.FileName);
                    if (result != "1")
                    {
                        LblPhoto.Text = "Image can not be saved as '" + result + "'";
                    }
                    else
                    {
                        LblPhoto.Text = "Image Updated ";
                    }


                }
                else
                {
                    Image2.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadSIGN.JPG";
                    Image2.DataBind();

                }


                LblMsg.Focus();

            }
            else
            {
                LblMsg.Text = SaveFlag.ToString();
            }

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

        ApplicantName.Focus();
    }



    protected void VerifySeat()
    {
        // Check Seat Allocation (On UnivCode , Collcode and Stream Code, Session("Year"))

        string clgcode = "";
        string UnivId = "";
        string TotalRegistered ="";
        string TotalSeat = "";
        int AvailableSeat = 0;


           UnivService.Service1 ss = new UnivService.Service1();
           UnivId=ss.GetNewCode("Select UnivCode From install");
           clgcode = ss.GetNewCode("select collcode from college");

           TotalSeat = ss.GetNewCode("select NoOfSeats from SeatAllocation where (CollCode =' "+clgcode+"') AND (StreamCode = '" + StreamCode.SelectedValue + "') AND (AllotedYear = '" + RegYear.Text.Trim() + "') ");
           if (TotalSeat == "error")
               TotalSeat = "0";

           TotalRegistered = ss.GetNewCode("SELECT COUNT(1)as total FROM REGISTRATION WHERE  (CollCode = '"+clgcode+"') AND (StreamCode = '" + StreamCode.SelectedValue + "') AND (RegYear = '" + RegYear.Text.Trim() + "') ");
           AvailableSeat = Int16.Parse(TotalSeat) - Int16.Parse(TotalRegistered);

           if (AvailableSeat <= 0)
           {
               string msg = " Seats have already Fulfilled or not Alloted .";
               string popupScript = "<script language='javascript'>" +
                                  " alert('" + msg + " ')" +
                                   "</script>";
               Page.RegisterStartupScript("PopupScript", popupScript);
           }
    }
    protected void DocumentNotAvailable(string AckNo)
    {
        try
        {

            string[] col = new string[3];
            string[] val = new string[3];
            col[0] = "AckNo";
            col[1] = "ReasonOfRejection";
            col[2] = "Date";

            val[0] = AckNo;
            val[1] = DocRemarks.Text.Trim();
            val[2] = string.Format("{0:MM/dd/yyyy}", System.DateTime.Now);
            UnivService.Service1 ss = new UnivService.Service1();
            string abc = ss.SaveData("RejectedRegistration", col, val);
            string status;
                   status = "B";
            abc = ss.UpdateData(" update Registration set verifystatus='" + status + " ' where ackno='" + AckNo + "'");
            
            if (abc == "ok")
            {
                LblMsgRemarks.Text = "Remarks Saved";
                
            }
            else
            {
                LblMsgRemarks.Text = abc.ToString();
            }
        }
        catch (Exception ex)
        {
            LblMsgRemarks.Text = ex.Message;
        }
    }

   





    protected void BtnSave_Click(object sender, EventArgs e)
    {
        try
        {
            //VerifySeat();  // commented due to seat details are not entered.
            SaveReg();
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

        
    }
    protected void InstCode_Enter(object sender, EventArgs e)
    {
        LblMsg.Text = "Enter Pressed";
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBox1.Checked == true)
        {
            Panel1.Visible = true;
           // MainSubject.Focus();
        }
        else
        {
            Panel1.Visible = false; 

        }
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (StreamCode.SelectedValue == "00") return; 
        PopulateDDL popddl = new PopulateDDL();
        //popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPart", "StreamPart", "StreamPartCode");
       // popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        //set Session
        UnivService.Service1 NicService = new UnivService.Service1();
        string y = NicService.GetNewCode ("Select Duration from stream Where StreamCode='"+StreamCode.SelectedValue  +"'");
        Year2.Text = (int.Parse(Year1.Text) + int.Parse(y))+"";
       // SubCode_SelectedIndexChanged(StreamCode, e); // call subcode selected index
        //034

       

        StreamCode.Focus();    

        



    }
    /*protected void SubCode_SelectedIndexChanged(object sender, EventArgs e)
    {

        PopulateList poplist = new PopulateList();
        //PopulateList poplist = new PopulateList();

        if (StreamCode.SelectedValue.ToString() == "04")
        {
            poplist.Popualate(CompPaper, "COMPOSITION", "Select Name,CompCode from COMPOSITION order by Name", "Name", "CompCode");
        }
        else
        {
            // remove from Comppaper
            poplist.Popualate(CompPaper, "COMPOSITION", "Select Name,CompCode from COMPOSITION where 1<>1 order by Name", "Name", "CompCode");
        }
   
        
        
        poplist.Popualate(HPaper, "COURSEPAPERS", "Select PaperName,SubPaperCode from COURSEPAPERS Where StreamCode='" + StreamCode.SelectedValue + "' And StreamPartCode='" + StreamPart.SelectedValue + "' And SubCode='" + SubCode.SelectedValue + "' order by SubPaperCode", "PaperName", "SubPaperCode");
        poplist.Popualate(SPaper, "SUBJECT", "Select SUBJECT.SubCode,SubjectName from SUBJECT,Subsidiary Where StreamCode='" + StreamCode.SelectedValue + "' and SUBJECT.subcode<>'" + SubCode.SelectedValue + "' And SUBJECT.SUBCode=Subsidiary.SubCode   order by SubjectName", "SubjectName", "SubCode");
        for (int i = 0; i < HPaper.Items.Count; i++)
        {
            HPaper.Items[i].Selected = true;
        }


        // auto selection of subsidiary - dinyat & arabic language paper
        for (int i = 0; i < SPaper.Items.Count; i++)
        {
            if (SPaper.Items[i].Value == "034")
            {
                SPaper.Items[i].Selected = true;
            }
        }
        // above subsidiary section close


        SubCode.Focus();

    }*/
    protected void Year1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            UnivService.Service1 NicService = new UnivService.Service1();
            string y = NicService.GetNewCode("Select Duration from stream Where StreamCode='" + StreamCode.SelectedValue + "'");
            Year2.Text = (int.Parse(Year1.Text) + int.Parse(y)) + "";
           // SubCode_SelectedIndexChanged(sender, e);

        }
        catch (Exception ex)
        {
        }
    }
    protected void State1_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(PermanentDistCode, "District", "Select DistName,DistCode from District Where StateCode='" + State1.SelectedValue + "' order by DistName", "DistName", "DistCode");
        
            
    }
    protected void State2_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(PresentDistrictCode, "District", "Select DistName,DistCode from District Where StateCode='" + State2.SelectedValue + "' order by DistName", "DistName", "DistCode");
    }
    protected void CheckBox2_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBox2.Checked == true)
        {
            
            PresentAddress1.Text = PermanentAddress1.Text;
            PresentAddress2.Text = PermanentAddress2.Text;
            State2.Text = State1.Text;
            State2_SelectedIndexChanged(sender, e);
            PresentPinCode.Text = PermanentPinCode.Text;
            PresentDistrictCode.SelectedValue= PermanentDistCode.SelectedValue;

            PresentAddress1.Enabled=false;
            PresentAddress2.Enabled=false;
            State2.Enabled=false;
            PresentPinCode.Enabled=false;
            PresentDistrictCode.Enabled = false;

            StreamCode.Focus();


        }
        else
        {
            PresentAddress1.Text = "";
            PresentAddress2.Text = "";
            PresentPinCode.Text = "";

            PresentAddress1.Enabled = true;
            PresentAddress2.Enabled = true;
            State2.Enabled = true;
            PresentPinCode.Enabled = true;
            PresentDistrictCode.Enabled = true;

            PresentAddress1.Focus();

        }
    }
   /* protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
    }  */
   /* protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    } */
    protected void RBDocY_CheckedChanged(object sender, EventArgs e)
    {
        if (RBDocY.Checked == true)
        {
            DocRemarks.Enabled = false;
            DocRemarks.Text = "Remarks";
        }
        //else
          //  DocRemarks.Enabled = true;
    }
    protected void RBDocN_CheckedChanged(object sender, EventArgs e)
    {
        if (RBDocN.Checked == true)
            DocRemarks.Enabled = true;
        //else
          //  DocRemarks.Enabled = false;
    }

    protected void BtnReset_Click(object sender, EventArgs e)
    {
        HindiName.Text = "";
        ApplicantName.Text = "";
        FatherName.Text = "";
        MotherName.Text = "";
        DOB.Text = "";
        txtYearAppeared.Text = "";
        txtSelectionExamRollNo.Text = "";
        txtAllIndiaRank.Text = "";
        txtQualifingExamDegree.Text = "";
        txtExamScore.Text = "";
        MaritalStatus.Text = "";
        PermanentAddress1.Text = "";
        PermanentAddress2.Text = "";
        PermanentPinCode.Text = "";
        PresentAddress1.Text = "";
        PresentAddress2.Text = "";
        PresentPinCode.Text = "";
        CollegeAdmissionDate.Text = "";
        SCBNo.Text = "";
        RegFeeAmt.Text = "";
        SCBDate.Text = "";
        EmailId.Text = "";
        ContactNo.Text = "";
        ddlExamAppeared.Text = "";
       
        txtBank.Text = "";
        RegYear.Text = "";
        Subject1.Text = "";
        Subject2.Text = "";
        Subject3.Text = "";
        Subject4.Text = "";
        Subject5.Text = "";
        PassYear1.Text = "";
        PassYear2.Text = "";
        PassYear3.Text = "";
        PassYear4.Text = "";
        PassYear5.Text = "";
        CollCode1.Text = "";
        CollCode2.Text = "";
        CollCode3.Text = "";
        CollCode4.Text = "";
        CollCode5.Text = "";
        marks1.Text = "";
        marks2.Text = "";
        marks3.Text = "";
        marks4.Text = "";
        marks5.Text = "";
        Image2.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadSIGN.JPG";
        Image2.DataBind();
        Image1.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadPhoto.JPG";
        Image1.DataBind();
        LblPhoto.Text = "";
      



    }
    
    
    
    
  


}
