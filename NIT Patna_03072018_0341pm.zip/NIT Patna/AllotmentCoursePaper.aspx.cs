using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class AllotmentCoursePaper : System.Web.UI.Page
{

    Functionreviseed fn = new Functionreviseed();
    Functionreviseed chkfn = new Functionreviseed();
    // static int CountCourse = 0;
    //static int CountElective = 0;

    string querypart = "";

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "10"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            string deptcode = (fn.singlevalue("Select Designation From Login Where Userid = '" + Session["UserId"].ToString() + "'")).ToString();
            if (deptcode == "ME") querypart = "and StreamCode IN ('01','26','36')";
            else if (deptcode == "CE") querypart = "and StreamCode IN ('03','23','37')";
            else if (deptcode == "EE") querypart = "and StreamCode IN ('02','21','35')";
            else if (deptcode == "ECE") querypart = "and StreamCode IN ('04','29','33')";
            else if (deptcode == "CSE") querypart = "and StreamCode IN ('06','07','28','38','32','43')";
            else if (deptcode == "Arch") querypart = "and StreamCode IN ('05','31','30','40')";
            else if (deptcode == "Math") querypart = "and StreamCode IN ('09','34','41')";
            else querypart = "";


            PopulateDDL popddl = new PopulateDDL();

            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y'" + querypart + " order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(Year3, "Year", "Select Year from Year where year > '2016'order by Year", "Year", "Year");
            popddl.Popualate(PaperTypeCode, "PaperType", "Select * from PaperType order by PaperType", "PaperType", "PaperTypeCode");
            popddl.Popualate(ddlDepartment, "Department", "select Id, Name from Department", "Name", "Id");
            ddlDepartment.Items.Insert(0, new ListItem("-Select", "0"));

            Year3.Text = System.DateTime.Now.Year.ToString();
            ViewState["action"] = "Save";
            popupcontent.Visible = false;

        }


    }

    protected void BtnSave_Click(object sender, EventArgs e)
    {
        try
        {
            //SaveExam();
            clear();

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

    }

    void InstCode_Enter(object sender, EventArgs e)
    {
        LblMsg.Text = "Enter Pressed";
    }

    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        clear();

        if (StreamCode.SelectedValue == "00") return;

        UnivService.Service1 NicService = new UnivService.Service1();
        string y = NicService.GetNewCode("Select Duration from stream Where StreamCode='" + StreamCode.SelectedValue + "'");
        int semValue = 0;
        if (month1.SelectedValue != "JAN")
        {
            semValue = 1;
        }
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(Semester, "StreamPart", "Select STREAMPART,StreamPartCode from STREAMPART where StreamCode in ('" + StreamCode.SelectedValue + "','00') and " +
            " (CONVERT(int, LEFT(SUBSTRING(StreamPart, PATINDEX('%[0-9]%', StreamPart), 8000), PATINDEX('%[^0-9]%', SUBSTRING(StreamPart, PATINDEX('%[0-9]%', " +
            " StreamPart), 8000) + 'X') - 1))%2=" + semValue.ToString() + " OR CONVERT(int, LEFT(SUBSTRING(StreamPart, PATINDEX('%[0-9]%', StreamPart), 8000), PATINDEX('%[^0-9]%', " +
            " SUBSTRING(StreamPart, PATINDEX('%[0-9]%', StreamPart), 8000) + 'X') - 1)) = 3) order by StreamPart", "StreamPart", "StreamPartCode");
//        popddl.Popualate(Semester, "StreamPart", "Select STREAMPART,StreamPartCode from STREAMPART where StreamCode in ('" + StreamCode.SelectedValue + "','00') and  CONVERT(int, LEFT(SUBSTRING(StreamPart, PATINDEX('%[0-9]%', StreamPart), 8000), " +
// " PATINDEX('%[^0-9]%', SUBSTRING(StreamPart, PATINDEX('%[0-9]%', " +
//" StreamPart), 8000) + 'X') - 1))%2=" + semValue.ToString() + " order by StreamPart", "StreamPart", "StreamPartCode");
        StreamCode.Focus();

        DataSet dssplcode = fn.SelectDataset("SELECT Stream_Specialization.SplCode as SPCode, CourseSpecialization.SpDescription FROM Stream_Specialization " +
            " INNER JOIN CourseSpecialization ON Stream_Specialization.SplCode = CourseSpecialization.SPCode WHERE Stream_Specialization.StreamCode = '" + StreamCode.SelectedValue + "'");
        if (dssplcode.Tables[0].Rows.Count > 0)
        {
            drpsplType.Items.Clear();
            drpsplType.DataSource = dssplcode.Tables[0];
            drpsplType.DataTextField = "SpDescription";
            drpsplType.DataValueField = "SPCode";
            drpsplType.DataBind();
        }
        else
        {
            drpsplType.Items.Clear();
            drpsplType.Items.Insert(0, new ListItem("NA", "00"));
        }
        GetData();

    }

    protected void Year1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            UnivService.Service1 NicService = new UnivService.Service1();
            string y = NicService.GetNewCode("Select Duration from stream Where StreamCode='" + StreamCode.SelectedValue + "'");

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }
    DataSet dscrsespl;
    protected void bindddlcoursespl()
    {
        Functionreviseed appfn = new Functionreviseed();
        dscrsespl = appfn.SelectDataset("select * from Stream_Specialization where ISNULL(streamcode,'')=case when (select COUNT(StreamCode) from Stream_Specialization where StreamCode='" + StreamCode.SelectedValue + "')>0 then '" + StreamCode.SelectedValue + "' else '' end");
        drpsplType.DataSource = dscrsespl.Tables[0];
        drpsplType.DataTextField = "SPCode";
        drpsplType.DataValueField = "SPCode";
        drpsplType.DataBind();
        drpsplType.Items.Insert(0, "--Select--");
        GetData();
    }

    protected void Semester_SelectedIndexChanged(object sender, EventArgs e)
    {
        GetData();
    }

    private void GetData()
    {
        gvcourse.DataSource = null;
        gvcourse.DataBind();
        ViewState["CurrentTable"] = null;
        coursetitle.Text = "";
        credit.Text = "";
        ltp.Text = "";
        LblMsg.Text = "";
        btnsubmit.Text = "Save";
        string examsession = month1.SelectedItem.ToString() + "-" + month2.SelectedItem.ToString() + "_" + Year3.SelectedItem.ToString();
        DataSet dsassignedcourse = fn.SelectDataset(" SELECT c.Id as SubPaperCode, c.CourseCode as txtcoursecode, c.Title as txtcoursetitle, " +
                                                   " c.Credit as txtcredit, c.L + '-' + c.T + '-' + c.P AS  txtltp " +
                                                   " FROM CourseCodeOfferedDetail AS A inner join CourseCodeOffered d on a.CourseCodeOfferedId=d.Id  INNER JOIN " +
                                                   " COURSEPAPERS AS B ON A.SubPaperCode = B.SubPaperCode inner join MasterCoursePaper c on b.MasterPaperId=c.Id " +
                                                   " WHERE     (d.ExamSession = '" + examsession + "') AND (d.StreamPartCode = '" + Semester.SelectedValue + "') AND (A.OfferedTypeId = '1') and (d.SplCode='" + drpsplType.SelectedValue + "') ");
        dsassignedcourse.Tables[0].PrimaryKey = new DataColumn[] { dsassignedcourse.Tables[0].Columns["SubPaperCode"] };
        if (dsassignedcourse.Tables[0].Rows.Count > 0)
        {
            ViewState["CurrentTable"] = dsassignedcourse.Tables[0];
            gvcourse.DataSource = dsassignedcourse.Tables[0];
            gvcourse.DataBind();
            ViewState["action"] = "Update";
            btnsubmit.Text = "UPDATE";
            btnsubmit.Visible = true;
        }
        else
        {
            examsession = month1.SelectedItem.ToString() + "-" + month2.SelectedItem.ToString() + "_" + (Convert.ToInt32(Year3.SelectedItem.ToString()) - 1).ToString();
            dsassignedcourse = fn.SelectDataset(" SELECT c.Id as SubPaperCode, c.CourseCode as txtcoursecode, c.Title as txtcoursetitle, " +
                                                    " c.Credit as txtcredit, c.L + '-' + c.T + '-' + c.P AS  txtltp " +
                                                    " FROM CourseCodeOfferedDetail AS A inner join CourseCodeOffered d on a.CourseCodeOfferedId=d.Id INNER JOIN " +
                                                    " COURSEPAPERS AS B ON A.SubPaperCode = B.SubPaperCode inner join MasterCoursePaper c on b.MasterPaperId=c.Id " +
                                                    " WHERE     (d.ExamSession = '" + examsession + "') AND (d.StreamPartCode = '" + Semester.SelectedValue + "') AND (A.OfferedTypeId = '1') and (d.SplCode='" + drpsplType.SelectedValue + "') ");
            dsassignedcourse.Tables[0].PrimaryKey = new DataColumn[] { dsassignedcourse.Tables[0].Columns["SubPaperCode"] };
            ViewState["CurrentTable"] = dsassignedcourse.Tables[0];
            if (dsassignedcourse.Tables[0].Rows.Count > 0)
            {

                gvcourse.DataSource = dsassignedcourse.Tables[0];
                gvcourse.DataBind();
                ViewState["action"] = "Update";
                btnsubmit.Text = "UPDATE";
                btnsubmit.Visible = true;
            }
        }
        DataSet dscourse = fn.SelectDataset("select Id,CourseCode from MasterCoursePaper");
        drpdlcoursecode.DataSource = dscourse.Tables[0];
        drpdlcoursecode.DataTextField = "CourseCode";
        drpdlcoursecode.DataValueField = "Id";
        drpdlcoursecode.DataBind();
        drpdlcoursecode.Items.Insert(0, new ListItem("Select CourseCode", "00"));
    }


    protected void btnshow_Click(object sender, EventArgs e)
    {
        DataTable dt = fn.SelectDatatable("SELECT c.Id as SubPaperCode, c.CourseCode as txtcoursecode, c.Title as txtcoursetitle, " +
                                                    " c.Credit as txtcredit, c.L + '-' + c.T + '-' + c.P AS  txtltp From MasterCoursePaper c" +
                    " where Id=" + drpdlcoursecode.SelectedValue);
        DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
        if (dt.Rows.Count > 0)
        {
            dtCurrentTable.Merge(dt);
            ViewState["CurrentTable"] = dtCurrentTable;
            gvcourse.DataSource = dtCurrentTable;
            gvcourse.DataBind();
        }
    }

    public void clear()
    {
    }

    protected void month1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (month1.SelectedIndex == 1)
        {
            month2.SelectedIndex = 1;
        }
        else if (month1.SelectedIndex == 2)
        {
            month2.SelectedIndex = 2;
        }
        else
        {
            month2.SelectedIndex = 0;
        }
        GetData();

    }
    protected void Year3_SelectedIndexChanged(object sender, EventArgs e)
    {
        GetData();
    }

    protected void drpsplType_SelectedIndexChanged(object sender, EventArgs e)
    {
    }

    protected void drpdlcoursecode_SelectedIndexChanged(object sender, EventArgs e)
    {
        CourseSelectionChanged();
    }

    private void CourseSelectionChanged()
    {
        DataSet dscoursedetails = fn.SelectDataset("Select Title,Credit,L+'-'+T+'-'+P AS LTP From MasterCoursePaper Where Id = " + drpdlcoursecode.SelectedValue);
        if (dscoursedetails.Tables[0].Rows.Count > 0)
        {
            coursetitle.Text = dscoursedetails.Tables[0].Rows[0]["Title"].ToString();
            credit.Text = dscoursedetails.Tables[0].Rows[0]["Credit"].ToString();
            ltp.Text = dscoursedetails.Tables[0].Rows[0]["LTP"].ToString();
        }
        else
        {
            coursetitle.Text = "";
            credit.Text = "";
            ltp.Text = "";
        }
    }

    protected void gvcourse_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "remove")
        {
            GridViewRow gvr = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
            int RowIndex = gvr.RowIndex;

            string subPaperCode = Convert.ToString(gvcourse.DataKeys[RowIndex].Value);
            if (ViewState["CurrentTable"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                string expression = "SubPaperCode = '" + subPaperCode + "'";
                foreach (DataRow row in dtCurrentTable.Select(expression))
                {
                    if (row["SubPaperCode"].ToString() == subPaperCode)
                    {
                        row.Delete();
                    }
                }
                dtCurrentTable.AcceptChanges();
                ViewState["CurrentTable"] = dtCurrentTable;
                gvcourse.DataSource = dtCurrentTable;
                gvcourse.DataBind();
            }
        }
    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        string[] subPaperCodeList = new string[gvcourse.Rows.Count];
        for (int i = 0; i <= gvcourse.Rows.Count - 1; i++)
        {
            int masterPaperId = (int)gvcourse.DataKeys[i].Value;
            string subPaperCode = (string)fn.singlevalue(" select SubPaperCode from MasterCoursePaper a  inner join CoursePapers b on a.Id=b.MasterPaperId where a.Id=" + masterPaperId + " and b.StreampartCode='" + Semester.SelectedValue + "'");
            if (subPaperCode == null)
            {
                string newCourseCode = " INSERT INTO COURSEPAPERS " +
                                        " (MasterPaperId, PaperAbbr, PaperName, L, T, P, Credit, FullMarks, PassMarks, " +
                                        " PaperTypeCode, StreamPart, StreamPartCode,StreamCode, SubPaperCode, SubCode) " +
                                        " SELECT Id, CONVERT(varchar, LEFT(SUBSTRING('" + Semester.SelectedItem.Text.Trim() + "', PATINDEX('%[0-9]%', '" + Semester.SelectedItem.Text.Trim() + "'), 8000), PATINDEX('%[^0-9]%', SUBSTRING('" + Semester.SelectedItem.Text.Trim() + "', PATINDEX('%[0-9]%', '" + Semester.SelectedItem.Text.Trim() + "'), 8000) + 'X') - 1))+ CourseCode, Title, L, T, P, Credit, FullMarks, PassMarks, PaperTypeCode, '" + Semester.SelectedItem.Text.Trim() + "','" + Semester.SelectedValue + "','" + StreamCode.SelectedValue + "',(select max(Subpapercode)+1 from CoursePapers),(select SubCode from Subject where streamCode='" + StreamCode.SelectedValue + "') " +
                                        " FROM MasterCoursePaper AS a WHERE (Id = " + masterPaperId.ToString() + ")";
                int result = fn.InsertUpdateDelete(newCourseCode);
           //manish --- 
                if (result == -1000)
                {
                    result = fn.InsertUpdateDelete("Update COURSEPAPERS SET MasterPaperId = '" + masterPaperId.ToString() + "' WHERE PaperAbbr =  CONVERT(varchar, LEFT(SUBSTRING('" + Semester.SelectedItem.Text.Trim() + "', PATINDEX('%[0-9]%', '" + Semester.SelectedItem.Text.Trim() + "'), 8000), PATINDEX('%[^0-9]%', SUBSTRING('" + Semester.SelectedItem.Text.Trim() + "', PATINDEX('%[0-9]%', '" + Semester.SelectedItem.Text.Trim() + "'), 8000) + 'X') - 1))+ (select CourseCode from MasterCoursePaper where Id='" + masterPaperId.ToString() + "')");
                }
                subPaperCode = (string)fn.singlevalue(" select SubPaperCode from MasterCoursePaper a  inner join CoursePapers b on a.Id=b.MasterPaperId where a.Id=" + masterPaperId.ToString() + " and b.StreampartCode='" + Semester.SelectedValue + "'");
                string paperTypeCode = (string)fn.singlevalue("select PaperTypeCode from CoursePapers where SubpaperCode='" + subPaperCode + "'");
                if (paperTypeCode == "04")
                {
                    string practicalPapers = " INSERT INTO PRACTICALPAPERS (FullMarks, PassMarks, Credit,SubPaperCode) " +
                                            " SELECT    Credit, FullMarks, '00','" + subPaperCode + "' FROM         MasterCoursePaper  ";
                    result = fn.InsertUpdateDelete(practicalPapers);
                }
            }

            subPaperCodeList[i] = subPaperCode;
        }
        string examsession = month1.SelectedItem.ToString() + "-" + month2.SelectedItem.ToString() + "_" + Year3.SelectedItem.ToString();
        string courseCodeOffered = string.Empty;
        int resultouter = 0;
        int count = (int)fn.singlevalue(" select Count(*) from CourseCodeOffered where SplCode='" + drpsplType.SelectedValue + "' and StreamPartCode='" + Semester.SelectedValue + "'  and ExamSession='" + examsession + "'");
        if (count == 0)
        {
            courseCodeOffered = " INSERT INTO CourseCodeOffered ( ExamSession, StreamPartCode, Splcode,   ModifiedDate, UserId) " +
                                         " VALUES     ('" + examsession + "','" + Semester.SelectedValue + "','" + drpsplType.SelectedValue + "',getdate(),'" + Session["UserId"].ToString() + "') ";
            resultouter = fn.InsertUpdateDelete(courseCodeOffered);
        }

        int courseCodeOfferedId = (int)fn.singlevalue(" select Id from CourseCodeOffered where SplCode='" + drpsplType.SelectedValue + "' and StreamPartCode='" + Semester.SelectedValue + "'  and ExamSession='" + examsession + "'");


        string restInactive = " INSERT INTO CourseCodeOfferedDetailHistory (SubPaperCode,  OfferedTypeId,CourseCodeOfferedId,  DeletedDate, UserId) SELECT     SubPaperCode,  OfferedTypeId, CourseCodeOfferedId, GetDate(), '" + Session["UserId"].ToString() + "' FROM         CourseCodeOfferedDetail where OfferedTypeId=1 and CourseCodeOfferedId=" + courseCodeOfferedId.ToString() + "; " +
                                " Delete FROM CourseCodeOfferedDetail   where OfferedTypeId=1 and CourseCodeOfferedId=" + courseCodeOfferedId.ToString() + "; ";
        resultouter = fn.InsertUpdateDelete(restInactive);
        foreach (string insertSubPaper in subPaperCodeList)
        {

            string insertNew = " INSERT INTO CourseCodeOfferedDetail (SubPaperCode,  OfferedTypeId, CourseCodeOfferedId,  ModifiedDate, UserId) VALUES  " +
                              " ('" + insertSubPaper + "',1," + courseCodeOfferedId.ToString() + ",getdate(),'" + Session["UserId"].ToString() + "') ";
            resultouter = fn.InsertUpdateDelete(insertNew);
        }
        LblMsg.Text = "Saved Successfully";
    }
    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        GetCoursePaperFromDropDown();
    }
    protected void btnDashBoard_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Home.aspx");
    }
    protected void lnkCoursePaperAdd_Click(object sender, EventArgs e)
    {
        popupcontent.Visible = true;
    }

    private void GetCoursePaperFromDropDown()
    {
        string txtSearchText = txtSearch.Text;
        string subPaperCode = (string)fn.singlevalue("Select Convert(varchar,Id) From MasterCoursePaper Where CourseCode ='" + txtSearchText + "'");
        if (subPaperCode == string.Empty)
        {
            drpdlcoursecode.SelectedValue = "0";
            CourseSelectionChanged();
        }
        else
        {
            drpdlcoursecode.SelectedValue = subPaperCode;
            CourseSelectionChanged();

        }
    }
    protected void BtnAdd_Click(object sender, ImageClickEventArgs e)
    {
        popupcontent.Visible = true;

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {

        char firstChar = char.Parse(txtPaperCode.Text.Substring(0, 1));
        if (Char.IsNumber(firstChar))
        {
            lblMsgCourse.Text = "Please Enter Valid Course Code";
            return;
        }
        if (ddlDepartment.SelectedValue == "0")
        {
            lblMsgCourse.Text = "Please Select any Department";
            return;
        }
        int courseCodeCheck = (int)fn.singlevalue("Select Count(*) From MasterCoursePaper Where CourseCode ='" + txtPaperCode.Text + "'");
        if (courseCodeCheck != 0)
        {
            lblMsgCourse.Text = "Course Code already exists in the database";
            return;
        }
        if (!txtPaperCode.Text.Contains(ddlDepartment.SelectedValue))
        {
            lblMsgCourse.Text = "Either of Department or CourseCode Entered is not Correct";
            return;
        }
        string practFullmarks = string.Empty;
        if (PaperTypeCode.SelectedValue == "04")
        {
            practFullmarks = txtPractFullMarks.Text;
        }
        string insertQuery = " INSERT INTO MasterCoursePaper " +
                              " (CourseCode, Title, L, T, P, Credit, FullMarks, PassMarks, PaperTypeCode, PracticalFullMarks, DepartmentId) " +
                              " VALUES     ('" + txtPaperCode.Text + "','" + PaperName.Text + "','" + L.Text + "','" + T.Text + "','" + P.Text + "','" + txtCredit.Text + "','" + FullMarks.Text + "','" + PassMarks.Text + "','" + PaperTypeCode.SelectedValue + "','" + practFullmarks + "','" + ddlDepartment.SelectedValue + "') ";
        fn.InsertUpdateDelete(insertQuery);
        drpdlcoursecode.Items.Clear();
        DataSet dscourse = fn.SelectDataset("select Id,CourseCode from MasterCoursePaper");
        drpdlcoursecode.DataSource = dscourse.Tables[0];
        drpdlcoursecode.DataTextField = "CourseCode";
        drpdlcoursecode.DataValueField = "Id";
        drpdlcoursecode.DataBind();
        drpdlcoursecode.Items.Insert(0, new ListItem("--Select--", "00"));
        ResetControlInsidePopup();
        popupcontent.Visible = false;
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        ResetControlInsidePopup();
        popupcontent.Visible = false;
    }
    protected void ResetControlInsidePopup()
    {
        txtPaperCode.Text = "";
        PaperName.Text = "";
        L.Text = "";
        T.Text = "";
        P.Text = "";
        txtCredit.Text = "";
        FullMarks.Text = "";
        PassMarks.Text = "";
        txtPractFullMarks.Text = "";
        ddlDepartment.SelectedValue = "0";
    }
}
