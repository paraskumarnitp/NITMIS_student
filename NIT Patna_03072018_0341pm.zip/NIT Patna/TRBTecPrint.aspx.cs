using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;

public partial class TRBTecPrint : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    DataTable dttrbtec;
    DataTable dttrbtec2;
    DataTable dttrbtec3;
    DataTable dttrbtec4;
    DataTable dttrbtec5;
    DataTable dttrpaper;
   
    DSTRBtec dstrrecord = new DSTRBtec();
    DSTRBtec2 dstrrecord2 = new DSTRBtec2();
    DSTRBtec3 dstrrecord3 = new DSTRBtec3();
    DSTRBtec4 dstrrecord4 = new DSTRBtec4();
    DSTRBtec5 dstrrecord5 = new DSTRBtec5();
    string streamcode, streampartcode, examyear, Program, semester, examsession, Splcode, spart, checknb, qrystr, qrystrMtec;
    int dept_wise = 0,grp_wise=0;
    ReportDocument crystalReport = new ReportDocument();
    ReportDocument CrystalReport1 = new ReportDocument();
    ReportDocument CrystalReport2 = new ReportDocument();
    ReportDocument CrystalReport3 = new ReportDocument();
    ReportDocument CrystalReport4 = new ReportDocument();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "2") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
        }
        streamcode = Request.QueryString["sc"];
        streampartcode = Request.QueryString["spc"];
        examyear = Request.QueryString["ey"];
        Program = Request.QueryString["prg"];
        semester = Request.QueryString["sem"];
        examsession = Request.QueryString["exses"];
        Splcode = Request.QueryString["splc"];
        spart = Request.QueryString["spart"];
        checknb = Request.QueryString["grp"];
        if (checknb == "NB")
        {
            qrystr = " TRBTec.ExamType IN ('N','B')";
            qrystrMtec = "TRMTec.ExamType IN ('N','B')";
        }
        else if (checknb == "R")
        {
            qrystr = " TRBTec.ExamType NOT IN ('N','B')";
            qrystrMtec = "TRMTec.ExamType NOT IN ('N','B')";
        }

        UnivService.Service1 NICService = new UnivService.Service1();
        string StreamPart_temp = NICService.GetNewCode("select streampart from streampart where streampartcode='" + streampartcode + "'");

        if (StreamPart_temp == "sem 1-A")
        {
            dept_wise = 0; grp_wise = 1;
            
        }
        else if (StreamPart_temp == "sem 1-B")
        {
            dept_wise = 0; grp_wise = 2;
        }
        else if (StreamPart_temp == "sem 2-A")
        {
            dept_wise = 0; grp_wise = 3;
        }
        else if (StreamPart_temp == "sem 2-B")
        {
            dept_wise = 0; grp_wise = 4;
        }
        else 
        {
            dept_wise = 1; grp_wise = 0;
        }


        // ReportDocument crystalReport = new ReportDocument();
        
        filldatatable();
        
        //crystalReport.Load(Server.MapPath("~/Report/TrbtecPrint.rpt"));

        if (streamcode == "21" || streamcode == "23" || streamcode == "26" || streamcode == "28" || streamcode == "29" || streamcode == "30" || streamcode == "31" || streamcode == "32" || streamcode == "33" || streamcode == "35" || streamcode == "36" || streamcode == "37" || streamcode == "38" || streamcode == "39" || streamcode == "40" || streamcode == "41" || streamcode == "42")
        {
            filltrpapers_Mtec();
        }
        else
        {
            filltrpapers();
        }
        
        int i = 0;
        crystalReport.Load(Server.MapPath("~/Report/Rpttr1.rpt"));
        dstrrecord.Tables[0].Merge(dttrbtec);
        dstrrecord.Tables[1].Merge(dttrpaper);
        crystalReport.SetDataSource(dstrrecord);
        CrystalReportViewer1.ReportSource = crystalReport;
        CrystalReportViewer1.ShowLastPage();
        i = CrystalReportViewer1.ViewInfo.LastPageNumber;
        CrystalReportViewer1.ShowFirstPage();


        CrystalReport1.Load(Server.MapPath("~/Report/Rpttr2.rpt"));
        dstrrecord2.Tables[0].Merge(dttrbtec2);
        dstrrecord2.Tables[1].Merge(dttrpaper);
        CrystalReport1.SetDataSource(dstrrecord2);
        CrystalReportViewer2.ReportSource = CrystalReport1;
        CrystalReport1.SetParameterValue(0, i);
        CrystalReportViewer2.ShowLastPage();
        i = CrystalReportViewer2.ViewInfo.LastPageNumber + i;
        CrystalReportViewer2.ShowFirstPage();


        CrystalReport2.Load(Server.MapPath("~/Report/Rpttr3.rpt"));
        dstrrecord3.Tables[0].Merge(dttrbtec3);
        dstrrecord3.Tables[1].Merge(dttrpaper);
        CrystalReport2.SetDataSource(dstrrecord3);
        CrystalReportViewer3.ReportSource = CrystalReport2;
        CrystalReport2.SetParameterValue(0, i);
        CrystalReportViewer3.ShowLastPage();
        i = CrystalReportViewer3.ViewInfo.LastPageNumber + i;
        CrystalReportViewer3.ShowFirstPage();


        CrystalReport3.Load(Server.MapPath("~/Report/Rpttr4.rpt"));
        dstrrecord4.Tables[0].Merge(dttrbtec4);
        dstrrecord4.Tables[1].Merge(dttrpaper);
        CrystalReport3.SetDataSource(dstrrecord4);
        CrystalReportViewer4.ReportSource = CrystalReport3;
        CrystalReport3.SetParameterValue(0, i);
        CrystalReportViewer4.ShowLastPage();
        i = CrystalReportViewer4.ViewInfo.LastPageNumber + i;
        CrystalReportViewer4.ShowFirstPage();

        CrystalReport4.Load(Server.MapPath("~/Report/Rpttr5.rpt"));
        dstrrecord5.Tables[0].Merge(dttrbtec5);
        dstrrecord5.Tables[1].Merge(dttrpaper);
        CrystalReport4.SetDataSource(dstrrecord5);
        CrystalReportViewer5.ReportSource = CrystalReport4;
        CrystalReport4.SetParameterValue(0, i);
    }
    protected void Page_Unload(object sender, EventArgs e)
    {
        if (crystalReport != null)
        {
            crystalReport.Close();
            crystalReport.Dispose();
        }
        if (CrystalReport1 != null)
        {
            CrystalReport1.Close();
            CrystalReport1.Dispose();
        }
        if (CrystalReport2 != null)
        {
            CrystalReport2.Close();
            CrystalReport2.Dispose();
        }
        if (CrystalReport3 != null)
        {
            CrystalReport3.Close();
            CrystalReport3.Dispose();
        }
        if (CrystalReport4 != null)
        {
            CrystalReport4.Close();
            CrystalReport4.Dispose();
        }
    }
    DataSet dsstudentrecord = new DataSet();
    DataSet dsstudsubpaer = new DataSet();
    DataRow dr;
    DataRow[] dr1;
    string papercode;
    private void filldatatable()
    {
        dttrbtec = new DataTable();
        dttrbtec.Columns.Add("RollNo", typeof(string));
        dttrbtec.Columns.Add("Applicantname", typeof(string));
        dttrbtec.Columns.Add("Cpaper1", typeof(string));
        dttrbtec.Columns.Add("FullMarks1", typeof(string));

        dttrbtec.Columns.Add("PRFMARKS1", typeof(string));
        dttrbtec.Columns.Add("LTP1", typeof(string));

        dttrbtec.Columns.Add("Credit1", typeof(string));
        dttrbtec.Columns.Add("CA_MSM_TH1", typeof(string));
        dttrbtec.Columns.Add("TH_ESM1", typeof(string));
        dttrbtec.Columns.Add("TH_PMO1", typeof(string));
        dttrbtec.Columns.Add("CA_MSM_PT1", typeof(string));
        dttrbtec.Columns.Add("PT_ESM1", typeof(string));
        dttrbtec.Columns.Add("PT_PMO1", typeof(string));
        dttrbtec.Columns.Add("Total_PMO1", typeof(string));
        dttrbtec.Columns.Add("Grade_Point1", typeof(string));
        dttrbtec.Columns.Add("ER_CREDIT1", typeof(string));
        dttrbtec.Columns.Add("Grade1", typeof(string));
        dttrbtec.Columns.Add("Cpaper2", typeof(string));
        dttrbtec.Columns.Add("FullMarks2", typeof(string));

        dttrbtec.Columns.Add("PRFMARKS2", typeof(string));
        dttrbtec.Columns.Add("LTP2", typeof(string));

        dttrbtec.Columns.Add("Credit2", typeof(string));
        dttrbtec.Columns.Add("CA_MSM_TH2", typeof(string));
        dttrbtec.Columns.Add("TH_ESM2", typeof(string));
        dttrbtec.Columns.Add("TH_PMO2", typeof(string));
        dttrbtec.Columns.Add("CA_MSM_PT2", typeof(string));
        dttrbtec.Columns.Add("PT_ESM2", typeof(string));
        dttrbtec.Columns.Add("PT_PMO2", typeof(string));
        dttrbtec.Columns.Add("Total_PMO2", typeof(string));
        dttrbtec.Columns.Add("Grade_Point2", typeof(string));
        dttrbtec.Columns.Add("ER_CREDIT2", typeof(string));
        dttrbtec.Columns.Add("Grade2", typeof(string));
        dttrbtec.Columns.Add("Cpaper3", typeof(string));
        dttrbtec.Columns.Add("FullMarks3", typeof(string));

        dttrbtec.Columns.Add("PRFMARKS3", typeof(string));
        dttrbtec.Columns.Add("LTP3", typeof(string));

        dttrbtec.Columns.Add("Credit3", typeof(string));
        dttrbtec.Columns.Add("CA_MSM_TH3", typeof(string));
        dttrbtec.Columns.Add("TH_ESM3", typeof(string));
        dttrbtec.Columns.Add("TH_PMO3", typeof(string));
        dttrbtec.Columns.Add("CA_MSM_PT3", typeof(string));
        dttrbtec.Columns.Add("PT_ESM3", typeof(string));
        dttrbtec.Columns.Add("PT_PMO3", typeof(string));
        dttrbtec.Columns.Add("Total_PMO3", typeof(string));
        dttrbtec.Columns.Add("Grade_Point3", typeof(string));
        dttrbtec.Columns.Add("ER_CREDIT3", typeof(string));
        dttrbtec.Columns.Add("Grade3", typeof(string));
        dttrbtec.Columns.Add("Program", typeof(string));
        dttrbtec.Columns.Add("Semester", typeof(string));
        dttrbtec.Columns.Add("ExamSession", typeof(string));

        dttrbtec2 = new DataTable();
        dttrbtec2.Columns.Add("RollNo", typeof(string));
        dttrbtec2.Columns.Add("Applicantname", typeof(string));
        dttrbtec2.Columns.Add("Cpaper4", typeof(string));
        dttrbtec2.Columns.Add("FullMarks4", typeof(string));

        dttrbtec2.Columns.Add("PRFMARKS4", typeof(string));
        dttrbtec2.Columns.Add("LTP4", typeof(string));

        dttrbtec2.Columns.Add("Credit4", typeof(string));
        dttrbtec2.Columns.Add("CA_MSM_TH4", typeof(string));
        dttrbtec2.Columns.Add("TH_ESM4", typeof(string));
        dttrbtec2.Columns.Add("TH_PMO4", typeof(string));
        dttrbtec2.Columns.Add("CA_MSM_PT4", typeof(string));
        dttrbtec2.Columns.Add("PT_ESM4", typeof(string));
        dttrbtec2.Columns.Add("PT_PMO4", typeof(string));
        dttrbtec2.Columns.Add("Total_PMO4", typeof(string));
        dttrbtec2.Columns.Add("Grade_Point4", typeof(string));
        dttrbtec2.Columns.Add("ER_CREDIT4", typeof(string));
        dttrbtec2.Columns.Add("Grade4", typeof(string));
        dttrbtec2.Columns.Add("Cpaper5", typeof(string));
        dttrbtec2.Columns.Add("FullMarks5", typeof(string));

        dttrbtec2.Columns.Add("PRFMARKS5", typeof(string));
        dttrbtec2.Columns.Add("LTP5", typeof(string));

        dttrbtec2.Columns.Add("Credit5", typeof(string));
        dttrbtec2.Columns.Add("CA_MSM_TH5", typeof(string));
        dttrbtec2.Columns.Add("TH_ESM5", typeof(string));
        dttrbtec2.Columns.Add("TH_PMO5", typeof(string));
        dttrbtec2.Columns.Add("CA_MSM_PT5", typeof(string));
        dttrbtec2.Columns.Add("PT_ESM5", typeof(string));
        dttrbtec2.Columns.Add("PT_PMO5", typeof(string));
        dttrbtec2.Columns.Add("Total_PMO5", typeof(string));
        dttrbtec2.Columns.Add("Grade_Point5", typeof(string));
        dttrbtec2.Columns.Add("ER_CREDIT5", typeof(string));
        dttrbtec2.Columns.Add("Grade5", typeof(string));
        dttrbtec2.Columns.Add("Cpaper6", typeof(string));
        dttrbtec2.Columns.Add("FullMarks6", typeof(string));

        dttrbtec2.Columns.Add("PRFMARKS6", typeof(string));
        dttrbtec2.Columns.Add("LTP6", typeof(string));

        dttrbtec2.Columns.Add("Credit6", typeof(string));
        dttrbtec2.Columns.Add("CA_MSM_TH6", typeof(string));
        dttrbtec2.Columns.Add("TH_ESM6", typeof(string));
        dttrbtec2.Columns.Add("TH_PMO6", typeof(string));
        dttrbtec2.Columns.Add("CA_MSM_PT6", typeof(string));
        dttrbtec2.Columns.Add("PT_ESM6", typeof(string));
        dttrbtec2.Columns.Add("PT_PMO6", typeof(string));
        dttrbtec2.Columns.Add("Total_PMO6", typeof(string));
        dttrbtec2.Columns.Add("Grade_Point6", typeof(string));
        dttrbtec2.Columns.Add("ER_CREDIT6", typeof(string));
        dttrbtec2.Columns.Add("Grade6", typeof(string));
        dttrbtec2.Columns.Add("Program", typeof(string));
        dttrbtec2.Columns.Add("Semester", typeof(string));
        dttrbtec2.Columns.Add("ExamSession", typeof(string));
        

        dttrbtec3 = new DataTable();
        dttrbtec3.Columns.Add("RollNo", typeof(string));
        dttrbtec3.Columns.Add("Applicantname", typeof(string));
        dttrbtec3.Columns.Add("Cpaper7", typeof(string));
        dttrbtec3.Columns.Add("FullMarks7", typeof(string));

        dttrbtec3.Columns.Add("PRFMARKS7", typeof(string));
        dttrbtec3.Columns.Add("LTP7", typeof(string));

        dttrbtec3.Columns.Add("Credit7", typeof(string));
        dttrbtec3.Columns.Add("CA_MSM_TH7", typeof(string));
        dttrbtec3.Columns.Add("TH_ESM7", typeof(string));
        dttrbtec3.Columns.Add("TH_PMO7", typeof(string));
        dttrbtec3.Columns.Add("CA_MSM_PT7", typeof(string));
        dttrbtec3.Columns.Add("PT_ESM7", typeof(string));
        dttrbtec3.Columns.Add("PT_PMO7", typeof(string));
        dttrbtec3.Columns.Add("Total_PMO7", typeof(string));
        dttrbtec3.Columns.Add("Grade_Point7", typeof(string));
        dttrbtec3.Columns.Add("ER_CREDIT7", typeof(string));
        dttrbtec3.Columns.Add("Grade7", typeof(string));
        dttrbtec3.Columns.Add("Cpaper8", typeof(string));
        dttrbtec3.Columns.Add("FullMarks8", typeof(string));

        dttrbtec3.Columns.Add("PRFMARKS8", typeof(string));
        dttrbtec3.Columns.Add("LTP8", typeof(string));

        dttrbtec3.Columns.Add("Credit8", typeof(string));
        dttrbtec3.Columns.Add("CA_MSM_TH8", typeof(string));
        dttrbtec3.Columns.Add("TH_ESM8", typeof(string));
        dttrbtec3.Columns.Add("TH_PMO8", typeof(string));
        dttrbtec3.Columns.Add("CA_MSM_PT8", typeof(string));
        dttrbtec3.Columns.Add("PT_ESM8", typeof(string));
        dttrbtec3.Columns.Add("PT_PMO8", typeof(string));
        dttrbtec3.Columns.Add("Total_PMO8", typeof(string));
        dttrbtec3.Columns.Add("Grade_Point8", typeof(string));
        dttrbtec3.Columns.Add("ER_CREDIT8", typeof(string));
        dttrbtec3.Columns.Add("Grade8", typeof(string));
        dttrbtec3.Columns.Add("Cpaper9", typeof(string));
        dttrbtec3.Columns.Add("FullMarks9", typeof(string));

        dttrbtec3.Columns.Add("PRFMARKS9", typeof(string));
        dttrbtec3.Columns.Add("LTP9", typeof(string));

        dttrbtec3.Columns.Add("Credit9", typeof(string));
        dttrbtec3.Columns.Add("CA_MSM_TH9", typeof(string));
        dttrbtec3.Columns.Add("TH_ESM9", typeof(string));
        dttrbtec3.Columns.Add("TH_PMO9", typeof(string));
        dttrbtec3.Columns.Add("CA_MSM_PT9", typeof(string));
        dttrbtec3.Columns.Add("PT_ESM9", typeof(string));
        dttrbtec3.Columns.Add("PT_PMO9", typeof(string));
        dttrbtec3.Columns.Add("Total_PMO9", typeof(string));
        dttrbtec3.Columns.Add("Grade_Point9", typeof(string));
        dttrbtec3.Columns.Add("ER_CREDIT9", typeof(string));
        dttrbtec3.Columns.Add("Grade9", typeof(string));
        dttrbtec3.Columns.Add("Program", typeof(string));
        dttrbtec3.Columns.Add("Semester", typeof(string));
        dttrbtec3.Columns.Add("ExamSession", typeof(string));
        
        dttrbtec4 = new DataTable();
        dttrbtec4.Columns.Add("RollNo", typeof(string));
        dttrbtec4.Columns.Add("Applicantname", typeof(string));
        dttrbtec4.Columns.Add("Cpaper10", typeof(string));
        dttrbtec4.Columns.Add("FullMarks10", typeof(string));

        dttrbtec4.Columns.Add("PRFMARKS10", typeof(string));
        dttrbtec4.Columns.Add("LTP10", typeof(string));

        dttrbtec4.Columns.Add("Credit10", typeof(string));
        dttrbtec4.Columns.Add("CA_MSM_TH10", typeof(string));
        dttrbtec4.Columns.Add("TH_ESM10", typeof(string));
        dttrbtec4.Columns.Add("TH_PMO10", typeof(string));
        dttrbtec4.Columns.Add("CA_MSM_PT10", typeof(string));
        dttrbtec4.Columns.Add("PT_ESM10", typeof(string));
        dttrbtec4.Columns.Add("PT_PMO10", typeof(string));
        dttrbtec4.Columns.Add("Total_PMO10", typeof(string));
        dttrbtec4.Columns.Add("Grade_Point10", typeof(string));
        dttrbtec4.Columns.Add("ER_CREDIT10", typeof(string));
        dttrbtec4.Columns.Add("Grade10", typeof(string));
        dttrbtec4.Columns.Add("Cpaper11", typeof(string));
        dttrbtec4.Columns.Add("FullMarks11", typeof(string));

        dttrbtec4.Columns.Add("PRFMARKS11", typeof(string));
        dttrbtec4.Columns.Add("LTP11", typeof(string));

        dttrbtec4.Columns.Add("Credit11", typeof(string));
        dttrbtec4.Columns.Add("CA_MSM_TH11", typeof(string));
        dttrbtec4.Columns.Add("TH_ESM11", typeof(string));
        dttrbtec4.Columns.Add("TH_PMO11", typeof(string));
        dttrbtec4.Columns.Add("CA_MSM_PT11", typeof(string));
        dttrbtec4.Columns.Add("PT_ESM11", typeof(string));
        dttrbtec4.Columns.Add("PT_PMO11", typeof(string));
        dttrbtec4.Columns.Add("Total_PMO11", typeof(string));
        dttrbtec4.Columns.Add("Grade_Point11", typeof(string));
        dttrbtec4.Columns.Add("ER_CREDIT11", typeof(string));
        dttrbtec4.Columns.Add("Grade11", typeof(string));
        dttrbtec4.Columns.Add("Cpaper12", typeof(string));
        dttrbtec4.Columns.Add("FullMarks12", typeof(string));

        dttrbtec4.Columns.Add("PRFMARKS12", typeof(string));
        dttrbtec4.Columns.Add("LTP12", typeof(string));

        dttrbtec4.Columns.Add("Credit12", typeof(string));
        dttrbtec4.Columns.Add("CA_MSM_TH12", typeof(string));
        dttrbtec4.Columns.Add("TH_ESM12", typeof(string));
        dttrbtec4.Columns.Add("TH_PMO12", typeof(string));
        dttrbtec4.Columns.Add("CA_MSM_PT12", typeof(string));
        dttrbtec4.Columns.Add("PT_ESM12", typeof(string));
        dttrbtec4.Columns.Add("PT_PMO12", typeof(string));
        dttrbtec4.Columns.Add("Total_PMO12", typeof(string));
        dttrbtec4.Columns.Add("Grade_Point12", typeof(string));
        dttrbtec4.Columns.Add("ER_CREDIT12", typeof(string));
        dttrbtec4.Columns.Add("Grade12", typeof(string));
        dttrbtec4.Columns.Add("Program", typeof(string));
        dttrbtec4.Columns.Add("Semester", typeof(string));
        dttrbtec4.Columns.Add("ExamSession", typeof(string));

        dttrbtec5 = new DataTable();
        dttrbtec5.Columns.Add("RollNo", typeof(string));
        dttrbtec5.Columns.Add("Applicantname", typeof(string));
        dttrbtec5.Columns.Add("Cpaper13", typeof(string));
        dttrbtec5.Columns.Add("FullMarks13", typeof(string));

        dttrbtec5.Columns.Add("PRFMARKS13", typeof(string));
        dttrbtec5.Columns.Add("LTP13", typeof(string));

        dttrbtec5.Columns.Add("Credit13", typeof(string));
        dttrbtec5.Columns.Add("CA_MSM_TH13", typeof(string));
        dttrbtec5.Columns.Add("TH_ESM13", typeof(string));
        dttrbtec5.Columns.Add("TH_PMO13", typeof(string));
        dttrbtec5.Columns.Add("CA_MSM_PT13", typeof(string));
        dttrbtec5.Columns.Add("PT_ESM13", typeof(string));
        dttrbtec5.Columns.Add("PT_PMO13", typeof(string));
        dttrbtec5.Columns.Add("Total_PMO13", typeof(string));
        dttrbtec5.Columns.Add("Grade_Point13", typeof(string));
        dttrbtec5.Columns.Add("ER_CREDIT13", typeof(string));
        dttrbtec5.Columns.Add("Grade13", typeof(string));
        dttrbtec5.Columns.Add("Cpaper14", typeof(string));
        dttrbtec5.Columns.Add("FullMarks14", typeof(string));

        dttrbtec5.Columns.Add("PRFMARKS14", typeof(string));
        dttrbtec5.Columns.Add("LTP14", typeof(string));

        dttrbtec5.Columns.Add("Credit14", typeof(string));
        dttrbtec5.Columns.Add("CA_MSM_TH14", typeof(string));
        dttrbtec5.Columns.Add("TH_ESM14", typeof(string));
        dttrbtec5.Columns.Add("TH_PMO14", typeof(string));
        dttrbtec5.Columns.Add("CA_MSM_PT14", typeof(string));
        dttrbtec5.Columns.Add("PT_ESM14", typeof(string));
        dttrbtec5.Columns.Add("PT_PMO14", typeof(string));
        dttrbtec5.Columns.Add("Total_PMO14", typeof(string));
        dttrbtec5.Columns.Add("Grade_Point14", typeof(string));
        dttrbtec5.Columns.Add("ER_CREDIT14", typeof(string));
        dttrbtec5.Columns.Add("Grade14", typeof(string));
        dttrbtec5.Columns.Add("Cpaper15", typeof(string));
        dttrbtec5.Columns.Add("FullMarks15", typeof(string));

        dttrbtec5.Columns.Add("PRFMARKS15", typeof(string));
        dttrbtec5.Columns.Add("LTP15", typeof(string));

        dttrbtec5.Columns.Add("Credit15", typeof(string));
        dttrbtec5.Columns.Add("CA_MSM_TH15", typeof(string));
        dttrbtec5.Columns.Add("TH_ESM15", typeof(string));
        dttrbtec5.Columns.Add("TH_PMO15", typeof(string));
        dttrbtec5.Columns.Add("CA_MSM_PT15", typeof(string));
        dttrbtec5.Columns.Add("PT_ESM15", typeof(string));
        dttrbtec5.Columns.Add("PT_PMO15", typeof(string));
        dttrbtec5.Columns.Add("Total_PMO15", typeof(string));
        dttrbtec5.Columns.Add("Grade_Point15", typeof(string));
        dttrbtec5.Columns.Add("ER_CREDIT15", typeof(string));
        dttrbtec5.Columns.Add("Grade15", typeof(string));
        dttrbtec5.Columns.Add("Program", typeof(string));
        dttrbtec5.Columns.Add("Semester", typeof(string));
        dttrbtec5.Columns.Add("ExamSession", typeof(string));
       
        dttrbtec.Rows.Clear();
        
        if (dept_wise == 1)
        {
            if (streamcode == "21" || streamcode == "23" || streamcode == "26" || streamcode == "28" || streamcode == "29" || streamcode == "30" || streamcode == "31" || streamcode == "32" || streamcode == "33" || streamcode == "35" || streamcode == "36" || streamcode == "37" || streamcode == "38" || streamcode == "39" || streamcode == "40" || streamcode == "41" || streamcode == "42")
            {
                withoutgroup_Mtec();
            }
            else 
            {
                withoutgroup_Btec();
            }
        }
        else
        {
            if (grp_wise == 1)
                dsstudentrecord = fnrev.SelectDataset("SELECT DISTINCT UnivRollNo,EName fROM TRBTec WHERE ExamSession='" + examsession + "' AND StreamPart in ('11','19','27','35','43','51') AND + " + qrystr + " ");
            else if (grp_wise == 2)
                dsstudentrecord = fnrev.SelectDataset("SELECT DISTINCT UnivRollNo,EName fROM TRBTec WHERE ExamSession='" + examsession + "' AND (StreamPart between 137 and 142) AND + " + qrystr + " ");
            else if (grp_wise == 3)
                dsstudentrecord = fnrev.SelectDataset("SELECT DISTINCT UnivRollNo,EName fROM TRBTec WHERE ExamSession='" + examsession + "' AND StreamPart in ('12','20','28','36','44','52') AND + " + qrystr + " ");
            else if (grp_wise == 4)
                dsstudentrecord = fnrev.SelectDataset("SELECT DISTINCT UnivRollNo,EName fROM TRBTec WHERE ExamSession='" + examsession + "' AND (StreamPart between 143 and 148) AND + " + qrystr + " ");
            //}
            withgroup();
        
        }
    }

    private void withoutgroup_Mtec()
    {
        dsstudentrecord = fnrev.SelectDataset("SELECT DISTINCT UnivRollNo,EName fROM TRMTec WHERE ExamSession = '" + examsession + "' AND + " + qrystrMtec + " " +
            " AND SplCode = '" + Splcode + "' AND StreamPart = '" + streampartcode + "'");
        DataSet dspapers = fnrev.SelectDataset("SELECT DISTINCT TRMTec.SubPaperCode, COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper " +
                  " FROM TRMTec INNER JOIN COURSEPAPERS ON TRMTec.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN " +
                  " PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE TRMTec.StreamCode = '" + streamcode + "' " +
                  " AND (TRMTec.StreamPart = '" + streampartcode + "') AND (TRMTec.SplCode = '" + Splcode + "') AND (TRMTec.ExamSession = '" + examsession + "') ORDER BY trpaper");
        
        for (int g = 0; g <= dsstudentrecord.Tables[0].Rows.Count - 1; g++)
        {

            dsstudsubpaer = fnrev.SelectDataset("SELECT COURSEPAPERS.SubPaperCode,COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper, TRMTec.CA_MSM_TH, " +
                " TRMTec.TH_ESM, TRMTec.TH_PMO, TRMTec.CA_MSM_PT, TRMTec.PT_ESM, TRMTec.PT_PMO, TRMTec.Total_PMO, TRMTec.Grade_Point, TRMTec.ER_CREDIT, " +
                " TRMTec.Grade, COURSEPAPERS.FullMarks, COURSEPAPERS.Credit, PRACTICALPAPERS.FullMarks AS PRFMARKS, " +
                " COURSEPAPERS.L + ' - ' + COURSEPAPERS.T + ' - ' + COURSEPAPERS.P AS LTP,COURSEPAPERS.PaperTypeCode FROM TRMTec INNER JOIN " +
                " COURSEPAPERS ON TRMTec.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN PRACTICALPAPERS ON " +
                " COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE " +
                 " UnivRollNo ='" + dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString() + "' AND " +
                 " TRMTec.StreamCode ='" + streamcode + "' AND TRMTec.StreamPart ='" + streampartcode + "'  AND " +
                 " TRMTec.SplCode = '" + Splcode + "' AND " +
                 " TRMTec.ExamSession = '" + examsession + "' ORDER BY trpaper");
            for (int r = 0; r <= dspapers.Tables[0].Rows.Count - 1; r++)
            {

                dr = dttrbtec.NewRow();
                papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                dr[0] = dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString();
                dr[1] = dsstudentrecord.Tables[0].Rows[g]["EName"].ToString();
                if (dr1.Length > 0)
                {
                    dr[2] = dr1[0]["trpaper"].ToString();
                    if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                    {
                        dr[3] = dr1[0]["FullMarks"].ToString();
                        dr[4] = "0";
                    }
                    else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                    {
                        dr[3] = "0";
                        dr[4] = dr1[0]["FullMarks"].ToString();
                    }
                    else
                    {
                        dr[3] = dr1[0]["FullMarks"].ToString();
                        dr[4] = dr1[0]["PRFMARKS"].ToString();
                    }
                    dr[5] = dr1[0]["LTP"].ToString();

                    dr[6] = dr1[0]["Credit"].ToString();
                    dr[7] = dr1[0]["CA_MSM_TH"].ToString();
                    dr[8] = dr1[0]["TH_ESM"].ToString();
                    dr[9] = dr1[0]["TH_PMO"].ToString();
                    dr[10] = dr1[0]["CA_MSM_PT"].ToString();
                    dr[11] = dr1[0]["PT_ESM"].ToString();
                    dr[12] = dr1[0]["PT_PMO"].ToString();
                    dr[13] = dr1[0]["Total_PMO"].ToString();
                    dr[14] = dr1[0]["Grade_Point"].ToString();
                    dr[15] = dr1[0]["ER_CREDIT"].ToString();
                    dr[16] = dr1[0]["Grade"].ToString();
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[17] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[18] = "0";
                            dr[19] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[20] = dr1[0]["LTP"].ToString();

                        dr[21] = dr1[0]["Credit"].ToString();
                        dr[22] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[23] = dr1[0]["TH_ESM"].ToString();
                        dr[24] = dr1[0]["TH_PMO"].ToString();
                        dr[25] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[26] = dr1[0]["PT_ESM"].ToString();
                        dr[27] = dr1[0]["PT_PMO"].ToString();
                        dr[28] = dr1[0]["Total_PMO"].ToString();
                        dr[29] = dr1[0]["Grade_Point"].ToString();
                        dr[30] = dr1[0]["ER_CREDIT"].ToString();
                        dr[31] = dr1[0]["Grade"].ToString();
                    }
                }

                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[32] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[33] = "0";
                            dr[34] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[35] = dr1[0]["LTP"].ToString();

                        dr[36] = dr1[0]["Credit"].ToString();
                        dr[37] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[38] = dr1[0]["TH_ESM"].ToString();
                        dr[39] = dr1[0]["TH_PMO"].ToString();
                        dr[40] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[41] = dr1[0]["PT_ESM"].ToString();
                        dr[42] = dr1[0]["PT_PMO"].ToString();
                        dr[43] = dr1[0]["Total_PMO"].ToString();
                        dr[44] = dr1[0]["Grade_Point"].ToString();
                        dr[45] = dr1[0]["ER_CREDIT"].ToString();
                        dr[46] = dr1[0]["Grade"].ToString();

                    }
                }

                dr[47] = Program;
                dr[48] = semester;
                dr[49] = examsession;
                dttrbtec.Rows.Add(dr);
                r++;
                // add value in dttrbtec2
                dr = dttrbtec2.NewRow();

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    dr[0] = dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString();
                    dr[1] = dsstudentrecord.Tables[0].Rows[g]["EName"].ToString();
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");

                    if (dr1.Length > 0)
                    {
                        dr[2] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[3] = "0";
                            dr[4] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[5] = dr1[0]["LTP"].ToString();

                        dr[6] = dr1[0]["Credit"].ToString();
                        dr[7] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[8] = dr1[0]["TH_ESM"].ToString();
                        dr[9] = dr1[0]["TH_PMO"].ToString();
                        dr[10] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[11] = dr1[0]["PT_ESM"].ToString();
                        dr[12] = dr1[0]["PT_PMO"].ToString();
                        dr[13] = dr1[0]["Total_PMO"].ToString();
                        dr[14] = dr1[0]["Grade_Point"].ToString();
                        dr[15] = dr1[0]["ER_CREDIT"].ToString();
                        dr[16] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[17] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[18] = "0";
                            dr[19] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[20] = dr1[0]["LTP"].ToString();

                        dr[21] = dr1[0]["Credit"].ToString();
                        dr[22] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[23] = dr1[0]["TH_ESM"].ToString();
                        dr[24] = dr1[0]["TH_PMO"].ToString();
                        dr[25] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[26] = dr1[0]["PT_ESM"].ToString();
                        dr[27] = dr1[0]["PT_PMO"].ToString();
                        dr[28] = dr1[0]["Total_PMO"].ToString();
                        dr[29] = dr1[0]["Grade_Point"].ToString();
                        dr[30] = dr1[0]["ER_CREDIT"].ToString();
                        dr[31] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[32] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[33] = "0";
                            dr[34] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[35] = dr1[0]["LTP"].ToString();

                        dr[36] = dr1[0]["Credit"].ToString();
                        dr[37] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[38] = dr1[0]["TH_ESM"].ToString();
                        dr[39] = dr1[0]["TH_PMO"].ToString();
                        dr[40] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[41] = dr1[0]["PT_ESM"].ToString();
                        dr[42] = dr1[0]["PT_PMO"].ToString();
                        dr[43] = dr1[0]["Total_PMO"].ToString();
                        dr[44] = dr1[0]["Grade_Point"].ToString();
                        dr[45] = dr1[0]["ER_CREDIT"].ToString();
                        dr[46] = dr1[0]["Grade"].ToString();

                    }
                }
                dr[47] = Program;
                dr[48] = semester;
                dr[49] = examsession;
                dttrbtec2.Rows.Add(dr);
                r++;

                dr = dttrbtec3.NewRow();

                dr[0] = dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString();
                dr[1] = dsstudentrecord.Tables[0].Rows[g]["EName"].ToString();
                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");

                    if (dr1.Length > 0)
                    {
                        dr[2] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[3] = "0";
                            dr[4] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[5] = dr1[0]["LTP"].ToString();

                        dr[6] = dr1[0]["Credit"].ToString();
                        dr[7] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[8] = dr1[0]["TH_ESM"].ToString();
                        dr[9] = dr1[0]["TH_PMO"].ToString();
                        dr[10] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[11] = dr1[0]["PT_ESM"].ToString();
                        dr[12] = dr1[0]["PT_PMO"].ToString();
                        dr[13] = dr1[0]["Total_PMO"].ToString();
                        dr[14] = dr1[0]["Grade_Point"].ToString();
                        dr[15] = dr1[0]["ER_CREDIT"].ToString();
                        dr[16] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[17] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[18] = "0";
                            dr[19] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[20] = dr1[0]["LTP"].ToString();

                        dr[21] = dr1[0]["Credit"].ToString();
                        dr[22] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[23] = dr1[0]["TH_ESM"].ToString();
                        dr[24] = dr1[0]["TH_PMO"].ToString();
                        dr[25] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[26] = dr1[0]["PT_ESM"].ToString();
                        dr[27] = dr1[0]["PT_PMO"].ToString();
                        dr[28] = dr1[0]["Total_PMO"].ToString();
                        dr[29] = dr1[0]["Grade_Point"].ToString();
                        dr[30] = dr1[0]["ER_CREDIT"].ToString();
                        dr[31] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[32] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[33] = "0";
                            dr[34] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[35] = dr1[0]["LTP"].ToString();

                        dr[36] = dr1[0]["Credit"].ToString();
                        dr[37] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[38] = dr1[0]["TH_ESM"].ToString();
                        dr[39] = dr1[0]["TH_PMO"].ToString();
                        dr[40] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[41] = dr1[0]["PT_ESM"].ToString();
                        dr[42] = dr1[0]["PT_PMO"].ToString();
                        dr[43] = dr1[0]["Total_PMO"].ToString();
                        dr[44] = dr1[0]["Grade_Point"].ToString();
                        dr[45] = dr1[0]["ER_CREDIT"].ToString();
                        dr[46] = dr1[0]["Grade"].ToString();

                    }
                }
                dr[47] = Program;
                dr[48] = semester;
                dr[49] = examsession;
                dttrbtec3.Rows.Add(dr);
                r++;

                dr = dttrbtec4.NewRow();
                dr[0] = dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString();
                dr[1] = dsstudentrecord.Tables[0].Rows[g]["EName"].ToString();
                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");

                    if (dr1.Length > 0)
                    {
                        dr[2] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[3] = "0";
                            dr[4] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[5] = dr1[0]["LTP"].ToString();

                        dr[6] = dr1[0]["Credit"].ToString();
                        dr[7] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[8] = dr1[0]["TH_ESM"].ToString();
                        dr[9] = dr1[0]["TH_PMO"].ToString();
                        dr[10] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[11] = dr1[0]["PT_ESM"].ToString();
                        dr[12] = dr1[0]["PT_PMO"].ToString();
                        dr[13] = dr1[0]["Total_PMO"].ToString();
                        dr[14] = dr1[0]["Grade_Point"].ToString();
                        dr[15] = dr1[0]["ER_CREDIT"].ToString();
                        dr[16] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[17] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[18] = "0";
                            dr[19] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[20] = dr1[0]["LTP"].ToString();

                        dr[21] = dr1[0]["Credit"].ToString();
                        dr[22] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[23] = dr1[0]["TH_ESM"].ToString();
                        dr[24] = dr1[0]["TH_PMO"].ToString();
                        dr[25] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[26] = dr1[0]["PT_ESM"].ToString();
                        dr[27] = dr1[0]["PT_PMO"].ToString();
                        dr[28] = dr1[0]["Total_PMO"].ToString();
                        dr[29] = dr1[0]["Grade_Point"].ToString();
                        dr[30] = dr1[0]["ER_CREDIT"].ToString();
                        dr[31] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[32] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[33] = "0";
                            dr[34] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[35] = dr1[0]["LTP"].ToString();

                        dr[36] = dr1[0]["Credit"].ToString();
                        dr[37] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[38] = dr1[0]["TH_ESM"].ToString();
                        dr[39] = dr1[0]["TH_PMO"].ToString();
                        dr[40] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[41] = dr1[0]["PT_ESM"].ToString();
                        dr[42] = dr1[0]["PT_PMO"].ToString();
                        dr[43] = dr1[0]["Total_PMO"].ToString();
                        dr[44] = dr1[0]["Grade_Point"].ToString();
                        dr[45] = dr1[0]["ER_CREDIT"].ToString();
                        dr[46] = dr1[0]["Grade"].ToString();
                    }
                }
                dr[47] = Program;
                dr[48] = semester;
                dr[49] = examsession;
                dttrbtec4.Rows.Add(dr);
                r++;

                dr = dttrbtec5.NewRow();
                dr[0] = dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString();
                dr[1] = dsstudentrecord.Tables[0].Rows[g]["EName"].ToString();
                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");

                    if (dr1.Length > 0)
                    {
                        dr[2] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[3] = "0";
                            dr[4] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[5] = dr1[0]["LTP"].ToString();

                        dr[6] = dr1[0]["Credit"].ToString();
                        dr[7] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[8] = dr1[0]["TH_ESM"].ToString();
                        dr[9] = dr1[0]["TH_PMO"].ToString();
                        dr[10] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[11] = dr1[0]["PT_ESM"].ToString();
                        dr[12] = dr1[0]["PT_PMO"].ToString();
                        dr[13] = dr1[0]["Total_PMO"].ToString();
                        dr[14] = dr1[0]["Grade_Point"].ToString();
                        dr[15] = dr1[0]["ER_CREDIT"].ToString();
                        dr[16] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[17] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[18] = "0";
                            dr[19] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[20] = dr1[0]["LTP"].ToString();

                        dr[21] = dr1[0]["Credit"].ToString();
                        dr[22] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[23] = dr1[0]["TH_ESM"].ToString();
                        dr[24] = dr1[0]["TH_PMO"].ToString();
                        dr[25] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[26] = dr1[0]["PT_ESM"].ToString();
                        dr[27] = dr1[0]["PT_PMO"].ToString();
                        dr[28] = dr1[0]["Total_PMO"].ToString();
                        dr[29] = dr1[0]["Grade_Point"].ToString();
                        dr[30] = dr1[0]["ER_CREDIT"].ToString();
                        dr[31] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[32] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[33] = "0";
                            dr[34] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[35] = dr1[0]["LTP"].ToString();

                        dr[36] = dr1[0]["Credit"].ToString();
                        dr[37] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[38] = dr1[0]["TH_ESM"].ToString();
                        dr[39] = dr1[0]["TH_PMO"].ToString();
                        dr[40] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[41] = dr1[0]["PT_ESM"].ToString();
                        dr[42] = dr1[0]["PT_PMO"].ToString();
                        dr[43] = dr1[0]["Total_PMO"].ToString();
                        dr[44] = dr1[0]["Grade_Point"].ToString();
                        dr[45] = dr1[0]["ER_CREDIT"].ToString();
                        dr[46] = dr1[0]["Grade"].ToString();
                    }
                }
                dr[47] = Program;
                dr[48] = semester;
                dr[49] = examsession;
                dttrbtec5.Rows.Add(dr);

                //dttrbtec.Rows.Add(dr);

                //dstrrecord.Tables.Add(dttrbtec);

                //dsprintvalue.Tables.Add(dttrbtec);

            }

        }
    }
    private void withoutgroup_Btec()
    {
        dsstudentrecord = fnrev.SelectDataset("SELECT DISTINCT UnivRollNo,EName fROM TRBTec WHERE ExamSession='" + examsession + "' AND StreamPart = '" + streampartcode + "' AND + " + qrystr + "");
        DataSet dspapers = fnrev.SelectDataset("SELECT DISTINCT TRBTec.SubPaperCode, COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper " +
                  " FROM TRBTec INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN " +
                  " PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE TRBTec.StreamCode = '" + streamcode + "' " +
                  " AND (TRBTec.StreamPart = '" + streampartcode + "') AND (TRBTec.ExamYear = '" + examyear + "') AND TRBtec.ExamSession = '" + examsession + "' AND " + qrystr + " ORDER BY trpaper");
        
        for (int g = 0; g <= dsstudentrecord.Tables[0].Rows.Count - 1; g++)
        {

            dsstudsubpaer = fnrev.SelectDataset("SELECT COURSEPAPERS.SubPaperCode,COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper, TRBTec.CA_MSM_TH, " +
                " TRBTec.TH_ESM, TRBTec.TH_PMO, TRBTec.CA_MSM_PT, TRBTec.PT_ESM, TRBTec.PT_PMO, TRBTec.Total_PMO, TRBTec.Grade_Point, TRBTec.ER_CREDIT, " +
                " TRBTec.Grade, COURSEPAPERS.FullMarks, COURSEPAPERS.Credit, PRACTICALPAPERS.FullMarks AS PRFMARKS, " +
                " COURSEPAPERS.L + ' - ' + COURSEPAPERS.T + ' - ' + COURSEPAPERS.P AS LTP,COURSEPAPERS.PaperTypeCode FROM TRBTec INNER JOIN " +
                " COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN PRACTICALPAPERS ON " +
                " COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE " +
                 " UnivRollNo ='" + dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString() + "' AND " +
                 " TRBTec.StreamCode ='" + streamcode + "' AND TRBTec.StreamPart ='" + streampartcode + "' AND " +
                 " TRBTec.ExamYear = '" + examyear + "' AND " + qrystr + " AND TRBtec.ExamSession = '" + examsession + "' ORDER BY trpaper");
            for (int r = 0; r <= dspapers.Tables[0].Rows.Count - 1; r++)
            {

                dr = dttrbtec.NewRow();
                papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                dr[0] = dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString();
                dr[1] = dsstudentrecord.Tables[0].Rows[g]["EName"].ToString();
                if (dr1.Length > 0)
                {
                    dr[2] = dr1[0]["trpaper"].ToString();
                    if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                    {
                        dr[3] = dr1[0]["FullMarks"].ToString();
                        dr[4] = "0";
                    }
                    else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                    {
                        dr[3] = "0";
                        dr[4] = dr1[0]["FullMarks"].ToString();
                    }
                    else
                    {
                        dr[3] = dr1[0]["FullMarks"].ToString();
                        dr[4] = dr1[0]["PRFMARKS"].ToString();
                    }
                    dr[5] = dr1[0]["LTP"].ToString();

                    dr[6] = dr1[0]["Credit"].ToString();
                    dr[7] = dr1[0]["CA_MSM_TH"].ToString();
                    dr[8] = dr1[0]["TH_ESM"].ToString();
                    dr[9] = dr1[0]["TH_PMO"].ToString();
                    dr[10] = dr1[0]["CA_MSM_PT"].ToString();
                    dr[11] = dr1[0]["PT_ESM"].ToString();
                    dr[12] = dr1[0]["PT_PMO"].ToString();
                    dr[13] = dr1[0]["Total_PMO"].ToString();
                    dr[14] = dr1[0]["Grade_Point"].ToString();
                    dr[15] = dr1[0]["ER_CREDIT"].ToString();
                    dr[16] = dr1[0]["Grade"].ToString();
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[17] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[18] = "0";
                            dr[19] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[20] = dr1[0]["LTP"].ToString();

                        dr[21] = dr1[0]["Credit"].ToString();
                        dr[22] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[23] = dr1[0]["TH_ESM"].ToString();
                        dr[24] = dr1[0]["TH_PMO"].ToString();
                        dr[25] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[26] = dr1[0]["PT_ESM"].ToString();
                        dr[27] = dr1[0]["PT_PMO"].ToString();
                        dr[28] = dr1[0]["Total_PMO"].ToString();
                        dr[29] = dr1[0]["Grade_Point"].ToString();
                        dr[30] = dr1[0]["ER_CREDIT"].ToString();
                        dr[31] = dr1[0]["Grade"].ToString();
                    }
                }

                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[32] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[33] = "0";
                            dr[34] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[35] = dr1[0]["LTP"].ToString();

                        dr[36] = dr1[0]["Credit"].ToString();
                        dr[37] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[38] = dr1[0]["TH_ESM"].ToString();
                        dr[39] = dr1[0]["TH_PMO"].ToString();
                        dr[40] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[41] = dr1[0]["PT_ESM"].ToString();
                        dr[42] = dr1[0]["PT_PMO"].ToString();
                        dr[43] = dr1[0]["Total_PMO"].ToString();
                        dr[44] = dr1[0]["Grade_Point"].ToString();
                        dr[45] = dr1[0]["ER_CREDIT"].ToString();
                        dr[46] = dr1[0]["Grade"].ToString();

                    }
                }

                dr[47] = Program;
                dr[48] = semester;
                dr[49] = examsession;
                dttrbtec.Rows.Add(dr);
                r++;
                // add value in dttrbtec2
                dr = dttrbtec2.NewRow();

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    dr[0] = dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString();
                    dr[1] = dsstudentrecord.Tables[0].Rows[g]["EName"].ToString();
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");

                    if (dr1.Length > 0)
                    {
                        dr[2] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[3] = "0";
                            dr[4] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[5] = dr1[0]["LTP"].ToString();

                        dr[6] = dr1[0]["Credit"].ToString();
                        dr[7] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[8] = dr1[0]["TH_ESM"].ToString();
                        dr[9] = dr1[0]["TH_PMO"].ToString();
                        dr[10] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[11] = dr1[0]["PT_ESM"].ToString();
                        dr[12] = dr1[0]["PT_PMO"].ToString();
                        dr[13] = dr1[0]["Total_PMO"].ToString();
                        dr[14] = dr1[0]["Grade_Point"].ToString();
                        dr[15] = dr1[0]["ER_CREDIT"].ToString();
                        dr[16] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[17] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[18] = "0";
                            dr[19] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[20] = dr1[0]["LTP"].ToString();

                        dr[21] = dr1[0]["Credit"].ToString();
                        dr[22] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[23] = dr1[0]["TH_ESM"].ToString();
                        dr[24] = dr1[0]["TH_PMO"].ToString();
                        dr[25] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[26] = dr1[0]["PT_ESM"].ToString();
                        dr[27] = dr1[0]["PT_PMO"].ToString();
                        dr[28] = dr1[0]["Total_PMO"].ToString();
                        dr[29] = dr1[0]["Grade_Point"].ToString();
                        dr[30] = dr1[0]["ER_CREDIT"].ToString();
                        dr[31] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[32] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[33] = "0";
                            dr[34] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[35] = dr1[0]["LTP"].ToString();

                        dr[36] = dr1[0]["Credit"].ToString();
                        dr[37] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[38] = dr1[0]["TH_ESM"].ToString();
                        dr[39] = dr1[0]["TH_PMO"].ToString();
                        dr[40] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[41] = dr1[0]["PT_ESM"].ToString();
                        dr[42] = dr1[0]["PT_PMO"].ToString();
                        dr[43] = dr1[0]["Total_PMO"].ToString();
                        dr[44] = dr1[0]["Grade_Point"].ToString();
                        dr[45] = dr1[0]["ER_CREDIT"].ToString();
                        dr[46] = dr1[0]["Grade"].ToString();

                    }
                }
                dr[47] = Program;
                dr[48] = semester;
                dr[49] = examsession;
                dttrbtec2.Rows.Add(dr);
                r++;

                dr = dttrbtec3.NewRow();

                dr[0] = dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString();
                dr[1] = dsstudentrecord.Tables[0].Rows[g]["EName"].ToString();
                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");

                    if (dr1.Length > 0)
                    {
                        dr[2] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[3] = "0";
                            dr[4] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[5] = dr1[0]["LTP"].ToString();

                        dr[6] = dr1[0]["Credit"].ToString();
                        dr[7] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[8] = dr1[0]["TH_ESM"].ToString();
                        dr[9] = dr1[0]["TH_PMO"].ToString();
                        dr[10] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[11] = dr1[0]["PT_ESM"].ToString();
                        dr[12] = dr1[0]["PT_PMO"].ToString();
                        dr[13] = dr1[0]["Total_PMO"].ToString();
                        dr[14] = dr1[0]["Grade_Point"].ToString();
                        dr[15] = dr1[0]["ER_CREDIT"].ToString();
                        dr[16] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[17] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[18] = "0";
                            dr[19] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[20] = dr1[0]["LTP"].ToString();

                        dr[21] = dr1[0]["Credit"].ToString();
                        dr[22] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[23] = dr1[0]["TH_ESM"].ToString();
                        dr[24] = dr1[0]["TH_PMO"].ToString();
                        dr[25] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[26] = dr1[0]["PT_ESM"].ToString();
                        dr[27] = dr1[0]["PT_PMO"].ToString();
                        dr[28] = dr1[0]["Total_PMO"].ToString();
                        dr[29] = dr1[0]["Grade_Point"].ToString();
                        dr[30] = dr1[0]["ER_CREDIT"].ToString();
                        dr[31] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[32] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[33] = "0";
                            dr[34] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[35] = dr1[0]["LTP"].ToString();

                        dr[36] = dr1[0]["Credit"].ToString();
                        dr[37] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[38] = dr1[0]["TH_ESM"].ToString();
                        dr[39] = dr1[0]["TH_PMO"].ToString();
                        dr[40] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[41] = dr1[0]["PT_ESM"].ToString();
                        dr[42] = dr1[0]["PT_PMO"].ToString();
                        dr[43] = dr1[0]["Total_PMO"].ToString();
                        dr[44] = dr1[0]["Grade_Point"].ToString();
                        dr[45] = dr1[0]["ER_CREDIT"].ToString();
                        dr[46] = dr1[0]["Grade"].ToString();

                    }
                }
                dr[47] = Program;
                dr[48] = semester;
                dr[49] = examsession;
                dttrbtec3.Rows.Add(dr);
                r++;

                dr = dttrbtec4.NewRow();
                dr[0] = dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString();
                dr[1] = dsstudentrecord.Tables[0].Rows[g]["EName"].ToString();
                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");

                    if (dr1.Length > 0)
                    {
                        dr[2] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[3] = "0";
                            dr[4] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[5] = dr1[0]["LTP"].ToString();

                        dr[6] = dr1[0]["Credit"].ToString();
                        dr[7] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[8] = dr1[0]["TH_ESM"].ToString();
                        dr[9] = dr1[0]["TH_PMO"].ToString();
                        dr[10] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[11] = dr1[0]["PT_ESM"].ToString();
                        dr[12] = dr1[0]["PT_PMO"].ToString();
                        dr[13] = dr1[0]["Total_PMO"].ToString();
                        dr[14] = dr1[0]["Grade_Point"].ToString();
                        dr[15] = dr1[0]["ER_CREDIT"].ToString();
                        dr[16] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[17] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[18] = "0";
                            dr[19] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[20] = dr1[0]["LTP"].ToString();

                        dr[21] = dr1[0]["Credit"].ToString();
                        dr[22] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[23] = dr1[0]["TH_ESM"].ToString();
                        dr[24] = dr1[0]["TH_PMO"].ToString();
                        dr[25] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[26] = dr1[0]["PT_ESM"].ToString();
                        dr[27] = dr1[0]["PT_PMO"].ToString();
                        dr[28] = dr1[0]["Total_PMO"].ToString();
                        dr[29] = dr1[0]["Grade_Point"].ToString();
                        dr[30] = dr1[0]["ER_CREDIT"].ToString();
                        dr[31] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[32] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[33] = "0";
                            dr[34] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[35] = dr1[0]["LTP"].ToString();

                        dr[36] = dr1[0]["Credit"].ToString();
                        dr[37] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[38] = dr1[0]["TH_ESM"].ToString();
                        dr[39] = dr1[0]["TH_PMO"].ToString();
                        dr[40] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[41] = dr1[0]["PT_ESM"].ToString();
                        dr[42] = dr1[0]["PT_PMO"].ToString();
                        dr[43] = dr1[0]["Total_PMO"].ToString();
                        dr[44] = dr1[0]["Grade_Point"].ToString();
                        dr[45] = dr1[0]["ER_CREDIT"].ToString();
                        dr[46] = dr1[0]["Grade"].ToString();
                    }
                }
                dr[47] = Program;
                dr[48] = semester;
                dr[49] = examsession;
                dttrbtec4.Rows.Add(dr);

                r++;

                dr = dttrbtec5.NewRow();
                dr[0] = dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString();
                dr[1] = dsstudentrecord.Tables[0].Rows[g]["EName"].ToString();
                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");

                    if (dr1.Length > 0)
                    {
                        dr[2] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[3] = "0";
                            dr[4] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[5] = dr1[0]["LTP"].ToString();

                        dr[6] = dr1[0]["Credit"].ToString();
                        dr[7] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[8] = dr1[0]["TH_ESM"].ToString();
                        dr[9] = dr1[0]["TH_PMO"].ToString();
                        dr[10] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[11] = dr1[0]["PT_ESM"].ToString();
                        dr[12] = dr1[0]["PT_PMO"].ToString();
                        dr[13] = dr1[0]["Total_PMO"].ToString();
                        dr[14] = dr1[0]["Grade_Point"].ToString();
                        dr[15] = dr1[0]["ER_CREDIT"].ToString();
                        dr[16] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[17] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[18] = "0";
                            dr[19] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[20] = dr1[0]["LTP"].ToString();

                        dr[21] = dr1[0]["Credit"].ToString();
                        dr[22] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[23] = dr1[0]["TH_ESM"].ToString();
                        dr[24] = dr1[0]["TH_PMO"].ToString();
                        dr[25] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[26] = dr1[0]["PT_ESM"].ToString();
                        dr[27] = dr1[0]["PT_PMO"].ToString();
                        dr[28] = dr1[0]["Total_PMO"].ToString();
                        dr[29] = dr1[0]["Grade_Point"].ToString();
                        dr[30] = dr1[0]["ER_CREDIT"].ToString();
                        dr[31] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["SubPaperCode"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("SubPaperCode = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[32] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[33] = "0";
                            dr[34] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[35] = dr1[0]["LTP"].ToString();

                        dr[36] = dr1[0]["Credit"].ToString();
                        dr[37] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[38] = dr1[0]["TH_ESM"].ToString();
                        dr[39] = dr1[0]["TH_PMO"].ToString();
                        dr[40] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[41] = dr1[0]["PT_ESM"].ToString();
                        dr[42] = dr1[0]["PT_PMO"].ToString();
                        dr[43] = dr1[0]["Total_PMO"].ToString();
                        dr[44] = dr1[0]["Grade_Point"].ToString();
                        dr[45] = dr1[0]["ER_CREDIT"].ToString();
                        dr[46] = dr1[0]["Grade"].ToString();
                    }
                }
                dr[47] = Program;
                dr[48] = semester;
                dr[49] = examsession;
                dttrbtec5.Rows.Add(dr);
                //dttrbtec.Rows.Add(dr);

                //dstrrecord.Tables.Add(dttrbtec);

                //dsprintvalue.Tables.Add(dttrbtec);

            }

        }
    }

    private void withgroup()
    
    {
        for (int g = 0; g <= dsstudentrecord.Tables[0].Rows.Count - 1; g++)
        {

            //if (dept_wise == 1)
            //{
            //    dsstudsubpaer = fnrev.SelectDataset("SELECT COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper, TRBTec.CA_MSM_TH, " +
            //     " TRBTec.TH_ESM, TRBTec.TH_PMO, TRBTec.`CA_MSM_PT, TRBTec.PT_ESM, TRBTec.PT_PMO, TRBTec.Total_PMO, TRBTec.Grade_Point, TRBTec.ER_CREDIT, " +
            //     " TRBTec.Grade, COURSEPAPERS.FullMarks, COURSEPAPERS.Credit, PRACTICALPAPERS.FullMarks AS PRFMARKS, " +
            //     " COURSEPAPERS.L + ' - ' + COURSEPAPERS.T + ' - ' + COURSEPAPERS.P AS LTP,COURSEPAPERS.PaperTypeCode FROM TRBTec INNER JOIN " +
            //     " COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN PRACTICALPAPERS ON " +
            //     " COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE " +
            //      " UnivRollNo ='" + dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString() + "' AND " +
            //      " TRBTec.StreamCode ='" + streamcode + "' AND TRBTec.StreamPart ='" + streampartcode + "' AND " +
            //      " TRBTec.ExamYear = '" + examyear + "' order by trpaper");
            //}
            DataSet dspapers=new DataSet();
            if (dept_wise == 0)
                        {
                
                if (grp_wise == 1)
                {
                    dspapers = fnrev.SelectDataset("SELECT DISTINCT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper " +
                 " FROM TRBTec INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN " +
                 " PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE " +
                 " TRBTec.StreamPart in ('11','19','27','35','43','51') AND (TRBTec.ExamSession='" + examsession + "') AND " + qrystr + " ORDER BY trpaper");

                    dsstudsubpaer = fnrev.SelectDataset("SELECT  COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper, TRBTec.CA_MSM_TH, " +
                      " TRBTec.TH_ESM, TRBTec.TH_PMO, TRBTec.CA_MSM_PT, TRBTec.PT_ESM, TRBTec.PT_PMO, TRBTec.Total_PMO, TRBTec.Grade_Point, TRBTec.ER_CREDIT, " +
                      " TRBTec.Grade, COURSEPAPERS.FullMarks, COURSEPAPERS.Credit, PRACTICALPAPERS.FullMarks AS PRFMARKS, " +
                      " COURSEPAPERS.L + ' - ' + COURSEPAPERS.T + ' - ' + COURSEPAPERS.P AS LTP,COURSEPAPERS.PaperTypeCode,COURSEPAPERS.PaperAbbr FROM TRBTec INNER JOIN " +
                      " COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN PRACTICALPAPERS ON " +
                      " COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE " +
                       " UnivRollNo ='" + dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString() + "' AND " +
                       " TRBTec.StreamPart in ('11','19','27','35','43','51') AND " + qrystr + " AND " +
                       " TRBTec.ExamSession='" + examsession + "'  order by trpaper");
                }
                else if (grp_wise == 2)
                {
                    dspapers = fnrev.SelectDataset("SELECT DISTINCT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper " +
                " FROM TRBTec INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN " +
                " PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE " +
                " (TRBTec.StreamPart between 137 and 142) AND (TRBTec.ExamSession='" + examsession + "') AND " + qrystr + " ORDER BY trpaper");

                    dsstudsubpaer = fnrev.SelectDataset("SELECT COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper, TRBTec.CA_MSM_TH, " +
" TRBTec.TH_ESM, TRBTec.TH_PMO, TRBTec.CA_MSM_PT, TRBTec.PT_ESM, TRBTec.PT_PMO, TRBTec.Total_PMO, TRBTec.Grade_Point, TRBTec.ER_CREDIT, " +
" TRBTec.Grade, COURSEPAPERS.FullMarks, COURSEPAPERS.Credit, PRACTICALPAPERS.FullMarks AS PRFMARKS, " +
" COURSEPAPERS.L + ' - ' + COURSEPAPERS.T + ' - ' + COURSEPAPERS.P AS LTP,COURSEPAPERS.PaperTypeCode,COURSEPAPERS.PaperAbbr  FROM TRBTec INNER JOIN " +
" COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN PRACTICALPAPERS ON " +
" COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE " +
" UnivRollNo ='" + dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString() + "' AND " +
" TRBTec.StreamPart between '137' and '142' AND " + qrystr + " AND " +
" TRBTec.ExamSession='" + examsession + "'  order by trpaper");
                }
                else if (grp_wise == 3)
                {
                    dspapers = fnrev.SelectDataset("SELECT DISTINCT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper " +
                " FROM TRBTec INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN " +
                " PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE " +
                " TRBTec.StreamPart in ('12','20','28','36','44','52') AND (TRBTec.ExamSession='" + examsession + "') AND " + qrystr + " ORDER BY trpaper");

                    dsstudsubpaer = fnrev.SelectDataset("SELECT COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper, TRBTec.CA_MSM_TH, " +
" TRBTec.TH_ESM, TRBTec.TH_PMO, TRBTec.CA_MSM_PT, TRBTec.PT_ESM, TRBTec.PT_PMO, TRBTec.Total_PMO, TRBTec.Grade_Point, TRBTec.ER_CREDIT, " +
" TRBTec.Grade, COURSEPAPERS.FullMarks, COURSEPAPERS.Credit, PRACTICALPAPERS.FullMarks AS PRFMARKS, " +
" COURSEPAPERS.L + ' - ' + COURSEPAPERS.T + ' - ' + COURSEPAPERS.P AS LTP,COURSEPAPERS.PaperTypeCode,COURSEPAPERS.PaperAbbr  FROM TRBTec INNER JOIN " +
" COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN PRACTICALPAPERS ON " +
" COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE " +
" UnivRollNo ='" + dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString() + "' AND " +
" TRBTec.StreamPart in ('12','20','28','36','44','52') AND " + qrystr + "  AND " +
" TRBTec.ExamSession='" + examsession + "' order by trpaper");
                }
                else if (grp_wise == 4)
                {
                    dspapers = fnrev.SelectDataset("SELECT DISTINCT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper " +
                " FROM TRBTec INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN " +
                " PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE " +
                " (TRBTec.StreamPart between 143 and 148) AND (TRBTec.ExamSession='" + examsession + "') AND " + qrystr + " ORDER BY trpaper");

                    dsstudsubpaer = fnrev.SelectDataset("SELECT COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper, TRBTec.CA_MSM_TH, " +
" TRBTec.TH_ESM, TRBTec.TH_PMO, TRBTec.CA_MSM_PT, TRBTec.PT_ESM, TRBTec.PT_PMO, TRBTec.Total_PMO, TRBTec.Grade_Point, TRBTec.ER_CREDIT, " +
" TRBTec.Grade, COURSEPAPERS.FullMarks, COURSEPAPERS.Credit, PRACTICALPAPERS.FullMarks AS PRFMARKS, " +
" COURSEPAPERS.L + ' - ' + COURSEPAPERS.T + ' - ' + COURSEPAPERS.P AS LTP,COURSEPAPERS.PaperTypeCode,COURSEPAPERS.PaperAbbr  FROM TRBTec INNER JOIN " +
" COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN PRACTICALPAPERS ON " +
" COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE " +
" UnivRollNo ='" + dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString() + "' AND " +
" TRBTec.StreamPart between '143' and '148' AND " +
" TRBTec.ExamSession='" + examsession + "' AND " + qrystr + " order by trpaper");
                }
            }
            for (int r = 0; r <= dspapers.Tables[0].Rows.Count - 1; r++)
            {

                dr = dttrbtec.NewRow();
                papercode = dspapers.Tables[0].Rows[r]["PaperAbbr"].ToString();
                dr1 = dsstudsubpaer.Tables[0].Select("PaperAbbr = '" + papercode + "'");
                dr[0] = dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString();
                dr[1] = dsstudentrecord.Tables[0].Rows[g]["EName"].ToString();
                if (dr1.Length > 0)
                {
                    dr[2] = dr1[0]["trpaper"].ToString();
                    if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                    {
                        dr[3] = dr1[0]["FullMarks"].ToString();
                        dr[4] = "0";
                    }
                    else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                    {
                        dr[3] = "0";
                        dr[4] = dr1[0]["FullMarks"].ToString();
                    }
                    else
                    {
                        dr[3] = dr1[0]["FullMarks"].ToString();
                        dr[4] = dr1[0]["PRFMARKS"].ToString();
                    }
                    dr[5] = dr1[0]["LTP"].ToString();

                    dr[6] = dr1[0]["Credit"].ToString();
                    dr[7] = dr1[0]["CA_MSM_TH"].ToString();
                    dr[8] = dr1[0]["TH_ESM"].ToString();
                    dr[9] = dr1[0]["TH_PMO"].ToString();
                    dr[10] = dr1[0]["CA_MSM_PT"].ToString();
                    dr[11] = dr1[0]["PT_ESM"].ToString();
                    dr[12] = dr1[0]["PT_PMO"].ToString();
                    dr[13] = dr1[0]["Total_PMO"].ToString();
                    dr[14] = dr1[0]["Grade_Point"].ToString();
                    dr[15] = dr1[0]["ER_CREDIT"].ToString();
                    dr[16] = dr1[0]["Grade"].ToString();
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["PaperAbbr"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("PaperAbbr = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[17] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[18] = "0";
                            dr[19] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[20] = dr1[0]["LTP"].ToString();

                        dr[21] = dr1[0]["Credit"].ToString();
                        dr[22] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[23] = dr1[0]["TH_ESM"].ToString();
                        dr[24] = dr1[0]["TH_PMO"].ToString();
                        dr[25] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[26] = dr1[0]["PT_ESM"].ToString();
                        dr[27] = dr1[0]["PT_PMO"].ToString();
                        dr[28] = dr1[0]["Total_PMO"].ToString();
                        dr[29] = dr1[0]["Grade_Point"].ToString();
                        dr[30] = dr1[0]["ER_CREDIT"].ToString();
                        dr[31] = dr1[0]["Grade"].ToString();
                    }
                }

                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["PaperAbbr"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("PaperAbbr = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[32] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[33] = "0";
                            dr[34] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[35] = dr1[0]["LTP"].ToString();

                        dr[36] = dr1[0]["Credit"].ToString();
                        dr[37] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[38] = dr1[0]["TH_ESM"].ToString();
                        dr[39] = dr1[0]["TH_PMO"].ToString();
                        dr[40] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[41] = dr1[0]["PT_ESM"].ToString();
                        dr[42] = dr1[0]["PT_PMO"].ToString();
                        dr[43] = dr1[0]["Total_PMO"].ToString();
                        dr[44] = dr1[0]["Grade_Point"].ToString();
                        dr[45] = dr1[0]["ER_CREDIT"].ToString();
                        dr[46] = dr1[0]["Grade"].ToString();

                    }
                }
                if (grp_wise == 1 || grp_wise == 3)
                {
                    dr[47] = "GROUP_A";

                }
                else
                {
                    dr[47] = "GROUP_B";
                }
                dr[48] = semester;
                dr[49] = examsession;
                dttrbtec.Rows.Add(dr);
                r++;
                // add value in dttrbtec2
                dr = dttrbtec2.NewRow();

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    dr[0] = dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString();
                    dr[1] = dsstudentrecord.Tables[0].Rows[g]["EName"].ToString();
                    papercode = dspapers.Tables[0].Rows[r]["PaperAbbr"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("PaperAbbr = '" + papercode + "'");

                    if (dr1.Length > 0)
                    {
                        dr[2] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[3] = "0";
                            dr[4] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[5] = dr1[0]["LTP"].ToString();

                        dr[6] = dr1[0]["Credit"].ToString();
                        dr[7] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[8] = dr1[0]["TH_ESM"].ToString();
                        dr[9] = dr1[0]["TH_PMO"].ToString();
                        dr[10] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[11] = dr1[0]["PT_ESM"].ToString();
                        dr[12] = dr1[0]["PT_PMO"].ToString();
                        dr[13] = dr1[0]["Total_PMO"].ToString();
                        dr[14] = dr1[0]["Grade_Point"].ToString();
                        dr[15] = dr1[0]["ER_CREDIT"].ToString();
                        dr[16] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["PaperAbbr"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("PaperAbbr = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[17] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[18] = "0";
                            dr[19] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[20] = dr1[0]["LTP"].ToString();

                        dr[21] = dr1[0]["Credit"].ToString();
                        dr[22] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[23] = dr1[0]["TH_ESM"].ToString();
                        dr[24] = dr1[0]["TH_PMO"].ToString();
                        dr[25] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[26] = dr1[0]["PT_ESM"].ToString();
                        dr[27] = dr1[0]["PT_PMO"].ToString();
                        dr[28] = dr1[0]["Total_PMO"].ToString();
                        dr[29] = dr1[0]["Grade_Point"].ToString();
                        dr[30] = dr1[0]["ER_CREDIT"].ToString();
                        dr[31] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["PaperAbbr"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("PaperAbbr = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[32] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[33] = "0";
                            dr[34] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[35] = dr1[0]["LTP"].ToString();

                        dr[36] = dr1[0]["Credit"].ToString();
                        dr[37] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[38] = dr1[0]["TH_ESM"].ToString();
                        dr[39] = dr1[0]["TH_PMO"].ToString();
                        dr[40] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[41] = dr1[0]["PT_ESM"].ToString();
                        dr[42] = dr1[0]["PT_PMO"].ToString();
                        dr[43] = dr1[0]["Total_PMO"].ToString();
                        dr[44] = dr1[0]["Grade_Point"].ToString();
                        dr[45] = dr1[0]["ER_CREDIT"].ToString();
                        dr[46] = dr1[0]["Grade"].ToString();

                    }
                }
                dr[47] = Program;
                dr[48] = semester;
                dr[49] = examsession;
                dttrbtec2.Rows.Add(dr);
                r++;

                dr = dttrbtec3.NewRow();

                dr[0] = dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString();
                dr[1] = dsstudentrecord.Tables[0].Rows[g]["EName"].ToString();
                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["PaperAbbr"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("PaperAbbr = '" + papercode + "'");

                    if (dr1.Length > 0)
                    {
                        dr[2] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[3] = "0";
                            dr[4] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[5] = dr1[0]["LTP"].ToString();

                        dr[6] = dr1[0]["Credit"].ToString();
                        dr[7] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[8] = dr1[0]["TH_ESM"].ToString();
                        dr[9] = dr1[0]["TH_PMO"].ToString();
                        dr[10] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[11] = dr1[0]["PT_ESM"].ToString();
                        dr[12] = dr1[0]["PT_PMO"].ToString();
                        dr[13] = dr1[0]["Total_PMO"].ToString();
                        dr[14] = dr1[0]["Grade_Point"].ToString();
                        dr[15] = dr1[0]["ER_CREDIT"].ToString();
                        dr[16] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["PaperAbbr"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("PaperAbbr = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[17] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[18] = "0";
                            dr[19] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[20] = dr1[0]["LTP"].ToString();

                        dr[21] = dr1[0]["Credit"].ToString();
                        dr[22] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[23] = dr1[0]["TH_ESM"].ToString();
                        dr[24] = dr1[0]["TH_PMO"].ToString();
                        dr[25] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[26] = dr1[0]["PT_ESM"].ToString();
                        dr[27] = dr1[0]["PT_PMO"].ToString();
                        dr[28] = dr1[0]["Total_PMO"].ToString();
                        dr[29] = dr1[0]["Grade_Point"].ToString();
                        dr[30] = dr1[0]["ER_CREDIT"].ToString();
                        dr[31] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["PaperAbbr"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("PaperAbbr = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[32] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[33] = "0";
                            dr[34] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[35] = dr1[0]["LTP"].ToString();

                        dr[36] = dr1[0]["Credit"].ToString();
                        dr[37] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[38] = dr1[0]["TH_ESM"].ToString();
                        dr[39] = dr1[0]["TH_PMO"].ToString();
                        dr[40] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[41] = dr1[0]["PT_ESM"].ToString();
                        dr[42] = dr1[0]["PT_PMO"].ToString();
                        dr[43] = dr1[0]["Total_PMO"].ToString();
                        dr[44] = dr1[0]["Grade_Point"].ToString();
                        dr[45] = dr1[0]["ER_CREDIT"].ToString();
                        dr[46] = dr1[0]["Grade"].ToString();

                    }
                }
                dr[47] = Program;
                dr[48] = semester;
                dr[49] = examsession;
                dttrbtec3.Rows.Add(dr);
                r++;

                dr = dttrbtec4.NewRow();
                dr[0] = dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString();
                dr[1] = dsstudentrecord.Tables[0].Rows[g]["EName"].ToString();
                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["PaperAbbr"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("PaperAbbr = '" + papercode + "'");

                    if (dr1.Length > 0)
                    {
                        dr[2] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[3] = "0";
                            dr[4] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[5] = dr1[0]["LTP"].ToString();

                        dr[6] = dr1[0]["Credit"].ToString();
                        dr[7] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[8] = dr1[0]["TH_ESM"].ToString();
                        dr[9] = dr1[0]["TH_PMO"].ToString();
                        dr[10] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[11] = dr1[0]["PT_ESM"].ToString();
                        dr[12] = dr1[0]["PT_PMO"].ToString();
                        dr[13] = dr1[0]["Total_PMO"].ToString();
                        dr[14] = dr1[0]["Grade_Point"].ToString();
                        dr[15] = dr1[0]["ER_CREDIT"].ToString();
                        dr[16] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["PaperAbbr"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("PaperAbbr = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[17] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[18] = "0";
                            dr[19] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[20] = dr1[0]["LTP"].ToString();

                        dr[21] = dr1[0]["Credit"].ToString();
                        dr[22] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[23] = dr1[0]["TH_ESM"].ToString();
                        dr[24] = dr1[0]["TH_PMO"].ToString();
                        dr[25] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[26] = dr1[0]["PT_ESM"].ToString();
                        dr[27] = dr1[0]["PT_PMO"].ToString();
                        dr[28] = dr1[0]["Total_PMO"].ToString();
                        dr[29] = dr1[0]["Grade_Point"].ToString();
                        dr[30] = dr1[0]["ER_CREDIT"].ToString();
                        dr[31] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["PaperAbbr"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("PaperAbbr = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[32] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[33] = "0";
                            dr[34] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[35] = dr1[0]["LTP"].ToString();

                        dr[36] = dr1[0]["Credit"].ToString();
                        dr[37] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[38] = dr1[0]["TH_ESM"].ToString();
                        dr[39] = dr1[0]["TH_PMO"].ToString();
                        dr[40] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[41] = dr1[0]["PT_ESM"].ToString();
                        dr[42] = dr1[0]["PT_PMO"].ToString();
                        dr[43] = dr1[0]["Total_PMO"].ToString();
                        dr[44] = dr1[0]["Grade_Point"].ToString();
                        dr[45] = dr1[0]["ER_CREDIT"].ToString();
                        dr[46] = dr1[0]["Grade"].ToString();
                    }
                }
                dr[47] = Program;
                dr[48] = semester;
                dr[49] = examsession;
                dttrbtec4.Rows.Add(dr);

                r++;

                dr = dttrbtec5.NewRow();
                dr[0] = dsstudentrecord.Tables[0].Rows[g]["UnivRollNo"].ToString();
                dr[1] = dsstudentrecord.Tables[0].Rows[g]["EName"].ToString();
                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["PaperAbbr"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("PaperAbbr = '" + papercode + "'");

                    if (dr1.Length > 0)
                    {
                        dr[2] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[3] = "0";
                            dr[4] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[3] = dr1[0]["FullMarks"].ToString();
                            dr[4] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[5] = dr1[0]["LTP"].ToString();

                        dr[6] = dr1[0]["Credit"].ToString();
                        dr[7] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[8] = dr1[0]["TH_ESM"].ToString();
                        dr[9] = dr1[0]["TH_PMO"].ToString();
                        dr[10] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[11] = dr1[0]["PT_ESM"].ToString();
                        dr[12] = dr1[0]["PT_PMO"].ToString();
                        dr[13] = dr1[0]["Total_PMO"].ToString();
                        dr[14] = dr1[0]["Grade_Point"].ToString();
                        dr[15] = dr1[0]["ER_CREDIT"].ToString();
                        dr[16] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["PaperAbbr"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("PaperAbbr = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[17] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[18] = "0";
                            dr[19] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[18] = dr1[0]["FullMarks"].ToString();
                            dr[19] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[20] = dr1[0]["LTP"].ToString();

                        dr[21] = dr1[0]["Credit"].ToString();
                        dr[22] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[23] = dr1[0]["TH_ESM"].ToString();
                        dr[24] = dr1[0]["TH_PMO"].ToString();
                        dr[25] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[26] = dr1[0]["PT_ESM"].ToString();
                        dr[27] = dr1[0]["PT_PMO"].ToString();
                        dr[28] = dr1[0]["Total_PMO"].ToString();
                        dr[29] = dr1[0]["Grade_Point"].ToString();
                        dr[30] = dr1[0]["ER_CREDIT"].ToString();
                        dr[31] = dr1[0]["Grade"].ToString();
                    }
                }
                r++;

                if (r <= dspapers.Tables[0].Rows.Count - 1)
                {
                    papercode = dspapers.Tables[0].Rows[r]["PaperAbbr"].ToString();
                    dr1 = dsstudsubpaer.Tables[0].Select("PaperAbbr = '" + papercode + "'");
                    if (dr1.Length > 0)
                    {
                        dr[32] = dr1[0]["trpaper"].ToString();
                        if (dr1[0]["PaperTypeCode"].ToString() == "02" || dr1[0]["PaperTypeCode"].ToString() == "03")
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = "0";
                        }
                        else if (dr1[0]["PaperTypeCode"].ToString() == "01")
                        {
                            dr[33] = "0";
                            dr[34] = dr1[0]["FullMarks"].ToString();
                        }
                        else
                        {
                            dr[33] = dr1[0]["FullMarks"].ToString();
                            dr[34] = dr1[0]["PRFMARKS"].ToString();
                        }

                        dr[35] = dr1[0]["LTP"].ToString();

                        dr[36] = dr1[0]["Credit"].ToString();
                        dr[37] = dr1[0]["CA_MSM_TH"].ToString();
                        dr[38] = dr1[0]["TH_ESM"].ToString();
                        dr[39] = dr1[0]["TH_PMO"].ToString();
                        dr[40] = dr1[0]["CA_MSM_PT"].ToString();
                        dr[41] = dr1[0]["PT_ESM"].ToString();
                        dr[42] = dr1[0]["PT_PMO"].ToString();
                        dr[43] = dr1[0]["Total_PMO"].ToString();
                        dr[44] = dr1[0]["Grade_Point"].ToString();
                        dr[45] = dr1[0]["ER_CREDIT"].ToString();
                        dr[46] = dr1[0]["Grade"].ToString();
                    }
                }
                dr[47] = Program;
                dr[48] = semester;
                dr[49] = examsession;
                dttrbtec5.Rows.Add(dr);

                r++;
                            

            }
        }
    }

    private void filltrpapers()
    {
        dttrpaper = new DataTable();
        dttrpaper.Columns.Add("Cpaper1", typeof(string));
        dttrpaper.Columns.Add("FullMarks1", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS1", typeof(string));
        dttrpaper.Columns.Add("LTP1", typeof(string));
        dttrpaper.Columns.Add("Credit1", typeof(string));

        dttrpaper.Columns.Add("Cpaper2", typeof(string));
        dttrpaper.Columns.Add("FullMarks2", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS2", typeof(string));
        dttrpaper.Columns.Add("LTP2", typeof(string));
        dttrpaper.Columns.Add("Credit2", typeof(string));

        dttrpaper.Columns.Add("Cpaper3", typeof(string));
        dttrpaper.Columns.Add("FullMarks3", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS3", typeof(string));
        dttrpaper.Columns.Add("LTP3", typeof(string));
        dttrpaper.Columns.Add("Credit3", typeof(string));

        dttrpaper.Columns.Add("Cpaper4", typeof(string));
        dttrpaper.Columns.Add("FullMarks4", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS4", typeof(string));
        dttrpaper.Columns.Add("LTP4", typeof(string));
        dttrpaper.Columns.Add("Credit4", typeof(string));

        dttrpaper.Columns.Add("Cpaper5", typeof(string));
        dttrpaper.Columns.Add("FullMarks5", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS5", typeof(string));
        dttrpaper.Columns.Add("LTP5", typeof(string));
        dttrpaper.Columns.Add("Credit5", typeof(string));

        dttrpaper.Columns.Add("Cpaper6", typeof(string));
        dttrpaper.Columns.Add("FullMarks6", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS6", typeof(string));
        dttrpaper.Columns.Add("LTP6", typeof(string));
        dttrpaper.Columns.Add("Credit6", typeof(string));

        dttrpaper.Columns.Add("Cpaper7", typeof(string));
        dttrpaper.Columns.Add("FullMarks7", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS7", typeof(string));
        dttrpaper.Columns.Add("LTP7", typeof(string));
        dttrpaper.Columns.Add("Credit7", typeof(string));

        dttrpaper.Columns.Add("Cpaper8", typeof(string));
        dttrpaper.Columns.Add("FullMarks8", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS8", typeof(string));
        dttrpaper.Columns.Add("LTP8", typeof(string));
        dttrpaper.Columns.Add("Credit8", typeof(string));

        dttrpaper.Columns.Add("Cpaper9", typeof(string));
        dttrpaper.Columns.Add("FullMark9", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS9", typeof(string));
        dttrpaper.Columns.Add("LTP9", typeof(string));
        dttrpaper.Columns.Add("Credit9", typeof(string));

        dttrpaper.Columns.Add("Cpaper10", typeof(string));
        dttrpaper.Columns.Add("FullMark10", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS10", typeof(string));
        dttrpaper.Columns.Add("LTP10", typeof(string));
        dttrpaper.Columns.Add("Credit10", typeof(string));

        dttrpaper.Columns.Add("Cpaper11", typeof(string));
        dttrpaper.Columns.Add("FullMark11", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS11", typeof(string));
        dttrpaper.Columns.Add("LTP11", typeof(string));
        dttrpaper.Columns.Add("Credit11", typeof(string));

        dttrpaper.Columns.Add("Cpaper12", typeof(string));
        dttrpaper.Columns.Add("FullMark12", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS12", typeof(string));
        dttrpaper.Columns.Add("LTP12", typeof(string));
        dttrpaper.Columns.Add("Credit12", typeof(string));

        dttrpaper.Columns.Add("Cpaper13", typeof(string));
        dttrpaper.Columns.Add("FullMark13", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS13", typeof(string));
        dttrpaper.Columns.Add("LTP13", typeof(string));
        dttrpaper.Columns.Add("Credit13", typeof(string));

        dttrpaper.Columns.Add("Cpaper14", typeof(string));
        dttrpaper.Columns.Add("FullMark14", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS14", typeof(string));
        dttrpaper.Columns.Add("LTP14", typeof(string));
        dttrpaper.Columns.Add("Credit14", typeof(string));

        dttrpaper.Columns.Add("Cpaper15", typeof(string));
        dttrpaper.Columns.Add("FullMark15", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS15", typeof(string));
        dttrpaper.Columns.Add("LTP15", typeof(string));
        dttrpaper.Columns.Add("Credit15", typeof(string));

        DataRow dr;

        string querystr="";
        if (spart.IndexOf('A') > 0 || spart.IndexOf('B') > 0)
        {
            //querystr = " (STREAMPART.StreamPart = '" + spart + "') AND " + qrystr ;
            {
                querystr = "SELECT DISTINCT COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper, " +
                " COURSEPAPERS.FullMarks, COURSEPAPERS.Credit,PRACTICALPAPERS.FullMarks AS PRFMARKS, " +
                " COURSEPAPERS.L+ ' - ' + COURSEPAPERS.T+ ' - ' + COURSEPAPERS.P AS LTP, COURSEPAPERS.PaperTypeCode " +
                " FROM TRBTec INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " +
                " STREAMPART ON COURSEPAPERS.StreamPartCode = STREAMPART.StreamPartCode LEFT OUTER JOIN " +
                " PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE " +
                " (STREAMPART.StreamPart = '" + spart + "') AND " + qrystr + " AND TRBTec.ExamSession='" + examsession + "' " +
                " ORDER BY trpaper";
            }

        }
        else
        {
           // querystr = " (TRBTec.StreamPart = '" + streampartcode + "') ";
            querystr = "SELECT DISTINCT COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper, COURSEPAPERS.FullMarks," +
            " COURSEPAPERS.Credit, PRACTICALPAPERS.FullMarks AS PRFMARKS, COURSEPAPERS.L + ' - ' + COURSEPAPERS.T + ' - ' + COURSEPAPERS.P AS LTP, " +
            " COURSEPAPERS.PaperTypeCode FROM TRBTec INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN PRACTICALPAPERS " +
            " ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE TRBTec.ExamSession = '" + examsession + "' AND " + qrystr + " AND " +
            " (TRBTec.ExamYear = '" + examyear + "') AND (TRBTec.StreamCode = '" + streamcode + "') AND (TRBTec.StreamPart = '" + streampartcode + "') " + 
            " ORDER BY trpaper ";
        }

        DataSet dstrpaper = fnrev.SelectDataset(querystr);      


        for (int d = 0; d <= dstrpaper.Tables[0].Rows.Count - 1; d++)
        {
            dr = dttrpaper.NewRow();
            dr[0] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
            if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
            {
                dr[1] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                dr[2] = "0";
            }
            else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
            {
                dr[1] = "0";
                dr[2] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
            }
            else
            {
                dr[1] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                dr[2] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
            }

            dr[3] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
            dr[4] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count - 1)
            {
                dr[5] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[6] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[7] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[6] = "0";
                    dr[7] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[6] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[7] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[8] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[9] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count - 1)
            {
                dr[10] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[11] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[12] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[11] = "0";
                    dr[12] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[11] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[12] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[13] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[14] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count - 1)
            {
                dr[15] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[16] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[17] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[16] = "0";
                    dr[17] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[16] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[17] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[18] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[19] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count - 1)
            {
                dr[20] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[21] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[22] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[21] = "0";
                    dr[22] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[21] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[22] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[23] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[24] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count - 1)
            {
                dr[25] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[26] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[27] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[26] = "0";
                    dr[27] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[26] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[27] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[28] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[29] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count - 1)
            {
                dr[30] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[31] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[32] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[31] = "0";
                    dr[32] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[31] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[32] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[33] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[34] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count - 1)
            {
                dr[35] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[36] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[37] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[36] = "0";
                    dr[37] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[36] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[37] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[38] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[39] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count - 1)
            {
                dr[40] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[41] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[42] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[41] = "0";
                    dr[42] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[41] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[42] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[43] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[44] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count - 1)
            {
                dr[45] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[46] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[47] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[46] = "0";
                    dr[47] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[46] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[47] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[48] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[49] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count - 1)
            {
                dr[50] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[51] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[52] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[51] = "0";
                    dr[52] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[51] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[52] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[53] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[54] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count - 1)
            {
                dr[55] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[56] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[57] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[56] = "0";
                    dr[57] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[56] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[57] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[58] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[59] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }
            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count - 1)
            {
                dr[60] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[61] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[62] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[61] = "0";
                    dr[62] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[61] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[62] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[63] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[64] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }
            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count - 1)
            {
                dr[65] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[66] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[67] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[66] = "0";
                    dr[67] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[66] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[67] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[68] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[69] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }
            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count - 1)
            {
                dr[70] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[71] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[72] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[71] = "0";
                    dr[72] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[71] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[72] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[73] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[74] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }
            dttrpaper.Rows.Add(dr);
        }
    }

    private void filltrpapers_Mtec()
    {
        dttrpaper = new DataTable();
        dttrpaper.Columns.Add("Cpaper1", typeof(string));
        dttrpaper.Columns.Add("FullMarks1", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS1", typeof(string));
        dttrpaper.Columns.Add("LTP1", typeof(string));
        dttrpaper.Columns.Add("Credit1", typeof(string));

        dttrpaper.Columns.Add("Cpaper2", typeof(string));
        dttrpaper.Columns.Add("FullMarks2", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS2", typeof(string));
        dttrpaper.Columns.Add("LTP2", typeof(string));
        dttrpaper.Columns.Add("Credit2", typeof(string));

        dttrpaper.Columns.Add("Cpaper3", typeof(string));
        dttrpaper.Columns.Add("FullMarks3", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS3", typeof(string));
        dttrpaper.Columns.Add("LTP3", typeof(string));
        dttrpaper.Columns.Add("Credit3", typeof(string));

        dttrpaper.Columns.Add("Cpaper4", typeof(string));
        dttrpaper.Columns.Add("FullMarks4", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS4", typeof(string));
        dttrpaper.Columns.Add("LTP4", typeof(string));
        dttrpaper.Columns.Add("Credit4", typeof(string));

        dttrpaper.Columns.Add("Cpaper5", typeof(string));
        dttrpaper.Columns.Add("FullMarks5", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS5", typeof(string));
        dttrpaper.Columns.Add("LTP5", typeof(string));
        dttrpaper.Columns.Add("Credit5", typeof(string));

        dttrpaper.Columns.Add("Cpaper6", typeof(string));
        dttrpaper.Columns.Add("FullMarks6", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS6", typeof(string));
        dttrpaper.Columns.Add("LTP6", typeof(string));
        dttrpaper.Columns.Add("Credit6", typeof(string));

        dttrpaper.Columns.Add("Cpaper7", typeof(string));
        dttrpaper.Columns.Add("FullMarks7", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS7", typeof(string));
        dttrpaper.Columns.Add("LTP7", typeof(string));
        dttrpaper.Columns.Add("Credit7", typeof(string));

        dttrpaper.Columns.Add("Cpaper8", typeof(string));
        dttrpaper.Columns.Add("FullMarks8", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS8", typeof(string));
        dttrpaper.Columns.Add("LTP8", typeof(string));
        dttrpaper.Columns.Add("Credit8", typeof(string));

        dttrpaper.Columns.Add("Cpaper9", typeof(string));
        dttrpaper.Columns.Add("FullMark9", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS9", typeof(string));
        dttrpaper.Columns.Add("LTP9", typeof(string));
        dttrpaper.Columns.Add("Credit9", typeof(string));

        dttrpaper.Columns.Add("Cpaper10", typeof(string));
        dttrpaper.Columns.Add("FullMark10", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS10", typeof(string));
        dttrpaper.Columns.Add("LTP10", typeof(string));
        dttrpaper.Columns.Add("Credit10", typeof(string));

        dttrpaper.Columns.Add("Cpaper11", typeof(string));
        dttrpaper.Columns.Add("FullMark11", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS11", typeof(string));
        dttrpaper.Columns.Add("LTP11", typeof(string));
        dttrpaper.Columns.Add("Credit11", typeof(string));

        dttrpaper.Columns.Add("Cpaper12", typeof(string));
        dttrpaper.Columns.Add("FullMark12", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS12", typeof(string));
        dttrpaper.Columns.Add("LTP12", typeof(string));
        dttrpaper.Columns.Add("Credit12", typeof(string));

        dttrpaper.Columns.Add("Cpaper13", typeof(string));
        dttrpaper.Columns.Add("FullMark13", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS13", typeof(string));
        dttrpaper.Columns.Add("LTP13", typeof(string));
        dttrpaper.Columns.Add("Credit13", typeof(string));

        dttrpaper.Columns.Add("Cpaper14", typeof(string));
        dttrpaper.Columns.Add("FullMark14", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS14", typeof(string));
        dttrpaper.Columns.Add("LTP14", typeof(string));
        dttrpaper.Columns.Add("Credit14", typeof(string));

        dttrpaper.Columns.Add("Cpaper15", typeof(string));
        dttrpaper.Columns.Add("FullMark15", typeof(string));
        dttrpaper.Columns.Add("PRFMARKS15", typeof(string));
        dttrpaper.Columns.Add("LTP15", typeof(string));
        dttrpaper.Columns.Add("Credit15", typeof(string));
        DataRow dr;
        DataSet dstrpaper = fnrev.SelectDataset("SELECT DISTINCT TRMTec.SubPaperCode, COURSEPAPERS.PaperAbbr + '-' + COURSEPAPERS.PaperName AS trpaper, " +
            " COURSEPAPERS.FullMarks, COURSEPAPERS.Credit,PRACTICALPAPERS.FullMarks AS PRFMARKS, COURSEPAPERS.L+ ' - ' + COURSEPAPERS.T+ ' - ' + COURSEPAPERS.P " +
            " AS LTP, COURSEPAPERS.PaperTypeCode FROM TRMTec INNER JOIN COURSEPAPERS ON TRMTec.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN " +
            " PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE TRMTec.StreamCode = '" + streamcode + "' AND " +
            " TRMTec.StreamPart = '" + streampartcode + "' AND TRMTec.ExamSession='" + examsession + "' AND TRMtec.SplCode = '" + Splcode + "' ORDER BY trpaper");

        for (int d = 0; d <= dstrpaper.Tables[0].Rows.Count-1; d++)
        {
            dr = dttrpaper.NewRow();
            dr[0] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
            if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
            {
                dr[1] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                dr[2] = "0";
            }
            else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
            {
                dr[1] = "0";
                dr[2] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
            }
            else
            {
                dr[1] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                dr[2] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
            }

            dr[3] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
            dr[4] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count-1)
            {
                dr[5] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[6] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[7] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[6] = "0";
                    dr[7] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[6] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[7] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[8] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[9] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count-1)
            {
                dr[10] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[11] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[12] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[11] = "0";
                    dr[12] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[11] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[12] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[13] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[14] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count-1)
            {
                dr[15] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[16] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[17] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[16] = "0";
                    dr[17] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[16] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[17] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[18] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[19] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count-1)
            {
                dr[20] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[21] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[22] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[21] = "0";
                    dr[22] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[21] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[22] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[23] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[24] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count-1)
            {
                dr[25] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[26] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[27] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[26] = "0";
                    dr[27] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[26] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[27] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[28] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[29] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count-1)
            {
                dr[30] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[31] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[32] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[31] = "0";
                    dr[32] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[31] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[32] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[33] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[34] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count-1)
            {
                dr[35] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[36] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[37] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[36] = "0";
                    dr[37] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[36] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[37] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[38] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[39] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count-1)
            {
                dr[40] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[41] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[42] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[41] = "0";
                    dr[42] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[41] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[42] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[43] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[44] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count-1)
            {
                dr[45] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[46] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[47] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[46] = "0";
                    dr[47] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[46] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[47] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[48] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[49] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count-1)
            {
                dr[50] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[51] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[52] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[51] = "0";
                    dr[52] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[51] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[52] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[53] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[54] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }

            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count-1)
            {
                dr[55] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[56] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[57] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[56] = "0";
                    dr[57] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[56] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[57] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[58] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[59] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }
            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count-1)
            {
                dr[60] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[61] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[62] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[61] = "0";
                    dr[62] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[61] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[62] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[63] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[64] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }
            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count-1)
            {
                dr[65] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[66] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[67] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[66] = "0";
                    dr[67] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[66] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[67] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[68] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[69] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }
            d++;
            if (d <= dstrpaper.Tables[0].Rows.Count-1)
            {
                dr[70] = dstrpaper.Tables[0].Rows[d]["trpaper"].ToString();
                if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "02" || dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "03")
                {
                    dr[71] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[72] = "0";
                }
                else if (dstrpaper.Tables[0].Rows[d]["PaperTypeCode"].ToString() == "01")
                {
                    dr[71] = "0";
                    dr[72] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                }
                else
                {
                    dr[71] = dstrpaper.Tables[0].Rows[d]["FullMarks"].ToString();
                    dr[72] = dstrpaper.Tables[0].Rows[d]["PRFMARKS"].ToString();
                }

                dr[73] = dstrpaper.Tables[0].Rows[d]["LTP"].ToString();
                dr[74] = dstrpaper.Tables[0].Rows[d]["Credit"].ToString();
            }
            dttrpaper.Rows.Add(dr);
        }
    }
}
