using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class RollDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "5")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
                //ViewState.Add("EditMode", "false");
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            BindGrid();

            //PopulateDDL popddl = new PopulateDDL();
            //popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            //popddl.Popualate(ExamYear, "Year", "Select Year from Year where year >='2008'order by Year", "Year", "Year");
          
        }

    }
    //protected void Button1_Click(object sender, EventArgs e)
    //{
        
    //    // if (MarksEntryGrid.Rows.Count > 0)
    //    BtnSave.Enabled = true;

    //        Panel3.Enabled = false;
    //        Panel2.Visible = true;
    //        LblMsg2.Text = "";
    //        RunNo.Focus();
    //       BindGrid();

    //}


    void BindGrid()
    {
       string sql = "SELECT  AckNo, OldRollNo from RollBackDetails order by ackno" ;
       DataSet ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
       MarksGrid.DataSource = ds;
       MarksGrid.DataBind();
    }


    protected int SaveMarks()
    {
        SqlTransaction tran;
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        SqlDataReader rd;
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        int n =0;        

        con.Open();


        tran = con.BeginTransaction();
        cmd.Transaction = tran;
        
        string ack="";
        ack=AckPreNo.Text;
        ack+=RunNo.Text;

        try
        {
          cmd.CommandText = "insert into RollBackDetails (Ackno,OldRollNo) values ( '" + ack + "'  , '" + OldRoll.Text + "' ) ";
          n = cmd.ExecuteNonQuery();
          tran.Commit();
          return n;
        }
        catch (Exception ex)
        {
            tran.Rollback();
            //Response.Write(ex.Message);
            return n;
        }
    }

    protected void BtnSave_Click(object sender, EventArgs e)
    {
        int flag = SaveMarks();
        if (flag == 1)
        {
            BindGrid();
            LblMsg2.Text = "Code inserted for Ack no:-" + AckPreNo.Text + RunNo.Text + " - " + OldRoll.Text;
            RunNo.Text = "";
            OldRoll.Text = "";
            RunNo.Focus();
        }
        else if (flag == -1)
        {
            LblMsg2.Text = " Please check Roll no.";
            RunNo.Focus();
        }
        else if (flag == 0)
        {
            LblMsg2.Text = "Duplicate AckNo/Roll no.";
            RunNo.Focus();
        }
        else
        {
            LblMsg2.Text = "Plz check Roll No.";
            RunNo.Focus();
        }

    }
    protected void MarksGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        MarksGrid.PageIndex = e.NewPageIndex;
        BindGrid();
    }
}
