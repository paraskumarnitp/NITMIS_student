using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class ViewRegNoDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["UserId"].ToString() == "")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CastCode, "Category", "Select Category,CategoryCode from Category order by Category", "Category", "CategoryCode");
            popddl.Popualate(PermanentDistCode, "District", "Select DistName,DistCode from District order by DistName", "DistName", "DistCode");
            popddl.Popualate(PresentDistrictCode, "District", "Select DistName,DistCode from District order by DistName", "DistName", "DistCode");
            popddl.Popualate(NationalityCode, "Nationality", "Select Nationality,NationalityCode from Nationality order by Nationality", "Nationality", "NationalityCode");
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(Year1, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(Year2, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(ReligionCode, "Religion", "Select * from Religion order by ReligionCode", "Religion", "ReligionCode");
            popddl.Popualate(ExamCode1, "ExamName", "Select ExamName, ExamCode from ExamName order by ExamName", "ExamName", "ExamCode");
            popddl.Popualate(UnivCode1, "University", "Select UnivName,UnivCode from University order by UnivName", "UnivName", "UnivCode");
            RegNo.Focus();
        }
    }
    protected void BtnReg_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

   
        HPaper.Items.Clear();
        SPaper.Items.Clear();
        CompPaper.Items.Clear();   
     
     

      
        cmd.CommandText="select count(*) N from registration where RegNo='" + RegNo.Text + "' "; //change by suraj for registration using old registration no.
        SqlDataReader rd;                     // change by suraj 19-dec-2012
        con.Open();
        rd=cmd.ExecuteReader();
        rd.Read();
        string temp1=rd["N"].ToString();
        con.Close();
        rd.Close();

        if(temp1 == "2") //if there are two records having the same reg no. then latest registration details wl come in the interface.
        cmd.CommandText = " select AckNo,ApplicantName,HindiName,FatherName,MotherName,DOB,Gender,MaritalStatus,BloodGroup,EmailId,ContactNo,CastCode,NationalityCode," +
            "CollCode,AdmissionDate,TempRollNo,CourseSession,PermanentAddress1,PermanentAddress2,PermanentDistCode,PermanentPinCode,PresentAddress1,PresentAddress2,PresentDistrictCode,PresentPinCode," +
            "AdmFeeAmt,paymentID,paymentDate,ReligionCode,AdmformNo,StreamCode,CourseSession,StreamPartCode, SubCode  from Registration where RegNo='" + RegNo.Text + "' and IsOld='Y' ";
        
            
            else
        cmd.CommandText = " select AckNo,ApplicantName,HindiName,FatherName,MotherName,DOB,Gender,MaritalStatus,BloodGroup,EmailId,ContactNo,CastCode,NationalityCode," +
            "CollCode,AdmissionDate,TempRollNo,CourseSession,PermanentAddress1,PermanentAddress2,PermanentDistCode,PermanentPinCode,PresentAddress1,PresentAddress2,PresentDistrictCode,PresentPinCode," +
            "AdmFeeAmt,paymentID,paymentDate,ReligionCode,AdmformNo,StreamCode,CourseSession,StreamPartCode, SubCode  from Registration where RegNo='" + RegNo.Text + "'";

        
        SqlDataReader reader;
        con.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            reader.Read();
            ApplicantName.Text = reader["ApplicantName"].ToString();
            HindiName.Text = reader["HindiName"].ToString();
            FatherName.Text = reader["FatherName"].ToString();
            MotherName.Text = reader["MotherName"].ToString();
            if (reader["DOB"].ToString() == "") DOB.Text = "Data Unavailable";
            else DOB.Text = string.Format ("{0:dd/MM/yyyy}",Convert.ToDateTime (reader["DOB"]));
            if (reader["ReligionCode"].ToString()!="")
            ReligionCode.SelectedValue = reader["ReligionCode"].ToString();
            if (reader["NationalityCode"].ToString() != "")
            NationalityCode.SelectedValue = reader["NationalityCode"].ToString();
            if (reader["Gender"].ToString() == "M")
                GenderM.Checked = true;
            else
                GenderF.Checked = true;
            if (reader["MaritalStatus"].ToString()!="")
            MaritalStatus.SelectedValue = reader["MaritalStatus"].ToString();
            if (reader["BloodGroup"].ToString() != "")
            {
                BloodGroup.SelectedValue = reader["BloodGroup"].ToString();
            }
            EmailId.Text = reader["EmailId"].ToString();
            ContactNo.Text = reader["ContactNo"].ToString();
            CollCode.Text = reader["CollCode"].ToString();
            CastCode.SelectedValue = reader["castcode"].ToString();
          //  NationalityCode.SelectedValue = reader["NationalityCode"].ToString();
            if (reader["AdmissionDate"].ToString()!="")
            AdmissionDate.Text = string.Format ("{0:dd/MM/yyyy}",Convert.ToDateTime (reader["AdmissionDate"]));
            RollNo.Text = reader["TempRollNo"].ToString();
            PermanentAddress1.Text = reader["PermanentAddress1"].ToString();
            PermanentAddress2.Text = reader["PermanentAddress2"].ToString();
            if (reader["PermanentDistCode"].ToString()!="")
            PermanentDistCode.SelectedValue = reader["PermanentDistCode"].ToString();
            PermanentPinCode.Text = reader["PermanentPinCode"].ToString();
            PresentAddress1.Text = reader["PresentAddress1"].ToString();
            PresentAddress2.Text = reader["PresentAddress2"].ToString();
            if (reader["PresentDistrictCode"].ToString()!="")
            PresentDistrictCode.SelectedValue = reader["PresentDistrictCode"].ToString();
            PresentPinCode.Text = reader["PresentPinCode"].ToString();
           // AdmissionDate.Text = string.Format ("{0:dd/MM/yyyy}",Convert.ToDateTime (reader["AdmissionDate"]));
            AdmFeeAmt.Text = reader["AdmFeeAmt"].ToString();
            paymentID.Text = reader["paymentID"].ToString();
            if (reader["paymentDate"].ToString()!="")
            paymentDate.Text = string.Format ("{0:dd/MM/yyyy}",Convert.ToDateTime (reader["paymentDate"]));
            AdmformNo.Text = reader["AdmformNo"].ToString();
            StreamCode.SelectedValue = reader["StreamCode"].ToString();
            Year1.Text = (reader["CourseSession"].ToString()).Substring(0, 4);
            Year2.Text = (reader["CourseSession"].ToString()).Substring(5, 4);
            //GetSubComb(reader["SubCombCode"].ToString());


            ImageUpload imgUpload = new ImageUpload();
            string strFileName = imgUpload.Image_Load(reader["AckNo"].ToString());


            if (strFileName.ToString().Contains("temp"))
            {


                string photo = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/temp.jpg";

                string strRightNow = "";
                string IUrl = "";

                strRightNow = System.DateTime.Now.ToString("ddMMyyyyHHmmss");
                IUrl = photo + "?img=" + strRightNow;

                Image3.ImageUrl = IUrl;
                Image3.DataBind();


            }
            else if (strFileName.ToString().Contains("UploadPhoto"))
            {

                Image3.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadPhoto.JPG";
                Image3.DataBind();

            }

            else
            {
                LblMsg.Text = "Error" + strFileName;
                //Response.Write("Error");
                //Response.Write(strFileName);
            }


            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");

            string spc = reader["StreamPartCode"].ToString();
           
            if (spc!="")
            {
                StreamPart.SelectedValue = reader["StreamPartCode"].ToString();
            }
            else
            {
                StreamPart.SelectedIndex = 0;
                
            }

            popddl.Popualate(SubCode, "Subject", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
             spc= reader["SubCode"].ToString();
             if (spc != "")
            {
                SubCode.SelectedValue = reader["SubCode"].ToString();
            }
            else
            {
               SubCode.SelectedIndex = 0;
            }
            
            reader.Close();

         /*   if(temp1=="2") //change by suraj on 20-DEC-2012
                cmd.CommandText = " select ExamCode,UnivCode,CollCode,PassYear,RollNo,Division from PREREGQUALIFICATION where RegNo='" + RegNo.Text + "' and PassYear=(select max(PassYear) from PREREGQUALIFICATION where RegNo='" + RegNo.Text + "')";
            else

            cmd.CommandText = " select ExamCode,UnivCode,CollCode,PassYear,RollNo,Division from PREREGQUALIFICATION where RegNo='" + RegNo.Text + "'";
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                ExamCode1.SelectedValue = reader["ExamCode"].ToString();
                UnivCode1.SelectedValue = reader["UnivCode"].ToString();
                CollCode1.Text = reader["CollCode"].ToString();
                PassYear1.Text = reader["PassYear"].ToString();
                RollNo1.Text = reader["RollNo"].ToString();
                Division1.SelectedValue = reader["Division"].ToString();

            } */
            
            // if migarated student
            reader.Close(); 
            cmd.CommandText = "select MigrationNo,MigrationIssueDate from PREREGMIGRATION where RegNo='" + RegNo.Text + "'";
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                MigrationNo.Text = reader["MigrationNo"].ToString();
                MigrationIssueDate.Text =string.Format ("{0:dd/MM/yyyy}",Convert.ToDateTime ( reader["MigrationIssueDate"].ToString()));
                Panel4.Visible = true;
            }
            else
                Panel4.Visible = false; 
 

            reader.Close(); 
            con.Close();

            LblMsg.Text = "";
            Panel2.Visible = true;
           
        }
        else
        {
            LblMsg.Text = " Please check Registration No.";
            Panel2.Visible = false;
            RegNo.Focus(); 
        }
    }

    protected void GetSubComb(string s)
    {
        // Get Subject Combination

        string c = "", h = "", su = "", papercode = "";
        string[] PaperCode = new string[15];
        int i;
        for (i = 0; i < 15; i++)
            PaperCode[i] = "";

        int noofpaper = 0;
        PopulateList poplist = new PopulateList();
        //comp

        if (s.IndexOf('H') - 4 > 0)
        {
            c = s.Substring(2, s.IndexOf('H') - 4);
            for (i = 0; i < c.Length; i++)
            {
                if (c.Substring(i, 1) != ",")
                    papercode = papercode + c.Substring(i, 1);
                else
                {
                    PaperCode[noofpaper] = papercode;
                    noofpaper++;
                    papercode = "";
                }
            }
            PaperCode[noofpaper] = papercode;
            noofpaper++;
        }

        // set Composition paper name in composition paperlist box
        string sql = "";
        for (i = 0; i < noofpaper; i++)
        {
            sql += "CompCode='" + PaperCode[i] + "' OR ";
        }

        if (sql.Length > 3)
        {
            sql = sql.Substring(0, sql.Length - 3);
            sql = "Select Name,compCode from COMPOSITION Where " + sql;
            poplist.Popualate(CompPaper, "COMPOSITION", sql, "Name", "CompCode");

        }

        //honours
        //hon



        if ((s.IndexOf('S') - (s.IndexOf('H') + 4)) > 0)
        {
            h = s.Substring(s.IndexOf('H') + 2, s.IndexOf('S') - (s.IndexOf('H') + 4));

            papercode = "";
            for (i = 0; i < h.Length; i++)
            {


                if (h.Substring(i, 1) != ",")
                    papercode = papercode + h.Substring(i, 1);
                else
                {
                    PaperCode[noofpaper] = papercode;
                    noofpaper++;
                    papercode = "";
                }
            }
            PaperCode[noofpaper] = papercode;
            noofpaper++;

        }
        // set honours paper name in honours paperlist box
        sql = "";
        for (i = 0; i < noofpaper; i++)
        {
            sql += "SubPaperCode='" + PaperCode[i] + "' OR ";
        }

        if (sql.Length > 3)
        {
            sql = sql.Substring(0, sql.Length - 3);
            sql = "Select PaperName,SubPaperCode from COURSEPAPERS Where " + sql;


            poplist.Popualate(HPaper, "COURSEPAPERS", sql, "PaperName", "SubPaperCode");
        }

        //sub
        noofpaper = 0; sql = "";

        if ((s.Length - (s.IndexOf('S') + 3)) > 0)
        {
            su = s.Substring(s.IndexOf('S') + 2, s.Length - (s.IndexOf('S') + 3));

            papercode = "";
            for (i = 0; i < su.Length; i++)
            {


                if (su.Substring(i, 1) != ",")
                    papercode = papercode + su.Substring(i, 1);
                else
                {
                    PaperCode[noofpaper] = papercode;
                    noofpaper++;
                    papercode = "";
                }
            }
            PaperCode[noofpaper] = papercode;
            noofpaper++;
        }

        // set subsidiary paper name in subsidiary paperlist box

        sql = "";
        for (i = 0; i < noofpaper; i++)
        {
            sql += "SubCode='" + PaperCode[i] + "' OR ";
        }
        if (sql.Length > 3)
        {
            sql = sql.Substring(0, sql.Length - 3);
            sql = "Select SubCode,SubjectName from SUBJECT Where " + sql;
            poplist.Popualate(SPaper, "SUBJECT", sql, "SubjectName", "SubCode");
        }



        //------------ End Of Subject Combination
    }
   
}
