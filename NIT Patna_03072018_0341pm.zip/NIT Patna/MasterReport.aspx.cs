using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class MasterReport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "1") && (Session["Role"].ToString() != "10") && (Session["Role"].ToString() != "15"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            string param = "";
            param = Request.QueryString["Report"];
            //Response.Write(param);

            if (param == "District")
            {
                
                crs.Report.FileName = @"Report\District.rpt"; 
                Panel1.Visible = true;
                CR.ReportSource = crs;
                CR.RefreshReport();
            }
            else if (param == "University")
            {
                crs.Report.FileName = @"Report\University.rpt";
                Panel1.Visible = true;
                CR.ReportSource = crs;
                CR.RefreshReport();
            }
            else if (param == "College")
            {
                crs.Report.FileName = @"Report\College.rpt";
                Panel1.Visible = true;
                CR.ReportSource = crs;
                CR.RefreshReport();
            }
            else if (param == "Category")
            {
                crs.Report.FileName = @"Report\Category.rpt";
                Panel1.Visible = true;
                CR.ReportSource = crs;
                CR.RefreshReport();
            }
            else if (param == "Cast")
            {
                
            }
            else if (param == "Seat")
            {
                crs.Report.FileName = @"Report\SeatAllocation.rpt";
                Panel1.Visible = true;
                CR.ReportSource = crs;
                CR.RefreshReport();
            }
            else if (param == "Stream")
            {
                crs.Report.FileName = @"Report\StreamList.rpt";
                Panel1.Visible = true;
                CR.ReportSource = crs;
                CR.RefreshReport();
            }
            else if (param == "Course")
            {
                crs.Report.FileName = @"Report\Course.rpt";
                Panel1.Visible = true;
                CR.ReportSource = crs;
                CR.RefreshReport();
            }
            else if (param == "CoursePart")
            {
                crs.Report.FileName = @"Report\StreamPart.rpt";
                Panel1.Visible = true;
                CR.ReportSource = crs;
                CR.RefreshReport();
            }
            else if (param == "Subject")
            {
                crs.Report.FileName = @"Report\CourseWsieSubjectList.rpt";
                Panel1.Visible = true;
                CR.ReportSource = crs;
                CR.RefreshReport();
            }
            else if (param == "Hons")
            {
                crs.Report.FileName = @"Report\CourseWiseHonsPaperList.rpt";
                Panel1.Visible = true;
                CR.ReportSource = crs;
                CR.RefreshReport();
            }

            else if (param == "Comp")
            {
                crs.Report.FileName = @"Report\CompositionPaperList.rpt";
                Panel1.Visible = true;
                CR.ReportSource = crs;
                CR.RefreshReport();
            }
            else if (param == "Sub")
            {
                crs.Report.FileName = @"Report\SubsidiaryList.rpt";
                Panel1.Visible = true;
                CR.ReportSource = crs;
                CR.RefreshReport();
            }
            else if (param == "User")
            {
                crs.Report.FileName = @"Report\UserMaster.rpt";
                Panel1.Visible = true;
                CR.ReportSource = crs;
                CR.RefreshReport();
            }
            else if (param == "Faculty")
            {
                crs.Report.FileName = @"Report\Faculty.rpt";
                Panel1.Visible = true;
                CR.ReportSource = crs;
                CR.RefreshReport();
            }


            else
            { 
            }

           // CrystalReportViewer1.BackColor = System.Drawing.Color.Red;

            CR.BackColor = System.Drawing.Color.White;
            CR.BestFitPage = true;
        }
    }
}
