using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Data.SqlClient;

using System.Data.Odbc;


public partial class DemandLetter : System.Web.UI.Page
{
    string adyear ="";
    string  streamtypecode = "";
    int rec1 = 0;

    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {


        if (!Page.IsPostBack)
        {
           LoadReport();
        }
        if (!Page.IsPostBack)
        {

            try
            {
                if (Session["Role"].ToString() != "1" && Session["Role"].ToString() != "10" && Session["Role"].ToString() != "16")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
        }
    }



    protected void LoadReport()
    {

       


    }


    protected void txtsubmit_Click(object sender, EventArgs e)
    {
        Session["roll"] = txtrollno.Text.Trim();
        Session["name"] = txtName.Text.Trim();
        Session["sem"] = txtsem.Text.Trim();
        Session["nextsem"] = txtnextsem.Text;
        Session["program"] = txtprogram.Text;

        Session["fname"] = txtfname.Text;
      Response.Redirect("Demandlatterreport.aspx");


      // LoadReport();

     //   txtsubmit.Text = adyear;



        
       









         
    }
    protected void btngetdetails_Click1(object sender, EventArgs e)
    {
        



        

        try
        {






            string query = "select ApplicantName from REGISTRATION where TempRollNo='" + txtrollno.Text.Trim() + "' ";
            object RegNo = fnrev.singlevalue(query);

            txtName.Text = RegNo.ToString();
            query = "select fathername from REGISTRATION where TempRollNo='" + txtrollno.Text.Trim() + "' ";
            RegNo = fnrev.singlevalue(query);

            txtfname.Text = RegNo.ToString();


            query = "SELECT  distinct STREAM.StreamAbbr FROM  STREAM INNER JOIN  STREAMPART ON STREAM.StreamCode = STREAMPART.StreamCode INNER JOIN  EXAMPAPERDETAIL ON STREAMPART.StreamPartCode = EXAMPAPERDETAIL.StreamPartCode and UnivRollNo='" + txtrollno.Text.Trim() + "' ";
            RegNo = fnrev.singlevalue(query);

            txtprogram.Text = RegNo.ToString();


            query = "SELECT  distinct max(STREAMPART.StreamPartCode) FROM  STREAM INNER JOIN  STREAMPART ON STREAM.StreamCode = STREAMPART.StreamCode INNER JOIN  EXAMPAPERDETAIL ON STREAMPART.StreamPartCode = EXAMPAPERDETAIL.StreamPartCode and UnivRollNo='" + txtrollno.Text.Trim() + "'  ";
            RegNo = fnrev.singlevalue(query);
            query = "select STREAMPART from STREAMPART where StreamPartCode='" + RegNo + "' ";
            RegNo = fnrev.singlevalue(query);

            string rec = RegNo.ToString().Substring(4);
            txtsem.Text = RegNo.ToString();
             rec1 = Convert.ToInt32(rec) + 1;

          

            txtnextsem.Text = "sem "+rec1.ToString();




            query = "select AdmYear,ActualAdmYear from REGISTRATION where TempRollNo='"+txtrollno.Text.Trim()+"'";


            DataTable Formdetails;
            Formdetails = fnrev.SelectDatatable(query);
            if (Formdetails.Rows.Count > 0)
            {
                if (Formdetails.Rows[0]["ActualAdmYear"].ToString() != "")
                {
                    adyear = Formdetails.Rows[0]["ActualAdmYear"].ToString();
                }
                else
                {
                    adyear = Formdetails.Rows[0]["AdmYear"].ToString();
                }

            }

       

        }
        catch (Exception ex)
        {
        }





        try
        {
            string query1 = "SELECT distinct STREAM.StreamTypeCode FROM  REGISTRATION INNER JOIN  STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode cross JOIN Feetype where TempRollNo='" + txtrollno.Text.Trim() + "'";
            object RegNo = fnrev.singlevalue(query1);
            streamtypecode = RegNo.ToString();
            Session["stramtypecode"] = streamtypecode;
        }
        catch (Exception ex)
        {
        }









        Session["year"] = adyear;
        Session["oddeven"] = rec1.ToString();


    }
}
