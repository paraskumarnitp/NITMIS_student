using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using GenCode128;
using System.Drawing;
using System.IO;
using System.Threading;

public partial class CertificateGeneration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();

            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College where collcode in (select distinct collcode from exam) order by CollName", "CollName", "CollCode");
            popddl.Popualate(ExamYear, "Exam", "Select distinct ExamYear from Exam order by ExamYear", "ExamYear", "ExamYear");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from exam) order by StreamAbbr", "StreamAbbr", "StreamCode");
            CourseValue();



        }

    }

    protected void CourseValue()
    {
        PopulateDDL popddl = new PopulateDDL();
        //popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart, StreamPartCode from StreamPart where streamcode='" + StreamCode.SelectedValue + "' and streampartcode in (select distinct streampartcode from exam) order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");


    }
    
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        CourseValue();
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }

    protected void BtnGenerate_Click(object sender, EventArgs e)
    {

        try
        {

            // For Diploma ................. 1 Year Diploma
            SqlConnection con = new SqlConnection();
            SqlDataReader rd;
            SqlCommand cmd = new SqlCommand();

            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;

            string sql = "";

            if (StreamCode.SelectedValue == "01")
            {
                // Select Data From TRDiploma for the selected year......
                sql = "select RegNo,Univrollno,CollCode,StreamCode,SubCode,EName,ExamYear,ExamHeldDate,Grade,Promoted from TRDiploma where CollCode='" + CollCode.SelectedValue.ToString() + "' and ExamYear='" + ExamYear.SelectedValue.ToString() + "' and StreamCode='" + StreamCode.SelectedValue.ToString() + "' and SubCode='" + SubCode.SelectedValue.ToString() + "' and Grade<>'F'  ";
            }
            else if (StreamCode.SelectedValue == "03")
            {
                // Select Data From TRDiploma for the selected year......
                sql = "select RegNo,Univrollno,CollCode,StreamCode,EName,ExamYear,ExamHeldDate,Grade,Promoted from TRVoc where CollCode='" + CollCode.SelectedValue.ToString() + "' and ExamYear='" + ExamYear.SelectedValue.ToString() + "' and StreamCode='" + StreamCode.SelectedValue.ToString() + "'  and Grade<>'F'  ";
            }



            cmd.CommandText = sql;
            con.Open();
            rd = cmd.ExecuteReader();

            int TotCount = 0;

            if (rd.HasRows)
            {
                UnivService.Service1 NicService = new UnivService.Service1();


                string AckNo = "";
                string DegreeNo = "";
                string StreamName = "";
                string CourseSession = "";
                //string BarCodeData = "";
                string PassMonth = "";

                string[] col = new string[17];
                string[] val = new string[17];


                col[0] = "DegreeNo";
                col[1] = "RegNo";
                col[2] = "UnivRollNo";
                col[3] = "CollCode";
                col[4] = "StreamCode";
                col[5] = "SubCode";
                col[6] = "ApplicantName";
                col[7] = "CourseSession";
                col[8] = "StreamName";
                col[9] = "PassMonth";
                col[10] = "PassYear";
                col[11] = "PassDivision";
                col[12] = "ConvocationDate";
                col[13] = "BarCodeImage";
                col[14] = "BarCodeData";
                col[15] = "DegreeSLNo";
                col[16] = "AckNo";

                while (rd.Read())
                {

                    try
                    {
                        string SQL = "SELECT     ISNULL(MAX(ABS(DegreeSLNo)), '0') + 1 AS NewDegreeNo FROM  CertificateDetails ";
                        string NewDegreeNo = NicService.GetNewCode(SQL);

                        //string NewDegreeNo = TotCount.ToString();

                        DegreeNo = ConvocationDate.Text.Substring(6, 4) + "/" + string.Format("{0:D5}", Convert.ToInt32(NewDegreeNo));

                        CourseSession = NicService.GetNewCode("Select CourseSession from Registration where regno='" + rd["regno"].ToString() + "'");
                        AckNo = NicService.GetNewCode("Select Ackno from Registration where regno='" + rd["regno"].ToString() + "'");                        
                        
                        StreamName = NicService.GetNewCode("Select stream from stream where streamcode='" + rd["StreamCode"].ToString() + "'");
                        PassMonth = rd["ExamHeldDate"].ToString().Substring(0, rd["ExamHeldDate"].ToString().Length - 5);
                        //System.Drawing.Image myimg;
                        //Bitmap bmp1;
                        try
                        {

                            System.Drawing.Image myimg = Code128Rendering.MakeBarcodeImage(rd["RegNo"].ToString(), int.Parse("2"), true);
                            Bitmap bmp1 = new Bitmap(myimg);
                            string s = Server.MapPath("./Image/TempBarcode/barcode" + rd["RegNo"].ToString() + ".jpg");
                            bmp1.Save(s, System.Drawing.Imaging.ImageFormat.Jpeg);
                            //Thread th = new Thread();
                            bmp1.Dispose();
                            myimg.Dispose();
                            Thread.Sleep(10000);
                            //GC.Collect();
                        }
                        catch (Exception ex)
                        {
                            Label1.Text = ex.Message.ToString() + " -" + rd["RegNo"].ToString();
                        }

                        finally
                        {
                            //bmp1.Dispose();
                            //myimg.Dispose();
                        }
                        
                        //Image1.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadPhoto.JPG";

                        //byte[] imageData = ReadFile(Server.MapPath("./Image/barcodeTempCertificate.jpg"));
                        byte[] imageData = ReadFile(Server.MapPath("./Image/TempBarcode/barcode" + rd["RegNo"].ToString() + ".jpg"));

                        //byte[] imageData = ReadFile(Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/barcodeTempCertificate.jpg");


                        val[0] = DegreeNo;
                        val[1] = rd["RegNo"].ToString();
                        val[2] = rd["UnivRollNo"].ToString();
                        val[3] = rd["CollCode"].ToString();
                        val[4] = rd["StreamCode"].ToString();
                        val[5] = SubCode.SelectedValue.ToString();
                        val[6] = rd["EName"].ToString();
                        val[7] = CourseSession;
                        val[8] = StreamName;
                        val[9] = PassMonth;
                        val[10] = rd["ExamYear"].ToString();
                        val[11] = rd["Promoted"].ToString();
                        val[12] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(ConvocationDate.Text.Trim()));
                        val[13] = "";
                        val[14] = rd["RegNo"].ToString();  // bar code data
                        val[15] = NewDegreeNo;
                        val[16] = AckNo;

                        StreamName = NicService.SaveData("CertificateDetails", col, val);
                        if (StreamName == "1")
                        {
                            // Update Image in Database...............

                            SqlConnection CN = new SqlConnection();
                            CN.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

                            //Set insert query
                            string qry = "update CertificateDetails set BarCodeImage=@ImageData where BarCodeData=@RegNo";

                            //Initialize SqlCommand object for insert.
                            SqlCommand SqlCom = new SqlCommand(qry, CN);

                            //We are passing Original Image Path and Image byte data as sql parameters.
                            SqlCom.Parameters.Add(new SqlParameter("@Regno", (object)rd["RegNo"].ToString()));
                            SqlCom.Parameters.Add(new SqlParameter("@ImageData", (object)imageData));

                            //Open connection and execute insert query.
                            CN.Open();
                            SqlCom.ExecuteNonQuery();
                            CN.Close();
                            SqlCom.Dispose();
                            //File.Delete("D:\\barcodeTempCertificate.jpg");

                            //Thread.Sleep(10000);
                            //----------

                            TotCount++;
                        }
                    }
                    catch (Exception ex)
                    {
                        LblMsg.Text = ex.Message.ToString();
                    }

                }


                LblMsg.Text = "Total Record - " + TotCount + " Successfully inserted. ";

            }

            con.Close();
        }
        catch(Exception ex)
        {
            LblMsg.Text = ex.Message.ToString();
        }



    }


    //Open file into a filestream and 
    //read data in a byte array.
    public byte[] ReadFile(string sPath)
    {
        //Initialize byte array with a null value initially.
        byte[] data = null;

        //Use FileInfo object to get file size.
        FileInfo fInfo = new FileInfo(sPath);
        long numBytes = fInfo.Length;

        //Open FileStream to read file
        FileStream fStream = new FileStream(sPath, FileMode.Open,FileAccess.Read);

        //Use BinaryReader to read file stream into byte array.
        BinaryReader br = new BinaryReader(fStream);

        //When you use BinaryReader, you need to 

        //supply number of bytes to read from file.
        //In this case we want to read entire file. 

        //So supplying total number of bytes.
        data = br.ReadBytes((int)numBytes);
        return data;
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        SqlDataReader rd;
        SqlCommand cmd = new SqlCommand();

        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.Connection = con;

        string sql = "Select Regno from CertificateDetails where DegreeSLNo<='00300' and BarCodeImage is null";

        cmd.CommandText = sql;
        con.Open();
        rd = cmd.ExecuteReader();

        int count = 0;

        while (rd.Read())
        {

        
            try
            {

                System.Drawing.Image myimg = Code128Rendering.MakeBarcodeImage(rd["RegNo"].ToString(), int.Parse("2"), true);
                Bitmap bmp1 = new Bitmap(myimg);
                string s = Server.MapPath("./Image/TempBarcode/barcode" + rd["RegNo"].ToString() + ".jpg");
                bmp1.Save(s, System.Drawing.Imaging.ImageFormat.Jpeg);
                //Thread th = new Thread();
                bmp1.Dispose();
                myimg.Dispose();
                Thread.Sleep(10000);
                //GC.Collect();
            }
            catch (Exception ex)
            {
                Label1.Text = ex.Message.ToString() + " -" + rd["RegNo"].ToString();
            }

            byte[] imageData = ReadFile(Server.MapPath("./Image/TempBarcode/barcode" + rd["RegNo"].ToString() + ".jpg"));




            // Update Image in Database...............

            try
            {

                SqlConnection CN = new SqlConnection();
                CN.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

                //Set insert query
                string qry = "update CertificateDetails set BarCodeImage=@ImageData where BarCodeData=@RegNo";

                //Initialize SqlCommand object for insert.
                SqlCommand SqlCom = new SqlCommand(qry, CN);

                //We are passing Original Image Path and Image byte data as sql parameters.
                SqlCom.Parameters.Add(new SqlParameter("@Regno", (object)rd["RegNo"].ToString()));
                SqlCom.Parameters.Add(new SqlParameter("@ImageData", (object)imageData));

                //Open connection and execute insert query.
                CN.Open();
                SqlCom.ExecuteNonQuery();
                CN.Close();
                SqlCom.Dispose();
                count++;
            }
            catch (Exception ex)
            {
                Label1.Text = ex.Message.ToString() + " -" + rd["RegNo"].ToString();
            }

        }
        LblMsg.Text="Total Records Updated - "+count;

    }
}
