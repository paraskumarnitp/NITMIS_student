using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class Registrationdetails : System.Web.UI.Page
{
    Functionreviseed fn = new Functionreviseed();
    PopulateDDL popddl = new PopulateDDL();
    string qpart = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //Session["checkclear"] = criteria;
            try
            {

                if ((Session["Role"].ToString() != "10") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "11") && (Session["Role"].ToString() != "14") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "15") && (Session["Role"].ToString() != "16"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }               

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }
            
            popddl.Popualate(ExamYear, "Year", "select distinct ExamSession from EXAMPAPERDETAIL order by ExamSession desc", "ExamSession", "ExamSession");

            ExamYear.Items.Insert(0, new ListItem("--Select--", "00"));
            StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
            StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
            
        }

    }
    protected void facultycriteria()
    {
        string uid = Session["UserId"].ToString();
        if (uid == "fc017") qpart = "";
        else
        {
            string deptcode = (fn.singlevalue("Select Designation From Login Where Userid = '" + Session["UserId"].ToString() + "'")).ToString();
            if (deptcode == "ME") qpart = "and STREAMPART.StreamCode IN ('01','26','36')";
            else if (deptcode == "CE") qpart = "and STREAMPART.StreamCode IN ('03','23','37')";
            else if (deptcode == "EE") qpart = "and STREAMPART.StreamCode IN ('02','21','35')";
            else if (deptcode == "ECE") qpart = "and STREAMPART.StreamCode IN ('04','29','33')";
            else if (deptcode == "CSE") qpart = "and STREAMPART.StreamCode IN ('06','07','28','38','32','43')";
            else if (deptcode == "Arch") qpart = "and STREAMPART.StreamCode IN ('05','31','30,'40')";
            else qpart = "";
        }
    }
    string querypart = "";
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        if (All.Checked == true)
        {
            querypart = "EXAMPAPERDETAIL.ExamSession =" + "'"+ ExamYear.SelectedItem.ToString() +"'";
        }
        else if (streamwise.Checked == true)
        {
            if (StreamCode.SelectedValue.ToString() == "00")
            {
                lblmsg.Text = "Select Branch";
                return;
            }
            if (StreamPart.SelectedValue.ToString() == "00")
            {
                lblmsg.Text = "Select Semester";
                return;
            }
            querypart = "EXAMPAPERDETAIL.ExamSession =" + "'" + ExamYear.SelectedItem.ToString() + "'" + " AND STREAM.StreamAbbr = " + "'" + StreamCode.SelectedItem.ToString() + "'";
        }
        fillredg();
    }
    protected void btnexport_Click(object sender, EventArgs e)
    {
        if (All.Checked == true)
        {
            querypart = "EXAMPAPERDETAIL.ExamSession =" + "'" + ExamYear.SelectedItem.ToString() + "'";
        }
        else if (streamwise.Checked == true)
        {
            if (StreamCode.SelectedValue.ToString() == "00")
            {
                lblmsg.Text = "Select Branch";
                return;
            }
            if (StreamPart.SelectedValue.ToString() == "00")
            {
                lblmsg.Text = "Select Semester";
                return;
            }
            querypart = "EXAMPAPERDETAIL.ExamSession =" + "'" + ExamYear.SelectedItem.ToString() + "'" + " AND STREAM.StreamAbbr = " + "'" + StreamCode.SelectedItem.ToString() + "'";
        }

         string query = "SELECT EXAMPAPERDETAIL.UnivRollNo AS RollNo, REGISTRATION.AckNo AS Enrollmentno, REGISTRATION.ApplicantName, STREAM.StreamAbbr, STREAMPART.StreamPart, " + 
            " CourseSpecialization.SpDescription, COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName, COURSEPAPERS.L, COURSEPAPERS.T, COURSEPAPERS.P,COURSEPAPERS.Credit, " + 
            " COURSEPAPERS.PaperTypeCode, ISNULL(COURSEPAPERS.FullMarks, 0) + ISNULL(PRACTICALPAPERS.FullMarks, 0) AS FullMarks, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.ExamYear, " + 
            " EXAMPAPERDETAIL.ExamSession, REGISTRATION.AdmYear, CATEGORY.Category FROM EXAMPAPERDETAIL INNER JOIN REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo INNER JOIN " + 
            " STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode INNER JOIN STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN COURSEPAPERS ON " + 
            " EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN CourseSpecialization ON REGISTRATION.SplCode = CourseSpecialization.SPCode LEFT OUTER JOIN " + 
            " CATEGORY ON REGISTRATION.PhCategory = CATEGORY.CategoryCode LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE " +
            " " + querypart + " AND (EXAMPAPERDETAIL.RegNo IN (SELECT DISTINCT RegNo FROM EXAM WHERE (ExamSession = '" + ExamYear.SelectedItem.ToString() + "') AND (Status = 'SUBMIT'))) AND (ISNULL(REGISTRATION.MigrationStatus, 'N') = 'N')"; 

        /*string query = "SELECT     EXAMPAPERDETAIL.UnivRollNo AS RollNo, REGISTRATION.AckNo AS Enrollmentno, REGISTRATION.ApplicantName, STREAM.StreamAbbr, STREAMPART.StreamPart, " + 
            " CourseSpecialization.SpDescription, COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName, COURSEPAPERS.L, COURSEPAPERS.T, COURSEPAPERS.P, COURSEPAPERS.Credit, " + 
            " COURSEPAPERS.PaperTypeCode, ISNULL(COURSEPAPERS.FullMarks, 0) + ISNULL(PRACTICALPAPERS.FullMarks, 0) AS FullMarks, EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.ExamYear, " + 
            " EXAMPAPERDETAIL.ExamSession, REGISTRATION.AdmYear, CATEGORY.Category, CoursePaperOfferedType.Name " + 
            " FROM EXAMPAPERDETAIL INNER JOIN REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo INNER JOIN STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode " + 
            " INNER JOIN STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode " + 
            " INNER JOIN CourseSpecialization ON REGISTRATION.SplCode = CourseSpecialization.SPCode LEFT OUTER JOIN CoursePaperOfferedType INNER JOIN CourseCodeOffered INNER JOIN " + 
            " CourseCodeOfferedDetail ON CourseCodeOffered.Id = CourseCodeOfferedDetail.CourseCodeOfferedId ON CoursePaperOfferedType.Id = CourseCodeOfferedDetail.OfferedTypeId ON " + 
            " COURSEPAPERS.SubPaperCode = CourseCodeOfferedDetail.SubPaperCode AND REGISTRATION.SplCode = CourseCodeOffered.Splcode LEFT OUTER JOIN CATEGORY ON REGISTRATION.PhCategory = CATEGORY.CategoryCode " +
            " LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE     (EXAMPAPERDETAIL.ExamSession = '" + ExamYear.SelectedItem.ToString() + "') AND (EXAMPAPERDETAIL.RegNo IN (SELECT DISTINCT RegNo FROM EXAM " +
            " WHERE (ExamSession = '" + ExamYear.SelectedItem.ToString() + "') AND (Status = 'SUBMIT'))) AND (ISNULL(REGISTRATION.MigrationStatus, 'N') = 'N') AND (CourseCodeOffered.ExamSession = '" + ExamYear.SelectedItem.ToString() + "')"; */

        /* string query = "SELECT EXAMPAPERDETAIL.UnivRollNo AS RollNo, REGISTRATION.AckNo AS Enrollmentno, REGISTRATION.ApplicantName, " +
            " STREAM.StreamAbbr, STREAMPART.StreamPart, COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName, COURSEPAPERS.L, COURSEPAPERS.T, " +
            " COURSEPAPERS.P, COURSEPAPERS.PaperTypeCode, ISNULL(COURSEPAPERS.FullMarks, 0) + ISNULL(PRACTICALPAPERS.FullMarks, 0) AS FullMarks, " +
            " EXAMPAPERDETAIL.ExamType, EXAMPAPERDETAIL.ExamYear, EXAMPAPERDETAIL.ExamSession, REGISTRATION.AdmYear, CATEGORY.Category " +
            " FROM EXAMPAPERDETAIL INNER JOIN REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo INNER JOIN STREAM ON " +
            " REGISTRATION.StreamCode = STREAM.StreamCode INNER JOIN STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN " +
            " COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN CATEGORY ON " +
            " REGISTRATION.PhCategory = CATEGORY.CategoryCode LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
            " WHERE " + querypart + " and EXAMPAPERDETAIL.RegNo IN (SELECT DISTINCT RegNo FROM EXAM WHERE ExamSession = '"+ ExamYear.SelectedItem.ToString() +"' and Status = 'SUBMIT')"; */
        DataSet dsexportexcel = fn.SelectDataset(query);
        if (dsexportexcel.Tables[0].Rows.Count > 0)
        {
            //Create a dummy GridView
            GridView GridView1 = new GridView();
            GridView1.AllowPaging = false;
            GridView1.DataSource = dsexportexcel.Tables[0];
            GridView1.DataBind();
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=Registration_Data_" + DateTime.Now.Date + ".xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                //Apply text style to each Row
                GridView1.Rows[i].Attributes.Add("class", "textmode");

            }
            GridView1.RenderControl(hw);
            //style to format numbers to string
            string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    protected void All_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void streamwise_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void ExamYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        facultycriteria();
        string strstream = "SELECT DISTINCT STREAM.StreamAbbr, STREAM.StreamCode FROM EXAMPAPERDETAIL INNER JOIN STREAMPART ON " + 
            " EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN STREAM ON STREAMPART.StreamCode = STREAM.StreamCode " + 
            " WHERE EXAMPAPERDETAIL.ExamSession = '" + ExamYear.SelectedItem.ToString() + "'" + qpart + "order by StreamCode ";
        popddl.Popualate(StreamCode, "STREAM", strstream, "StreamAbbr", "StreamCode");
        StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
        StreamPart.Items.Clear();
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        //All.Checked = false;
        //streamwise.Checked = false;

    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        StreamPart.Items.Clear();
        string strstream = "SELECT DISTINCT StreamPart, StreamPartCode FROM STREAMPART WHERE StreamCode = '" + StreamCode.SelectedValue + "' ORDER BY StreamPartCode ";
        popddl.Popualate(StreamPart, "STREAMPART", strstream, "StreamPart", "StreamPartCode");
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        //All.Checked = false;
        //streamwise.Checked = false;
    }

    private void fillredg()
    {
        /* gvRedg.DataSource = GetData("SELECT DISTINCT EXAMPAPERDETAIL.UnivRollNo AS RollNo, REGISTRATION.AckNo AS Enrollmentno," + 
            " REGISTRATION.ApplicantName, STREAM.StreamAbbr, EXAMPAPERDETAIL.ExamYear, EXAMPAPERDETAIL.ExamSession " + 
            " FROM EXAMPAPERDETAIL INNER JOIN REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo INNER JOIN " +
            " STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode INNER JOIN STREAMPART ON " + 
            " EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode WHERE " + querypart); */
        gvRedg.DataSource = GetData("SELECT DISTINCT EXAMPAPERDETAIL.UnivRollNo AS RollNo, REGISTRATION.AckNo AS Enrollmentno, " + 
            " REGISTRATION.ApplicantName, STREAM.StreamAbbr, EXAMPAPERDETAIL.ExamYear, EXAMPAPERDETAIL.ExamSession, REGISTRATION.AdmYear, " + 
            " CATEGORY.Category FROM EXAMPAPERDETAIL INNER JOIN REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo " + 
            " INNER JOIN STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode INNER JOIN STREAMPART ON " + 
            " EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode LEFT OUTER JOIN CATEGORY ON REGISTRATION.PhCategory = CATEGORY.CategoryCode " +
            " WHERE " + querypart + " and EXAMPAPERDETAIL.RegNo IN (SELECT DISTINCT RegNo FROM EXAM WHERE ExamSession = '" + ExamYear.SelectedItem.ToString() + "' and Status = 'SUBMIT') AND (ISNULL(REGISTRATION.MigrationStatus, 'N') = 'N')");
        gvRedg.DataBind();
        
    }

    private static DataTable GetData(string query)
    {
        string strConnString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        using (SqlConnection con = new SqlConnection(strConnString))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = query;
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    using (DataSet ds = new DataSet())
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        return dt;
                    }
                }
            }
        }
    }
    protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string enrollmentno = gvRedg.DataKeys[e.Row.RowIndex].Value.ToString();
            
            GridView gvsubjects = e.Row.FindControl("gvsubjects") as GridView;
            gvsubjects.DataSource = GetData(string.Format("SELECT STREAMPART.StreamPart, COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName, " + 
                " COURSEPAPERS.L, COURSEPAPERS.T, COURSEPAPERS.P, COURSEPAPERS.PaperTypeCode, " + 
                " ISNULL(COURSEPAPERS.FullMarks, 0) + ISNULL(PRACTICALPAPERS.FullMarks, 0) AS FullMarks, EXAMPAPERDETAIL.ExamType " + 
                " FROM EXAMPAPERDETAIL INNER JOIN REGISTRATION ON EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo INNER JOIN " + 
                " STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode INNER JOIN STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode " + 
                " INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN " + 
                " PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode WHERE EXAMPAPERDETAIL.ExamSession = '"+ExamYear.SelectedItem.ToString()+"'" +
                " AND REGISTRATION.AckNo = '{0}'", enrollmentno));
            gvsubjects.DataBind();
        }
    }
}
