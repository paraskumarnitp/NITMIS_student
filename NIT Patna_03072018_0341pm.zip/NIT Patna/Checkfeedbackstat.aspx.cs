using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Checkfeedbackstat : System.Web.UI.Page
{
    Functionreviseed fn = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "10")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            bindgrid();
        }

    }
  
    protected void bindgrid()
    {
        string strrole = "";
        if ((Session["Role"].ToString() == "9") && (Session["Role"].ToString() != "14") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "15"))
            strrole = "   where Feedback.userid = '" + Session["UserId"].ToString() + "'";


        string strorder = " order by feedback.EntryDate desc  ";


        string str = "select Feedback.Feedbckid as [Complaint No],messagetype As [Form Type],convert(varchar,feedback.EntryDate,106) as [Entered On] " +
                      " ,status.status , isnull(A.repliedno,0) as [No of Replies], convert(varchar,A.EntryDate,106) as [Last Replied At], Feedback.userid As UserId,Feedback.UserName  " +
                      " from Feedback INNER JOIN Status ON Feedback.status = Status.ID left join (SELECT   FeedbckID,  COUNT(*) AS repliedno " +
                      " ,MAX(EntryDate) as EntryDate FROM         Feedbackstat GROUP BY FeedbckID) As A on A.FeedbckID=Feedback.Feedbckid "+strrole+strorder;
 


        DataTable dt = fn.SelectDatatable(str);
        grdfacupap.DataSource = dt;
        grdfacupap.DataBind();
    }



    protected void grdfacupap_SelectedIndexChanged(object sender, EventArgs e)
    {
        bindrepeater();
        Panel1.Visible = true;
       

    }
    protected void btnSubmit_click(object sender, EventArgs e)
    {
        TextBox txtcomm=new TextBox();
        string textcomm="";
        if (Repeater1.Items.Count > 0)
        {
           txtcomm = (TextBox)Repeater1.Controls[Repeater1.Controls.Count - 1].Controls[0].FindControl("txtcomment1");
           textcomm = txtcomm.Text;
        }
        String str = txtcomment.Text != "" ? txtcomment.Text : textcomm != "" ? textcomm : "";
        string insquery = "INSERT INTO Feedbackstat (FeedbckID, senderuserid, comments, EntryDate) "+
                            " VALUES     ('" + grdfacupap.Rows[grdfacupap.SelectedIndex].Cells[1].Text + "','" + Session["UserId"].ToString() + "','" + str + "',getdate())";
        


         int i = fn.InsertUpdateDelete(insquery);

        if (i == 0)
            {
                string msg = " Could Not Saved!!!. ";
                     string popupScript = " alert('" + msg + " ');" ;
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popupScript", popupScript, true);
                    
            }
            else
            {
                string msg = " Comment Saved!!!. ";
                string popupScript = " alert('" + msg + " ');" ;
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popupScript", popupScript, true);
                txtcomment.Text = "";
                if (txtcomm != null)
                    txtcomm.Text = "";
        
            }
   

         bindgrid();
        bindrepeater();
        

        
    }
    protected void grdfacupap_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdfacupap.PageIndex = e.NewPageIndex;

        bindgrid();
    }

    protected void bindrepeater()
    {
        int i = grdfacupap.SelectedIndex;
        lblfeedback.Text = grdfacupap.Rows[i].Cells[1].Text;
        lblmsgtype.Text = grdfacupap.Rows[i].Cells[2].Text;
        lblstatus.Text = grdfacupap.Rows[i].Cells[4].Text;
        lblentrydt.Text = grdfacupap.Rows[i].Cells[3].Text;
        txtmessage.Text = (string)fn.singlevalue("select message from Feedback where FeedbckID='" + grdfacupap.Rows[i].Cells[1].Text + "'");
        if (grdfacupap.Rows[i].Cells[4].Text == "CLOSED")
        {
            txtcomment.Enabled = false;
            Button1.Enabled = false;
        }
        else
        {
            txtcomment.Enabled = true;
            Button1.Enabled = true;
        
        }
        string str = "SELECT   LogIn.UserName+' ( '+Feedbackstat.senderuserid+' )' as username,  Feedbackstat.comments, " +
                      " CONVERT(varchar,Feedbackstat.EntryDate,106) as EntryDt  " +
                       " FROM         Feedbackstat INNER JOIN " +
                        " LogIn ON Feedbackstat.senderuserid = LogIn.UserId where " +
                        " Feedbackstat.FeedbckID='" + grdfacupap.Rows[i].Cells[1].Text + "' order by EntryDate asc ";
        DataTable dt = fn.SelectDatatable(str);
        if (dt.Rows.Count > 0)
        {
            Repeater1.DataSource = dt;
            Repeater1.DataBind();
        }
        else
        {
            Repeater1.DataSource = null;
            Repeater1.DataBind();
        }
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedValue == "Y")
        {

            string statudid = Session["Role"].ToString() == "9" ? "4" : "3";
            int i = fn.InsertUpdateDelete("Update Feedback set status='"+ statudid +"' where FeedbckID='"+ grdfacupap.Rows[grdfacupap.SelectedIndex].Cells[1].Text +"'");
        
        }
        bindgrid();
        bindrepeater();
    }

    protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Footer)
        {
         if (lblstatus.Text=="CLOSED")
           e.Item.Visible=false;
           // TextBox txtcomment1 = (Label)e.Item.FindControl("txtcomment1");
           //txtcomment1.
        }
    }
}
