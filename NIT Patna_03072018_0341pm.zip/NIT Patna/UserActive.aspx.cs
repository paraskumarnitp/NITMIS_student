using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class UserActive : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {

                if ((Session["Role"].ToString() != "6") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "16"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
                
                PopulateDDL popddl = new PopulateDDL();
                string sql="";
                if (Session["Role"].ToString() == "7")
                {
                    sql = "Select Userid from login where userrole ='9' order by SUBSTRING(UserId,3,3) ";
                }
                else sql = "Select Userid from login where userrole<>'6' order by SUBSTRING(UserId,3,3)";
                popddl.Popualate(UserId, "Login",sql ,"Userid", "Userid");
                BindUserName();

            }
            catch (Exception ex)
            {
                LblMsg.Text = ex.Message;
            }
            UserId.Focus();
        }
    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            string sql = "";
            string abc = "";
            string action = "";

            UnivService.Service1 ss = new UnivService.Service1();
            if (RadioButton1.Checked == true)
            {

                sql = "Update LOGIN Set IsLock='N' where UserId='" + UserId.SelectedValue + "' ";
                action = "Activated";

            }

            else if (RadioButton2.Checked == true)
            {
                sql = "Update LOGIN Set IsLock='Y' where UserId='" + UserId.SelectedValue + "' ";
                action = "Deactivated";
            }
            else
            { 
            
            }

            abc = ss.UpdateData(sql);

            if (abc == "ok")
            {
                LblMsg.Text = UserId.SelectedValue +" has been "+action.ToString()+" Successfully";
                UserId.Focus();
            }

            else
            {
                LblMsg.Text = abc.ToString();
            }
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }

      protected void UserId_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindUserName();
    }
    protected void BindUserName()
    {
        string Uname = "";
        string sql = "";

        UnivService.Service1 ss = new UnivService.Service1();
        sql = "Select UserName From Login where UserId='" + UserId.SelectedValue + "' ";
        Uname = ss.GetNewCode(sql);
        UserName.Text = Uname;
        UserId.Focus();
    }
   
}

