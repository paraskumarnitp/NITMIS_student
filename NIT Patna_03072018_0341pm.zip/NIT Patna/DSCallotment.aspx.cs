using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
public partial class DSCallotment : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    static string hodbranch = "";
    string memberty = "";
   static string roll, regno;
   DataRow dr = null;
   DataTable dt1 = new DataTable();
 int memtypecount = 0, comemtypecount = 0, exmemtypecount = 0, eexmemtypecount = 0, cmemtypecount = 0;
 
    bool ckeck = false,check1=false,check2=false,check3=false;
    protected void Page_Load(object sender, EventArgs e)
    {
        popupcontent.Visible = false;

        try
        {
            //if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "9") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "15"))
            //{
            //    Session["userName"] = null;
            //    FormsAuthentication.SignOut();
            //    Response.Redirect("default.aspx");
            //    return;
            //}
        }
        catch (Exception ex)
        {
            Response.Redirect("default.aspx");

        }


        if (!IsPostBack)
        {
            bindBranch();
           // binddscData();
                    
        }

    }


    public void bindBranch()
    {
        String query = "select DepartmentId from LogIn where UserId like '" + Session["UserId"].ToString() + "'";
        DataSet dsmasterpaper = new DataSet();
        dsmasterpaper = fnrev.SelectDataset(query);

        hodbranch = dsmasterpaper.Tables[0].Rows[0]["DepartmentId"].ToString();

        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(drpbranch, "STREAM", " select stream from STREAM WHERE (STREAM.StreamTypeCode = '03') ", "stream", "stream"); //and StreamCode = '" + hodbranch + "'  
        drpbranch.Items.Insert(0, new ListItem("-SELECT-", "00"));
      

    }

    public void bindData()
    {
        try
        {

            String query = "SELECT DISTINCT REGISTRATION.AckNo,REGISTRATION.regno, REGISTRATION.ApplicantName, REGISTRATION.EmailId, REGISTRATION.ContactNo, REGISTRATION.RegYear,stream FROM  STREAM INNER JOIN  STREAMPART ON STREAM.StreamCode = STREAMPART.StreamCode INNER JOIN  REGISTRATION ON STREAMPART.StreamCode = REGISTRATION.StreamCode WHERE     (STREAM.StreamTypeCode = '03')  AND STREAM=('" + drpbranch .SelectedItem.ToString()+ "')   and AckNo not  in(Select rollno from dscallotment)  ";
            DataSet dsmasterpaper = new DataSet();
            dsmasterpaper = fnrev.SelectDataset(query);
            grdstudetails.DataSource = dsmasterpaper.Tables[0];
            grdstudetails.DataBind();
        }
        catch (Exception ex)
        {

        } 
    }






    public void binddscData()
    {

        dt1.Columns.Add(new DataColumn("id", typeof(int)));
        dt1.Columns.Add(new DataColumn("rollno", typeof(string)));
        dt1.Columns.Add(new DataColumn("regno", typeof(string)));
        dt1.Columns.Add(new DataColumn("membertype", typeof(string)));
        dt1.Columns.Add(new DataColumn("memuserid", typeof(string)));
        dt1.Columns.Add(new DataColumn("member", typeof(string)));
        dt1.Columns.Add(new DataColumn("cuid", typeof(string)));
        dt1.Columns.Add(new DataColumn("ctime", typeof(string)));


        string strConnString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlConnection con = new SqlConnection(strConnString);

        string query = "select * from phdallotment where regno='"+regno+"' order by id";

        // DataSet ds = new DataSet();
        // ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, query);
        con.Open();
        SqlDataReader dr1;
        SqlCommand cmd = new SqlCommand(query, con);

        dr1 = cmd.ExecuteReader();

        if (dr1.Read())
        {


            dr = dt1.NewRow();


            dr["id"] = 1;
            dr["rollno"] = roll;
            dr["regno"] = regno;
            dr["membertype"] = cmbdsctype.SelectedItem.ToString();
            //dr["memuserid"] = userid;
            //dr["member"] = uname;


            dr["cuid"] = Session["UserId"].ToString();
            dr["ctime"] = DateTime.Now.ToString();
            dt1.Rows.Add(dr);
            ViewState["phdstudent"] = dt1;
            grdregistrationdetails.DataSource = dt1;
            grdregistrationdetails.DataBind();

        }

    }




    protected void drpbranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        bindData();
        grdregdetails.Visible = false;
        grdstudetails.Visible = true;
        //grdstudetails.DataSource = dtmis;
        //grdstudetails.DataBind();

    }
    protected void btnok_Click(object sender, EventArgs e)
    {
        try
        {


            String query = "SELECT DISTINCT REGISTRATION.AckNo,REGISTRATION.regno, REGISTRATION.ApplicantName, REGISTRATION.EmailId, REGISTRATION.ContactNo, REGISTRATION.RegYear,stream FROM  STREAM INNER JOIN  STREAMPART ON STREAM.StreamCode = STREAMPART.StreamCode INNER JOIN  REGISTRATION ON STREAMPART.StreamCode = REGISTRATION.StreamCode WHERE     (STREAM.StreamTypeCode = '03')  AND STREAM=('" + drpbranch.SelectedItem.ToString() + "') and   (REGISTRATION.AckNo like '" + txtroll.Text.Trim() + "%')   and  AckNo not  in(Select rollno from dscallotment)  ";

            //String query = "SELECT DISTINCT REGISTRATION.AckNo,REGISTRATION.regno, REGISTRATION.ApplicantName, REGISTRATION.EmailId, REGISTRATION.ContactNo, REGISTRATION.RegYear,stream " +
            //              "FROM  STREAM INNER JOIN  STREAMPART ON STREAM.StreamCode = STREAMPART.StreamCode INNER JOIN " +
            //              " REGISTRATION ON STREAMPART.StreamCode = REGISTRATION.StreamCode WHERE     (STREAM.StreamTypeCode = '03')  AND STREAM=('" + drpbranch.SelectedItem.ToString() + "') and   (REGISTRATION.AckNo like '" + txtroll.Text.Trim() + "%')   ";

            DataTable dtmis = fnrev.SelectDatatable(query);
           
            grdstudetails.DataSource = dtmis;
            grdstudetails.DataBind();


        }
        catch (Exception ex)
        {

        }
        grdregdetails.Visible = false;
       
        grdstudetails.Visible = true;
    }
    protected void grdstudetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        grdstudetails.PageIndex = e.NewPageIndex;
        bindData();
    }
    protected void grdstudetails_SelectedIndexChanged(object sender, EventArgs e)
    {
        roll = (grdstudetails.SelectedRow.FindControl("lblroll") as Label).Text;
        //branch = (grdstudetails.SelectedRow.FindControl("lblbranch") as Label).Text;
        regno = (grdstudetails.SelectedRow.FindControl("lblregno") as Label).Text;


        popupcontent.Visible = true;
        binddscData();




        bindselectedData();

               
    }


    public void  bindselectedData()
    {
        try
        {

            String query = "SELECT DISTINCT REGISTRATION.AckNo,REGISTRATION.regno, REGISTRATION.ApplicantName, REGISTRATION.EmailId, REGISTRATION.ContactNo, REGISTRATION.RegYear,stream " +
                          "FROM  STREAM INNER JOIN  STREAMPART ON STREAM.StreamCode = STREAMPART.StreamCode INNER JOIN " +
                          " REGISTRATION ON STREAMPART.StreamCode = REGISTRATION.StreamCode WHERE     (STREAM.StreamTypeCode = '03')  AND STREAM=('" + drpbranch.SelectedItem.ToString() + "')  and   AckNo='"+roll+"'  ";

            DataSet dsmasterpaper = new DataSet();
            dsmasterpaper = fnrev.SelectDataset(query);
            grdstudetails.DataSource = dsmasterpaper.Tables[0];
            grdstudetails.DataBind();
        }
        catch (Exception ex)
        {

        }

        grdstudetails.Visible = true;
    }



    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            string strConnString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            SqlConnection con = new SqlConnection(strConnString);

            string query = "SELECT DISTINCT REGISTRATION.Ackno as rollno , REGISTRATION.RegNo, REGISTRATION.ApplicantName, dscallotment.cuid  FROM   REGISTRATION INNER JOIN  dscallotment ON REGISTRATION.AckNo = dscallotment.rollno WHERE     (REGISTRATION.StreamCode = '" + hodbranch + "')";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            DataSet ds = new DataSet();
            sda.Fill(ds, "REGISTRATION");

            grdregdetails.DataSource = ds;
            grdregdetails.DataBind();
        }
        catch (Exception ex)
        {
        }
        grdregdetails.Visible = true;
        grdstudetails.Visible = false;
    }
    protected void grdregdetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {


try
{
    if (e.Row.RowType == DataControlRowType.DataRow)
    {

        string roll = grdregdetails.DataKeys[e.Row.RowIndex].Value.ToString();
        GridView grdmember = e.Row.FindControl("gvmember") as GridView;

        string strConnString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlConnection con = new SqlConnection(strConnString);

        string query = "select membertype ,memuserid ,member  from dscallotment where rollno='" + roll + "'";
        SqlDataAdapter sda = new SqlDataAdapter(query, con);
        DataSet ds = new DataSet();
        sda.Fill(ds, "dscallotment");
        grdmember.DataSource = ds;
      //  grdmember.DataSource = GetData(string.Format("select membertype ,memuserid ,member  from dscallotment where rollno='" + roll + "'  "));
        grdmember.DataBind();

        

    }



        }
        catch (Exception ex)
        {
        }
    }


    private static DataTable GetData(string query)
    {
        string strConnString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        using (SqlConnection con = new SqlConnection(strConnString))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = query;
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    using (DataSet ds = new DataSet())
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        return dt;
                    }
                }
            }
        }
    }
    protected void grdsupervisor_SelectedIndexChanged(object sender, EventArgs e)
    {



        string userid = (grdsupervisor.SelectedRow.FindControl("lbluid") as Label).Text;
        string uname = (grdsupervisor.SelectedRow.FindControl("lbluname") as Label).Text;



        string query1 = "INSERT INTO phdallotment(rollno,regno, membertype,memuserid,member,cuid,ctime) VALUES  ('" + roll + "','" + regno + "','" + cmbdsctype.SelectedItem.ToString() + "','"+userid+"','"+uname+"','" + Session["UserId"].ToString() + "',GETDate())";
        fnrev.InsertUpdateDelete(query1);



      
        try
        {

            string strConnString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            SqlConnection con = new SqlConnection(strConnString);

            dt1.Columns.Add(new DataColumn("id", typeof(int)));
            dt1.Columns.Add(new DataColumn("rollno", typeof(string)));
            dt1.Columns.Add(new DataColumn("regno", typeof(string)));
            dt1.Columns.Add(new DataColumn("membertype", typeof(string)));
            dt1.Columns.Add(new DataColumn("memuserid", typeof(string)));
            dt1.Columns.Add(new DataColumn("member", typeof(string)));
            dt1.Columns.Add(new DataColumn("cuid", typeof(string)));
            dt1.Columns.Add(new DataColumn("ctime", typeof(string)));

            con.Open();

            string query = "select * from phdallotment where rollno='" + roll+ "' order by id";


            SqlDataReader dr1;
            SqlCommand cmd = new SqlCommand(query, con);

            dr1 = cmd.ExecuteReader();

            if (dr1.Read())
            {


                dr = dt1.NewRow();


                dr["id"] = 1;
                dr["rollno"] = roll;
                dr["regno"] = regno;

                dr["membertype"] = cmbdsctype.SelectedItem.ToString();
                dr["memuserid"] = userid;
                dr["member"] = uname;

                dr["cuid"] = Session["UserId"].ToString();
                dr["ctime"] = DateTime.Now.ToString();
                dt1.Rows.Add(dr);
                ViewState["phdstudent"] = dt1;
                grdregistrationdetails.DataSource = dt1;
                grdregistrationdetails.DataBind();

            }




        }
        catch (Exception ex)
        {

        }

        popupcontent.Visible = true;




    }
    protected void btnmemserch_Click(object sender, EventArgs e)
    {
        grdsupervisor.Visible = true;

        DataSet ds = new DataSet();
        if (cmbdsctype.SelectedItem.ToString().Equals("External Expert"))
        {
            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select id As UserId ,name As UserName from dscsetting where name like '" + txtmember.Text.Trim() + "%'  and is_Active='1' and membertype='EXTERNAL' ");
            grdsupervisor.DataSource = ds;
        }
        else
        {
            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select UserId,name As UserName from dscsetting where name like '" + txtmember.Text.Trim() + "%'  and is_Active='1' and  membertype='INTERNAL' ");
            grdsupervisor.DataSource = ds;
        }
            grdsupervisor.DataBind();
            popupcontent.Visible = true;
    }


    protected void grdregistrationdetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {


        try
        {


            if (e.Row.RowType == DataControlRowType.DataRow)
            {
            //   string roll = grdregdetails.DataKeys[e.Row.RowIndex].Value.ToString().Trim();
                GridView grdmember = e.Row.FindControl("gvmemberdetails") as GridView;


                grdmember.DataSource = GetData(string.Format("select membertype ,memuserid ,member  from phdallotment where rollno='"+roll+"'  "));
              grdmember.DataBind();

            }

        }
        catch (Exception ex)
        {
        }

    }

    protected void btnConfirm_Click(object sender, EventArgs e)
    {
        string uname = "";
        int count = 0, count1 = 0, count2 = 0, count3 = 0;
        try
        {
         //   string query = "select UserName from LogIn where Userid='" + Session["UserId"].ToString() + "'";
         //   DataSet dsmasterpaper = new DataSet();
         //   dsmasterpaper = fnrev.SelectDataset(query);

         //uname = dsmasterpaper.Tables[0].Rows[0]["UserName"].ToString();

         //   string query1 = "INSERT INTO dscallotment(rollno,regno, membertype,memuserid,member,cuid,ctime) VALUES  ('" +roll+"','" + regno + "','HOD','" + Session["UserId"].ToString() + "','" + uname + "','" + Session["UserId"].ToString() + "',GETDate())";
         //   fnrev.InsertUpdateDelete(query1);

        }
        catch (Exception ex)
        {
        }


        int flag = 0;
      
        try
        {
            String membertype = "", memberid = "", member = "";
            DataTable dt4 = new DataTable();
            dt4 = (DataTable)ViewState["phdstudent"];

            if (ViewState["phdstudent"] != null)
            {
                dt4 = (DataTable)ViewState["phdstudent"];
                if (dt4.Rows.Count > 0)
                {

                    foreach (GridViewRow row in grdregistrationdetails.Rows)
                    {

                        if (row.RowType == DataControlRowType.DataRow)
                        {

                            GridView gvChild = (GridView)row.FindControl("gvmemberdetails");

                            for (int j = 0; j < gvChild.Rows.Count; j++)
                            {


                                Label memtype = (Label)gvChild.Rows[j].Cells[1].FindControl("lblmemtype");
                                membertype = memtype.Text;
                                memtype = (Label)gvChild.Rows[j].Cells[2].FindControl("lblmemid");
                                memberid = memtype.Text;
                                memtype = (Label)gvChild.Rows[j].Cells[3].FindControl("lblmemname");
                                member = memtype.Text;


                                string query = "select membertype from phdallotment where membertype='" + membertype + "'";
                                DataSet dsmasterpaper = new DataSet();
                                dsmasterpaper = fnrev.SelectDataset(query);

                                string memtype1 = dsmasterpaper.Tables[0].Rows[0]["membertype"].ToString();


                                if (memtype1 == "Supervisor")
                                {
                                    memberty = "Supervisor";
                                    memtypecount++;
                                   
                                }
                                else  if (memtype1 == "Co-Supervisor")
                                {
                                    memberty = "Co-Supervisor";
                                    comemtypecount++;
                                  
                                }
                                //else if (memtype1 == "Care Taker")
                                //{
                                //    memberty = "Care Taker";
                                //    cmemtypecount++;
                                   
                                //}
                                else  if (memtype1 == "Expert")
                                {
                                    memberty = "Expert";
                                    exmemtypecount++;
                                   
                                }
                                else if (memtype1 == "External Expert")
                                {
                                    memberty = "External Expert";
                                    eexmemtypecount++;
                                   
                                }


                                if (memtypecount ==1)
                                {
                                    Label2.Text = " One  " + " Supervisor" + " Allowed";
                                   count=1;

                                }
                                else 
                                {
                                    count =0;
                                }
                                 if (comemtypecount == 2)
                                {
                                    Label2.Text = "  Two " + " Co-Supervisor " + " Allowed";
                                   count1=1;
                                }
                             else
                                 {
                                     count1=0;
                                 }
                              if (exmemtypecount ==1)
                                {
                                    Label2.Text = " One " + " Expert " + " Allowed";

                                    count2 = 1;

                                }
                              else
                              {
                                  count2=0;
                              }
                              if (eexmemtypecount == 1)
                                {
                                    Label2.Text = " One " + " External Expert " + " Allowed";
                                    count3 = 1;
                                }
                                else
                                {
                                    count3 = 0;

                                }


                            }
                           
                        }
                    }


                }
            }


        }
        catch (Exception ex)
        {
        }






        if (count == 1 && count1==1  && count2==1 && count3==1)
        {
         
            string query = "select UserName from LogIn where Userid='" + Session["UserId"].ToString() + "'";
            DataSet dsmasterpaper = new DataSet();
            dsmasterpaper = fnrev.SelectDataset(query);

            uname = dsmasterpaper.Tables[0].Rows[0]["UserName"].ToString();


            string query2 = "INSERT INTO dscallotment(rollno,regno, membertype,memuserid,member,cuid,ctime) VALUES  ('" + roll + "','" + regno + "','HOD','" + Session["UserId"].ToString() + "','" + uname + "','" + Session["UserId"].ToString() + "',GETDate())";
            fnrev.InsertUpdateDelete(query2);


            try
            {


                String membertype = "", memberid = "", member = "";
                DataTable dt4 = new DataTable();
                dt4 = (DataTable)ViewState["phdstudent"];



                if (ViewState["phdstudent"] != null)
                {
                    dt4 = (DataTable)ViewState["phdstudent"];
                    if (dt4.Rows.Count > 0)
                    {

                        foreach (GridViewRow row in grdregistrationdetails.Rows)
                        {
                            if (row.RowType == DataControlRowType.DataRow)
                            {
                                GridView gvChild = (GridView)row.FindControl("gvmemberdetails");

                                for (int j = 0; j < gvChild.Rows.Count; j++)
                                {


                                    Label memtype = (Label)gvChild.Rows[j].Cells[1].FindControl("lblmemtype");
                                    membertype = memtype.Text;
                                    memtype = (Label)gvChild.Rows[j].Cells[2].FindControl("lblmemid");
                                    memberid = memtype.Text;
                                    memtype = (Label)gvChild.Rows[j].Cells[3].FindControl("lblmemname");
                                    member = memtype.Text;
                                    Label2.Text = "";

                                    //string strConnString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
                                    //SqlConnection con = new SqlConnection(strConnString);
                                    //con.Open();
                                    //SqlCommand cmd = new SqlCommand("select memuserid from dscallotment where  memuserid='" + memberid + "' and rollno='"+roll+"' ", con);
                                    //SqlDataReader dr = cmd.ExecuteReader();
                                    //if (dr.Read())
                                    //{
                                    //    Label2.Text = memberid + "is alloted for  " + membertype + "So select Another Member of " + membertype + "Post";

                                    //}

                                    //else
                                    //{
                                        string query1 = "INSERT INTO dscallotment(rollno,regno, membertype,memuserid,member,cuid,ctime) VALUES  ('" + roll + "','" + regno + "','" + membertype + "','" + memberid + "','" + member + "','" + Session["UserId"].ToString() + "',GETDate())";

                                        fnrev.InsertUpdateDelete(query1);
                                        flag = 1;

                                    //}
                                  //  con.Close();


                                }

                                if (flag == 1)
                                {
                                    query2 = "delete from phdallotment";

                                    fnrev.InsertUpdateDelete(query2);
                                    lblCinfirm.Text = "DSC alloted Sucessfully..";
                                    memtypecount = 0;
                                    comemtypecount = 0;
                                    exmemtypecount = 0;
                                    eexmemtypecount = 0;
                                    cmemtypecount = 0;
                                }
                            }

                     }
                    }
                }


            }
            catch (Exception ex)
            {
            }

        }
        else
        {




        Label2.Text = " Not " + " Exact  " + " Member Selected";

        }




        popupcontent.Visible = true;
        Label2.Visible = false;


    }
    protected void btnExit_Click(object sender, EventArgs e)
    {
        popupcontent.Visible = false;
        Label2.Visible = false;
        bindData();


    }
    protected void gvmemberdetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {


        GridView gvmember = sender as GridView;
        string memid = (gvmember.DataKeys[e.RowIndex].Value).ToString();
        string name = ((Label)gvmember.Rows[e.RowIndex].FindControl("lblmemtype")).Text;
        if (name == "Supervisor")
        {
            memtypecount--;
        }
        else if (name == "Co-Supervisor")
        {
            comemtypecount--;

        }
        else if (name == "Expert")
        {
            exmemtypecount--;

        }
        else if (name == "External Expert")
        {
            eexmemtypecount--;

        }
        this.Delete(memid);

        binddscData();
        //
        //

        //grdregistrationdetails.Visible = true;
        popupcontent.Visible=true;
        

    }



    private void Delete(string memid)
    {
        string constr = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        string sqlStatment = "DELETE FROM  phdallotment WHERE memuserid = @memuserid";
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand(sqlStatment, con))
            {
                con.Open();
                cmd.Parameters.AddWithValue("@memuserid", memid);
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        grdregistrationdetails.Visible = true;

    }



    protected void grdregistrationdetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        grdregistrationdetails.Visible = true;
    }
}
