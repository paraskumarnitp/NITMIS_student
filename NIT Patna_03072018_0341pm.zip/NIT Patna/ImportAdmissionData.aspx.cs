using System;
using System.Data;
using System.Data.OleDb;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class ImportAdmissionData : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "1")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            

            PopulateDDL popddl = new PopulateDDL();
            //popddl.Popualate(College, "CollName", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(Year, "Year", "Select Year from Year where year >='2008' order by Year ", "Year", "Year");
            //ViewState.Add("EditMode", "false");
            //ViewState.Add("DeleteFlag", "0");
            //CategoryNm.Focus();
        }
        

    }
    protected void BtnImport_Click(object sender, EventArgs e)
    {

            int RecordImported = 0,TotRecord=0;
            LblMsg2.Text = ""; 
            SqlCommand SqlCmd= new SqlCommand ();
            SqlConnection SqlCon = new SqlConnection();
            SqlCon.ConnectionString =  ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            SqlCon.Open();
            SqlCmd.Connection  = SqlCon;
            
            OleDbConnection con = new OleDbConnection();
            //con.ConnectionString = "Dsn=College";
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\CollegeDataBase\" + FileUpload1.FileName.ToString()+";Jet OLEDB:Database Password=college@123";
            con.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = con;
            cmd.CommandText = "SELECT T.AckNo,RegNo,Registration.RegYear,ApplicantName, HindiName, FatherName, MotherName, DOB, ReligionCode, Gender, MaritalStatus, CastCode, NationalityCode, BloodGroup, EmailId, ContactNo, PermanentAddress1, PermanentAddress2, PermanentDistCode, PermanentPinCode, PresentAddress1, PresentAddress2, PresentDistrictCode, PresentPinCode, StreamCode, StreamPartCode, CollCode, SubCode, CollegeAdmissionDate, RollNo, CourseSession, SubCombCode, Photo, T.RegFormNo, T.SCBNo, T.SCBDate, T.RegYear as RegYear, T.RegFeeAmt,T.SendToUni, UserId, EntryOptDateTime " +
                              " FROM Registration, RegFeeDetails AS T WHERE Registration.ackno in (select ackno from RegFeeDetails where SendToUni='N') And T.AckNo=Registration.AckNo And Registration.RegYear='"+Year.SelectedValue +"'" ;
        
            OleDbDataReader rd = cmd.ExecuteReader();
            string AckNo_List = "(";
            
            try
            {
                while (rd.Read())
                {
                    if (rd["sendToUni"].ToString() == "N")
                    {

                        string a = rd["photo"].ToString();
                        if (a != "")
                        {
                            SqlCmd.CommandText = "insert into registration (AckNo, RegNo,ApplicantName," +
                                         " HindiName, FatherName, MotherName, DOB, ReligionCode,Gender, MaritalStatus," +
                                         " CastCode,NationalityCode,BloodGroup,EmailId,ContactNo,PermanentAddress1, PermanentAddress2," +
                                         " PermanentDistCode,PermanentPinCode,PresentAddress1,PresentAddress2, PresentDistrictCode,PresentPinCode," +
                                         " StreamCode, StreamPartCode,CollCode, SubCode, CollegeAdmissionDate, RollNo,CourseSession,SubCombCode," +
                                         " RegYear,RegFormNo,RegFeeAmt, SCBNo,Photo,ScbDate,UserId, EntryOptDateTime) values(@AckNo,@RegNo, @ApplicantName," +
                                         " @HindiName, @FatherName, @MotherName, @DOB, @ReligionCode,@Gender, @MaritalStatus," +
                                         " @CastCode,@NationalityCode,@BloodGroup,@EmailId,@ContactNo,@PermanentAddress1, @PermanentAddress2," +
                                         " @PermanentDistCode,@PermanentPinCode,@PresentAddress1,@PresentAddress2, @PresentDistrictCode,@PresentPinCode," +
                                         " @StreamCode, @StreamPartCode,@CollCode, @SubCode, @CollegeAdmissionDate, @RollNo,@CourseSession,@SubCombCode," +
                                         " @RegYear,@RegFormNo,@RegFeeAmt, @SCBNo, @Photo,@ScbDate,@UserId, @EntryOptDateTime)";
                                          SqlCmd.Parameters.Add("photo", SqlDbType.Binary, ((byte[])rd["photo"]).Length ).Value = (byte[])rd["photo"];
                                          
                        }
                        else
                        {
                            SqlCmd.CommandText = "insert into registration (AckNo,RegNo, ApplicantName," +
                                         " HindiName, FatherName, MotherName, DOB, ReligionCode,Gender, MaritalStatus," +
                                         " CastCode,NationalityCode,BloodGroup,EmailId,ContactNo,PermanentAddress1, PermanentAddress2," +
                                         " PermanentDistCode,PermanentPinCode,PresentAddress1,PresentAddress2, PresentDistrictCode,PresentPinCode," +
                                         " StreamCode, StreamPartCode,CollCode, SubCode, CollegeAdmissionDate, RollNo,CourseSession,SubCombCode," +
                                         " RegYear,RegFormNo,RegFeeAmt,SCBNo,ScbDate,UserId, EntryOptDateTime) values(@AckNo, @RegNo,@ApplicantName," +
                                         " @HindiName, @FatherName, @MotherName, @DOB, @ReligionCode,@Gender, @MaritalStatus," +
                                         " @CastCode,@NationalityCode,@BloodGroup,@EmailId,@ContactNo,@PermanentAddress1, @PermanentAddress2," +
                                         " @PermanentDistCode,@PermanentPinCode,@PresentAddress1,@PresentAddress2, @PresentDistrictCode,@PresentPinCode," +
                                         " @StreamCode, @StreamPartCode,@CollCode, @SubCode, @CollegeAdmissionDate, @RollNo,@CourseSession,@SubCombCode," +
                                         " @RegYear,@RegFormNo,@RegFeeAmt, @SCBNo, @ScbDate,@UserId, @EntryOptDateTime)";
                        }


                        SqlCmd.Parameters.Add("AckNo", SqlDbType.Char, 11).Value = rd["AckNo"].ToString().Trim();
                        SqlCmd.Parameters.Add("RegNo", SqlDbType.VarChar, 20).Value = rd["RegNo"].ToString().Trim();
                        SqlCmd.Parameters.Add("ApplicantName", SqlDbType.VarChar, 50).Value = rd["ApplicantName"].ToString().Trim();
                        SqlCmd.Parameters.Add("HindiName", SqlDbType.NVarChar, 50).Value = rd["HindiName"].ToString().Trim();
                        SqlCmd.Parameters.Add("FatherName", SqlDbType.NVarChar, 50).Value = rd["FatherName"].ToString().Trim();
                        SqlCmd.Parameters.Add("MotherName", SqlDbType.NVarChar, 50).Value = rd["MotherName"].ToString().Trim();
                        SqlCmd.Parameters.Add("DOB", SqlDbType.SmallDateTime, 10).Value = rd["DOB"].ToString();
                        SqlCmd.Parameters.Add("ReligionCode", SqlDbType.Char, 2).Value = rd["ReligionCode"].ToString().Trim();
                        SqlCmd.Parameters.Add("Gender", SqlDbType.Char, 1).Value = rd["Gender"].ToString().Trim();
                        SqlCmd.Parameters.Add("MaritalStatus", SqlDbType.Char, 1).Value = rd["MaritalStatus"].ToString().Trim();
                        SqlCmd.Parameters.Add("CastCode", SqlDbType.Char, 2).Value = rd["CastCode"].ToString().Trim();
                        SqlCmd.Parameters.Add("NationalityCode", SqlDbType.Char, 1).Value = rd["NationalityCode"].ToString().Trim();
                        SqlCmd.Parameters.Add("BloodGroup", SqlDbType.VarChar, 3).Value = rd["BloodGroup"].ToString().Trim();
                        SqlCmd.Parameters.Add("EmailId", SqlDbType.VarChar, 50).Value = rd["EmailId"].ToString().Trim();
                        SqlCmd.Parameters.Add("ContactNo", SqlDbType.VarChar, 20).Value = rd["ContactNo"].ToString().Trim();
                        SqlCmd.Parameters.Add("PermanentAddress1", SqlDbType.VarChar, 50).Value = rd["PermanentAddress1"].ToString().Trim();
                        SqlCmd.Parameters.Add("PermanentAddress2", SqlDbType.VarChar, 50).Value = rd["PermanentAddress2"].ToString().Trim();
                        SqlCmd.Parameters.Add("PermanentDistCode", SqlDbType.VarChar, 3).Value = rd["PermanentDistCode"].ToString().Trim();
                        SqlCmd.Parameters.Add("PermanentPinCode", SqlDbType.Char, 6).Value = rd["PermanentPinCode"].ToString().Trim();
                        SqlCmd.Parameters.Add("PresentAddress1", SqlDbType.VarChar, 50).Value = rd["PresentAddress1"].ToString().Trim();
                        SqlCmd.Parameters.Add("PresentAddress2", SqlDbType.VarChar, 50).Value = rd["PresentAddress2"].ToString().Trim();
                        SqlCmd.Parameters.Add("PresentDistrictCode", SqlDbType.VarChar, 3).Value = rd["PresentDistrictCode"].ToString().Trim();
                        SqlCmd.Parameters.Add("PresentPinCode", SqlDbType.Char, 6).Value = rd["PresentPinCode"].ToString().Trim();
                        SqlCmd.Parameters.Add("StreamCode", SqlDbType.Char, 2).Value = rd["StreamCode"].ToString().Trim();
                        SqlCmd.Parameters.Add("StreamPartCode", SqlDbType.VarChar, 4).Value = rd["StreamPartCode"].ToString().Trim();
                        SqlCmd.Parameters.Add("CollCode", SqlDbType.Char, 3).Value = rd["CollCode"].ToString().Trim();
                        SqlCmd.Parameters.Add("SubCode", SqlDbType.Char, 3).Value = rd["SubCode"].ToString().Trim();
                        SqlCmd.Parameters.Add("CollegeAdmissionDate", SqlDbType.SmallDateTime, 10).Value = rd["CollegeAdmissionDate"].ToString();
                        SqlCmd.Parameters.Add("RollNo", SqlDbType.VarChar, 8).Value = rd["RollNo"].ToString().Trim();
                        SqlCmd.Parameters.Add("CourseSession", SqlDbType.VarChar, 9).Value = rd["CourseSession"].ToString().Trim();
                        SqlCmd.Parameters.Add("SubCombCode", SqlDbType.VarChar, 100).Value = rd["SubCombCode"].ToString().Trim();
                        SqlCmd.Parameters.Add("RegFormNo", SqlDbType.VarChar, 12).Value = rd["RegFormNo"].ToString().Trim();
                        SqlCmd.Parameters.Add("RegFeeAmt", SqlDbType.Float, 8).Value = rd["RegFeeAmt"].ToString().Trim();
                        SqlCmd.Parameters.Add("SCBNo", SqlDbType.VarChar, 10).Value = rd["SCBNo"].ToString().Trim();
                        SqlCmd.Parameters.Add("ScbDate", SqlDbType.SmallDateTime, 10).Value = rd["ScbDate"].ToString();
                        SqlCmd.Parameters.Add("RegYear", SqlDbType.Char, 4).Value = rd["RegYear"].ToString().Trim();
                        
                        

                        SqlCmd.Parameters.Add("UserId", SqlDbType.Char, 5).Value = rd["UserId"].ToString();
                        SqlCmd.Parameters.Add("EntryOptDateTime", SqlDbType.SmallDateTime, 10).Value = rd["EntryOptDateTime"].ToString();
                        SqlCmd.ExecuteNonQuery();
                        SqlCmd.Parameters.Clear();
                        RecordImported++;
                        //update collegedatabase set sendtouni=U
                        AckNo_List  +="'"+rd["AckNo"].ToString()+"',";
                       
                    }
                    TotRecord++;
                }

                
                rd.Close();
                AckNo_List +=  "'0')";
                cmd.CommandText = "update RegFeeDetails set SendToUni='U' where AckNo in" + AckNo_List;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                SqlCmd.Dispose();
                con.Close();
                SqlCon.Close();
                //import PREREGQUALIFICATION() details
                PREREGQUALIFICATION(AckNo_List);
                //import PREREGMIGRATION() details
                PREREGMIGRATION(AckNo_List);
                LblMsg2.Text = " Total Record = " + TotRecord + " & Tottal Imported =" + RecordImported;
                BindRecotd();
    
            }
            catch (Exception ex)
            {
                LblMsg2.Text = " Total Record = " + TotRecord + " & Tottal Imported =" + RecordImported + "Error occured..."+ex.Message  ;
                //LblMsg2.Text = LblMsg2.Text + "  Error occured - ";
                rd.Close();
                cmd.Dispose();
                SqlCmd.Dispose();
                con.Close();
                SqlCon.Close();
            }
 
    }
    protected void PREREGQUALIFICATION( string ackno)
    {
        
        SqlCommand SqlCmd = new SqlCommand();
        SqlConnection SqlCon = new SqlConnection();
        SqlCon.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlCon.Open();
        SqlCmd.Connection = SqlCon;

        OleDbConnection con = new OleDbConnection();
        //con.ConnectionString = "Dsn=College";
        con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\CollegeDataBase\" + FileUpload1.FileName.ToString()+";Jet OLEDB:Database Password=college@123";
        con.Open();
        OleDbCommand cmd = new OleDbCommand();
        cmd.Connection = con;
        cmd.CommandText = "select * from  PREREGQUALIFICATION where Ackno in "+ackno;
        OleDbDataReader rd = cmd.ExecuteReader();
        SqlCmd.CommandText = " insert into PREREGQUALIFICATION (AckNo,RegNo, ExamCode, UnivCode, CollCode,PassYear,RollNo,ExamPercentage,Division,MainSubject ) " +
                             " values(@AckNo,@RegNo, @ExamCode, @UnivCode, @CollCode,@PassYear,@RollNo,@ExamPercentage,@Division,@MainSubject )";

        try
        {
            while (rd.Read())
            {

                SqlCmd.Parameters.Add("AckNo", SqlDbType.Char, 11).Value = rd["AckNo"].ToString().Trim();
                SqlCmd.Parameters.Add("RegNo", SqlDbType.VarChar, 20).Value = rd["RegNo"].ToString().Trim();
                SqlCmd.Parameters.Add("ExamCode", SqlDbType.Char, 2).Value = rd["ExamCode"].ToString().Trim();
                SqlCmd.Parameters.Add("UnivCode", SqlDbType.Char, 2).Value = rd["UnivCode"].ToString().Trim();
                SqlCmd.Parameters.Add("CollCode", SqlDbType.VarChar, 30).Value = rd["collcode"].ToString().Trim();
                SqlCmd.Parameters.Add("PassYear", SqlDbType.Char, 4).Value = rd["Passyear"].ToString().Trim();
                SqlCmd.Parameters.Add("RollNo", SqlDbType.Char, 8).Value = rd["RollNo"].ToString().Trim();
                SqlCmd.Parameters.Add("ExamPercentage", SqlDbType.Char, 2).Value = rd["ExamPercentage"].ToString().Trim();
                SqlCmd.Parameters.Add("Division", SqlDbType.NVarChar, 5).Value = rd["Division"].ToString().Trim();
                SqlCmd.Parameters.Add("MainSubject", SqlDbType.VarChar, 150).Value = rd["MainSubject"].ToString().Trim();
                
                SqlCmd.ExecuteNonQuery();
                SqlCmd.Parameters.Clear();
            }
            rd.Close();
            cmd.Dispose();
            SqlCmd.Dispose();
            con.Close();
            SqlCon.Close();
        }
        catch (Exception ex)
        {
            rd.Close();
            cmd.Dispose();
            SqlCmd.Dispose();
            con.Close();
            SqlCon.Close();
        }
    }
    protected void PREREGMIGRATION(string ackno)
    {
        SqlCommand SqlCmd = new SqlCommand();
        SqlConnection SqlCon = new SqlConnection();
        SqlCon.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlCon.Open();
        SqlCmd.Connection = SqlCon;

        OleDbConnection con = new OleDbConnection();
        //con.ConnectionString = "Dsn=College";
        con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\CollegeDataBase\" + FileUpload1.FileName.ToString() + ";Jet OLEDB:Database Password=college@123";
        con.Open();
        OleDbCommand cmd = new OleDbCommand();
        cmd.Connection = con;
        cmd.CommandText = "select * from  PREREGMIGRATION where Ackno in " + ackno;
        OleDbDataReader rd = cmd.ExecuteReader();
        SqlCmd.CommandText = " insert into PREREGMIGRATION (AckNo, RegNo,MigrationNo, MigrationIssueDate ) " +
                             " values(@AckNo,@RegNo, @MigrationNo, @MigrationIssueDate )";

        try
        {
            while (rd.Read())
            {

                SqlCmd.Parameters.Add("AckNo", SqlDbType.Char, 11).Value = rd["AckNo"].ToString().Trim();
                SqlCmd.Parameters.Add("RegNo", SqlDbType.VarChar, 20).Value = rd["RegNo"].ToString().Trim();
                SqlCmd.Parameters.Add("MigrationNo", SqlDbType.VarChar, 12).Value = rd["MigrationNo"].ToString().Trim();
                SqlCmd.Parameters.Add("MigrationIssueDate", SqlDbType.SmallDateTime, 10).Value = rd["MigrationIssueDate"].ToString();
                
                SqlCmd.ExecuteNonQuery();
                SqlCmd.Parameters.Clear();
            }
            rd.Close();
            cmd.Dispose();
            SqlCmd.Dispose();
            con.Close();
            SqlCon.Close();
        }
        catch (Exception ex)
        {
            rd.Close();
            cmd.Dispose();
            SqlCmd.Dispose();
            con.Close();
            SqlCon.Close();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        BindRecotd();
    }
    protected void  BindRecotd()
    {
        SqlConnection SqlCon = new SqlConnection();
        SqlCon.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlCon.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = SqlCon;
        cmd.CommandText = "select college.CollName, count(*) from registration, college where registration.collcode=college.collcode And RegYear='"+Year.SelectedValue+ "'   group by college.collname ";
        SqlDataReader rd = cmd.ExecuteReader();
        CollegeList.Items.Clear();  
        while (rd.Read())
        {
            CollegeList.Items.Add(rd[0].ToString() + " - " + rd[1].ToString());
        }
        rd.Close();
        cmd.Dispose();
        SqlCon.Close();
    }
}

