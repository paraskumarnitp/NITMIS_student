using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Microsoft.Reporting.WebForms;
public partial class CoursePaperDetatisReport : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    Functionreviseed dut = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {


        try
        {
            if ((Session["Role"].ToString() != "1") && (Session["Role"].ToString() != "10") && (Session["Role"].ToString() != "14"))
            {
                Session["userName"] = null;
                FormsAuthentication.SignOut();
                Response.Redirect("default.aspx");
                return;
            }
        }
        catch (Exception ex)
        {
            Response.Redirect("default.aspx");
        }   
       
        if (!IsPostBack)
        {


            try
            {

               // ReportViewer1.LocalReport.EnableHyperlinks = true;



                string qur = " SELECT ROW_NUMBER()OVER(ORDER BY  streamcode ASC) as 'SerialNO', streamcode,STREAM ,streamAbbr from STREAM where stream<>'--select--'";
                // string qur = "SELECT ROW_NUMBER()OVER(ORDER BY  PaperName ASC) as 'SerialNO',COURSEPAPERS.PaperName ,COURSEPAPERS.PaperAbbr  FROM CourseCodeOfferedDetail INNER JOIN   COURSEPAPERS ON CourseCodeOfferedDetail.SubPaperCode = COURSEPAPERS.SubPaperCode  INNER JOIN  CoursePaperOfferedType ON CourseCodeOfferedDetail.OfferedTypeId = CoursePaperOfferedType.Id  WHERE (CourseCodeOfferedDetail.CourseCodeOfferedId IN  (SELECT     Id  FROM   CourseCodeOffered  WHERE  (ExamSession = 'JUL-DEC_2017') AND (StreamPartCode = '11') ))";

                string conString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

                SqlConnection con = new SqlConnection(conString);

                SqlDataAdapter sda = new SqlDataAdapter(qur, con);


                DataTable dt = new DataTable("course_DataTable1");


                sda.Fill(dt);


                grdcoursepaper.DataSource = dt;
                grdcoursepaper.DataBind();


                //ReportViewer1.ProcessingMode = ProcessingMode.Local;
                //ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/CoursePaperreport.rdlc");


                //ReportDataSource datasource = new ReportDataSource("course_DataTable1", dt);
                //ReportViewer1.LocalReport.DataSources.Clear();
                //ReportViewer1.LocalReport.DataSources.Add(datasource);
            }
            catch (Exception ex)
            {
            }
        }
    }

    protected void grdcoursepaper_SelectedIndexChanged(object sender, EventArgs e)
    {


        string stramcode = (grdcoursepaper.SelectedRow.FindControl("lblstcode") as Label).Text;
        Session["streamcode"] = stramcode;

        Response.Redirect("CoursePaperDetailsCriteriagrid.aspx");


    }
}
