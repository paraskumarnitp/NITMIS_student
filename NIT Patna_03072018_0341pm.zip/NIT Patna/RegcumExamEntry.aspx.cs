using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;



public partial class RegcumExamEntry : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        { 
            try
            {
                if (Session["Role"].ToString() != "4")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CastCode, "Category", "Select Category,CategoryCode from Category order by Category", "Category", "CategoryCode");
            popddl.Popualate(PermanentDistCode, "District", "Select DistName,DistCode from District order by DistName", "DistName", "DistCode");
            popddl.Popualate(PresentDistrictCode, "District", "Select DistName,DistCode from District order by DistName", "DistName", "DistCode");
            popddl.Popualate(NationalityCode, "Nationality", "Select Nationality,NationalityCode from Nationality order by Nationality", "Nationality", "NationalityCode");
            popddl.Popualate(ReligionCode, "Religion", "Select * from Religion order by ReligionCode", "Religion", "ReligionCode");
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            //popddl.Popualate(LPassYear, "Year", "Select Year from Year order by Year", "Year", "Year");
            //popddl.Popualate(MPassYear, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(Year1, "Year", "Select Year from Year where year >'1996'order by Year", "Year", "Year");
            popddl.Popualate(Year2, "Year", "Select Year from Year where year > '1996'order by Year", "Year", "Year");
            PopulateList poplist = new PopulateList();
            poplist.Popualate(CompPaper, "COMPOSITION", "Select Name,CompCode from COMPOSITION order by Name", "Name", "CompCode");
            Year1.Text = System.DateTime.Now.Year.ToString();
            Year2.Text = System.DateTime.Now.Year.ToString();
            ExamYear.Text = System.DateTime.Now.Year.ToString();
            RegistrationNumber.Focus();
        }
    }
    protected void BtnSave_Click(object sender, EventArgs e)
    {
        SaveReg();
        RegistrationNumber.Focus(); 
    }

    protected void DoBtn_Click(object sender, EventArgs e)
    {
        PresentAddress1.Text = PermanentAddress1.Text;
        PresentAddress2.Text = PermanentAddress2.Text;
        PresentDistrictCode.Text = PermanentDistCode.Text;
        PresentPinCode.Text = PermanentPinCode.Text;
        PresentPinCode.Focus();

    }

    

    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        //set Session
        UnivService.Service1 NicService = new UnivService.Service1();
        string y = NicService.GetNewCode("Select Duration from stream Where StreamCode='" + StreamCode.SelectedValue + "'");
        Year2.Text = (int.Parse(Year1.Text) + int.Parse(y)) + "";   
        StreamCode.Focus();


    }


    protected void SubCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateList poplist = new PopulateList();

        poplist.Popualate(HPaper, "COURSEPAPERS", "Select PaperName,SubPaperCode from COURSEPAPERS Where StreamCode='" + StreamCode.SelectedValue + "' And StreamPartCode='" + StreamPart.SelectedValue + "' And SubCode='" + SubCode.SelectedValue + "' order by SubPaperCode", "PaperName", "SubPaperCode");
        poplist.Popualate(SPaper, "SUBJECT", "Select SubCode,SubjectName from SUBJECT Where StreamCode='" + StreamCode.SelectedValue + "' and subcode<>'" + SubCode.SelectedValue + "'  order by SubjectName", "SubjectName", "SubCode");
        for (int i = 0; i < HPaper.Items.Count; i++)
        {
            HPaper.Items[i].Selected = true;
        }
        SubCode.Focus();
    }

    protected void SaveReg()
    {

        try
        {
            // Check duplicate Entry of Form (On RegForm , Collcode and Stream Code)

            SqlConnection con = new SqlConnection();
            SqlDataReader rd;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;
            //cmd.CommandText = "select AckNo from Registration where RegFormNo='" + RegFormNo.Text.Trim() + "' AND CollCode='" + CollCode.SelectedValue + "' and RegNo='"+RegistrationNumber.Text.Trim () +"'";
            cmd.CommandText = "select AckNo from Registration where  RegNo='" + RegistrationNumber.Text.Trim() + "'";
            con.Open();
            rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                rd.Read();
                string msg = " Please Check Entry Form. This Form has already entered whose Enrollment No is -" + rd["AckNo"].ToString();
                string popupScript = "<script language='javascript'>" +
                                   " alert('" + msg + " ')" +
                                    "</script>";
                Page.RegisterStartupScript("PopupScript", popupScript);
                rd.Read();
                rd.Close();
                con.Close();
                HindiName.Focus();

                return;
            }
            else
            {
                rd.Close();
                con.Close();

                string SaveFlag = "";
               
                string[] col = new string[40];
                string[] val = new string[40];
                string[] coltype = new string[40];
                for (int i = 0; i < 40; i++)
                    coltype[i] = "0";
                coltype[0] = "1";

                // Colume Variable--Field Name
                col[0] = "HindiName"; val[0] = HindiName.Text.Trim();
                col[1] = "ApplicantName"; val[1] = (ApplicantName.Text.Trim()).ToUpper();
                ApplicantName.Text = (ApplicantName.Text.Trim()).ToUpper();

                col[2] = "DOB"; val[2] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(DOB.Text.Trim()));
                col[3] = "FatherName"; val[3] = FatherName.Text.Trim();
                col[4] = "MotherName"; val[4] = MotherName.Text.Trim();
                col[5] = "Gender"; if (GenderM.Checked == true) val[5] = "M"; else val[5] = "F";
                col[6] = "CastCode"; val[6] = CastCode.SelectedValue;
                col[7] = "MaritalStatus"; val[7] = MaritalStatus.SelectedValue;
                col[8] = "NationalityCode"; val[8] = NationalityCode.SelectedValue;
                col[9] = "PermanentAddress1"; val[9] = PermanentAddress1.Text.Trim();
                col[10] = "PermanentAddress2"; val[10] = PermanentAddress2.Text.Trim();
                col[11] = "PermanentDistCode"; val[11] = PermanentDistCode.SelectedValue;
                col[12] = "PermanentPinCode"; val[12] = PermanentPinCode.Text.Trim();
                col[13] = "PresentAddress1"; val[13] = PresentAddress1.Text.Trim();
                col[14] = "PresentAddress2"; val[14] = PresentAddress2.Text.Trim();
                col[15] = "PresentDistrictCode"; val[15] = PresentDistrictCode.SelectedValue;
                col[16] = "PresentPinCode"; val[16] = PresentPinCode.Text.Trim();
                col[17] = "RegFormNo"; val[17] = "";
                col[18] = "CollCode"; val[18] = CollCode.SelectedValue;
                col[19] = "CourseSession"; val[19] = Year1.SelectedValue + "-" + Year2.SelectedValue;
                col[20] = "CollegeAdmissionDate";
//                if (CollegeAdmissionDate.Text.ToString() != "")
  //                  val[20] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(CollegeAdmissionDate.Text.ToString()));
    //            else
                val[20] = "01/01/1900";
                
                
                col[21] = "StreamCode"; val[21] = StreamCode.SelectedValue.ToString();
                col[22] = "SCBNo"; val[22] = "";
                col[23] = "RegFeeAmt"; val[23] = "0";
                col[24] = "SCBDate"; val[24] = "01/01/1900";
                col[25] = "UserId"; val[25] = Session["UserId"].ToString();
                col[26] = "EntryOptDateTime"; val[26] = string.Format("{0:MM/dd/yyyy}", System.DateTime.Now);
                col[27] = "AckNo";
                col[28] = "ReligionCode"; val[28] = ReligionCode.SelectedValue;
                col[29] = "RollNo"; val[29] = RollNo.Text.Trim();
                col[31] = "StreamPartCode"; val[31] = StreamPart.SelectedValue;
                col[32] = "SubCode"; val[32] = SubCode.SelectedValue;
                col[33] = "RegYear"; val[33] = RegYear.Text.Trim();
                //col[34] = "RegNo"; val[34] = string.Format("{0:D11}", Convert.ToInt32(RegistrationNumber.Text.Trim()));
                col[34] = "RegNo"; val[34] = RegistrationNumber.Text.Trim();
                col[35] = "RegistrationDate"; val[35] = "01/01/1900";
                col[36] = "BloodGroup"; val[36] = BloodGroup.SelectedValue;
                col[37] = "EmailId"; val[37] = EmailId.Text.Trim();
                col[38] = "ContactNo"; val[38] = ContactNo.Text.Trim();
                col[39] = "IsOld"; val[39] = "Y";

                UnivService.Service1 NicService = new UnivService.Service1();
                //string Year = System.DateTime.Now.Year.ToString();
                //Year = Year.Substring(2, 2);

               
                string Year = RegYear.Text.Substring(2, 2); // getting Value from RegYear Text Box
                string SQL = "SELECT     ISNULL(MAX(ABS(SUBSTRING(AckNo, 8, 11))), '0') + 1 AS VarAckNo FROM  REGISTRATION WHERE     SUBSTRING(AckNo, 1, 2) = '" + Year + "' and collcode='" + CollCode.SelectedValue + "' and streamcode='" + StreamCode.SelectedValue + "'";
                string NewAckNo = NicService.GetNewCode(SQL);
                NewAckNo = Year + CollCode.SelectedValue + StreamCode.SelectedValue + string.Format("{0:D4}", Convert.ToInt32(NewAckNo));

                val[27] = NewAckNo;
                //----Subject Comb Code
                string CourseComb = "C(";
                //Composition
                for (int i = 0; i < CompPaper.Items.Count; i++)
                {
                    if (CompPaper.Items[i].Selected)
                    {

                        CourseComb += CompPaper.Items[i].Value + ",";
                    }

                }

                //Honours Paper
                CourseComb = CourseComb.Substring(0, CourseComb.Length - 1);

                CourseComb += ")+H(";

                for (int i = 0; i < HPaper.Items.Count; i++)
                {
                    if (HPaper.Items[i].Selected)
                    {
                        CourseComb += HPaper.Items[i].Value + ",";
                    }

                }

                //Sunsidiary Paper
                CourseComb = CourseComb.Substring(0, CourseComb.Length - 1);
                CourseComb += ")+S(";

                for (int i = 0; i < SPaper.Items.Count; i++)
                {
                    if (SPaper.Items[i].Selected)
                    {
                        CourseComb += SPaper.Items[i].Value + ",";
                    }

                }

                CourseComb = CourseComb.Substring(0, CourseComb.Length - 1);
                CourseComb += ")";




                //---SubCom Code

                col[30] = "SubCombCode";
                val[30] = CourseComb;
                SaveFlag = NicService.SaveDataUniCode("Registration", col, val, coltype);

                if (SaveFlag == "1")
                {

                    ViewState.Add("AckNo", NewAckNo);
                    //Page.RegisterStartupScript(@"startup", @"<script>altert('New User Id is " + val[0] + "');</script>");
                    SaveExam();
                    //update RollNo
                    BtnUpdateUnivRoll();
                    //SaveExamDetail(NewAckNo);
                    LblMsg.Text = " Registration Inserted Successfully -Enrollment No. = " + NewAckNo;
                    LblMsg2.Text = " Registration Inserted Successfully -Enrollment No. = " + NewAckNo;
                    HindiName.Text = "";
                    ApplicantName.Text = "";
                    FatherName.Text = "";
                    MotherName.Text = "";
                    DOB.Text = "";
                    RegistrationNumber.Text = "";
                 

                    if (ScanImage1.PostedFile.FileName != "")
                    {
                        SqlDataSource1.Update();


                        ImageUpload imgUpload = new ImageUpload();
                        string strFileName = imgUpload.Image_Load(NewAckNo);



                        if (strFileName.ToString().Contains("temp"))
                        {


                            string photo = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/temp.jpg";

                            string strRightNow = "";
                            string IUrl = "";

                            strRightNow = System.DateTime.Now.ToString("ddMMyyyyHHmmss");
                            IUrl = photo + "?img=" + strRightNow;

                            Image1.ImageUrl = IUrl;
                            Image1.DataBind();

                        }
                        else if (strFileName.ToString().Contains("UploadPhoto"))
                        {

                            Image1.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadPhoto.JPG";
                            Image1.DataBind();

                        }

                        else
                        {

                            LblPhoto.Text = "Error" + strFileName;

                        }

                    }
                    //////// end

                    else
                    {
                        Image1.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadPhoto.JPG";
                        Image1.DataBind();

                    }





                    LblMsg.Focus();


                }
                else
                {
                    LblMsg.Text = SaveFlag.ToString();
                }

                
            }
        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }


    protected void SaveExam()
    {

        try
        {
            // Check duplicate Entry of Form (On ExamFormNo , Collcode)

            SqlConnection con = new SqlConnection();
           // SqlDataReader rd;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;
            //cmd.CommandText = "select RegNo from Exam where ExamFormNo='" + ExamFormNo.Text.Trim() + "' AND CollCode='" + CollCode.SelectedValue + "' and StreamPartCode='" + StreamPart.SelectedValue + "' ";
            //con.Open();
            //rd = cmd.ExecuteReader();
            //if (rd.HasRows)
            //{
            //    rd.Read();
            //    string msg = " Please Check Entry Form. This Form has already entered. Reg No. is " + rd["RegNo"].ToString();
            //    string popupScript = "<script language='javascript'>" +
            //                       " alert('" + msg + " ')" +
            //                        "</script>";
            //    Page.RegisterStartupScript("PopupScript", popupScript);
            //    rd.Read();
            //    rd.Close();
            //    con.Close();
            //    RegistrationNumber.Focus(); 

            //    return;
            //}
            //else
            {
               // rd.Close();
                con.Close();

                string SaveFlag = "";

                string[] col = new string[20];
                string[] val = new string[20];


                // Colume Variable--Field Name

                col[0] = "RegNo"; val[0] = RegistrationNumber.Text;
                col[1] = "CollCode"; val[1] = CollCode.SelectedValue;
                col[2] = "ClassRollNo"; val[2] = RollNo.Text; 
                col[3] = "ExamYear"; val[3] = ExamYear.Text.Trim();
                col[4] = "StreamCode"; val[4] = StreamCode.SelectedValue;
                col[5] = "StreamPartCode"; val[5] = StreamPart.SelectedValue;
                col[6] = "SubCode"; val[6] = SubCode.SelectedValue;
                col[7] = "PresentAddress1"; val[7] = PresentAddress1.Text.Trim();
                col[8] = "PresentAddress2"; val[8] = PresentAddress2.Text.Trim();
                col[9] = "PresentDistrictCode"; val[9] = PresentDistrictCode.SelectedValue;
                col[10] = "PresentPinCode"; val[10] = PresentPinCode.Text.Trim();
                col[11] = "ExamFeeAmt"; val[11] = "0";
                col[12] = "SCBNo"; val[12] = "";
                col[13] = "SCBDate"; val[13] = "01/01/1900";
                col[14] = "ExamFormNo"; val[14] = ExamFormNo.Text; 
                col[15] = "ExamType"; val[15] = "R";
                col[16] = "UserId"; val[16] = Session["UserId"].ToString();
                col[17] = "EntryOptDateTime"; val[17] = string.Format("{0:MM/dd/yyyy}", System.DateTime.Now);
                col[18] = "Gender"; val[18] = GenderM.Checked == true ? "M" : "F";
                col[19] = "ModeOfExam";
                val[19] = "E";
                //if (ModeOfExamE.Checked == true) val[19] = "E";
                //else if (ModeOfExamH.Checked == true) val[19] = "H";
                //else val[19] = "N";


                UnivService.Service1 NicService = new UnivService.Service1();
                SaveFlag = NicService.SaveData("Exam", col, val);

                if (SaveFlag == "1")
                {
                    //LblMsg.Focus();
                    SavePaper();
                    LblMsg.Text = "Exam Form Successfully Saved";
                    //Panel2.Visible = false;
                }
                else
                {

                    LblMsg.Text = SaveFlag.ToString();
                }

            }
        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }


    }


    protected void SavePaperDetail(string pcode, string ptype)
    {

        try
        {

            string SaveFlag = "";

            string[] col = new string[5];
            string[] val = new string[5];


            // Colume Variable--Field Name

            col[0] = "RegNo"; val[0] =RegistrationNumber.Text.Trim();
            col[1] = "StreamPartCode"; val[1] = StreamPart.SelectedValue;
            col[2] = "SubPaperCode"; val[2] = pcode;
            col[3] = "PaperType"; val[3] = ptype;
            col[4] = "ExamYear"; val[4] = ExamYear.Text.Trim();


            UnivService.Service1 NicService = new UnivService.Service1();
            SaveFlag = NicService.SaveData("ExamPaperDetail", col, val);

            if (SaveFlag == "1")
            {
                LblMsg.Text = "";
            }
            else
            {
                LblMsg.Text = SaveFlag.ToString();
            }

        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

    }
    protected void SavePaper()
    {
        int i = 0;
        string papercode = "";

        // Composition Paper 
        for (i = 0; i < CompPaper.Items.Count; i++)
        {
            if (CompPaper.Items[i].Selected == true)
            {
                SavePaperDetail(CompPaper.Items[i].Value.ToString(), "C");
            }

        }

        // Honours Paper 
        for (i = 0; i < HPaper.Items.Count; i++)
        {
            if (HPaper.Items[i].Selected == true)
            {
                SavePaperDetail(HPaper.Items[i].Value.ToString(), "H");
                //Check PracticalPapers
                UnivService.Service1 NicService = new UnivService.Service1();
                papercode = NicService.GetNewCode(" select SubPaperCode from PracticalPapers where SubPaperCode='" + HPaper.Items[i].Value + "'");
                if (papercode != "")
                    SavePaperDetail(papercode, "P");
            }




        }

        // Subsidiary Paper 
        for (i = 0; i < SPaper.Items.Count; i++)
        {
            if (SPaper.Items[i].Selected == true)
            {
                SavePaperDetail(SPaper.Items[i].Value.ToString(), "S");

                //Check PracticalPapers
                UnivService.Service1 NicService = new UnivService.Service1();
                papercode = NicService.GetNewCode(" select PrPassMarks from subsidiary where SubCode='" + SPaper.Items[i].Value + "'");
                if (papercode != "0")
                    SavePaperDetail(SPaper.Items[i].Value.ToString(), "P");
            }
        }
    }
    //protected void SaveExamDetail(string ackno)
    //{

    //    try
    //    {
    //        string[] col = new string[7];
    //        string[] val = new string[7];

    //        col[0] = "AckNo";
    //        col[1] = "ExamCode";
    //        col[2] = "UnivCode";
    //        col[3] = "CollCode";
    //        col[4] = "PassYear";
    //        col[5] = "RollNo";
    //        col[6] = "Division";

    //        val[0] = ackno;
    //        val[1] = ExamCode1.SelectedValue;
    //        val[2] = UnivCode1.SelectedValue;
    //        val[3] = CollCode1.Text.Trim();
    //        val[4] = PassYear1.Text.Trim();
    //        val[5] = RollNo1.Text.Trim();
    //        val[6] = Division1.SelectedValue;

    //        UnivService.Service1 ss = new UnivService.Service1();
    //        string abc = ss.SaveData("PreRegQualification", col, val);
    //        //save Mig. No & Mig. Date
    //        if (CheckBox1.Checked == true)
    //        {
    //            string[] col1 = new string[3];
    //            string[] val1 = new string[3];

    //            col1[0] = "AckNo";
    //            col1[1] = "MigrationNo";
    //            col1[2] = "MigrationIssueDate";

    //            val1[0] = ackno;
    //            val1[1] = MigrationNo.Text.Trim();
    //            val1[2] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(MigrationIssueDate.Text));
    //            abc = ss.SaveData("PreRegMigration", col1, val1);

    //        }

    //    }
    //    catch (Exception ex)
    //    {
    //    }





    //}
    protected void Year1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            UnivService.Service1 NicService = new UnivService.Service1();
            string y = NicService.GetNewCode("Select Duration from stream Where StreamCode='" + StreamCode.SelectedValue + "'");
            Year2.Text = (int.Parse(Year1.Text) + int.Parse(y)) + "";
            SubCode_SelectedIndexChanged(sender, e);

        }
        catch (Exception ex)
        {
        }
    }
    protected void BtnUpdateUnivRoll()
    {
        try
        {
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            SqlDataReader reader;
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;
            con.Open();
            SqlTransaction tran;
            string univrollno=UnivRollNo.Text  ;
            string SQL = "";
            string SerialNo = "";
            UnivService.Service1 ss = new UnivService.Service1();
            int count = 0;
            string UnivCode = "";
            tran = con.BeginTransaction();
            cmd.Transaction = tran;
            cmd.CommandText = " update Exam set  UnivRollNo='" + UnivRollNo.Text + "', FinalizeDateTime='" + string.Format("{0:MM/dd/yyyy}", System.DateTime.Now) + "' where Regno='" + RegistrationNumber.Text + "'";
            cmd.ExecuteNonQuery();
            cmd.CommandText = " update ExamPaperDetail set  UnivRollNo='" + UnivRollNo.Text + "' where Regno='" + RegistrationNumber.Text + "'";
            cmd.ExecuteNonQuery();
            tran.Commit();
            //-------------------------------------------------------------
            //update Current exam status
            cmd.CommandText = "Select subPaperCode from ExamPaperDetail where UnivRollNo='" + univrollno + "'  And streampartcode='" + StreamPart.SelectedValue + "' and PaperType='C'";
            reader = cmd.ExecuteReader();
            string CourseComb = "C(";
            //Comp
            while (reader.Read())
            {
                CourseComb += reader["subPaperCode"].ToString() + ",";
            }
            reader.Close();
            //Honours
            cmd.CommandText = "Select subPaperCode from ExamPaperDetail where UnivRollNo='" + univrollno + "' And streampartcode='" + StreamPart.SelectedValue + "' and PaperType='H'";
            reader = cmd.ExecuteReader();
            CourseComb = CourseComb.Substring(0, CourseComb.Length - 1);
            CourseComb += ")+H(";
            while (reader.Read())
            {
                CourseComb += reader["subPaperCode"].ToString() + ",";
            }
            reader.Close();
            //Subsidiary
            cmd.CommandText = "Select subPaperCode from ExamPaperDetail where UnivRollNo='" + univrollno + "' And streampartcode='" + StreamPart.SelectedValue + "' and PaperType='S'";
            reader = cmd.ExecuteReader();
            CourseComb = CourseComb.Substring(0, CourseComb.Length - 1);
            CourseComb += ")+S(";
            while (reader.Read())
            {
                CourseComb += reader["subPaperCode"].ToString() + ",";
            }
            CourseComb = CourseComb.Substring(0, CourseComb.Length - 1);
            CourseComb += ")";
            reader.Close();

            // Save in CurrentExam Status
            string[] col = new string[11];
            string[] val = new string[11];
            col[0] = "RegNo"; val[0] = RegistrationNumber.Text;
            col[1] = "UnivRollNo"; val[1] = UnivRollNo.Text; 
            col[2] = "CollCode"; val[2] = CollCode.SelectedValue;
            col[3] = "ExamType"; val[3] = "";
            col[4] = "RollNo"; val[4] = RollNo.Text;
            col[5] = "StreamCode"; val[5] = StreamCode.SelectedValue.ToString ();
            col[6] = "StreamPartCode"; val[6] = StreamPart.SelectedValue.ToString();
            col[7] = "SubCode"; val[7] = SubCode.SelectedValue.ToString();  
            col[8] = "SubCombCode"; val[8] = CourseComb;
            col[9] = "Status"; val[9] = "ST";
            col[10] = "ExamYear"; val[10] = ExamYear.Text;
            CourseComb = ss.SaveData("CurrentExamStatus", col, val);
            // end update Ciurrent exam status

            
            con.Close();
        }
        catch (Exception ex)
        {
        }
    }

    
}

