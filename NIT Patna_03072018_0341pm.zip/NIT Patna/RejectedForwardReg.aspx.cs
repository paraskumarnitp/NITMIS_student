using System;
using System.IO;
using System.Data;
using System.Data.SqlClient ;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class RejectedForwardReg : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

            try
            {
                if (Session["Role"].ToString() != "2") //Role for EC
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CastCode, "Category", "Select Category,CategoryCode from Category order by Category", "Category", "CategoryCode");
            popddl.Popualate(PermanentDistCode, "District", "Select DistName,DistCode from District order by DistName", "DistName", "DistCode");
            popddl.Popualate(PresentDistrictCode, "District", "Select DistName,DistCode from District order by DistName", "DistName", "DistCode");
            popddl.Popualate(NationalityCode, "Nationality", "Select Nationality,NationalityCode from Nationality order by Nationality", "Nationality", "NationalityCode");
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(Year1, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(Year2, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(ReligionCode, "Religion", "Select * from Religion order by ReligionCode", "Religion", "ReligionCode");
            popddl.Popualate(ExamCode1, "ExamName", "Select ExamName, ExamCode from ExamName order by ExamName", "ExamName", "ExamCode");
            popddl.Popualate(UnivCode1, "University", "Select UnivName,UnivCode from University order by UnivName", "UnivName", "UnivCode");
            popddl.Popualate(AckNo, "Registration", "Select AckNo from Registration where verifystatus='F'", "AckNo", "AckNo");

           
            AckNo.Focus(); 


        }

    }
    protected void BtnReg_Click(object sender, EventArgs e)
    {
        try
        {

            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;



            ImageUpload imgUpload = new ImageUpload();
            string strFileName = imgUpload.Image_Load(AckNo.Text.Trim());

            //Image1.ImageUrl = strFileName;
            //Response.Write(strFileName.ToString());


            if (strFileName.ToString().Contains("temp"))
            {


                string photo = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/temp.jpg";

                string strRightNow = "";
                string IUrl = "";

                strRightNow = System.DateTime.Now.ToString("ddMMyyyyHHmmss");
                IUrl = photo + "?img=" + strRightNow;

                Image3.ImageUrl = IUrl;
                Image3.DataBind();


            }
            else if (strFileName.ToString().Contains("UploadPhoto"))
            {

                Image3.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadPhoto.JPG";
                Image3.DataBind();

            }

            else
            {
                LblMsg.Text = "Error" + strFileName;

            }


            HPaper.Items.Clear();
            SPaper.Items.Clear();
            CompPaper.Items.Clear();
            cmd.Connection = con;
            SqlDataReader reader;
            cmd.CommandText = "select ReasonOfRejection from RejectedRegistration where AckNo='" + AckNo.Text.Trim() + "'";
            con.Open();
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                LblMsg.Text = "***" + reader["ReasonOfRejection"].ToString();
            }
            reader.Close();
            con.Close();


            cmd.CommandText = " select ApplicantName,HindiName,FatherName,MotherName,DOB,Gender,MaritalStatus,BloodGroup,EmailId,ContactNo,CastCode,NationalityCode," +
                "CollCode,CollegeAdmissionDate,RollNo,CourseSession,PermanentAddress1,PermanentAddress2,PermanentDistCode,PermanentPinCode,PresentAddress1,PresentAddress2,PresentDistrictCode,PresentPinCode," +
                "RegFeeAmt,SCBNo,SCBDate,ReligionCode,RegFormNo,StreamCode,CourseSession,SubCombCode,StreamPartCode, SubCode  from Registration where AckNo='" + AckNo.Text + "'";


            con.Open();
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                ApplicantName.Text = reader["ApplicantName"].ToString();
                HindiName.Text = reader["HindiName"].ToString();
                FatherName.Text = reader["FatherName"].ToString();
                MotherName.Text = reader["MotherName"].ToString();
                DOB.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["DOB"]));
                ReligionCode.SelectedValue = reader["ReligionCode"].ToString();
                if (reader["Gender"].ToString() == "M")
                    GenderM.Checked = true;
                else
                    GenderF.Checked = true;
                MaritalStatus.SelectedValue = reader["MaritalStatus"].ToString();
                if (reader["BloodGroup"].ToString() != "")
                {
                    BloodGroup.SelectedValue = reader["BloodGroup"].ToString();
                }
                EmailId.Text = reader["EmailId"].ToString();
                ContactNo.Text = reader["ContactNo"].ToString();
                CollCode.Text = reader["CollCode"].ToString();
                CastCode.SelectedValue = reader["CastCode"].ToString();
                NationalityCode.SelectedValue = reader["NationalityCode"].ToString();
                CollegeAdmissionDate.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["CollegeAdmissionDate"]));
                RollNo.Text = reader["RollNo"].ToString();
                PermanentAddress1.Text = reader["PermanentAddress1"].ToString();
                PermanentAddress2.Text = reader["PermanentAddress2"].ToString();
                PermanentDistCode.SelectedValue = reader["PermanentDistCode"].ToString();
                PermanentPinCode.Text = reader["PermanentPinCode"].ToString();
                PresentAddress1.Text = reader["PresentAddress1"].ToString();
                PresentAddress2.Text = reader["PresentAddress2"].ToString();
                PresentDistrictCode.SelectedValue = reader["PresentDistrictCode"].ToString();
                PresentPinCode.Text = reader["PresentPinCode"].ToString();
                CollegeAdmissionDate.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["CollegeAdmissionDate"]));
                RegFeeAmt.Text = reader["RegFeeAmt"].ToString();
                SCBNo.Text = reader["SCBNo"].ToString();
                SCBDate.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["SCBDate"]));
                RegFormNo.Text = reader["RegFormNo"].ToString();
                StreamCode.SelectedValue = reader["StreamCode"].ToString();
                Year1.Text = (reader["CourseSession"].ToString()).Substring(0, 4);
                Year2.Text = (reader["CourseSession"].ToString()).Substring(5, 4);
                GetSubComb(reader["SubCombCode"].ToString());

                PopulateDDL popddl = new PopulateDDL();
                popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");

                string spc = reader["StreamPartCode"].ToString();

                if (spc != "")
                {
                    StreamPart.SelectedValue = reader["StreamPartCode"].ToString();
                }
                else
                {
                    StreamPart.SelectedIndex = 0;

                }

                popddl.Popualate(SubCode, "Subject", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
                spc = reader["SubCode"].ToString();
                if (spc != "")
                {
                    SubCode.SelectedValue = reader["SubCode"].ToString();
                }
                else
                {
                    SubCode.SelectedIndex = 0;
                }






                reader.Close();
                cmd.CommandText = " select ExamCode,UnivCode,CollCode,PassYear,RollNo,Division from PREREGQUALIFICATION where AckNo='" + AckNo.Text + "'";
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    ExamCode1.SelectedValue = reader["ExamCode"].ToString();
                    UnivCode1.SelectedValue = reader["UnivCode"].ToString();
                    CollCode1.Text = reader["CollCode"].ToString();
                    PassYear1.Text = reader["PassYear"].ToString();
                    RollNo1.Text = reader["RollNo"].ToString();
                    Division1.SelectedValue = reader["Division"].ToString();

                }

                // if migarated student
                reader.Close();
                cmd.CommandText = "select MigrationNo,MigrationIssueDate from PREREGMIGRATION where AckNo='" + AckNo.Text + "'";
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    MigrationNo.Text = reader["MigrationNo"].ToString();
                    MigrationIssueDate.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["MigrationIssueDate"].ToString()));
                    Panel4.Visible = true;
                }
                else
                    Panel4.Visible = false;


                reader.Close();


                //LblMsg.Text = "";

                Panel2.Visible = true;

            }
            else
            {
                LblMsg.Text = " Please check Ack no.";

                Panel2.Visible = false;

                AckNo.Focus();
            }
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }


    } 
      
     protected void BtnSignSave_Click(object sender, EventArgs e)
    {
        
        //ImageUpload imgUpload=new ImageUpload();
        // string  strFileName = imgUpload.ImageSave(File1, AckNo.Text.ToString());
        // Image2.ImageUrl = strFileName;

    }


    protected void BtnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            char g;
            if (GenderM.Checked == true) g = 'M'; else g = 'F';

            //----Subject Comb Code
            string CourseComb = "C(";
            //Composition
            for (int i = 0; i < CompPaper.Items.Count; i++)
            {
                if (CompPaper.Items[i].Selected)
                {
                    CourseComb += CompPaper.Items[i].Value + ",";
                }
            }
            //Honours Paper
            CourseComb = CourseComb.Substring(0, CourseComb.Length - 1);
            CourseComb += ")+H(";
            for (int i = 0; i < HPaper.Items.Count; i++)
            {
                if (HPaper.Items[i].Selected)
                {
                    CourseComb += HPaper.Items[i].Value + ",";
                }
            }
            //Sunsidiary Paper
            CourseComb = CourseComb.Substring(0, CourseComb.Length - 1);
            CourseComb += ")+S(";
            for (int i = 0; i < SPaper.Items.Count; i++)
            {
                if (SPaper.Items[i].Selected)
                {
                    CourseComb += SPaper.Items[i].Value + ",";
                }
            }
            CourseComb = CourseComb.Substring(0, CourseComb.Length - 1);
            CourseComb += ")";
            //---SubCom Code

            string abc = " update Registration  set HindiName=N'" + HindiName.Text.Trim() +
                        "', ApplicantName='" + ApplicantName.Text.Trim().ToUpper() +
                        "', FatherName='" + FatherName.Text.Trim() +
                        "', MotherName='" + MotherName.Text.Trim() +
                        "', DOB='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(DOB.Text)) +
                        "', ReligionCode='" + ReligionCode.SelectedValue +
                        "', Gender='" + g +
                        "', MaritalStatus='" + MaritalStatus.SelectedValue +
                         "',BloodGroup='" + BloodGroup.SelectedValue +
                        "',EmailId='" + EmailId.Text.Trim() +
                        "',ContactNo='" + ContactNo.Text.Trim() +
                        "', CastCode='" + CastCode.SelectedValue +
                        "', NationalityCode='" + NationalityCode.SelectedValue +
                        "', PermanentAddress1='" + PermanentAddress1.Text.Trim() +
                        "', PermanentAddress2='" + PermanentAddress2.Text.Trim() +
                        "', PermanentDistCode='" + PermanentDistCode.SelectedValue +
                        "', PermanentPinCode='" + PermanentPinCode.Text +
                        "', PresentAddress1='" + PresentAddress1.Text.Trim() +
                        "', PresentAddress2='" + PresentAddress2.Text.Trim() +
                        "', PresentDistrictCode='" + PresentDistrictCode.SelectedValue +
                        "', PresentPinCode='" + PresentPinCode.Text +
                        "', StreamCode='" + StreamCode.SelectedValue +
                       "', CollCode='" + CollCode.SelectedValue +
                       "', CollegeAdmissionDate='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(CollegeAdmissionDate.Text)) +
                       "', RollNo='" + RollNo.Text.Trim() +
                       "', CourseSession='" + Year1.Text + "-" + Year2.Text +
                        "', SCBNo='" + SCBNo.Text.Trim() +
                        "', SCBDate='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(SCBDate.Text)) +
                        "', RegFeeAmt='" + RegFeeAmt.Text.Trim() +
                        "', RegFormNo='" + RegFormNo.Text.Trim() +
                        "', StreamPartCode='" + StreamPart.SelectedValue +
                        "', SubCode ='" + SubCode.SelectedValue +
                        "', SubCombCode='" + CourseComb +
                        "' where AckNo='" + AckNo.Text.Trim() + "'";
            UnivService.Service1 ss = new UnivService.Service1();
            abc = ss.UpdateData(abc);
            // update examdetail
            abc = " update PREREGQUALIFICATION set ExamCode='" + ExamCode1.SelectedValue +
                "', UnivCode='" + UnivCode1.SelectedValue +
                "', CollCode='" + CollCode1.Text +
                "', PassYear='" + PassYear1.Text +
                "', RollNo='" + RollNo1.Text +
                "', Division='" + Division1.SelectedValue +
                 "' where AckNo='" + AckNo.Text.Trim() + "'";
            abc = ss.UpdateData(abc);

            // update migration no
            if (Panel4.Visible == true)
            {
                abc = " update PREREGMIGRATION set MigrationNo='" + MigrationNo.Text.Trim() + "' , MigrationIssueDate='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(MigrationIssueDate.Text)) + "' where AckNo='" + AckNo.Text.Trim() + "'";
                abc = ss.UpdateData(abc);
            }



            if (abc.ToString() == "ok")
            {

                LblMsg.Text = " Record is updated successfully.";


            }
            else
                LblMsg.Text = abc.ToString();
            abc = "update registration set verifystatus='N' where ackno='" + AckNo.Text + "'";
            abc = ss.UpdateData(abc);
            abc= "delete from RejectedRegistration where ackno='" + AckNo.Text + "'";
            abc = ss.UpdateData(abc);
            PopulateDDL popddl = new PopulateDDL();

            popddl.Popualate(AckNo, "Registration", "Select AckNo from Registration where verifystatus='F'", "AckNo", "AckNo");
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message; 
        }
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");


        PopulateList poplist = new PopulateList();
        poplist.Popualate(CompPaper , "COMPOSITION", "Select CompCode,Name from COMPOSITION  order by Name", "Name", "CompCode");
        StreamCode.Focus(); 

    }
    protected void ExamCode1_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateList poplist = new PopulateList();
        //poplist.Popualate(CompPaper, "COMPOSITION", "Select Name,CompCode from COMPOSITION order by Name", "Name", "CompCode");
        poplist.Popualate(HPaper, "COURSEPAPERS", "Select PaperName,SubPaperCode from COURSEPAPERS Where StreamCode='" + StreamCode.SelectedValue + "' And StreamPartCode='" + StreamPart.SelectedValue + "' And SubCode='" + SubCode.SelectedValue + "' order by SubPaperCode", "PaperName", "SubPaperCode");
        ExamCode1.Focus();
    }
    protected void SubCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateList poplist = new PopulateList();
        poplist.Popualate(HPaper, "COURSEPAPERS", "Select PaperName,SubPaperCode from COURSEPAPERS Where StreamCode='" + StreamCode.SelectedValue + "' And StreamPartCode='" + StreamPart.SelectedValue + "' And SubCode='" + SubCode.SelectedValue + "' order by SubPaperCode", "PaperName", "SubPaperCode");
        poplist.Popualate(SPaper, "SUBJECT", "Select SubCode,SubjectName from SUBJECT Where StreamCode='" + StreamCode.SelectedValue + "' and subcode<>'" + SubCode.SelectedValue + "'  order by SubjectName", "SubjectName", "SubCode");
        SubCode.Focus(); 

    }

    protected void GetSubComb(string s)
    {
        // Get Subject Combination

        string c = "", h = "", su = "", papercode = "";
        string[] PaperCode = new string[15];
        int i;
        for (i = 0; i < 15; i++)
            PaperCode[i] = "";

        int noofpaper = 0;
        PopulateList poplist = new PopulateList();
        //comp

        if (s.IndexOf('H') - 4 > 0)
        {
            c = s.Substring(2, s.IndexOf('H') - 4);
            for (i = 0; i < c.Length; i++)
            {
                if (c.Substring(i, 1) != ",")
                    papercode = papercode + c.Substring(i, 1);
                else
                {
                    PaperCode[noofpaper] = papercode;
                    noofpaper++;
                    papercode = "";
                }
            }
            PaperCode[noofpaper] = papercode;
            noofpaper++;
        }

        // set Composition paper name in composition paperlist box
        string sql = "";
        for (i = 0; i < noofpaper; i++)
        {
            sql += "CompCode='" + PaperCode[i] + "' OR ";
        }

        if (sql.Length > 3)
        {
            sql = sql.Substring(0, sql.Length - 3);
            sql = "Select Name,compCode from COMPOSITION Where " + sql;
            poplist.Popualate(CompPaper, "COMPOSITION", sql, "Name", "CompCode");
            for (i = 0; i < CompPaper.Items.Count; i++)
            {
                CompPaper.Items[i].Selected = true;
            }
        }

        //honours
        //hon



        if ((s.IndexOf('S') - (s.IndexOf('H') + 4)) > 0)
        {
            h = s.Substring(s.IndexOf('H') + 2, s.IndexOf('S') - (s.IndexOf('H') + 4));

            papercode = "";
            for (i = 0; i < h.Length; i++)
            {


                if (h.Substring(i, 1) != ",")
                    papercode = papercode + h.Substring(i, 1);
                else
                {
                    PaperCode[noofpaper] = papercode;
                    noofpaper++;
                    papercode = "";
                }
            }
            PaperCode[noofpaper] = papercode;
            noofpaper++;

        }
        // set honours paper name in honours paperlist box
        sql = "";
        for (i = 0; i < noofpaper; i++)
        {
            sql += "SubPaperCode='" + PaperCode[i] + "' OR ";
        }

        if (sql.Length > 3)
        {
            sql = sql.Substring(0, sql.Length - 3);
            sql = "Select PaperName,SubPaperCode from COURSEPAPERS Where " + sql;
            poplist.Popualate(HPaper, "COURSEPAPERS", sql, "PaperName", "SubPaperCode");
            for (i = 0; i < HPaper.Items.Count; i++)
            {
                //HPaper.SelectedIndex = i;
                HPaper.Items[i].Selected = true;
            }
        }

        //sub
        noofpaper = 0; sql = "";

        if ((s.Length - (s.IndexOf('S') + 3)) > 0)
        {
            su = s.Substring(s.IndexOf('S') + 2, s.Length - (s.IndexOf('S') + 3));

            papercode = "";
            for (i = 0; i < su.Length; i++)
            {


                if (su.Substring(i, 1) != ",")
                    papercode = papercode + su.Substring(i, 1);
                else
                {
                    PaperCode[noofpaper] = papercode;
                    noofpaper++;
                    papercode = "";
                }
            }
            PaperCode[noofpaper] = papercode;
            noofpaper++;
        }

        // set subsidiary paper name in subsidiary paperlist box

        sql = "";
        for (i = 0; i < noofpaper; i++)
        {
            sql += "SubCode='" + PaperCode[i] + "' OR ";
        }
        if (sql.Length > 3)
        {
            sql = sql.Substring(0, sql.Length - 3);
            sql = "Select SubCode,SubjectName from SUBJECT Where " + sql;
            poplist.Popualate(SPaper, "SUBJECT", sql, "SubjectName", "SubCode");
            for (i = 0; i < SPaper.Items.Count; i++)
            {

                SPaper.Items[i].Selected = true;
            }
        }



        //------------ End Of Subject Combination
    }
}


