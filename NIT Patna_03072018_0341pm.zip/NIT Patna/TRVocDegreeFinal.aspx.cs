using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Data;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class TRVocDegreeFinal : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();

            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College where collcode in (select distinct collcode from exam) order by CollName", "CollName", "CollCode");
            popddl.Popualate(ExamYear, "Exam", "Select distinct ExamYear from Exam order by ExamYear", "ExamYear", "ExamYear");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode='02'order by StreamAbbr", "StreamAbbr", "StreamCode");// streamcode in (select distinct streamcode from exam) 
            CourseValue();



        }
    }

    // Other Functions.....
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        CourseValue();
    }
    protected void CourseValue()
    {
        PopulateDDL popddl = new PopulateDDL();
        //popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart, StreamPartCode from StreamPart where streamcode='" + StreamCode.SelectedValue + "' and streampartcode in (select distinct streampartcode from exam) order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");


    }
    protected void CollChkBox_CheckedChanged(object sender, EventArgs e)
    {
        if (CollChkBox.Checked == true)
        {
            CollCode.Enabled = false;
            InstCode.Enabled = false;
        }
        else
        {
            CollCode.Enabled = true;
            InstCode.Enabled = true;
        }
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
    }


    protected void BtnGenerate_Click(object sender, EventArgs e)
    {
        // Data will save in Tabel - TRVocDegreeFinal -- created on 07 JUne 2012 //Ravi



        LblMsg.Text = string.Empty;
        LblMsgDeleted.Text = string.Empty;


        Boolean TRReprocess; TRReprocess = false;
        if (ChkBoxReProcess.Checked == true) TRReprocess = true;


        UnivService.Service1 NicService = new UnivService.Service1();
        String TypeCode = NicService.GetNewCode("Select StreamTypeCode from Stream where StreamCode='" + StreamCode.SelectedValue + "' ");

        // Get Stream Type--------------


        if (TypeCode == "03" && StreamCode.SelectedValue == "02")//Voc
        {
            //GenerateTRVoc(); // 3yr vocational degree

            if (SubCode.SelectedValue == "009")
            {
                // BJMC 

                if (TRReprocess == true) // Call DeleteTrProcessedData();
                    DeleteTRProcessedData("TRVocDegreeFinal");
                GenerateTRVoc();
            }
            else if (SubCode.SelectedValue == "008")
            {
                // BBA

                if (TRReprocess == true) // Call DeleteTrProcessedData();
                    DeleteTRProcessedData("TRVocDegreeFinal");
                GenerateTRVoc();
            }
            else if (SubCode.SelectedValue == "007")
            {
                // BCA
                if (TRReprocess == true) // Call DeleteTrProcessedData();
                    DeleteTRProcessedData("TRVocDegreeFinal");
                GenerateTRVoc();
            }
            else
            {
            }
        }
    }



    protected void GenerateTRVoc()
    {
        try
        {

            SqlConnection con = new SqlConnection();
            SqlConnection con1 = new SqlConnection();
            SqlConnection con2 = new SqlConnection();
            SqlConnection con3 = new SqlConnection();
            SqlDataReader rd;


            SqlCommand cmd = new SqlCommand();
            SqlCommand cmd3 = new SqlCommand();
            SqlCommand cmd2 = new SqlCommand();
            SqlCommand cmd1 = new SqlCommand();

            cmd.Connection = con;
            cmd3.Connection = con3;
            cmd2.Connection = con2;
            cmd1.Connection = con1;

            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            con3.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            con2.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            con1.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

          


            if (CollChkBox.Checked)
            {
                cmd.CommandText = "select univrollno,collcode from EXAM where StreamCode='" + StreamCode.SelectedValue + "' and streampartcode='5' and subcode='" + SubCode.SelectedValue + "' and examyear='" + ExamYear.SelectedValue + "'";
              
            }
            else
            {
                cmd.CommandText = "select univrollno from EXAM where CollCode='" + CollCode.SelectedValue + "' and StreamCode='" + StreamCode.SelectedValue + "' and streampartcode='5' and subcode='" + SubCode.SelectedValue + "' and examyear='" + ExamYear.SelectedValue + "'";
              
            }


            // only 4 BCA- Add union in query for those students who have already paas in 3rd year but promoted in 2nd year....

            //cmd.CommandText = "select RegNo,UnivRollNo,ENAME,FatherName,MotherName,Gender,Paper1 as Paper17,Paper2 as Paper18,Paper3 as Paper19,Paper4 as Paper20,Paper5 as Paper21,Paper6 as Paper22,Paper7 as Paper23,Paper8 as Paper24,PaperMarks1 as PaperMarks17,PaperMarks2 as PaperMarks18,PaperMarks3 as PaperMarks19,PaperMarks4 as PaperMarks20,PaperMarks5 as PaperMarks21,PaperMarks6 as PaperMarks22,PaperMarks7 as PaperMarks23,PaperMarks8 as PaperMarks24,PaperPracMarks1 as PaperPracMarks17,PaperPracMarks2 as PaperPracMarks18,PaperPracMarks3 as PaperPracMarks19,PaperPracMarks4 as PaperPracMarks20,PaperPracMarks5 as PaperPracMarks21,PaperPracMarks6 as PaperPracMarks22,PaperPracMarks7 as PaperPracMarks23,PaperPracMarks8 as PaperPracMarks24,GrandTotal as GrandTotal3,Remarks as Remarks3,examtype as ExamType3 from V_TRVocDegreeFinal where CollCode='" + CollCode.SelectedValue + "' and StreamCode='" + StreamCode.SelectedValue + "' and streampart='5' and subcode='" + SubCode.SelectedValue + "' and examyear='" + ExamYear.SelectedValue + "' ";




            string RecordUpdated = string.Empty;
            int count = 0, TotCount = 0; int HonsTotal = 0;

            con.Open();
            rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                UnivService.Service1 NicService = new UnivService.Service1();

                while (rd.Read())
                {

                    try
                    {

                        SqlDataReader rd3;
                        SqlDataReader rd2;
                        SqlDataReader rd1;

                        string CollCode1=string.Empty;

                        if (CollChkBox.Checked == true)
                            CollCode1 = rd["CollCode"].ToString();
                        else
                            CollCode1 = CollCode.SelectedValue.ToString();


                        cmd3.CommandText = "SELECT RegNo,UnivRollNo,ENAME,FatherName,MotherName,Gender,Paper1 as Paper17,Paper2 as Paper18,Paper3 as Paper19,Paper4 as Paper20,Paper5 as Paper21,Paper6 as Paper22,Paper7 as Paper23,Paper8 as Paper24,PaperMarks1 as PaperMarks17,PaperMarks2 as PaperMarks18,PaperMarks3 as PaperMarks19,PaperMarks4 as PaperMarks20,PaperMarks5 as PaperMarks21,PaperMarks6 as PaperMarks22,PaperMarks7 as PaperMarks23,PaperMarks8 as PaperMarks24,PaperPracMarks1 as PaperPracMarks17,PaperPracMarks2 as PaperPracMarks18,PaperPracMarks3 as PaperPracMarks19,PaperPracMarks4 as PaperPracMarks20,PaperPracMarks5 as PaperPracMarks21,PaperPracMarks6 as PaperPracMarks22,PaperPracMarks7 as PaperPracMarks23,PaperPracMarks8 as PaperPracMarks24,GrandTotal as GrandTotal3,Remarks as Remarks3,examtype as ExamType3,ExamHeldDate from V_TRVocDegreeFinal Where CollCode='" + CollCode1 + "' And ExamYear='" + ExamYear.SelectedValue + "' And Streamcode='02' And Streampart='5'  and  subcode='" + SubCode.SelectedValue + "' and UnivRollNo='" + rd["univrollno"].ToString() + "' ";
                        cmd2.CommandText = "SELECT Paper1 as Paper9,Paper2 as Paper10,Paper3 as Paper11,Paper4 as Paper12,Paper5 as Paper13,Paper6 as Paper14,Paper7 as Paper15,Paper8 as Paper16,PaperMarks1 as PaperMarks9,PaperMarks2 as PaperMarks10,PaperMarks3 as PaperMarks11,PaperMarks4 as PaperMarks12,PaperMarks5 as PaperMarks13,PaperMarks6 as PaperMarks14,PaperMarks7 as PaperMarks15,PaperMarks8 as PaperMarks16,PaperPracMarks1 as PaperPracMarks9,PaperPracMarks2 as PaperPracMarks10,PaperPracMarks3 as PaperPracMarks11,PaperPracMarks4 as PaperPracMarks12,PaperPracMarks5 as PaperPracMarks13,PaperPracMarks6 as PaperPracMarks14,PaperPracMarks7 as PaperPracMarks15,PaperPracMarks8 as PaperPracMarks16,GrandTotal as GrandTotal2,Remarks as Remarks2 from V_TRVocDegreeFinal Where UnivRollNo='" + rd["univrollno"].ToString() + "' And Streamcode='" + StreamCode.SelectedValue + "' And Streampart=4  and subcode='" + SubCode.SelectedValue + "'";//Where CollCode= 121 And Streamcode='02' And Streampart=4  and  subcode=008 and UnivRollNo='101210200017'"; //and CollCode='" + CollCode.SelectedValue + "'  
                        cmd1.CommandText = "SELECT Paper1,Paper2,Paper3,Paper4,Paper5,Paper6,Paper7,Paper8,PaperMarks1,PaperMarks2,PaperMarks3,PaperMarks4,PaperMarks5,PaperMarks6,PaperMarks7,PaperMarks8,PaperPracMarks1,PaperPracMarks2,PaperPracMarks3,PaperPracMarks4,PaperPracMarks5,PaperPracMarks6,PaperPracMarks7,PaperPracMarks8,GrandTotal as GrandTotal1,Remarks as Remarks1 from V_TRVocDegreeFinal Where UnivRollNo='" + rd["univrollno"].ToString() + "' and Streamcode='" + StreamCode.SelectedValue + "' And Streampart=3  and subcode='" + SubCode.SelectedValue + "'";//Where CollCode= 121 And Streamcode='02' And Streampart=3  and  subcode=008 and UnivRollNo='101210200017'"; // CollCode='" + CollCode.SelectedValue + "'  And 

                        con3.Open(); rd3 = cmd3.ExecuteReader(); rd3.Read();
                        con2.Open(); rd2 = cmd2.ExecuteReader(); rd2.Read();
                        con1.Open(); rd1 = cmd1.ExecuteReader(); rd1.Read();


                        string[] col = new string[93];
                        string[] val = new string[93];
                        string[] coltype = new string[93];
                        for (int i = 0; i < 93; i++)
                        {
                            coltype[i] = "0";
                        }
                        coltype[5] = "1";




                        col[0] = "CollCode"; val[0] = CollCode1; 
                        col[1] = "StreamCode"; val[1] = StreamCode.SelectedValue.ToString();
                        col[2] = "ExamYear"; val[2] = ExamYear.SelectedValue.ToString();
                        col[3] = "UnivRollNo"; val[3] = rd3["univrollno"].ToString();
                        col[4] = "SubCode"; val[4] = SubCode.SelectedValue.ToString();

                        col[5] = "HName"; val[5] = rd3["EName"].ToString();
                        col[6] = "EName"; val[6] = rd3["EName"].ToString();
                        col[7] = "FatherName"; val[7] = rd3["FatherName"].ToString();
                        col[8] = "MotherName"; val[8] = rd3["MotherName"].ToString();
                        col[9] = "Gender"; val[9] = rd3["Gender"].ToString();
                        col[10] = "RegNo"; val[10] = rd3["RegNo"].ToString();



                        col[11] = "Paper1"; val[11] = rd1["Paper1"].ToString();
                        col[12] = "Paper2"; val[12] = rd1["Paper2"].ToString();
                        col[13] = "Paper3"; val[13] = rd1["Paper3"].ToString();
                        col[14] = "Paper4"; val[14] = rd1["Paper4"].ToString();
                        col[15] = "Paper5"; val[15] = rd1["Paper5"].ToString();
                        col[16] = "Paper6"; val[16] = rd1["Paper6"].ToString();
                        col[17] = "Paper7"; val[17] = rd1["Paper7"].ToString();
                        col[18] = "Paper8"; val[18] = rd1["Paper8"].ToString();
                        col[19] = "Paper9"; val[19] = rd2["Paper9"].ToString();
                        col[20] = "Paper10"; val[20] = rd2["Paper10"].ToString();
                        col[21] = "Paper11"; val[21] = rd2["Paper11"].ToString();
                        col[22] = "Paper12"; val[22] = rd2["Paper12"].ToString();
                        col[23] = "Paper13"; val[23] = rd2["Paper13"].ToString();
                        col[24] = "Paper14"; val[24] = rd2["Paper14"].ToString();
                        col[25] = "Paper15"; val[25] = rd2["Paper15"].ToString();
                        col[26] = "Paper16"; val[26] = rd2["Paper16"].ToString();
                        col[27] = "Paper17"; val[27] = rd3["Paper17"].ToString();
                        col[28] = "Paper18"; val[28] = rd3["Paper18"].ToString();
                        col[29] = "Paper19"; val[29] = rd3["Paper19"].ToString();
                        col[30] = "Paper20"; val[30] = rd3["Paper20"].ToString();
                        col[31] = "Paper21"; val[31] = rd3["Paper21"].ToString();
                        col[32] = "Paper22"; val[32] = rd3["Paper22"].ToString();
                        col[33] = "Paper23"; val[33] = rd3["Paper23"].ToString();
                        col[34] = "Paper24"; val[34] = rd3["Paper24"].ToString();

                        col[35] = "PaperMarks1"; val[35] = rd1["PaperMarks1"].ToString();
                        col[36] = "PaperMarks2"; val[36] = rd1["PaperMarks2"].ToString();
                        col[37] = "PaperMarks3"; val[37] = rd1["PaperMarks3"].ToString();
                        col[38] = "PaperMarks4"; val[38] = rd1["PaperMarks4"].ToString();
                        col[39] = "PaperMarks5"; val[39] = rd1["PaperMarks5"].ToString();
                        col[40] = "PaperMarks6"; val[40] = rd1["PaperMarks6"].ToString();
                        col[41] = "PaperMarks7"; val[41] = rd1["PaperMarks7"].ToString();
                        col[42] = "PaperMarks8"; val[42] = rd1["PaperMarks8"].ToString();
                        col[43] = "PaperMarks9"; val[43] = rd2["PaperMarks9"].ToString();
                        col[44] = "PaperMarks10"; val[44] = rd2["PaperMarks10"].ToString();
                        col[45] = "PaperMarks11"; val[45] = rd2["PaperMarks11"].ToString();
                        col[46] = "PaperMarks12"; val[46] = rd2["PaperMarks12"].ToString();
                        col[47] = "PaperMarks13"; val[47] = rd2["PaperMarks13"].ToString();
                        col[48] = "PaperMarks14"; val[48] = rd2["PaperMarks14"].ToString();
                        col[49] = "PaperMarks15"; val[49] = rd2["PaperMarks15"].ToString();
                        col[50] = "PaperMarks16"; val[50] = rd2["PaperMarks16"].ToString();
                        col[51] = "PaperMarks17"; val[51] = rd3["PaperMarks17"].ToString();
                        col[52] = "PaperMarks18"; val[52] = rd3["PaperMarks18"].ToString();
                        col[53] = "PaperMarks19"; val[53] = rd3["PaperMarks19"].ToString();
                        col[54] = "PaperMarks20"; val[54] = rd3["PaperMarks20"].ToString();
                        col[55] = "PaperMarks21"; val[55] = rd3["PaperMarks21"].ToString();
                        col[56] = "PaperMarks22"; val[56] = rd3["PaperMarks22"].ToString();
                        col[57] = "PaperMarks23"; val[57] = rd3["PaperMarks23"].ToString();
                        col[58] = "PaperMarks24"; val[58] = rd3["PaperMarks24"].ToString();



                        col[59] = "PaperPracMarks1";
                        col[60] = "PaperPracMarks2";
                        col[61] = "PaperPracMarks3";
                        col[62] = "PaperPracMarks4";
                        col[63] = "PaperPracMarks5";
                        col[64] = "PaperPracMarks6";
                        col[65] = "PaperPracMarks7";
                        col[66] = "PaperPracMarks8";
                        col[67] = "PaperPracMarks9";
                        col[68] = "PaperPracMarks10";
                        col[69] = "PaperPracMarks11";
                        col[70] = "PaperPracMarks12";
                        col[71] = "PaperPracMarks13";
                        col[72] = "PaperPracMarks14";
                        col[73] = "PaperPracMarks15";
                        col[74] = "PaperPracMarks16";
                        col[75] = "PaperPracMarks17";
                        col[76] = "PaperPracMarks18";
                        col[77] = "PaperPracMarks19";
                        col[78] = "PaperPracMarks20";
                        col[79] = "PaperPracMarks21";
                        col[80] = "PaperPracMarks22";
                        col[81] = "PaperPracMarks23";
                        col[82] = "PaperPracMarks24";


                        val[59] = rd1["PaperPracMarks1"].ToString();
                        val[60] = rd1["PaperPracMarks2"].ToString();
                        val[61] = rd1["PaperPracMarks3"].ToString();
                        val[62] = rd1["PaperPracMarks4"].ToString();
                        val[63] = rd1["PaperPracMarks5"].ToString();
                        val[64] = rd1["PaperPracMarks6"].ToString();
                        val[65] = rd1["PaperPracMarks7"].ToString();
                        val[66] = rd1["PaperPracMarks8"].ToString();
                        val[67] = rd2["PaperPracMarks9"].ToString();
                        val[68] = rd2["PaperPracMarks10"].ToString();
                        val[69] = rd2["PaperPracMarks11"].ToString(); ;
                        val[70] = rd2["PaperPracMarks12"].ToString();
                        val[71] = rd2["PaperPracMarks13"].ToString();
                        val[72] = rd2["PaperPracMarks14"].ToString();
                        val[73] = rd2["PaperPracMarks15"].ToString();
                        val[74] = rd2["PaperPracMarks16"].ToString();
                        val[75] = rd3["PaperPracMarks17"].ToString();
                        val[76] = rd3["PaperPracMarks18"].ToString();
                        val[77] = rd3["PaperPracMarks19"].ToString();
                        val[78] = rd3["PaperPracMarks20"].ToString();
                        val[79] = rd3["PaperPracMarks21"].ToString();
                        val[80] = rd3["PaperPracMarks22"].ToString();
                        val[81] = rd3["PaperPracMarks23"].ToString();
                        val[82] = rd3["PaperPracMarks24"].ToString();

                        col[83] = "CourseSession"; val[83] = NicService.GetNewCode("Select coursesession from Registration where regno='" + rd3["regno"].ToString() + "'");
                        col[84] = "ExamHeldDate"; val[84] = rd3["ExamHeldDate"].ToString();
                        col[85] = "AggregateTotal"; val[85] = Convert.ToString(int.Parse(rd1["GrandTotal1"].ToString()) + int.Parse(rd2["GrandTotal2"].ToString()) + int.Parse(rd3["GrandTotal3"].ToString()));


                        string FinalResultStatus = string.Empty;

                        if (rd3["remarks3"].ToString() == "Pass" && rd2["remarks2"].ToString() == "Pass" && rd1["remarks1"].ToString() == "Pass")
                        {
                            FinalResultStatus = "Pass";
                        }
                        else if (rd3["remarks3"].ToString() == "PassUR" && rd2["remarks2"].ToString() == "Pass" && rd1["remarks1"].ToString() == "Pass")
                        {
                            FinalResultStatus = "PassUR";                        
                        }

                        else if (rd3["remarks3"].ToString() == "Pass" && rd2["remarks2"].ToString() == "Promoted" && rd1["remarks1"].ToString() == "Pass")
                        {
                            FinalResultStatus = "NC-PII";
                        }
                        else
                        {
                            FinalResultStatus = "Fail";
                        }






                        col[86] = "TotalPercentage"; val[86] = "";



                        if (SubCode.SelectedValue.ToString() == "008")
                        {
                            try
                            {

                                HonsTotal = int.Parse(val[35].ToString()) + int.Parse(val[36].ToString()) + int.Parse(val[37].ToString()) + int.Parse(val[38].ToString()) + int.Parse(val[59].ToString()) + int.Parse(val[60].ToString()) + int.Parse(val[61].ToString()) + int.Parse(val[62].ToString()) + int.Parse(val[43].ToString()) + int.Parse(val[44].ToString()) + int.Parse(val[45].ToString()) + int.Parse(val[46].ToString()) + int.Parse(val[67].ToString()) + int.Parse(val[68].ToString()) + int.Parse(val[69].ToString()) + int.Parse(val[70].ToString()) + int.Parse(val[51].ToString()) + int.Parse(val[52].ToString()) + int.Parse(val[53].ToString()) + int.Parse(val[54].ToString()) + int.Parse(val[75].ToString()) + int.Parse(val[76].ToString()) + int.Parse(val[77].ToString());
                                double TotPer = double.Parse(HonsTotal.ToString()) / 12;
                                val[86] = TotPer.ToString("F2");

                            }
                            catch (Exception ex)
                            {
                                HonsTotal = 0;
                                val[86] = "0.00";
                            }

                        }

                        else if (SubCode.SelectedValue.ToString() == "007")
                        {
                            try
                            {

                                HonsTotal = int.Parse(val[85].ToString());
                                double TotPer = double.Parse(HonsTotal.ToString()) / 24;
                                val[86] = TotPer.ToString("F2");

                            }
                            catch (Exception ex)
                            {
                                HonsTotal = 0;
                                val[86] = "0.00";
                            }
                        }

                        else if (SubCode.SelectedValue.ToString() == "009")
                        {
                            try
                            {

                                HonsTotal = int.Parse(val[35].ToString()) + int.Parse(val[36].ToString()) + int.Parse(val[37].ToString()) + int.Parse(val[38].ToString()) + int.Parse(val[59].ToString()) + int.Parse(val[60].ToString()) + int.Parse(val[61].ToString()) + int.Parse(val[62].ToString()) + int.Parse(val[43].ToString()) + int.Parse(val[44].ToString()) + int.Parse(val[45].ToString()) + int.Parse(val[46].ToString()) + int.Parse(val[67].ToString()) + int.Parse(val[68].ToString()) + int.Parse(val[69].ToString()) + int.Parse(val[70].ToString()) + int.Parse(val[51].ToString()) + int.Parse(val[52].ToString()) + int.Parse(val[53].ToString()) + int.Parse(val[54].ToString()) + int.Parse(val[55].ToString()) + int.Parse(val[56].ToString()) + int.Parse(val[75].ToString()) + int.Parse(val[76].ToString()) + int.Parse(val[77].ToString()) + int.Parse(val[78].ToString()) + int.Parse(val[79].ToString());
                                double TotPer = double.Parse(HonsTotal.ToString()) / 14;
                                val[86] = TotPer.ToString("F2");

                            }
                            catch (Exception ex)
                            {
                                HonsTotal = 0;
                                val[86] = "0.00";
                            }

                        }

                        else
                        {
                        }



                        col[87] = "ResultStatus"; val[87] = FinalResultStatus;
                        col[88] = "Grade"; val[88] = "";
                        col[89] = "Remarks"; val[89] = "";
                        col[90] = "HonsTotal"; val[90] = HonsTotal.ToString();
                        col[91] = "ProcessedDate"; val[91] = string.Format("{0:MM/dd/yyyy h:mm:ss}", System.DateTime.Now);
                        col[92] = "UserId"; val[92] = Session["UserId"].ToString();

                        RecordUpdated = NicService.SaveDataUniCode("TRVocDegreeFinal", col, val, coltype);
                        if (RecordUpdated == "1") TotCount = TotCount + 1;
                        rd3.Dispose(); rd2.Dispose(); rd1.Dispose();
                        con3.Close(); con2.Close(); con1.Close();
                    }
                    catch (Exception ex)
                    {

                        con3.Close(); con2.Close(); con1.Close();
                    }
                }


                LblMsg.Text = TotCount + " Records Updated";
                rd.Dispose();
                con.Close();

            }
        }
        catch (Exception ex1)
        {
            LblMsg.Text = ex1.Message.ToString();
        }



    }



    // Delete Already TR Processed Data from Table -- TRPG,TRVoc,TRDiploma etc.....
    protected void DeleteTRProcessedData(string TableName)
    {
        SqlConnection con = new SqlConnection();

        try
        {
            string SQL = string.Empty, TRCollCode = string.Empty, TRSubCode = string.Empty;
            int ResultCount; ResultCount = 0;
            if (CollChkBox.Checked == true) TRCollCode = "ALL";
            if (CollChkBox.Checked == true) TRSubCode = "ALL";


            if (TableName == "TRVocDegreeFinal")
            {
                if (TRCollCode == "ALL")
                    SQL = "Delete from " + TableName + " where StreamCode=" + StreamCode.SelectedValue.ToString() + " and SubCode=" + SubCode.SelectedValue.ToString() + " and ExamYear=" + ExamYear.SelectedValue.ToString() + " ";
                else
                    SQL = "Delete from " + TableName + " where CollCode=" + CollCode.SelectedValue.ToString() + " and StreamCode=" + StreamCode.SelectedValue.ToString() + " and SubCode=" + SubCode.SelectedValue.ToString() + " and ExamYear=" + ExamYear.SelectedValue.ToString() + " ";
            }



            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.CommandText = SQL;

            con.Open();
            ResultCount = int.Parse(cmd.ExecuteNonQuery().ToString());

            LblMsgDeleted.Text = "TR Deleted for " + ResultCount + " Students";

        }
        catch (Exception ex)
        {
            LblMsg.Text = "DeleteTRProcessedData " + ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }
    }






}
