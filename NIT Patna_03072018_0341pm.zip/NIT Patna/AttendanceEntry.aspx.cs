using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
public partial class AttendanceEntry : System.Web.UI.Page
{
    string criteria = "false";
    string Subcode;
    DataSet dsmarksdata;
    Functionreviseed fn = new Functionreviseed();
    string ThFMarks, PractFMarks;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            Session["checkclear"] = criteria;
            popupcontent.Visible = false;
            try
            {

                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "9") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "15"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }

                ViewState.Add("EditMode", "false");

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }

            string strrole = "";
            if (Session["Role"].ToString() == "9")
                strrole = " and UserId='" + Session["UserId"].ToString() + "'";
            PopulateDDL popddl = new PopulateDDL();


            //Manish-06092014
            popddl.Popualate(ExamYear, "Year", "select distinct ExamSession from Faculty_paper_a where is_active='Y'  order by ExamSession desc", "ExamSession", "ExamSession");
            ExamYear.Items.Insert(0, new ListItem("--Select--", "00"));
            StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
            StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
            Subject.Items.Insert(0, new ListItem("--Select--", "00"));
            splcode.Items.Insert(0, new ListItem("--Select--", "00"));
            //  ExamYear.Focus();
        }
        //for (int i = 0; i < gr1.Rows.Count - 1; i++)
        //{
        //    TextBox curTexbox = gr1.Rows[i].Cells[3].FindControl("ct1") as TextBox;
        //    TextBox nexTextbox = gr1.Rows[i + 1].Cells[3].FindControl("ct1") as TextBox;
        //    curTexbox.Attributes.Add("onkeypress", "return clickEnter('" + nexTextbox.ClientID + "', event)");
        //}
        /*   if (!IsPostBack)
           {
               ScriptManager.RegisterStartupScript(this, typeof(string), "alert", "validate();", true);
           }
          */

    }

    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        MTheory.Checked = false;
        // RBComp.Checked=false ;
        //MElective.Checked = false;
        //MThPr.Checked = false;
        MPrac.Checked = false;

        //shivam - 23-04-2014
        StreamPart.Items.Clear();
        Subject.Items.Clear();
        splcode.Items.Clear();
        string strrole = "";
        if (Session["Role"].ToString() == "9")
            strrole = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";
        string strspecilaization = "SELECT     CourseSpecialization.SpDescription, CourseSpecialization.SPCode " +
                                    " FROM Faculty_paper_a INNER JOIN COURSEPAPERS ON " +
                                    " Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " +
                                    " CourseSpecialization ON Faculty_paper_a.Splcode = CourseSpecialization.SPCode " +
                                    " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                                    " and COURSEPAPERS.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                                    " GROUP BY CourseSpecialization.SpDescription, CourseSpecialization.SPCode " +
                                    " order by CourseSpecialization.SPCode ";

        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(splcode, "Specialization", strspecilaization, "SpDescription", "SPCode");
        string strstreampart = "SELECT     STREAMPART.StreamPart,STREAMPART.StreamPartCode " +
                               " FROM         COURSEPAPERS AS COURSEPAPERS_1 INNER JOIN " +
                               " STREAMPART ON COURSEPAPERS_1.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN " +
                               " Faculty_paper_a INNER JOIN " +
                               " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode ON COURSEPAPERS_1.PaperAbbr = COURSEPAPERS.PaperAbbr " +
                               " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                               " and (Faculty_paper_a.splcode='" + splcode.SelectedValue + "') and STREAMPART.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                               " GROUP BY STREAMPART.StreamPartCode, STREAMPART.StreamPart " +
                               " order by StreamPart";

        popddl.Popualate(StreamPart, "StreamPart", strstreampart, "StreamPart", "StreamPartCode");
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
        StreamCode.Focus();
    }
    protected void MTheory_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("T");
    }
    //protected void MThPr_CheckedChanged(object sender, EventArgs e)
    //{
    //    GetPaperCode("X");

    //}
    ///*protected void RBComp_CheckedChanged(object sender, EventArgs e)
    //{
    //    GetPaperCode("Comp");
    //}*/
    //protected void MElective_CheckedChanged(object sender, EventArgs e)
    //{
    //    GetPaperCode("E");
    //}
    protected void MPrac_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("P");
    }

    private void GetPaperCode(string PaperType)
    {
        Subject.Items.Clear();
        string Querystr = "";
        string queryjoin = "";

        //if (StreamPart.SelectedItem.ToString().IndexOf('A') > 0 || StreamPart.SelectedItem.ToString().IndexOf('B') > 0)
        //{
        //    Querystr = " (COURSEPAPERS.StreamPart = '" + StreamPart.SelectedItem.ToString() + "')";
        //    queryjoin = "COURSEPAPERS_1.PaperAbbr = COURSEPAPERS.PaperAbbr";
        //}
        //else
        //{
        Querystr = " (COURSEPAPERS.StreamPartCode='" + StreamPart.SelectedValue + "')";
        queryjoin = "COURSEPAPERS_1.SubPaperCode = COURSEPAPERS.SubPaperCode";
        //}

        string strrole = "";
        if (Session["Role"].ToString() == "9" || Session["Role"].ToString() == "13")
            strrole = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";

        string strcourse = "SELECT     COURSEPAPERS.PaperAbbr " +
                           " FROM         Faculty_paper_a INNER JOIN COURSEPAPERS AS COURSEPAPERS_1 ON " +
                           " Faculty_paper_a.SubPaperCode = COURSEPAPERS_1.SubPaperCode INNER JOIN COURSEPAPERS " +
                            " ON " + queryjoin + " INNER JOIN " +
                            " EXAMPAPERDETAIL ON COURSEPAPERS.SubPaperCode = EXAMPAPERDETAIL.SubPaperCode " +
                          " WHERE     (Faculty_paper_a.Is_Active = 'Y') And (Faculty_paper_a.splcode = '" + splcode.SelectedValue + "') " + strrole +
                          " and" + Querystr + " and  (EXAMPAPERDETAIL.ExamSession='" + ExamYear.SelectedValue + "') and ";

        string querypart = " GROUP BY COURSEPAPERS.PaperAbbr ORDER BY COURSEPAPERS.PaperAbbr ";

        PopulateDDL popddl = new PopulateDDL();
        UnivService.Service1 NicService = new UnivService.Service1();
        Subcode = NicService.GetNewCode("select subcode from subject where streamcode='" + StreamCode.SelectedValue + "'");


        if (PaperType == "T")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "(COURSEPAPERS.PaperTypeCode='02' or COURSEPAPERS.PaperTypeCode='04') and (Faculty_paper_a.PaperType='T' or Faculty_paper_a.PaperType is null)" + querypart, "PaperAbbr", "PaperAbbr");
        }
        else if (PaperType == "X")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "PaperTypeCode='04'" + querypart, "PaperAbbr", "PaperAbbr");
        }
        else if (PaperType == "P")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "(COURSEPAPERS.PaperTypeCode='01' or COURSEPAPERS.PaperTypeCode='04') and (Faculty_paper_a.PaperType='P' or Faculty_paper_a.PaperType is null)" + querypart, "PaperAbbr", "PaperAbbr");
        }
        else if (PaperType == "E")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "PaperTypeCode='03'" + querypart, "PaperAbbr", "PaperAbbr");
        }
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
        //  GetMarks();
        Subject.Focus();

    }
    /*protected void SubCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        MTheory.Checked = false;
     //   RBComp.Checked = false;
        MElective.Checked = false;
        MThPr.Checked = false;
        MPrac.Checked = false;
        Subject.Items.Clear();
    }*/


    protected void LinkButton1_Click(object sender, EventArgs e)
    {

        UnivService.Service1 NicService = new UnivService.Service1();
        string countQuery = "   select Count( distinct Classheld) from attendancedetail where registerId=" + ddlMonth.SelectedValue;
        int totalClassCount = (int)fn.singlevalue(countQuery);
        if (totalClassCount > 1)
        {
            txtTotalClass.Enabled = false;
            chkDifferentClass.Enabled = false;
            chkDifferentClass.Checked = true;
            txtTotalClass.Text = "";
            RequiredFieldValidator3.ValidationGroup = "NoVali";
        }
        else
        {
            string query = " select ISNULL(convert(varchar, Classheld),'') from attendancedetail where registerId=" + ddlMonth.SelectedValue;
            string totalClass = (string)fn.singlevalue(query);

            txtTotalClass.Text = totalClass;
            txtTotalClass.Enabled = true;
            chkDifferentClass.Checked = false;
            chkDifferentClass.Enabled = true;
        }
        ddlMonth.Enabled = true;
        Subject.Enabled = true;
        Panel3.Enabled = true;
        panelattandancesem.Visible = false;
        savecommandgr4.Visible = false;
        //SelectedPaperList.Items.Clear();
        //criteria = "true";
        //Session["checkclear"] = criteria;
        //string sess = Session["checkclear"].ToString();
        dsmarksdata = null;

        //Gr8.Columns.Clear();
        // Gr8.EmptyDataText = "";
        LblMsg.Text = "";
        //criteria = "false";
        //Session["checkclear"] = criteria;
        //sess = Session["checkclear"].ToString();
    }
    int l, rcount;

    int Insdata;

    protected void Button1_Click(object sender, EventArgs e)
    {
        txtTotalClass.Enabled = false;
        chkDifferentClass.Enabled = false;
        ddlMonth.Enabled = false;
        Subject.Enabled = false;
        btnsaveall.Visible = true;
        Button2.Visible = true;
        ViewState["RegisterId"] = ddlMonth.SelectedValue;

        bindgrid();

    }

    protected void Subject_SelectedIndexChanged(object sender, EventArgs e)
    {
        //and  ( b.id>=month(DATEADD(dd,-6,getdate())) or Convert(Date,getdate()) between d.Fromdate and d.ToDate

        object checkstatus = fn.singlevalue("SELECT ISNULL(Faculty_paper_a.Is_AttendActive, 'Y') AS AttendStatus FROM " + 
            " Faculty_paper_a INNER JOIN COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " + 
            " (Faculty_paper_a.ExamSession = '"+ExamYear.SelectedItem.ToString()+"') AND (Faculty_paper_a.Is_Active = 'Y') AND " + 
            " (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') AND (COURSEPAPERS.PaperAbbr = '" + Subject.SelectedValue.ToString() + "') AND " + 
            " (COURSEPAPERS.StreamPartCode = '"+StreamPart.SelectedValue.ToString()+"') AND (COURSEPAPERS.StreamCode = '"+StreamCode.SelectedValue.ToString()+"') AND (Faculty_paper_a.Splcode = '"+splcode.SelectedValue.ToString()+"')");
        if (checkstatus == null)
        {
            LblMsg.Text = "";
            return;
        }

        if (checkstatus.ToString() == "Y")
        {
            UnivService.Service1 NicService = new UnivService.Service1();
            string query = "select b.Name,a.Id from attendanceregister a inner join Months b on a.Month = b.Id inner join Coursepapers c on a.subpapercode=c.subpapercode " +
                            " left join AttendanceExtended d on a.Id=d.RegisterId where c.paperabbr = '" + Subject.SelectedValue + "' and c.streampartcode = '" + StreamPart.SelectedValue + "' and a.SplCode='" + splcode.SelectedValue + "' and a.ExamSession = '"+ExamYear.SelectedItem.ToString()+"'";
                            //" and  ( b.id>=month(DATEADD(dd,-18,getdate())) or Convert(Date,getdate()) between d.Fromdate and d.ToDate) ";
            PopulateDDL popddl = new PopulateDDL();
            if (MTheory.Checked == true)
            {
                popddl.Popualate(ddlMonth, "COURSEPAPERS", query + " and papertype = 'T'", "Name", "Id");

            }
            else
            {
                popddl.Popualate(ddlMonth, "COURSEPAPERS", query + " and papertype = 'P'", "Name", "Id");
            }
        }
        else
        {
            LblMsg.Text = "Attendance Entry has been deactivated, Please contact to Exam Section.";
        }
        ddlMonth.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    protected void bindgrid()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        string totalClassChangeQuery = "',' + M.DayNum";

        string queryClassheld = "e.ClassHeld";
        if (!chkDifferentClass.Checked)
        {
            string totalClassDb = NicService.GetNewCode("select ClassHeld from AttendanceDetail where Registerid=" + ddlMonth.SelectedValue);
            queryClassheld = txtTotalClass.Text + " as ClassHeld";
            if (totalClassDb != "" && totalClassDb != txtTotalClass.Text)
            {
                totalClassChangeQuery = "''";
            }
        }
        string query = " with cte as " +
                        " (select * FROM(Select RegNo,RegisterId, SubPapercode, examsession, DayNum = SUBSTRING(DayCol, LEN(DayCol) - PATINDEX('%[^0-9]%', REVERSE(DayCol)) + 2, 32), DaysInput From " +
                        " (SELECT RegNo, b.RegisterId , c.SubPapercode, c.examsession, Day1, Day2, Day3, Day4, Day5, Day6, Day7, Day8, day9, day10, day11, day12, day13, day14, day15,Day16, Day17, Day18, day19, day20 from attendanceRegister c " +
                        " inner join AttendanceDetail b on b.RegisterId = c.Id " +
                        " where c.Id = " + ddlMonth.SelectedValue + ") as p " +
                        " UNPIVOT(DaysInput FOR DayCol IN(Day1, " +
                        " Day2, Day3, Day4, Day5, Day6, Day7, Day8, day9, day10, day11, day12, day13, day14, day15,Day16, Day17, Day18, day19, day20))AS unpvt) as x where " +
                        " DaysInput = 0) " +
                        " select distinct a.UnivRollNo,b.RegisterId,d.ApplicantName," + queryClassheld + ",  STUFF " +
                        " (    " +
                        " ( " +
                        " SELECT " + totalClassChangeQuery +
                        " FROM cte M " +
                        " WHERE M.RegNo = b.RegNo " +
                        " FOR XML PATH('') " +
                        " ), 1, 1,'' " +
                        " ) AS Input  from attendance a inner join attendanceRegister c on a.ExamSession = c.examsession " +
                        " and a.SubPaperCode = c.SubPaperCode inner join registration d on a.RegNo = d.RegNo and c.splcode = d.splcode " +
                        " left join cte b on a.SubPaperCode = b.SubPaperCode and a.RegNo = b.RegNo and a.ExamSession = b.ExamSession  left join attendanceDetail e on  a.RegNo = e.RegNo  and c.id=e.registerId where c.Id =" + ddlMonth.SelectedValue + " and d.Splcode = '" + splcode.SelectedValue + "'";

        dsmarksdata = fn.SelectDataset(query);

        if (dsmarksdata.Tables[0].Rows.Count > 0)
        {
            panelattandancesem.Visible = true;
            gr4.DataSource = dsmarksdata.Tables[0];
            gr4.DataBind();
            ViewState["griddata"] = dsmarksdata.Tables[0];
            LblMsg.Text = "";
            savecommandgr4.Visible = true;
        }
        else
        {
            LblMsg.Text = "<b style=" + "Font-size:13px;" + ">Record(S) not found according to above criteria!";
        }


        /* Code For filter student list according to month wise regsitration
         string mnthval = "";
          string mnth = ddlMonth.SelectedItem.ToString();
        switch (mnth)
        {
            case "JAN":
                mnthval = "1";
                break;
            case "FEB":
                mnthval = "2";
                break;
            case "MAR":
                mnthval = "3";
                break;
            case "APR":
                mnthval = "4";
                break;
            case "MAY":
                mnthval = "5";
                break;
            case "JUN":
                mnthval = "6";
                break;
            case "JUL":
                mnthval = "7";
                break;
            case "AUG":
                mnthval = "8";
                break;
            case "SEP":
                mnthval = "9";
                break;
            case "OCT":
                mnthval = "10";
                break;
            case "NOV":
                mnthval = "11";
                break;
            case "DEC":
                mnthval = "12";
                break;
        }
        string query = " with cte as " +
                       " (select * FROM(Select RegNo,RegisterId, SubPapercode, examsession, DayNum = SUBSTRING(DayCol, LEN(DayCol) - PATINDEX('%[^0-9]%', REVERSE(DayCol)) + 2, 32), DaysInput From " +
                       " (SELECT RegNo, b.RegisterId , c.SubPapercode, c.examsession, Day1, Day2, Day3, Day4, Day5, Day6, Day7, Day8, day9, day10, day11, day12, day13, day14, day15,Day16, Day17, Day18, day19, day20 from attendanceRegister c " +
                       " inner join AttendanceDetail b on b.RegisterId = c.Id " +
                       " where c.Id = " + ddlMonth.SelectedValue + ") as p " +
                       " UNPIVOT(DaysInput FOR DayCol IN(Day1, " +
                       " Day2, Day3, Day4, Day5, Day6, Day7, Day8, day9, day10, day11, day12, day13, day14, day15,Day16, Day17, Day18, day19, day20))AS unpvt) as x where " +
                       " DaysInput = 0) " +
                       " select distinct a.UnivRollNo,b.RegisterId,d.ApplicantName," + queryClassheld + ",  STUFF " +
                       " (    " +
                       " ( " +
                       " SELECT " + totalClassChangeQuery +
                       " FROM cte M " +
                       " WHERE M.RegNo = b.RegNo " +
                       " FOR XML PATH('') " +
                       " ), 1, 1,'' " +
                       " ) AS Input  from attendance a inner join attendanceRegister c on a.ExamSession = c.examsession " +
                       " and a.SubPaperCode = c.SubPaperCode inner join registration d on a.RegNo = d.RegNo and c.splcode = d.splcode INNER JOIN " +
                       " EXAMPAPERDETAIL ON a.RegNo = EXAMPAPERDETAIL.RegNo AND a.SubPaperCode = EXAMPAPERDETAIL.SubPaperCode AND a.ExamSession = EXAMPAPERDETAIL.ExamSession " +
                       " left join cte b on a.SubPaperCode = b.SubPaperCode and a.RegNo = b.RegNo and a.ExamSession = b.ExamSession  left join attendanceDetail e on " +
                       " a.RegNo = e.RegNo  and c.id=e.registerId where c.Id =" + ddlMonth.SelectedValue + " and d.Splcode = '" + splcode.SelectedValue + "' AND month(EXAMPAPERDETAIL.EntryDate1) <= '" + mnthval + "'";
            
         
         */

    }


    protected void gr4_RowDataBound(object sender, GridViewRowEventArgs e)
    {



    }

    protected void splcode_SelectedIndexChanged(object sender, EventArgs e)
    {

        MTheory.Checked = false;
        MPrac.Checked = false;
        StreamPart.Items.Clear();
        Subject.Items.Clear();

        string strrole = "";
        if (Session["Role"].ToString() == "9")
            strrole = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";

        PopulateDDL popddl = new PopulateDDL();

        string strstreampart = "SELECT     STREAMPART.StreamPart,STREAMPART.StreamPartCode " +
                           " FROM         COURSEPAPERS AS COURSEPAPERS_1 INNER JOIN " +
                           " STREAMPART ON COURSEPAPERS_1.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN " +
                           " Faculty_paper_a INNER JOIN " +
                           " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode ON COURSEPAPERS_1.PaperAbbr = COURSEPAPERS.PaperAbbr " +
                           " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                           " and (Faculty_paper_a.splcode='" + splcode.SelectedValue + "') and STREAMPART.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                           " GROUP BY STREAMPART.StreamPartCode, STREAMPART.StreamPart " +
                           " order by StreamPart";


        popddl.Popualate(StreamPart, "StreamPart", strstreampart, "StreamPart", "StreamPartCode");
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
        splcode.Focus();


    }
    protected void btnsaveall_Click(object sender, EventArgs e)
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        string totalClassDb = NicService.GetNewCode("select ClassHeld from AttendanceDetail where RegisterId=" + ddlMonth.SelectedValue);
        if (totalClassDb != "" && totalClassDb != txtTotalClass.Text)
        {
            string updateHistoryQuery = " INSERT INTO AttendanceDetailHistory " +
                        " (RegisterId, RegNo, UnivRollNo, Count, UserId,ClassHeld, Day1, Day2, Day3, Day4, Day5, Day6, Day7, Day8, Day9, Day10, Day11, Day12, Day13, Day14, Day15, Day16, Day17, Day18, Day19, Day20) " +
                        " SELECT     RegisterId, RegNo, UnivRollNo, Count,'" + Session["UserId"].ToString() + "',ClassHeld, Day1, Day2, Day3, Day4, Day5, Day6, Day7, Day8, Day9, Day10, Day11, Day12, Day13, Day14, Day15, Day16, Day17, Day18, Day19, Day20 FROM AttendanceDetail where RegisterId=" + ddlMonth.SelectedValue +
                        "; delete from AttendanceDetail where RegisterId=" + ddlMonth.SelectedValue;
            int updateAttendance = fn.InsertUpdateDelete(updateHistoryQuery);
        }
        string Querystr = "";
        Querystr = " INSERT INTO AttendanceDetail " +
                    " (RegisterId, RegNo, UnivRollNo, UserId, Count,ClassHeld) " +
                    " SELECT c.Id, a.RegNo,a.UnivRollNo,'" + Session["UserId"].ToString() + "',0,0" +
                    " FROM Attendance AS a INNER JOIN " +
                    " AttendanceRegister AS c ON a.ExamSession = c.ExamSession AND a.SubPaperCode = c.SubPaperCode INNER JOIN " +
                    " REGISTRATION AS d ON a.RegNo = d.RegNo AND c.SplCode = d.SplCode " +
                    " WHERE(NOT EXISTS " +
                    " (SELECT        RegNo, RegisterId " +
                    " FROM            AttendanceDetail AS AttendanceDetail_1 " +
                    " WHERE(RegisterId = c.Id) AND(RegNo = a.RegNo))) AND(c.Id = " + ddlMonth.SelectedValue + ")";
        int insertAttendance = fn.InsertUpdateDelete(Querystr);
        for (int i = 0; i <= gr4.Rows.Count - 1; i++)
        {
            //for attendance
            int Insdata = 0;
            string univroll = Convert.ToString(((Label)gr4.Rows[i].FindControl("Label7")).Text);
            string txtInput = Convert.ToString(((TextBox)gr4.Rows[i].FindControl("txtInput")).Text);
            string registerId = ViewState["RegisterId"].ToString();
            int classHeldCount = Convert.ToInt32(((TextBox)gr4.Rows[i].FindControl("txtClassHeld")).Text);
            string dayQuery = string.Empty;

            int[] absentDays = txtInput != "" ? Array.ConvertAll(txtInput.Replace(",,", ",").Split(','), new Converter<string, int>(int.Parse)) : new int[0];
            int presentCount = 0;
            for (int j = 1; j <= classHeldCount; j++)
            {
                if (dayQuery != string.Empty)
                {
                    dayQuery = dayQuery + ",";
                }
                if (Array.IndexOf(absentDays, j) >= 0)
                {
                    dayQuery = dayQuery + "day" + j.ToString() + "=0";
                }
                else
                {
                    dayQuery = dayQuery + "day" + j.ToString() + "=1";
                    presentCount = presentCount + 1;
                }


            }
            Insdata = fn.InsertUpdateDelete(" UPDATE AttendanceDetail " +
                                 " SET Count =" + presentCount.ToString() + ", ModifiedDate =getdate(),ClassHeld=" + classHeldCount.ToString() + " ," + dayQuery +
                                    " WHERE (UnivRollNo = '" + univroll + "') AND (RegisterId = '" + registerId.ToString() + "')");
            if (Insdata == 0)
            {
                string msg = " Could Not Saved!!!. ";
                string popupScript = "<script language='javascript'>" +
                                   " alert('" + msg + " ')" +
                                    "</script>";
                Page.RegisterStartupScript("PopupScript", popupScript);
            }
            else
            {
                string msg = " Attendance Saved!!!. ";
                string popupScript = "<script language='javascript'>" +
                                   " alert('" + msg + " ')" +
                                    "</script>";
                Page.RegisterStartupScript("PopupScript", popupScript);
                // int l = e.RowIndex + 1;

                // gr4.Rows[l].Cells[3].Focus();
            }



        }
        bindgrid();
    }
    protected void ExamYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        string strstream = "SELECT     STREAM.StreamAbbr, STREAM.StreamCode FROM Faculty_paper_a INNER JOIN " +
                  " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " +
                  " STREAM ON COURSEPAPERS.StreamCode = STREAM.StreamCode " +
                  " Where Faculty_paper_a.Is_Active='Y' and Faculty_paper_a.examsession='" + ExamYear.SelectedValue + "'" +
                  " GROUP BY STREAM.StreamAbbr, STREAM.StreamCode order by StreamAbbr ";

        StreamCode.Items.Clear();
        popddl.Popualate(StreamCode, "Stream", strstream, "StreamAbbr", "StreamCode");

    }




    protected void ddlMonth_SelectedIndexChanged(object sender, EventArgs e)
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        string countQuery = "   select Count( distinct Classheld) from attendancedetail where registerId= " + ddlMonth.SelectedValue;
        int totalClassCount = (int)fn.singlevalue(countQuery);
        if (totalClassCount > 1)
        {
            txtTotalClass.Enabled = false;
            chkDifferentClass.Enabled = false;
            chkDifferentClass.Checked = true;
            txtTotalClass.Text = "";
            RequiredFieldValidator3.ValidationGroup = "NoVali";
        }
        else
        {
            string query = " select ISNULL(convert(varchar, Classheld),'') from attendancedetail where registerId=" + ddlMonth.SelectedValue;
            string totalClass = (string)fn.singlevalue(query);

            txtTotalClass.Text = totalClass;
            txtTotalClass.Enabled = true;
            chkDifferentClass.Checked = false;
            chkDifferentClass.Enabled = true;
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Panel3.Enabled = true;
        panelattandancesem.Visible = false;
        savecommandgr4.Visible = false;


        dsmarksdata = null;


        LblMsg.Text = "";

    }


    protected void txtTotalClass_TextChanged(object sender, EventArgs e)
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        string totalClassDb = NicService.GetNewCode("select TotalClass from AttendanceRegister where id=" + ddlMonth.SelectedValue);
        if (totalClassDb != "" && totalClassDb != txtTotalClass.Text)
        {
            string msg = "All the attendance Entry will be clear on any change in Total Classes Held";
            string popupScript = " alert('" + msg + " ');";
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "popupScript", popupScript, true);
        }
    }
    protected void chkDifferentClass_CheckedChanged(object sender, EventArgs e)
    {
        if (chkDifferentClass.Checked)
        {
            txtTotalClass.Enabled = false;
            txtTotalClass.Text = "";
            //RequiredFieldValidator RequiredFieldValidator2 = new RequiredFieldValidator();
            //RequiredFieldValidator2.ControlToValidate = txtTotalClass.ID;
            //RequiredFieldValidator2.Focus();
            //RequiredFieldValidator2.ForeColor = System.Drawing.Color.Red;
            //RequiredFieldValidator2.Text="*";
            RequiredFieldValidator3.ValidationGroup = "NoVali";
        }
        else
        {
            txtTotalClass.Enabled = true;
            txtTotalClass.CausesValidation = true;
            string query = " select ISNULL(convert(varchar, Classheld),'') from AttendanceDetail where Registerid=" + ddlMonth.SelectedValue;
            string totalClass = (string)fn.singlevalue(query);
            txtTotalClass.Text = totalClass;
            RequiredFieldValidator3.ValidationGroup = "A";
        }
    }

    protected void btnPrint_Click(object sender, EventArgs e)
    {

    }
}