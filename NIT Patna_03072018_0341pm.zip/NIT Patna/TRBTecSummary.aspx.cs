using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using SGPAreportTableAdapters;

public partial class TRBTecSummary : System.Web.UI.Page
{
    
    Functionreviseed dut = new Functionreviseed();
    string streamcode, streampartcode, examyear, Program, semester, examsession;
    ReportDocument crystalreport = new ReportDocument();
 
    protected void Page_Load(object sender, EventArgs e)
    {
        streamcode = Request.QueryString["sc"];
        streampartcode = Request.QueryString["spc"];
        examyear = Request.QueryString["ey"];
        Program = Request.QueryString["prg"];
        if (streampartcode.IndexOf('A') > 0)
            Program = "Group A";
        else if (streampartcode.IndexOf('A') > 0)
            Program = "Group B";
        semester = Request.QueryString["sem"];
        examsession = Request.QueryString["exses"];
        
       
        //old query without addition of cummulative  Table summary


        //str = " SELECT     a.UnivRollNo, a.EName, a.Credit, a.Grade_Point, a.ER_CREDIT, ISNULL(SUM(b.Credit), 0) AS Prevcredit, ISNULL(SUM(b.Grade_Point), 0) AS prevgrade, " +
        //        " ISNULL(SUM(b.ER_CREDIT), 0) AS prevearnedcr, ISNULL(SUM(b.countno), 0)  AS Cumtillsem, a.passfail, ROUND(CONVERT(float, a.Grade_Point) / CONVERT(float, " +
        //        " a.Credit), 2) AS sgpa, 0 AS CGPA, a.Semester, a.ExamYear " +
        //        " FROM         TRDATA AS a LEFT OUTER JOIN " +
        //        " TRDATA AS b ON a.semno > b.semno AND a.UnivRollNo = b.UnivRollNo " +
        //        " GROUP BY a.UnivRollNo, a.EName, a.Credit, a.Grade_Point, a.ER_CREDIT, a.StreamPart, a.passfail, a.StreamCode, a.ExamYear, a.Semester " +
        //        " HAVING (a.ExamYear = '"+examyear+"') AND ";


        //new query
        
        //str= " SELECT     sa.UnivRollNo,sa.EName, sa.Credit, sa.Grade_Point, sa.ER_CREDIT, sa.passfail, sa.sgpa, sa.Semester, sa.ExamYear, ISNULL(Cummdata.prevcumcredit, 0)  "+
        //     " + sa.Prevcredit AS Prevcredit, ISNULL(Cummdata.prevcumgrad, 0) + sa.prevgrade AS prevgrade, ISNULL(Cummdata.prevcumearncred, 0)  "+
        //     " + sa.prevearnedcr AS prevearnedcr, sa.Cumtillsem + ISNULL(Cummdata.Cummtillsem, 0) AS Cumtillsem, case when  ISNULL(Cummdata.prevcumearncred, 0) + sa.prevearnedcr+sa.ER_CREDIT "+
        //     " =sa.Credit+   ISNULL(Cummdata.prevcumcredit, 0) + sa.Prevcredit then round( (convert(float,sa.Grade_Point+ISNULL(Cummdata.prevcumgrad, 0) + sa.prevgrade)) " +
        //     " /(convert(float,ISNULL(Cummdata.prevcumearncred, 0) + sa.prevearnedcr+sa.ER_CREDIT)),2) end AS CGPA "+
        //     " FROM         ( "+
        //    " SELECT     a.UnivRollNo, a.EName, a.Credit, a.Grade_Point, a.ER_CREDIT, ISNULL(SUM(b.Credit), 0) AS Prevcredit, ISNULL(SUM(b.Grade_Point), 0) AS prevgrade, "+
        //    " ISNULL(SUM(b.ER_CREDIT), 0) AS prevearnedcr, ISNULL(SUM(b.countno), 0) AS Cumtillsem, a.passfail, ROUND(CONVERT(float, a.Grade_Point) / CONVERT(float, "+
        //    " a.Credit), 2) AS sgpa, 0 AS CGPA, a.Semester, EXAM.ExamYear "+
        //    " FROM         TRDATA AS a INNER JOIN EXAM ON a.UnivRollNo = EXAM.UnivRollNo AND a.StreamPart = EXAM.StreamPartCode INNER JOIN "+
        //    " STREAMPART ON EXAM.StreamPartCode = STREAMPART.StreamPartCode LEFT OUTER JOIN "+
        //    " TRDATA AS b ON a.semno > b.semno AND a.UnivRollNo = b.UnivRollNo "+
        //    " WHERE     (EXAM.ExamSession = '" + examsession + "') AND (EXAM.ExamType = 'R') AND " + Querystr + 
        //    " GROUP BY a.UnivRollNo, a.EName, a.Credit, a.Grade_Point, a.ER_CREDIT, a.StreamPart, a.passfail, a.StreamCode, a.Semester, EXAM.ExamYear ) AS sa "+
        //    " LEFT OUTER JOIN " +
        //    " Cummdata ON sa.UnivRollNo = Cummdata.UnivRollNo ";

        SGPATableAdapter adapter=new SGPATableAdapter();
        
                  DataTable dt;
        

                  if (streampartcode.IndexOf('A') > 0 || streampartcode.IndexOf('B') > 0)
                  {
                      dt = adapter.GetDataBy(streampartcode, examsession);

                  }
                  else
                      dt = adapter.GetData(streampartcode, examsession);

                  
                  //dt.TableName = "TRSummary";
                  //dt.WriteXmlSchema(Server.MapPath("TRSummary.xsd"));
                
                
        if (dt.Rows.Count > 0)
        {
            crystalreport.Load(Server.MapPath("~/Report/FinalTR.rpt"));
            crystalreport.SetDataSource(dt);
            crystalreport.SetParameterValue(0, Program);
            crystalreport.SetParameterValue(1, semester);
            crystalreport.SetParameterValue(2, examyear);
            CrystalReportViewer1.ReportSource = crystalreport;
        }
     
    }
    protected void Page_Unload(object sender, EventArgs e)
    {
        if (crystalreport != null)
        {
            crystalreport.Close();
            crystalreport.Dispose();
        }
        
    }
    
}
