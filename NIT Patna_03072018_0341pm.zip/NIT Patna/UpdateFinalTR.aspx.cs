using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.SessionState;
using System.Web.Caching;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.Collections.Generic;

public partial class UpdateFinalTR : System.Web.UI.Page
{

    Functionreviseed dut = new Functionreviseed();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }



        }
        LblMsg.Text = "";
    }
    protected void BtnReg_Click(object sender, EventArgs e)
    {
        try
        {
            string sql = " SELECT REGISTRATION.ApplicantName, REGISTRATION.DOB, REGISTRATION.StreamCode, STREAM.StreamAbbr, " +
                " STREAMPART.StreamPart, STREAMPART.StreamPartCode, REGISTRATION.TempRollNo, REGISTRATION.RegNo FROM REGISTRATION " +
                " INNER JOIN EXAMPAPERDETAIL ON REGISTRATION.RegNo = EXAMPAPERDETAIL.RegNo INNER JOIN STREAM ON " +
                " REGISTRATION.StreamCode = STREAM.StreamCode INNER JOIN STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode " +
                " GROUP BY REGISTRATION.ApplicantName, REGISTRATION.DOB, REGISTRATION.StreamCode, STREAM.StreamAbbr, STREAMPART.StreamPart, STREAMPART.StreamPartCode, " +
                " REGISTRATION.TempRollNo, REGISTRATION.RegNo HAVING REGISTRATION.TempRollNo = '" + txtrollno.Text + "'";

            //string sql = " SELECT     REGISTRATION.ApplicantName, REGISTRATION.DOB, REGISTRATION.StreamCode, STREAM.StreamAbbr, "+
            //                " STREAMPART.StreamPart, STREAMPART.StreamPartCode, EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.RegNo " +
            //                " FROM         REGISTRATION INNER JOIN " +
            //                " EXAMPAPERDETAIL ON REGISTRATION.TempRollNo = EXAMPAPERDETAIL.UnivRollNo INNER JOIN "+
            //                " STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode INNER JOIN "+
            //                " STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode "+
            //                " GROUP BY REGISTRATION.ApplicantName, REGISTRATION.DOB, REGISTRATION.StreamCode, "+
            //                " STREAM.StreamAbbr, STREAMPART.StreamPart, STREAMPART.StreamPartCode, "+
            //                " EXAMPAPERDETAIL.UnivRollNo, REGISTRATION.RegNo " +
            //                " HAVING      (EXAMPAPERDETAIL.UnivRollNo = '" + txtrollno.Text + "')";

            DataTable dtvalue = dut.SelectDatatable(sql);

            if (dtvalue.Rows.Count > 0)
            {
                Panel1.Visible = true;
                Panel1.Enabled = true;

                ApplicantName.Text = dtvalue.Rows[0]["ApplicantName"].ToString();
                DOB.Text = Convert.ToDateTime(String.IsNullOrEmpty(dtvalue.Rows[0]["DOB"].ToString()) ? "1990-01-01" : dtvalue.Rows[0]["DOB"]).ToString("dd/MM/yyyy");
                StreamCode.Text = dtvalue.Rows[0]["StreamAbbr"].ToString();
                txtregno.Text = dtvalue.Rows[0]["RegNo"].ToString();
                ddlsemester.DataSource = dtvalue;
                ddlsemester.DataTextField = "StreamPart";
                ddlsemester.DataValueField = "StreamPartCode";
                ddlsemester.DataBind();
                ddlsemester.Items.Insert(0, new ListItem("--select--", "00"));
                ddlcourses.Items.Insert(0, new ListItem("--select--", "00"));
                ddlexamsess.Items.Insert(0, new ListItem("--select--", "00"));

            }
            else
            {
                Panel1.Visible = false;
                LblMsg.Text = " Please check Roll No.";

                return;
            }

        }



        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }


    }
    protected void BtnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            TextBox verify = new TextBox();
            List<string> finqueue = (List<string>)ViewState["verpap"];
            string updatefield = "";
            bool update = false;


            foreach (string item in finqueue)
            {
                verify = (TextBox)Panel1.FindControl(item + "N");
                string updateControlText = verify.Text.Trim();
                double updfield = double.Parse(string.IsNullOrEmpty(updateControlText) ? "0.0" : updateControlText);
                verify = (TextBox)Panel1.FindControl(item);
                if (updateControlText != verify.Text.Trim())
                {

                    if (updatefield == "")
                    {
                        updatefield += verify.ID.Trim() + "='" + updateControlText.Trim() + "'";
                        update = true;
                    }
                    else
                    {
                        updatefield += "," + verify.ID.Trim() + "='" + updfield.ToString().Trim() + "'";
                    }
                }

            }
            if (update == true)
            {
                string result = "UPDATE    EXAMPAPERDETAIL SET ";


                result += updatefield;

                result += ",opt1='" + Session["UserId"].ToString() + "' WHERE     (RegNo = '" + txtregno.Text.Trim() + "') AND (SubPaperCode = '" + ddlcourses.SelectedValue.Trim() + "') and (ExamSession = '" + ddlexamsess.SelectedValue.Trim() + "') ";


                int totalrow = dut.InsertUpdateDelete(result);

                if (totalrow > 0)
                {
                    LblMsg.Text = "Update Successfully";
                }


            }
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;

        }
    }



    protected void ddlsemester_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ddlcourses.Items.Clear();
            ddlexamsess.Items.Clear();
            string sql = "SELECT  distinct   EXAMPAPERDETAIL.examsession " +
                         " FROM         EXAMPAPERDETAIL " +
                          " where not exists ( Select TRfreeze.StreamPartCode,TRfreeze.ExamSession from trfreeze " +
                            " where   TRfreeze.StreamPartCode=EXAMPAPERDETAIL.StreamPartCode and TRfreeze.ExamSession=EXAMPAPERDETAIL.ExamSession  ) " +
                             " and     (EXAMPAPERDETAIL.RegNo = '" + txtregno.Text + "') AND " +
                          " (EXAMPAPERDETAIL.StreamPartCode = '" + ddlsemester.SelectedValue + "')  ";
            DataTable examses = dut.SelectDatatable(sql);
            if (examses.Rows.Count > 0)
            {
                ddlexamsess.DataSource = examses;
                ddlexamsess.DataTextField = "examsession";
                ddlexamsess.DataValueField = "examsession";
                ddlexamsess.DataBind();


            }
            ddlcourses.Items.Insert(0, new ListItem("--Select--", "00"));
            ddlexamsess.Items.Insert(0, new ListItem("--Select--", "00"));

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }




    }
    protected void ddlcourses_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            UnivService.Service1 nicuni = new UnivService.Service1();
            string papertype = nicuni.GetNewCode("select PaperTypeCode from COURSEPAPERS where SubPaperCode='" + ddlcourses.SelectedValue + "'");
            string examtype = nicuni.GetNewCode("select examtype FROM EXAMPAPERDETAIL WHERE     (EXAMPAPERDETAIL.RegNo = '" + txtregno.Text + "') AND (EXAMPAPERDETAIL.SubPaperCode = '" + ddlcourses.SelectedValue + "') AND (EXAMPAPERDETAIL.examsession = '" + ddlexamsess.SelectedValue + "') ");
            txtexamtype.Text = examtype;
            string[] p1 = new string[] { "ClassTest1", "ClassTest2", "Midsem", "THEndsem", "TH_Attendance" };
            string[] p2 = new string[] { "PracticalRecord", "PRClassPerfor", "PREndSem", "Prpreendsemviva", "PR_Attendance" };
            string[] t1 = new string[] { "THEndsem" };
            string[] t2 = new string[] { "PREndSem" };
            string[] z = new string[p1.Length + p2.Length];
            p1.CopyTo(z, 0);
            p2.CopyTo(z, p1.Length);
            string[] t3 = new string[t1.Length + t2.Length];
            t1.CopyTo(t3, 0);
            t2.CopyTo(t3, t1.Length);

            List<string> ew2 = new List<string>(z);
            List<string> ew1;

            string strquery = "";

            if (papertype == "01")
            {
                ew1 = new List<string>(examtype == "N" ? t2 : p2);
                strquery += " PracticalRecord, PRClassPerfor, PREndSem, Prpreendsemviva, PR_Attendance ";

            }
            else if (papertype == "02")
            {
                ew1 = new List<string>(examtype == "N" ? t1 : p1);
                strquery += " ClassTest1, ClassTest2, Midsem, THEndsem, TH_Attendance ";
            }
            else
            {

                ew1 = new List<string>(examtype == "N" ? t3 : z);
                strquery += " ClassTest1, ClassTest2, Midsem, THEndsem, TH_Attendance, PracticalRecord, PRClassPerfor, PREndSem, Prpreendsemviva, PR_Attendance ";

            }

            string sql = " select Papercomp,Markscomp,PaperTypeCode,examtype  from  " +
                        " ( select Papercomp,Markscomp,PaperTypeCode,examtype from " +
                         " (SELECT     EXAMPAPERDETAIL.ClassTest1, EXAMPAPERDETAIL.ClassTest2, EXAMPAPERDETAIL.Midsem," +
                         " EXAMPAPERDETAIL.THEndsem , EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor,EXAMPAPERDETAIL.PREndSem, EXAMPAPERDETAIL.Prpreendsemviva, exampaperdetail.PR_Attendance, " +
                         " COURSEPAPERS.PaperTypeCode,examtype FROM         EXAMPAPERDETAIL INNER JOIN " +
                        " COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                         " WHERE     (EXAMPAPERDETAIL.RegNo = '" + txtregno.Text + "') AND (EXAMPAPERDETAIL.SubPaperCode = '" + ddlcourses.SelectedValue + "') AND (EXAMPAPERDETAIL.examsession = '" + ddlexamsess.SelectedValue + "')) as p " +
                         " unpivot " +
                         " ( Markscomp for Papercomp in (" + strquery + ")) as q  ) s " +
                        " where  Papercomp  like case when ExamType='N' then '%EndSem' else Papercomp end ";

            DataTable dt = dut.SelectDatatable(sql);



            TextBox textassign = new TextBox();




            List<string> verify = new List<string>(ew1);
            ViewState["verpap"] = verify;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                textassign = (TextBox)Panel1.FindControl(dt.Rows[i][0].ToString());
                textassign.Text = dt.Rows[i][1].ToString();
                textassign = (TextBox)Panel1.FindControl(dt.Rows[i][0].ToString() + "N");
                textassign.Text = dt.Rows[i][1].ToString();
                textassign.Enabled = true;
                ew1.Remove(dt.Rows[i][0].ToString());
                ew2.Remove(dt.Rows[i][0].ToString());


            }
            foreach (string item in ew1)
            {
                textassign = (TextBox)Panel1.FindControl(item);
                textassign.Text = "";
                textassign = (TextBox)Panel1.FindControl(item + "N");
                textassign.Text = "";
                textassign.Enabled = true;
                ew2.Remove(item);

            }

            foreach (string allitem in ew2)
            {
                textassign = (TextBox)Panel1.FindControl(allitem);
                textassign.Text = "";
                textassign = (TextBox)Panel1.FindControl(allitem + "N");
                textassign.Text = "";
                textassign.Enabled = false;


            }
            TH_AttendanceN.Enabled = false;
            PR_AttendanceN.Enabled = false;
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }
    protected void ddlexamsess_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ddlcourses.Items.Clear();
            string sql = "SELECT     COURSEPAPERS.PaperAbbr, COURSEPAPERS.SubPaperCode " +
                         " FROM         EXAMPAPERDETAIL INNER JOIN " +
                         " COURSEPAPERS ON EXAMPAPERDETAIL.StreamPartCode = COURSEPAPERS.StreamPartCode AND " +
                          " EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                          " where not exists ( Select TRfreeze.StreamCode,TRfreeze.StreamPartCode,TRfreeze.ExamSession from trfreeze " +
                            " where  TRfreeze.StreamCode= COURSEPAPERS.StreamCode and TRfreeze.StreamPartCode=EXAMPAPERDETAIL.StreamPartCode and TRfreeze.ExamSession=EXAMPAPERDETAIL.ExamSession  ) " +
                             " and     (EXAMPAPERDETAIL.RegNo = '" + txtregno.Text + "') AND " +
                          " (EXAMPAPERDETAIL.StreamPartCode = '" + ddlsemester.SelectedValue + "') AND (EXAMPAPERDETAIL.examsession = '" + ddlexamsess.SelectedValue + "')   ";
            DataTable coursedet = dut.SelectDatatable(sql);
            if (coursedet.Rows.Count > 0)
            {
                ddlcourses.DataSource = coursedet;
                ddlcourses.DataTextField = "PaperAbbr";
                ddlcourses.DataValueField = "SubPaperCode";
                ddlcourses.DataBind();


            }
            ddlcourses.Items.Insert(0, new ListItem("--Select--", "00"));

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }



    }
}
