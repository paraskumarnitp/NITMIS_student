using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class VerifyRegStudents : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "3")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CastCode, "Category", "Select Category,CategoryCode from Category order by Category", "Category", "CategoryCode");
            popddl.Popualate(PermanentDistCode, "District", "Select DistName,DistCode from District order by DistName", "DistName", "DistCode");
            popddl.Popualate(PresentDistrictCode, "District", "Select DistName,DistCode from District order by DistName", "DistName", "DistCode");
            popddl.Popualate(NationalityCode, "Nationality", "Select Nationality,NationalityCode from Nationality order by Nationality", "Nationality", "NationalityCode");
            popddl.Popualate(CollCode2, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(StreamCode1, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(Year1, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(Year2, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(ReligionCode, "Religion", "Select * from Religion order by ReligionCode", "Religion", "ReligionCode");
            popddl.Popualate(ExamCode1, "ExamName", "Select ExamName, ExamCode from ExamName order by ExamName", "ExamName", "ExamCode");
            popddl.Popualate(UnivCode1, "University", "Select UnivName,UnivCode from University order by UnivName", "UnivName", "UnivCode");
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(Year, "Year", "Select Year from Year where Year > '2008'  order by Year", "Year", "Year");
            DataSet ds = new DataSet();
            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select AckNo,RegNo,ApplicantName,FatherName,MotherName,DOB,CollCode from Registration where RegNo is null or RegNo=''");
            RegView.DataSource = ds;
            RegView.DataBind();
            TotStudent.Text = RegView.Rows.Count.ToString();
            MultiView1.ActiveViewIndex = 0;
            Year.Text = System.DateTime.Now.Year.ToString();   
        }
       

        

    }
    protected void RegView_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            AckNo1.Text = RegView.SelectedRow.Cells[2].Text;
            MultiView1.ActiveViewIndex = 1;
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;
            cmd.CommandText = "select AckNo,ReasonOfRejection,date from RejectedRegistration where AckNo='" + AckNo1.Text + "'";
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                AckNo1.Text = reader["AckNo"].ToString();
                ReasonOfRejection.Text = reader["ReasonOfRejection"].ToString();
                LblMsg.Text = "Reamrks for Rejection is already added on Date " + string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["Date"].ToString()));

                BtnSaveReject.Enabled = false;
                reader.Close();
                con.Close();
            }
            else
            {
                BtnSaveReject.Enabled = true;
                ReasonOfRejection.Text = "";
                LblMsg.Text = "";
                reader.Close();
                con.Close();
            }
            //// Diplay Detail of Applicant
            ViewApplicantDetail(AckNo1.Text.Trim());

            //--------------

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }


    }
    
    protected void RegView_PageIndexChanged(object sender, EventArgs e)
    {
        
    }
    protected void RegView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
  
        RegView.PageIndex = e.NewPageIndex;
        BindGrid();

    }

    protected void LnkBtnAll_Click(object sender, EventArgs e)
    {

        foreach (GridViewRow row in RegView.Rows)
        {
            CheckBox myCheckBox = (CheckBox)row.FindControl("CheckBox1");
            myCheckBox.Checked = true;

        }


    }
    protected void LnkBtnNone_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow row in RegView.Rows)
        {
            CheckBox myCheckBox = (CheckBox)row.FindControl("CheckBox1");
            myCheckBox.Checked = false;
        }
    }
    void BindGrid()
    {
        DataSet ds = new DataSet();
        
        //ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select AckNo,RegNo,ApplicantName,FatherName,MotherName,DOB,CollCode,StreamCode from Registration where collcode='" + CollCode.SelectedValue.ToString() + "' and  YEAR(CollegeAdmissionDate) ='" + Year.SelectedValue.ToString() + "' and (regno is NULL or regno='') and (VerifySUDateTime is null or VerifySUDateTime='')  ");
        
        //changes on 17052010
        //ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select AckNo,RegNo,ApplicantName,FatherName,MotherName,DOB,CollCode,StreamCode from Registration where collcode='" + CollCode.SelectedValue.ToString() + "'  and (regno is NULL or regno='' or ISOld='Y') and (VerifySUDateTime is null or VerifySUDateTime='') and (VerifyStatus='N') and (RegYear='"+ Year.SelectedValue  +"') order by "+ OrderBy.SelectedValue +" ");
        
       // ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select AckNo,RegNo,ApplicantName,FatherName,MotherName,DOB,CollCode,StreamCode from Registration where collcode='" + CollCode.SelectedValue.ToString() + "' and StreamCode= '" + StreamCode1.SelectedValue + "' and SubCode='" + SubCode1.SelectedValue + "'     and (regno is NULL or regno='' or ISOld='Y') and (VerifySUDateTime is null or VerifySUDateTime='') and (VerifyStatus='N') and (AdmYear='" + Year.SelectedValue + "') order by " + OrderBy.SelectedValue + " ");
        //updated on 6/12/20113
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select AckNo,RegNo,ApplicantName,FatherName,MotherName,DOB,CollCode,StreamCode from Registration where collcode='" + CollCode.SelectedValue.ToString() + "' and StreamCode= '" + StreamCode1.SelectedValue + "' and SubCode='" + SubCode1.SelectedValue + "'     and (regno is NULL or regno='' or ISOld='Y') and (VerifySUDateTime is null or VerifySUDateTime='') and (VerifyStatus='Y') and (AdmYear='" + Year.SelectedValue + "') order by " + OrderBy.SelectedValue + " ");

        RegView.DataSource = ds;
        RegView.DataBind();
    }
    protected void BtnView_Click(object sender, EventArgs e)
    {

        try
        {

            BindGrid();
            if (RegView.Rows.Count > 0)
            {
                TotStudent.Visible = true;
                TotStudent.Text = " Total Student =  " + RegView.Rows.Count.ToString();
                Panel1.Visible = true;
            }
            else
            {
                TotStudent.Visible = true;
                TotStudent.Text = "All Records have been verified";
                Panel1.Visible = false;
            }
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }


    }
    protected void BtnVerifyRegNo_Click(object sender, EventArgs e)
    {
        try
        {

            if (RegView.Rows.Count > 0)
            {
                SqlConnection con = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
                cmd.Connection = con;
                con.Open();
                SqlTransaction tran;

                int count = 0;

                for (int i = 0; i < int.Parse(RegView.Rows.Count.ToString()); i++)
                {

                    CheckBox myCheckBox = (CheckBox)RegView.Rows[i].FindControl("CheckBox1");
                    if (myCheckBox.Checked == true)
                    {
                        count = count + 1;
                        tran = con.BeginTransaction();
                        cmd.Transaction = tran;

                        cmd.CommandText = " update Registration set  VerifySUDateTime=Getdate() where Ackno='" + RegView.Rows[i].Cells[2].Text + "'";
                        cmd.ExecuteNonQuery();
                        tran.Commit();
                    }
                }

                string popupScript = "<script language='javascript'>" +
                                  " alert('   " + count + " Students are Verified. ')" +
                                   "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);

                BindGrid();
            }
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0; 
    }

    protected void BtnSaveReject_Click(object sender, EventArgs e)
    {

        try
        {

            string[] col = new string[3];
            string[] val = new string[3];
            col[0] = "AckNo";
            col[1] = "ReasonOfRejection";
            col[2] = "Date";

            val[0] = AckNo1.Text;
            val[1] = ReasonOfRejection.Text.Trim();
            val[2] = string.Format("{0:MM/dd/yyyy}", System.DateTime.Now);
            UnivService.Service1 ss = new UnivService.Service1();
            string abc = ss.SaveData("RejectedRegistration", col, val);
            string status;
            if (RadioButton1.Checked)
                status = "B";
            else
                status = "F";
            abc = ss.UpdateData(" update Registration set verifystatus='" + status + " ' where ackno='" + AckNo1.Text.Trim() + "'");
            if (abc == "ok")
            {

                LblMsg.Text = " Remarks is saved successfully";
                BtnSaveReject.Enabled = false;

            }
            else
            {
                LblMsg.Text = abc.ToString();
            }
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

     }

    void ViewApplicantDetail(string Ackno)
    {

        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

        //Get Image 
        ImageUpload imgUpload = new ImageUpload();
        string strFileName = imgUpload.Image_Load(Ackno.Trim());


        //Image3.ImageUrl = strFileName;

        if (strFileName.ToString().Contains("temp"))
        {


            string photo = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/temp.jpg";

            string strRightNow = "";
            string IUrl = "";

            strRightNow = System.DateTime.Now.ToString("ddMMyyyyHHmmss");
            IUrl = photo + "?img=" + strRightNow;

            Image3.ImageUrl = IUrl;
            Image3.DataBind();


        }
        else if (strFileName.ToString().Contains("UploadPhoto"))
        {

            Image3.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadPhoto.JPG";
            Image3.DataBind();

        }

        else
        {
            LblMsg.Text = "Error" + strFileName;
            //Response.Write("Error");
            //Response.Write(strFileName);
        }

        
        
        
        //Get Image 



        HPaper.Items.Clear();
        SPaper.Items.Clear();
        CompPaper.Items.Clear();



        cmd.Connection = con;
        cmd.CommandText = " select ApplicantName,HindiName,FatherName,MotherName,DOB,Gender,MaritalStatus,BloodGroup,EmailId,ContactNo,CastCode,NationalityCode," +
            "CollCode,CollegeAdmissionDate,RollNo,CourseSession,PermanentAddress1,PermanentAddress2,PermanentDistCode,PermanentPinCode,PresentAddress1,PresentAddress2,PresentDistrictCode,PresentPinCode," +
            "RegFeeAmt,SCBNo,SCBDate,ReligionCode,RegFormNo,StreamCode,CourseSession,SubCombCode,StreamPartCode, SubCode  from Registration where AckNo='" + Ackno + "'";
        SqlDataReader reader;
        con.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            reader.Read();
            ApplicantName.Text = reader["ApplicantName"].ToString();
            HindiName.Text = reader["HindiName"].ToString();
            FatherName.Text = reader["FatherName"].ToString();
            MotherName.Text = reader["MotherName"].ToString();
            DOB.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["DOB"]));
            ReligionCode.SelectedValue = reader["ReligionCode"].ToString();
            if (reader["Gender"].ToString() == "M")
                GenderM.Checked = true;
            else
                GenderF.Checked = true;
            MaritalStatus.SelectedValue = reader["MaritalStatus"].ToString();
            if (reader["BloodGroup"].ToString() != "") 
            {
                BloodGroup.SelectedValue = reader["BloodGroup"].ToString();
            }
            EmailId.Text = reader["EmailId"].ToString();
            ContactNo.Text = reader["ContactNo"].ToString();
            CollCode.Text = reader["CollCode"].ToString();
            CollegeAdmissionDate.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["CollegeAdmissionDate"]));
            RollNo.Text = reader["RollNo"].ToString();
            PermanentAddress1.Text = reader["PermanentAddress1"].ToString();
            PermanentAddress2.Text = reader["PermanentAddress2"].ToString();
            PermanentDistCode.SelectedValue = reader["PermanentDistCode"].ToString();
            PermanentPinCode.Text = reader["PermanentPinCode"].ToString();
            PresentAddress1.Text = reader["PresentAddress1"].ToString();
            PresentAddress2.Text = reader["PresentAddress2"].ToString();
            PresentDistrictCode.SelectedValue = reader["PresentDistrictCode"].ToString();
            PresentPinCode.Text = reader["PresentPinCode"].ToString();
            CollegeAdmissionDate.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["CollegeAdmissionDate"]));
            RegFeeAmt.Text = reader["RegFeeAmt"].ToString();
            SCBNo.Text = reader["SCBNo"].ToString();
            SCBDate.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["SCBDate"]));
            RegFormNo.Text = reader["RegFormNo"].ToString();
            StreamCode.SelectedValue = reader["StreamCode"].ToString();
            Year1.Text = (reader["CourseSession"].ToString()).Substring(0, 4);
            Year2.Text = (reader["CourseSession"].ToString()).Substring(5, 4);
            GetSubComb(reader["SubCombCode"].ToString());

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");

            string spc = reader["StreamPartCode"].ToString();

            if (spc != "")
            {
                StreamPart.SelectedValue = reader["StreamPartCode"].ToString();
            }
            else
            {
               // StreamPart.SelectedIndex = 0;

            }

            popddl.Popualate(SubCode, "Subject", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
            spc = reader["SubCode"].ToString();
            if (spc != "")
            {
                SubCode.SelectedValue = reader["SubCode"].ToString();
            }
            else
            {
                SubCode.SelectedIndex = 0;
            }






            reader.Close();
            cmd.CommandText = " select ExamCode,UnivCode,CollCode,PassYear,RollNo,Division,ExamPercentage,MainSubject from PREREGQUALIFICATION where AckNo='" + Ackno + "'";
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                ExamCode1.SelectedValue = reader["ExamCode"].ToString();
                UnivCode1.SelectedValue = reader["UnivCode"].ToString();
                CollCode1.Text = reader["CollCode"].ToString();
                PassYear1.Text = reader["PassYear"].ToString();
                RollNo1.Text = reader["RollNo"].ToString();
                Division1.SelectedValue = reader["Division"].ToString();
                ExamPercentage.Text = reader["ExamPercentage"].ToString();
                MainSubject.Text = reader["MainSubject"].ToString(); 

            }

            // if migarated student
            reader.Close();
            cmd.CommandText = "select MigrationNo,MigrationIssueDate from PREREGMIGRATION where AckNo='" + Ackno + "'";
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                MigrationNo.Text = reader["MigrationNo"].ToString();
                MigrationIssueDate.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["MigrationIssueDate"].ToString()));
                Panel4.Visible = true;
            }
            else
                Panel4.Visible = false;


            reader.Close();
            con.Close();


            LblMsg.Text = "";
            Panel1.Visible = true;
            Panel2.Visible = true;
            //Panel3.Visible = true;
        }
        
    }

    protected void GetSubComb(string s)
    {
        // Get Subject Combination

        string c = "", h = "", su = "", papercode = "";
        string[] PaperCode = new string[15];
        int i;
        for (i = 0; i < 15; i++)
            PaperCode[i] = "";

        int noofpaper = 0;
        PopulateList poplist = new PopulateList();
        //comp

        if (s.IndexOf('H') - 4 > 0)
        {
            c = s.Substring(2, s.IndexOf('H') - 4);
            for (i = 0; i < c.Length; i++)
            {
                if (c.Substring(i, 1) != ",")
                    papercode = papercode + c.Substring(i, 1);
                else
                {
                    PaperCode[noofpaper] = papercode;
                    noofpaper++;
                    papercode = "";
                }
            }
            PaperCode[noofpaper] = papercode;
            noofpaper++;
        }

        // set Composition paper name in composition paperlist box
        string sql = "";
        for (i = 0; i < noofpaper; i++)
        {
            sql += "CompCode='" + PaperCode[i] + "' OR ";
        }

        if (sql.Length > 3)
        {
            sql = sql.Substring(0, sql.Length - 3);
            sql = "Select Name,compCode from COMPOSITION Where " + sql;
            poplist.Popualate(CompPaper, "COMPOSITION", sql, "Name", "CompCode");

        }

        //honours
        //hon



        if ((s.IndexOf('S') - (s.IndexOf('H') + 4)) > 0)
        {
            h = s.Substring(s.IndexOf('H') + 2, s.IndexOf('S') - (s.IndexOf('H') + 4));

            papercode = "";
            for (i = 0; i < h.Length; i++)
            {


                if (h.Substring(i, 1) != ",")
                    papercode = papercode + h.Substring(i, 1);
                else
                {
                    PaperCode[noofpaper] = papercode;
                    noofpaper++;
                    papercode = "";
                }
            }
            PaperCode[noofpaper] = papercode;
            noofpaper++;

        }
        // set honours paper name in honours paperlist box
        sql = "";
        for (i = 0; i < noofpaper; i++)
        {
            sql += "SubPaperCode='" + PaperCode[i] + "' OR ";
        }

        if (sql.Length > 3)
        {
            sql = sql.Substring(0, sql.Length - 3);
            sql = "Select PaperName,SubPaperCode from COURSEPAPERS Where " + sql;


            poplist.Popualate(HPaper, "COURSEPAPERS", sql, "PaperName", "SubPaperCode");
        }

        //sub
        noofpaper = 0; sql = "";

        if ((s.Length - (s.IndexOf('S') + 3)) > 0)
        {
            su = s.Substring(s.IndexOf('S') + 2, s.Length - (s.IndexOf('S') + 3));

            papercode = "";
            for (i = 0; i < su.Length; i++)
            {


                if (su.Substring(i, 1) != ",")
                    papercode = papercode + su.Substring(i, 1);
                else
                {
                    PaperCode[noofpaper] = papercode;
                    noofpaper++;
                    papercode = "";
                }
            }
            PaperCode[noofpaper] = papercode;
            noofpaper++;
        }

        // set subsidiary paper name in subsidiary paperlist box

        sql = "";
        for (i = 0; i < noofpaper; i++)
        {
            sql += "SubCode='" + PaperCode[i] + "' OR ";
        }
        if (sql.Length > 3)
        {
            sql = sql.Substring(0, sql.Length - 3);
            sql = "Select SubCode,SubjectName from SUBJECT Where " + sql;
            poplist.Popualate(SPaper, "SUBJECT", sql, "SubjectName", "SubCode");
        }



        //------------ End Of Subject Combination
    }


    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }
    protected void StreamCode1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (StreamCode1.SelectedValue == "00") return;

        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(SubCode1, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode1.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        //SubCode_SelectedIndexChanged(StreamCode, e); // call subcode selected index
        SubCode1.Focus();
    }
}
