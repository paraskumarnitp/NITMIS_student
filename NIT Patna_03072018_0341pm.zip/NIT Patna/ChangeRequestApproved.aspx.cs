using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class ChangeRequestApproved : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(RegNo, "ChangeRequest", "Select Distinct RegNo from ChangeRequest where ApprovedByUser is null ", "RegNo", "RegNo");



        }

    }
    protected void BtnReg_Click(object sender, EventArgs e)
    {
        BindGrid();
        UnivService.Service1 ss = new UnivService.Service1();
        string fnm=ss.GetNewCode ("Select DocName from ChangeRequest where RegNo='" + RegNo.Text + "' And ApprovedByUser is null");
        fnm = fnm.ToString().Substring(1); 
        Literal1.Text = "<iframe src='"+fnm+ "' width='600' height='450' scrolling='yes'></iframe>"; 
        
    }
    void BindGrid()
    {
        DataSet ds = new DataSet();
        string sql = "";
        sql = "Select ID,RequestFrom,ReqDate,TableName, ChangeRequestField, ChangeRequestValue,ChangedFinalValue,AsstUserNAme from ChangeRequest where RegNo='" + RegNo.Text + "' And ApprovedByUser is null";
 
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        ChangeRequestView.DataSource = ds;
        ChangeRequestView.DataBind();
    }
    protected void RegView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void BtnApproved_Click(object sender, EventArgs e)
    {
       
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        con.Open();
        for (int i = 0; i < ChangeRequestView.Rows.Count;i++)
        {
            //ChangeRequestView.Rows[0].Cells[4].Text ;
            cmd.CommandText = "update changerequest set ApprovedByUser='" + Session["userName"].ToString() + "' , ApprovedDate=Getdate() where RegNo='" + RegNo.Text + "' And ID='" + ChangeRequestView.Rows[i].Cells[0].Text + "'";
            cmd.ExecuteNonQuery ();
            cmd.CommandText = "Update Registration set " + ChangeRequestView.Rows[i].Cells[4].Text + "='" + ChangeRequestView.Rows[i].Cells[6].Text + "' where RegNo='" + RegNo.Text + "'";
            cmd.ExecuteNonQuery();
        }
        
        
        con.Close();
        
        string popupScript = "<script language='javascript'>" +
                       " alert(' Request is  Approved   ')" +
                        "</script>";

        Page.RegisterStartupScript("PopupScript", popupScript);
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(RegNo, "ChangeRequest", "Select Distinct RegNo from ChangeRequest where ApprovedByUser is null ", "RegNo", "RegNo");
        Literal1.Text =""; 
        BindGrid();


    }
}
