using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using CrystalDecisions.CrystalReports.Engine;
public partial class MarksheetPrint : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    PopulateDDL popddl = new PopulateDDL();
    string streamtypcode; String Streamvalue;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "3") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            

            //popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College where collcode in (select distinct collcode from TRHons) order by CollName", "CollName", "CollCode");
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College where collcode in (select distinct collcode from TRBTec) order by CollName", "CollName", "CollCode");
            //popddl.Popualate(ExamYear, "Exam", "Select distinct ExamYear from Exam order by ExamYear", "ExamYear", "ExamYear");
            popddl.Popualate(ExamYear, "Exam", "Select Distinct Examsession,Examyear From TRBTec order by Examyear", "ExamSession", "ExamSession");
            // popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from TRHons) order by StreamAbbr", "StreamAbbr", "StreamCode");
            
            CourseValue();

        }
    }
    string remarks, sgpa, cgpa, gradesno, Thfmarks, PRFmarks;
    string totalercredit = "", Credit = "", totalpmo = "";
    object datevalue;
    object autono;
    string totalmarks = "", query1, query2;
    double markspercent;
    DataSet dsgradedata;
    protected void ViewTR_Click(object sender, EventArgs e)
    {
        System.Threading.Thread.Sleep(3000);
        string Querystr;
        if (rdbbtec.Checked == true)
            streamtypcode = "01";
        else if (rdbmtec.Checked == true) streamtypcode = "02";
        if (StreamPart.SelectedItem.ToString().IndexOf('A') > 0 || StreamPart.SelectedItem.ToString().IndexOf('B') > 0)
        {
            Querystr = " (streampart.StreamPart = '" + StreamPart.SelectedItem.ToString() + "')";

        }
        else
            Querystr = " TRBTec.StreamCode = '" + StreamCode.SelectedValue + "' AND TRBTec.StreamPart = '" + StreamPart.SelectedValue + "'";

        datevalue = fnrev.singlevalue("Select CONVERT(VARCHAR(10),GETDATE() ,102) as Date");
        if (streamtypcode == "01")
        {
            //query1 = "SELECT DISTINCT TRBTec.UnivRollNo,TRBTec.EName, REGISTRATION.AckNo,STREAMPART.StreamPart," +
            //    " TRBTec.StreamCode, STREAM.StreamAbbr, TRBTec.ExamSession,STREAMPART.StreamPartCode FROM TRBTec INNER JOIN REGISTRATION ON TRBTec.RegNo = REGISTRATION.RegNo " +
            //    " INNER JOIN STREAMPART ON TRBTec.StreamPart = STREAMPART.StreamPartCode INNER JOIN STREAM ON TRBTec.StreamCode = STREAM.StreamCode " +
            //    " Where TRBTec.ExamYear = '" + ExamYear.SelectedItem + "' and isnull(TRBTec.ExamType,'R') not in ('N','B') AND " + Querystr;         
            query1 = " declare @semvalue as int; " +
                        " SELECT @semvalue =  CONVERT(int, LEFT(SUBSTRING(STREAMPART.StreamPart, PATINDEX('%[0-9]%', STREAMPART.StreamPart), 8000), " +
                        " PATINDEX('%[^0-9]%', SUBSTRING(STREAMPART.StreamPart, PATINDEX('%[0-9]%',  " +
                        " STREAMPART.StreamPart), 8000) + 'X') - 1))  from STREAMPART where StreamPartCode='" + StreamPart.SelectedValue + "' " +
                        " SELECT DISTINCT " +
                        " TRBTec.UnivRollNo, TRBTec.EName, REGISTRATION.AckNo, STREAMPART.StreamPart, TRBTec.StreamCode, STREAM.StreamAbbr, TRBTec.ExamSession, " +
                        " STREAMPART.StreamPartCode,a.cgpa " +
                        " FROM         TRBTec INNER JOIN " +
                        " REGISTRATION ON TRBTec.RegNo = REGISTRATION.RegNo INNER JOIN " +
                        " STREAMPART ON TRBTec.StreamPart = STREAMPART.StreamPartCode INNER JOIN " +
                        " STREAM ON TRBTec.StreamCode = STREAM.StreamCode left join ( " +
                        " select UnivRollNo, CONVERT(varchar,round((SUM(convert(float,grade_point))/convert(float,SUM(credit))),2)) as cgpa from cgpa where semno<=@semvalue group by UnivRollNo " +
                        " having COUNT(distinct semno)=@semvalue and SUM(ER_CREDIT)=SUM(credit)) a on a.UnivRollNo=TRBTec.UnivRollNo " +
                       " Where TRBTec.Examsession = '" + ExamYear.SelectedItem + "' and  " + Querystr;

            //query1 = " declare @semvalue as int; " +
            //           " SELECT @semvalue =  CONVERT(int, LEFT(SUBSTRING(STREAMPART.StreamPart, PATINDEX('%[0-9]%', STREAMPART.StreamPart), 8000), " +
            //           " PATINDEX('%[^0-9]%', SUBSTRING(STREAMPART.StreamPart, PATINDEX('%[0-9]%',  " +
            //           " STREAMPART.StreamPart), 8000) + 'X') - 1))  from STREAMPART where StreamPartCode='" + StreamPart.SelectedValue + "'; " +
            //           " with cte as " +
            //           " ( " +
            //           " select  b.RegNo, b.UnivRollNo, b.EName, REGISTRATION.AckNo,a.StreamPart, STREAM.StreamAbbr, a.StreamCode,a.StreamPartCode,SUM(b.Credit) over (partition by b.regno)  Credit,SUM(ER_CREDIT)  over (partition by b.regno) ER_CREDIT,SUM(grade_point)  over (partition by b.regno) grade_point " +
            //           " FROM         STREAMPART AS a INNER JOIN " +
            //           " (SELECT     UnivRollNo, StreamPart, semno,SUM(Credit) Credit, sum(ER_CREDIT) ER_CREDIT,sum(convert(float, Grade_Point)) Grade_Point , EName, RegNo ,min(CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,12) AS DATETIME)) as examlast " +
            //           " FROM         cgpa " +
            //           " GROUP BY StreamPart, semno, EName, RegNo,UnivRollNo) AS b ON a.StreamPartCode = b.StreamPart INNER JOIN (select RegNo,min(semno) cd from cgpa a inner join STREAMPART b on a.StreamPart=b.StreamPartCode where ExamSession = '" + ExamYear.SelectedItem + "' " + Querystr + "   group by RegNo " +
            //           " having MIN(semno)<=@semvalue) ce on b.RegNo =ce.RegNo INNER JOIN " +
            //           " REGISTRATION ON b.RegNo = REGISTRATION.RegNo INNER JOIN " +
            //           " STREAM ON a.StreamCode = STREAM.StreamCode " +
            //           " Where semno<=@semvalue and  examlast<=CAST(SUBSTRING('" + ExamYear.SelectedValue + "',5,3)+ SUBSTRING('" + ExamYear.SelectedValue + "',9,12) AS DATETIME) " +
            //           " group by  b.RegNo, b.UnivRollNo, b.EName, REGISTRATION.AckNo,a.StreamPart, STREAM.StreamAbbr, a.StreamCode,a.StreamPartCode,b.Credit,b.Grade_Point,ER_CREDIT " +
            //           " ) " +
            //           " select RegNo,UnivRollNo,EName,AckNo,StreamPart,StreamAbbr,StreamCode,StreamPartCode,case when ER_CREDIT=Credit then round(grade_point/ER_CREDIT,2) else null end as CGPA,'"+ ExamYear.SelectedValue +"' as ExamSession from cte where StreamPart='" + StreamPart.SelectedItem.ToString() + "' ";
        }
        else if (streamtypcode == "02")
        {
            query1 = " declare @semvalue as int; " +
                        " SELECT @semvalue =  CONVERT(int, LEFT(SUBSTRING(STREAMPART.StreamPart, PATINDEX('%[0-9]%', STREAMPART.StreamPart), 8000), " +
                        " PATINDEX('%[^0-9]%', SUBSTRING(STREAMPART.StreamPart, PATINDEX('%[0-9]%',  " +
                        " STREAMPART.StreamPart), 8000) + 'X') - 1))  from STREAMPART where StreamPartCode='" + StreamPart.SelectedValue + "' " +
                "SELECT DISTINCT TRMTec.UnivRollNo, TRMTec.EName, REGISTRATION.AckNo, STREAMPART.StreamPart, STREAM.StreamAbbr," +
                " TRMTec.ExamSession, STREAMPART.StreamPartCode, TRMTec.StreamCode, a.cgpa FROM TRMTec INNER JOIN " + 
                " REGISTRATION ON TRMTec.RegNo = REGISTRATION.RegNo INNER JOIN STREAMPART ON TRMTec.StreamPart = STREAMPART.StreamPartCode " +
                " INNER JOIN STREAM ON TRMTec.StreamCode = STREAM.StreamCode left join ( " +
                        " select UnivRollNo, CONVERT(varchar,round((SUM(convert(float,grade_point))/convert(float,SUM(credit))),2)) as cgpa from cgpa_Mtec where semno<=@semvalue group by UnivRollNo " +
                        " having COUNT(distinct semno)=@semvalue and SUM(ER_CREDIT)=SUM(credit)) a on a.UnivRollNo=TRMTec.UnivRollNo " +
                " WHERE TRMTec.ExamSession = '" + ExamYear.SelectedItem + "' AND " +
                " TRMTec.StreamCode = '" + StreamCode.SelectedValue + "' AND TRMTec.StreamPart = '" + StreamPart.SelectedValue + "' ";
        }
        dsgradedata = fnrev.SelectDataset(query1);

        for (int i = 0; i <= dsgradedata.Tables[0].Rows.Count - 1; i++)
        {
            if (streamtypcode == "01")
            {
                query2 = "SELECT cgpa.Grade_Point AS ER_CREDIT, cgpa.Grade, COURSEPAPERS.Credit, cgpa.Total_PMO, " +
                " COURSEPAPERS.FullMarks AS ThFmmarks,PRACTICALPAPERS.FullMarks AS PRFmarks, ISNULL(CONVERT(FLOAT,CA_MSM_TH),0)+ISNULL(CONVERT(FLOAT,TH_ESM),0)+ISNULL(CONVERT(FLOAT,CA_MSM_PT),0)+ISNULL(CONVERT(FLOAT,PT_ESM),0) AS TotalErMarks FROM cgpa INNER JOIN COURSEPAPERS ON " +
                " cgpa.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = " +
                " PRACTICALPAPERS.SubPaperCode WHERE  " +
                " cgpa.UnivRollNo = '" + dsgradedata.Tables[0].Rows[i]["UnivRollNo"].ToString() + "' AND " +
                " cgpa.StreamPart = '" + dsgradedata.Tables[0].Rows[i]["StreamPartCode"].ToString() + "'";
            }
            else if (streamtypcode == "02")
            {
                query2 = "SELECT cgpa_Mtec.Grade_Point AS ER_CREDIT, cgpa_Mtec.Grade, COURSEPAPERS.Credit, cgpa_Mtec.Total_PMO, COURSEPAPERS.FullMarks AS ThFmmarks," +
                " PRACTICALPAPERS.FullMarks AS PRFmarks,ISNULL(CONVERT(FLOAT,CA_MSM_TH),0)+ISNULL(CONVERT(FLOAT,TH_ESM),0)+ISNULL(CONVERT(FLOAT,CA_MSM_PT),0)+ISNULL(CONVERT(FLOAT,PT_ESM),0) AS TotalErMarks FROM cgpa_Mtec INNER JOIN COURSEPAPERS ON cgpa_Mtec.SubPaperCode = COURSEPAPERS.SubPaperCode " + 
                " LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                " WHERE (cgpa_Mtec.UnivRollNo = '" + dsgradedata.Tables[0].Rows[i]["UnivRollNo"].ToString() + "')" +
                " AND " +
                " (cgpa_Mtec.StreamPart = '" + dsgradedata.Tables[0].Rows[i]["StreamPartCode"].ToString() + "')";
            }

            DataSet dspapermarks = fnrev.SelectDataset(query2);
            //claculate Grade Serial No....
            
            if (streamtypcode == "01")
            {
            if (StreamPart.SelectedValue.ToString().Length.Equals(1))
            {
                Streamvalue = "00" + StreamPart.SelectedValue;
            }
            else if (StreamPart.SelectedValue.ToString().Length.Equals(2))
            {
                Streamvalue = "0" + StreamPart.SelectedValue;
            }
            else if (StreamPart.SelectedValue.ToString().Length.Equals(3))
            {
                Streamvalue = StreamPart.SelectedValue;
            }
            autono = fnrev.singlevalue("Select ISNULL(MAX(GrcardNo),'001') as GrcardNo From BtecGrade WHERE SubString(GrcardNo,3,3) = '" + Streamvalue + "'");
            }

            else if (streamtypcode == "02")
            {
                if (StreamPart.SelectedValue.ToString().Length.Equals(1))
            {
                Streamvalue = "00" + StreamPart.SelectedValue;
            }
            else if (StreamPart.SelectedValue.ToString().Length.Equals(2))
            {
                Streamvalue = "0" + StreamPart.SelectedValue;
            }
            else if (StreamPart.SelectedValue.ToString().Length.Equals(3))
            {
                Streamvalue = StreamPart.SelectedValue;
            }
            autono = fnrev.singlevalue("Select ISNULL(MAX(GrcardNo),'001') as GrcardNo From MtecGrade WHERE SubString(GrcardNo,3,3) = '" + Streamvalue + "'");
                
            }
            if (autono.ToString() == "001")
            {
                autono = autono.ToString();
            }
            else
            {
                autono = autono.ToString().Substring(5, 3);
                //if (StreamPart.SelectedValue.ToString().Length.Equals(1))
                //    autono = autono.ToString().Substring(3, 3);
                //else if (StreamPart.SelectedValue.ToString().Length.Equals(2))
                //    autono = autono.ToString().Substring(4, 3);
                //else if (StreamPart.SelectedValue.ToString().Length.Equals(3))
                //    autono = autono.ToString().Substring(5, 3);
                //else if (StreamPart.SelectedValue.ToString().Length.Equals(4))
                //    autono = autono.ToString().Substring(6, 3);
                //if(StreamCode.SelectedValue == "05" && int.Parse(StreamPart.SelectedValue.ToString()) < 10)
                //autono = autono.ToString().Substring(3, 3);
                //else 
                //autono = autono.ToString().Substring(4, 3);
                autono = int.Parse(autono.ToString()) + 1;
                if (autono.ToString().Length.Equals(1))
                {
                    autono = "00" + autono;
                }
                else if (autono.ToString().Length.Equals(2))
                {
                    autono = "0" + autono;
                }

            }
            gradesno = ExamYear.SelectedItem.ToString().Substring(2, 2) + Streamvalue + autono;
            //Calculate SGPA

            totalmarks = "0"; totalercredit = "0"; Credit = "0"; totalpmo = "0";
            for (int j = 0; j <= dspapermarks.Tables[0].Rows.Count - 1; j++)
            {
                // calculate total full marks
                Thfmarks = dspapermarks.Tables[0].Rows[j]["ThFmmarks"].ToString();
                PRFmarks = dspapermarks.Tables[0].Rows[j]["PRFmarks"].ToString();
                if (Thfmarks != "")
                {
                    totalmarks = (float.Parse(Thfmarks) + float.Parse(totalmarks)).ToString();
                }
                if (PRFmarks != "")
                {
                    totalmarks = (float.Parse(PRFmarks) + float.Parse(totalmarks)).ToString();
                }
                if (dspapermarks.Tables[0].Rows[j]["ER_CREDIT"].ToString() != "" && dspapermarks.Tables[0].Rows[j]["Credit"].ToString().ToUpper() != "")
                {
                    totalercredit = (int.Parse(totalercredit) + double.Parse(dspapermarks.Tables[0].Rows[j]["ER_CREDIT"].ToString())).ToString();
                    if (int.Parse(dspapermarks.Tables[0].Rows[j]["ER_CREDIT"].ToString()) != 0)
                    {
                        Credit = (int.Parse(Credit) + double.Parse(dspapermarks.Tables[0].Rows[j]["Credit"].ToString())).ToString();
                    }
                }
                if (dspapermarks.Tables[0].Rows[j]["Total_PMO"].ToString() != "")
                {

                    totalpmo = (double.Parse(totalpmo) +
                        double.Parse(dspapermarks.Tables[0].Rows[j]["Total_PMO"].ToString())).ToString();
                }

            }
            if (totalercredit != "" && Credit != "")
            {
                sgpa = (double.Parse(totalercredit) / double.Parse(Credit)).ToString();
                sgpa = (Math.Round(double.Parse(sgpa), 2)).ToString();
            }
            // calculate PM
            if (totalpmo != "")
            {
                float totalpm = float.Parse(totalpmo);
                markspercent = (totalpm / (dspapermarks.Tables[0].Rows.Count));
                markspercent = Math.Round(markspercent, 2);
            }
            //Calculate Remarks
            for (int j = 0; j <= dspapermarks.Tables[0].Rows.Count - 1; j++)
            {
                if (dspapermarks.Tables[0].Rows[j]["Grade"].ToString() == "F" || dspapermarks.Tables[0].Rows[j]["Grade"].ToString() == "f" || dspapermarks.Tables[0].Rows[j]["Grade"].ToString() == "x" || dspapermarks.Tables[0].Rows[j]["Grade"].ToString() == "X" || dspapermarks.Tables[0].Rows[j]["Grade"].ToString() == "I" || dspapermarks.Tables[0].Rows[j]["Grade"].ToString() == "i")
                {
                    remarks = "Backlog";
                    break;
                }
                else if (dspapermarks.Tables[0].Rows[j]["Grade"].ToString() == "" || dspapermarks.Tables[0].Rows[j]["Grade"].ToString().ToUpper() == "NULL")
                {
                    remarks = "Backlog";
                    break;
                }
                else
                {
                    remarks = "Pass";
                }

            }
            if (remarks == "Backlog")
            {
                sgpa = "";
            }
            if (streamtypcode == "01")
            {
               

               
                int InsData = fnrev.InsertUpdateDelete("INSERT INTO BtecGrade (GrcardNo, UnivRollNo, Enrollmentno, StreamAbbr, StreamPart, Marks_percent, " +
                    " Remarks, SGPA, CGPA, GenDate, ExamSession) VALUES ('" + gradesno + "','" + dsgradedata.Tables[0].Rows[i]["UnivRollNo"].ToString() + "'," +
                    " '" + dsgradedata.Tables[0].Rows[i]["AckNo"].ToString() + "','" + dsgradedata.Tables[0].Rows[i]["StreamAbbr"].ToString() + "'," +
                    " '" + dsgradedata.Tables[0].Rows[i]["StreamPart"].ToString() + "'," + markspercent + ",'" + remarks + "','" + sgpa + "'," +
                    " '" + dsgradedata.Tables[0].Rows[i]["cgpa"].ToString() + "','" + datevalue + "','" + dsgradedata.Tables[0].Rows[i]["ExamSession"].ToString() + "')");
            }
            else if (streamtypcode == "02")
            {
              
                int InsData = fnrev.InsertUpdateDelete("INSERT INTO MtecGrade (GrcardNo, UnivRollNo, Enrollmentno, StreamAbbr, StreamPart, Marks_percent, " +
                    " Remarks, SGPA, CGPA, GenDate, ExamSession) VALUES ('" + gradesno + "','" + dsgradedata.Tables[0].Rows[i]["UnivRollNo"].ToString() + "'," +
                    " '" + dsgradedata.Tables[0].Rows[i]["AckNo"].ToString() + "','" + dsgradedata.Tables[0].Rows[i]["StreamAbbr"].ToString() + "'," +
                    " '" + dsgradedata.Tables[0].Rows[i]["StreamPart"].ToString() + "'," + markspercent + ",'" + remarks + "','" + sgpa + "'," +
                    " '" + dsgradedata.Tables[0].Rows[i]["cgpa"].ToString() + "','" + datevalue + "','" + dsgradedata.Tables[0].Rows[i]["ExamSession"].ToString() + "')");
            }
            autono = "";
        }
        //crystal report bind--------------------------------
        //string examsession = "";
        //DataSet dsexamsession = fnrev.SelectDataset("Select ExamSession from AssignCoursePaper Where SUBSTRING(ExamSession,10,4)='" + ExamYear.SelectedItem + "' and Semester ='" + StreamPart.SelectedItem + "'");
        //examsession = dsexamsession.Tables[0].Rows[0]["ExamSession"].ToString();
        string streampart = StreamPart.SelectedValue;
        if (StreamPart.SelectedItem.ToString().IndexOf('A') > 0 || StreamPart.SelectedItem.ToString().IndexOf('B') > 0)
        {
            streampart = StreamPart.SelectedItem.ToString();
        }

        Response.Redirect("GradecardBtecprint.aspx?sc=" + StreamCode.SelectedValue + "&spc=" + streampart + "&ey=" + ExamYear.SelectedItem + "&prg=" + StreamCode.SelectedItem + "&sem=" + StreamPart.SelectedItem + "&stmtp=" + streamtypcode);



        //ReportDocument crystalReport = new ReportDocument();
        //crystalReport.Load(Server.MapPath("~/Report/MarksSheetBtech.rpt"));
        //DSGradeCard dsgrade = GetData("SELECT BtecGrade.GrcardNo, TRBTec.EName, BtecGrade.UnivRollNo, BtecGrade.Enrollmentno, BtecGrade.StreamAbbr, " + 
        //    " BtecGrade.StreamPart, BtecGrade.Marks_percent, BtecGrade.Remarks, BtecGrade.SGPA, BtecGrade.CGPA, BtecGrade.GenDate, COURSEPAPERS.PaperAbbr, " + 
        //    " COURSEPAPERS.PaperName, (COURSEPAPERS.L +'-'+COURSEPAPERS.T +'-'+COURSEPAPERS.P) as LTP, COURSEPAPERS.Credit, TRBTec.Grade " + 
        //    " FROM BtecGrade INNER JOIN TRBTec ON BtecGrade.UnivRollNo = TRBTec.UnivRollNo INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode " + 
        //    " Where TRBTec.StreamPart ='" + StreamPart.SelectedValue + "' And TRBTec.StreamCode ='" + StreamCode.SelectedValue + "' And TRBTec.ExamYear ='" + ExamYear.SelectedItem + "'");
        //crystalReport.SetDataSource(dsgrade);
        //CR.ReportSource = crystalReport;

        //UnivService.Service1 NicService = new UnivService.Service1();
        //String TypeCode = NicService.GetNewCode("Select StreamTypeCode from Stream where StreamCode='" + StreamCode.SelectedValue + "' ");

        //// Get Stream Type--------------
        //if (TypeCode == "01")//Gen
        //{
        //}
        //else if (TypeCode == "02" && StreamPart.SelectedItem.Text =="Part-III"  )//Hons
        //{

        //    Panel1.Visible = true;
        //    CR.ReportSource = CrsFinal; 
        //    CR.SelectionFormula =  @"{TRHonsFinal.CollCode} = '" + CollCode.SelectedValue + "' And {TRHonsFinal.ExamYear} ='" + ExamYear.SelectedValue + "' And {TRHonsFinal.StreamCode} ='" + StreamCode.SelectedValue + "'";  
        //    CR.RefreshReport();
        //}
        //else if (TypeCode == "02")//Hons for Part I & II
        //{

        //    Panel1.Visible = true;
        //    CR.ReportSource = crs;
        //    CR.SelectionFormula = @"{TRHons.CollCode} = '" + CollCode.SelectedValue + "' And {TRHons.ExamYear} ='" + ExamYear.SelectedValue + "' And {TRHons.StreamCode} ='" + StreamCode.SelectedValue + "' And {TRHons.StreamPart} ='" + StreamPart.SelectedValue + "'";  
        //    CR.RefreshReport();
        //}
        //else if (TypeCode == "03")//Voc
        //{
        //}
        //else if (TypeCode == "04")//Pro
        //{
        //}
    }
    private DSGradeCard GetData(string query)
    {
        string conString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlCommand cmd = new SqlCommand(query);
        using (SqlConnection con = new SqlConnection(conString))
        {
            using (SqlDataAdapter sda = new SqlDataAdapter())
            {
                cmd.Connection = con;

                sda.SelectCommand = cmd;
                using (DSGradeCard dsgrade = new DSGradeCard())
                {
                    sda.Fill(dsgrade, "DataTable1");
                    return dsgrade;
                }
            }
        }
    }
    protected void CourseValue()
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart, StreamPartCode from StreamPart where streamcode='" + StreamCode.SelectedValue + "' order by StreamPartCode", "StreamPart", "StreamPartCode");
        // popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");

    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        CourseValue();
    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }
    protected void rdbbtec_CheckedChanged(object sender, EventArgs e)
    {
        if (rdbbtec.Checked == true)
        {
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from TRBTec) order by StreamAbbr", "StreamAbbr", "StreamCode");
            CourseValue();
           
        }
       
    }
    protected void rdbmtec_CheckedChanged(object sender, EventArgs e)
    {
        if (rdbmtec.Checked == true)
        {
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from TRMTec) order by StreamAbbr", "StreamAbbr", "StreamCode");
            CourseValue();
            
        }
       
    }

}
