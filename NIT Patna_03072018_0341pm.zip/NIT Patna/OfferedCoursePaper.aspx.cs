using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class OfferedCoursePaper : System.Web.UI.Page
{

    Functionreviseed fn = new Functionreviseed();
    Functionreviseed chkfn = new Functionreviseed();
    // static int CountCourse = 0;
    //static int CountElective = 0;
    DataTable dt1;
    DataRow dr = null;
    DataRow dr2 = null;
    DataRow[] dr1;
    string querypart = "";

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "13"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            string deptcode = (fn.singlevalue("Select DepartmentId From Login Where Userid = '" + Session["UserId"].ToString() + "'")).ToString();
            ViewState["DeptCode"] = deptcode;

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(Year3, "Year", "Select Year from Year where year > '2016' order by Year", "Year", "Year");
            popddl.Popualate(ddlProgramCategory, "ProgramCategory", "SELECT Id, Name FROM ProgramCategory", "Name", "Id");
            ddlProgramCategory.Items.Insert(0, new ListItem("-Select", "0"));
            Year3.Text = System.DateTime.Now.Year.ToString();
            ViewState["action"] = "Save";
            Panel2.Visible = false;

        }


    }

    protected void BtnSave_Click(object sender, EventArgs e)
    {
        try
        {
            //SaveExam();
            clear();

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

    }
    
    protected void ddlProgramCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        ViewState["CurrentTable"] = null;
        string deptCode = (string)ViewState["DeptCode"];
        LblMsg.Text = "";
        btnsubmit.Text = "Save";
        string examsession = month1.SelectedItem.ToString() + "-" + month2.SelectedItem.ToString() + "_" + Year3.SelectedItem.ToString();
        DataSet dsassignedcourse = fn.SelectDataset(" select StreamAbbr as Program, b.StreamPart as Semester, b.PaperAbbr,f.spcode, f.SpDescription,a.SubPaperCode,b.PaperName,b.Credit,Row_number() over (order by a.SubpaperCode) as orderNumber,h.UserId " +
                                    " from CourseCodeOfferedDetail a inner join CourseCodeOffered k on a.CourseCodeOfferedId=k.Id  inner join COURSEPAPERS b on a.SubPaperCode=b.SubPaperCode " +
                                   " inner join MasterCoursePaper c on b.MasterPaperId=c.Id " +
                                    " inner join Stream e on e.streamcode=b.streamcode inner join " +
                                   " CourseSpecialization f on k.splcode=f.spcode inner join ProgramCategory_Stream d on e.streamCode=d.streamCode left join " +
                                   " faculty_paper_a h on a.subpaperCode=h.SubPaperCode and k.SplCode=h.SplCode " +
                                  " and h.Is_Active='Y' and k.ExamSession=h.ExamSession  where departmentId='" + deptCode + "'  and k.ExamSession='" + examsession + "' and d.ProgCategoryId=" + ddlProgramCategory.SelectedValue);
        dsassignedcourse.Tables[0].PrimaryKey = new DataColumn[] { dsassignedcourse.Tables[0].Columns["orderNumber"] };
        ViewState["CurrentTable"] = dsassignedcourse.Tables[0];
        dt1 = dsassignedcourse.Tables[0];
        rptCompulsaryPaper.DataSource = dsassignedcourse.Tables[0];
        rptCompulsaryPaper.DataBind();
        BindEngElectivePaperControl(deptCode, examsession);
        ViewState["action"] = "Update";
        btnsubmit.Text = "UPDATE";
        btnsubmit.Visible = true;
        Panel1.Visible = true;
        Panel2.Visible = true;
    }


    private void BindEngElectivePaperControl(string deptCode, string examSession)
    {
        PopulateDDL populateDDL = new PopulateDDL();
        DataTable dscourse = fn.SelectDatatable("select Id,CourseCode from MasterCoursePaper  Where IsElective=1 and DepartmentId='" + deptCode + "'");
        dscourse.PrimaryKey = new DataColumn[] { dscourse.Columns["Id"] };
        ddlEngElecCourseCode.DataSource = dscourse;
        ddlEngElecCourseCode.DataTextField = "CourseCode";
        ddlEngElecCourseCode.DataValueField = "Id";
        ddlEngElecCourseCode.DataBind();
        ddlEngElecCourseCode.Items.Insert(0, new ListItem("--Select--", "00"));
        populateDDL.Popualate(ddlfaculty, "Login", "select UserName+'-'+Designation AS UserName,RTRIM( UserId) as userId from LogIn where IsLock='N' and (Userrole='9' or Userrole='13' or Userrole='15') and  DepartmentId='" + deptCode + "' ", "UserName", "UserId");
        string strDataBindQuery = " select b.CourseCode, b.Title,b.Id,b.Credit,h.userId,d.UserName " +
                                   " from OpenElectiveOffered a   inner join MasterCoursePaper b on a.MasterPaperId=b.Id " +
                                   " left join " +
                                   " faculty_paper_a h on a.MasterPaperId=h.MasterPaperId and a.CategoryId=h.ProgramCategoryId " +
                                   " and h.Is_Active='Y' and a.ExamSession=h.ExamSession left join LogIn d on h.UserId=d.UserId  where b.departmentId='" + deptCode + "'  and a.ExamSession='" + examSession + "' and a.CategoryId=" + ddlProgramCategory.SelectedValue;
        DataTable dtElectiveCourse = fn.SelectDatatable(strDataBindQuery);
        dtElectiveCourse.PrimaryKey = new DataColumn[] { dtElectiveCourse.Columns["Id"] };
        ViewState["gvEngElectiveCourse"] = dtElectiveCourse;
        if (dtElectiveCourse.Rows.Count > 0)
        {
            gvEngElective.DataSource = dtElectiveCourse;
        }
        else
        {
            gvEngElective.DataSource = null;
        }
        gvEngElective.DataBind();
    }
    string semtype;
    public void clear()
    {


    }
    protected void month1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (month1.SelectedIndex == 1)
        {
            month2.SelectedIndex = 1;
        }
        else if (month1.SelectedIndex == 2)
        {
            month2.SelectedIndex = 2;
        }
        else
        {
            month2.SelectedIndex = 0;
        }

    }


    protected void rptCompulsaryPaper_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        string deptCode = (string)ViewState["DeptCode"];
        PopulateDDL popddl = new PopulateDDL();
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            DropDownList faculty_dropdown = e.Item.FindControl("drpddlfaculty") as DropDownList;

            if (faculty_dropdown != null)
            {
                popddl.Popualate(faculty_dropdown, "Login", "select UserName+'-'+Designation AS UserName,RTRIM( UserId) as UserId from LogIn where IsLock='N' and (Userrole='9' or Userrole='13' or Userrole='15') and DepartmentId='" + deptCode + "'", "UserName", "UserId");
                faculty_dropdown.Items.Insert(0, new ListItem("--Select--", "00"));
                DataTable dt = (DataTable)ViewState["CurrentTable"];
                HiddenField hfvalue = e.Item.FindControl("IdOrder") as HiddenField;
                DataRow foundRow = dt.Rows.Find(hfvalue.Value);
                if (foundRow["userId"] != DBNull.Value)
                {
                    string userId = (string)foundRow["userId"];
                    if (faculty_dropdown.Items.FindByValue(userId) != null)
                        faculty_dropdown.SelectedValue = userId;

                }
            }
        }
    }


    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        string examsession = month1.SelectedItem.ToString() + "-" + month2.SelectedItem.ToString() + "_" + Year3.SelectedItem.ToString();
        DataTable dt = (DataTable)ViewState["CurrentTable"];
        foreach (RepeaterItem item in rptCompulsaryPaper.Items)
        {
            if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
            {
                HiddenField idOrder = (HiddenField)item.FindControl("IdOrder");
                DropDownList facultyId = (DropDownList)item.FindControl("drpddlfaculty");
                DataRow foundRow = dt.Rows.Find(idOrder.Value);
                if (foundRow["SubPaperCode"] != DBNull.Value)
                {
                    string subPaperCode = (string)foundRow["SubPaperCode"];
                    string splCode = (string)foundRow["spcode"];

                    string insertFacultyQuery = " Update Faculty_paper_a set Is_Active='N' where SubPaperCode='" + subPaperCode + "' and Splcode='" + splCode + "' and ExamSession='" + examsession + "';" +
                                                " INSERT INTO Faculty_paper_a (UserId, SubPaperCode, Is_Active, EntryDt,  Splcode, ExamSession) " +
                                                " VALUES     ('" + facultyId.SelectedValue + "','" + subPaperCode + "','Y',getdate(),'" + splCode + "','" + examsession + "')";
                    fn.InsertUpdateDelete(insertFacultyQuery);
                }
            }
        }

        //Open Elective entry

        string departmentCode = (string)ViewState["DeptCode"];
        string restInactive = " INSERT INTO OpenElectiveOfferedHistory (CategoryId, MasterPaperId, ExamSession, CreatedDate, DeletedDate, UserId) SELECT   CategoryId, MasterPaperId, ExamSession, CreatedDate, getDate(), '" + Session["UserId"].ToString() + "' FROM OpenElectiveOffered where CategoryId=" + ddlProgramCategory.SelectedValue + "  and ExamSession='" + examsession + "'; " +
                                 " Delete FROM OpenElectiveOffered  INNER JOIN MasterCoursePaper AS b ON OpenElectiveOffered.MasterPaperId = b.Id where CategoryId=" + ddlProgramCategory.SelectedValue + "  and ExamSession='" + examsession + "' and DepartmentId='" + departmentCode + "';";
        int resultouter = fn.InsertUpdateDelete(restInactive);
        for (int i = 0; i <= gvEngElective.Rows.Count - 1; i++)
        {
            int masterPaperId = (int)gvEngElective.DataKeys[i].Value;
            HiddenField hfUserIdControl = (HiddenField)gvEngElective.Rows[i].FindControl("hfUserId");
            string insertNew = " INSERT INTO OpenElectiveOffered (CategoryId, MasterPaperId, ExamSession,  ModifiedDate, UserId) VALUES  " +
                              " ('" + ddlProgramCategory.SelectedValue + "'," + masterPaperId.ToString() + ",'" + examsession + "',getdate(),'" + Session["UserId"].ToString() + "') ";
            resultouter = fn.InsertUpdateDelete(insertNew);

            string insertFacultyQuery = " Update Faculty_paper_a set Is_Active='N' where MasterPaperId=" + masterPaperId + " and ProgramCategoryId=" + ddlProgramCategory.SelectedValue + " and ExamSession='" + examsession + "';" +
                                        " INSERT INTO Faculty_paper_a (UserId, ProgramCategoryId,MasterPaperId,SubPaperCode, Is_Active, EntryDt, ExamSession) " +
                                        " VALUES     ('" + hfUserIdControl.Value + "'," + ddlProgramCategory.SelectedValue + "," + masterPaperId.ToString() + ",'00','Y',getdate(),'" + examsession + "')";
            resultouter = fn.InsertUpdateDelete(insertFacultyQuery);
        }
        LblMsg.Text = "Saved Successfully";
    }
    protected void btnEngElectiveSearch_Click(object sender, ImageClickEventArgs e)
    {
        string txtSearchText = txtEngElecPaper.Text;
        string subPaperCode = (string)fn.singlevalue("Select Convert(varchar,Id) From MasterCoursePaper Where CourseCode ='" + txtSearchText + "'");
        if (subPaperCode == string.Empty)
        {
            ddlEngElecCourseCode.SelectedValue = "0";
        }
        else
        {
            ListItem listItem = ddlEngElecCourseCode.Items.FindByText(txtSearchText.ToUpper());
            if (listItem != null)
            {
                ddlEngElecCourseCode.SelectedValue = listItem.Value;
            }
        }
        EngElecSelectionChanged();
    }

    private void EngElecSelectionChanged()
    {
        DataSet dscoursedetails = fn.SelectDataset("Select Title,Credit,L+'-'+T+'-'+P AS LTP From MasterCoursePaper Where Id = " + ddlEngElecCourseCode.SelectedValue);
        if (dscoursedetails.Tables[0].Rows.Count > 0)
        {
            lblcoursetitle.Text = dscoursedetails.Tables[0].Rows[0]["Title"].ToString();
            lblcredit.Text = dscoursedetails.Tables[0].Rows[0]["Credit"].ToString();
            lblLTP.Text = dscoursedetails.Tables[0].Rows[0]["LTP"].ToString();
        }
        else
        {
            lblcoursetitle.Text = "";
            lblcredit.Text = "";
            lblLTP.Text = "";
        }
    }
    protected void ddlEngElecCourseCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        EngElecSelectionChanged();
    }
    protected void btnEngElecAdd_Click(object sender, EventArgs e)
    {
        string sqlQuery = " select Id,CourseCode,Title,Credit,UserId,UserName  from masterCoursePaper " +
                          " cross apply (select * from login where userid='" + ddlfaculty.SelectedValue + "') a " +
                           " where id=" + ddlEngElecCourseCode.SelectedValue;
        DataTable dt = fn.SelectDatatable(sqlQuery);
        dt.PrimaryKey = new DataColumn[] { dt.Columns["Id"] };
        DataTable dtElectiveCourse = (DataTable)ViewState["gvEngElectiveCourse"];
        if (dtElectiveCourse == null)
        {
            ViewState["gvEngElectiveCourse"] = dt;
            dtElectiveCourse = dt;
        }
        else
        {
            dtElectiveCourse.Merge(dt);
        }
        gvEngElective.DataSource = dtElectiveCourse;
        gvEngElective.DataBind();
    }
    private void BindDDLCourseCode(DataTable dtCoursePaper)
    {
        ddlEngElecCourseCode.DataSource = dtCoursePaper;
        ddlEngElecCourseCode.DataTextField = "CourseCode";
        ddlEngElecCourseCode.DataValueField = "Id";
        ddlEngElecCourseCode.DataBind();
    }
    protected void gvEngElective_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "remove")
        {
            GridViewRow gvr = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
            int RowIndex = gvr.RowIndex;

            string masterPaperId = Convert.ToString(gvEngElective.DataKeys[0].Value);
            if (ViewState["gvEngElectiveCourse"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["gvEngElectiveCourse"];
                DataRow foundRow = dtCurrentTable.Rows.Find(masterPaperId);
                if (foundRow != null)
                {
                    foundRow.Delete();
                }
                dtCurrentTable.AcceptChanges();
                ViewState["gvEngElectiveCourse"] = dtCurrentTable;
                gvEngElective.DataSource = dtCurrentTable;
                gvEngElective.DataBind();
            }
        }
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Home.aspx");
    }
}
