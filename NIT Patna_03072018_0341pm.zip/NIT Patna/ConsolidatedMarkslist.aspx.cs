using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.Shared;
using CrystalDecisions.CrystalReports.Engine;
using System.IO;


public partial class CosonlidatedMarkslist : System.Web.UI.Page
{
    ReportDocument crystalReport = new ReportDocument();
    Functionreviseed fnrev = new Functionreviseed();
    string query;
    DataTable dt1;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {

                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "12") && (Session["Role"].ToString() != "10"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }

                ViewState.Add("EditMode", "false");

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }

            FillExamsession();            
        }
        if (ViewState["dt"] != null)
        {

            crystalReport.Load(Server.MapPath("~/Report/Consolidatedmarkslist.rpt"));
            consolidatedmarkslist dsmarkslist = new consolidatedmarkslist();
            dt1 = (DataTable)ViewState["dt"];
            dsmarkslist.Tables[0].Merge(dt1);
            crystalReport.SetDataSource(dsmarkslist);
            CrystalReportViewer1.ReportSource = crystalReport;
            panel1.Visible = true;
        }
    }
    protected void ddlexamsession_SelectedIndexChanged(object sender, EventArgs e)
    {
        Fillbranch();
    }
    protected void ddlbranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        FillSemester();
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        getstudent();
        consolidatedmarkslist dsmarkslist  = new consolidatedmarkslist();
        crystalReport.Load(Server.MapPath("~/Report/Consolidatedmarkslist.rpt"));
        dsmarkslist.Tables[0].Merge(dt1);
        crystalReport.SetDataSource(dsmarkslist);
        CrystalReportViewer1.ReportSource = crystalReport;
        panel1.Visible = true;
    }
    protected void btnexport_Click(object sender, EventArgs e)
    {
        getstudent();
        //DataTable dsexportexcel = new DataTable();
        //dsexportexcel = dt1.Clone();
        if (dt1.Rows.Count > 0)
        {
            //Create a dummy GridView
            GridView GridView1 = new GridView();
            GridView1.AllowPaging = false;
            GridView1.DataSource = dt1;
            GridView1.DataBind();
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=ConsolidatedMarksList_Data_" + DateTime.Now.Date + ".xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                //Apply text style to each Row
                GridView1.Rows[i].Attributes.Add("class", "textmode");

            }
            GridView1.RenderControl(hw);
            //style to format numbers to string
            string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    protected void Fillbranch()
    {
        if (ddltoexamsession.SelectedItem.ToString() != "--Select--" && ddlfrexamsession.SelectedItem.ToString() != "--Select--")
        {

            DataSet dsbranch = fnrev.SelectDataset("SELECT Distinct STREAM.StreamCode,STREAM.StreamAbbr FROM EXAMPAPERDETAIL " +
                " INNER JOIN STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN STREAM ON " +
                " STREAMPART.StreamCode = STREAM.StreamCode WHERE (CAST(SUBSTRING(EXAMPAPERDETAIL.ExamSession, 5, 3) + EXAMPAPERDETAIL.ExamYear AS DATETIME) BETWEEN " +
                " '" + "01-" + ddlfrexamsession.SelectedItem.ToString().Substring(4, 3) + "-" + ddlfrexamsession.SelectedItem.ToString().Substring(8, 4) + "' AND " +
                " '" + "01-" + ddltoexamsession.SelectedItem.ToString().Substring(4, 3)+ "-" + ddltoexamsession.SelectedItem.ToString().Substring(8, 4) + "')");

            ddlbranch.DataTextField = "StreamAbbr";
            ddlbranch.DataValueField = "StreamCode";
            ddlbranch.DataSource = dsbranch.Tables[0];
            ddlbranch.DataBind();
            ddlbranch.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }
    protected void FillExamsession()
    {
        DataSet dsexamsession = fnrev.SelectDataset("Select Distinct ExamSession From EXAMPAPERDETAIL");
        ddltoexamsession.DataTextField = "ExamSession";
        ddltoexamsession.DataValueField = "ExamSession";
        ddltoexamsession.DataSource = dsexamsession.Tables[0];
        ddltoexamsession.DataBind();
        ddltoexamsession.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlfrexamsession.DataTextField = "ExamSession";
        ddlfrexamsession.DataValueField = "ExamSession";
        ddlfrexamsession.DataSource = dsexamsession.Tables[0];
        ddlfrexamsession.DataBind();
        ddlfrexamsession.Items.Insert(0, new ListItem("--Select--", "0"));
        Fillbranch();
    }
    protected void FillSemester()
    {
        DataSet dssemester = fnrev.SelectDataset("Select StreamPart,StreamPartCode From StreamPart Where StreamCode = '" + ddlbranch.SelectedValue + "' order by STREAMPART");

        ddlsemester.DataTextField = "StreamPart";
        ddlsemester.DataValueField = "StreamPartCode";

        ddlsemester.DataSource = dssemester.Tables[0];
        ddlsemester.DataBind();
        ddlsemester.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    string sem = ""; string cumulativequery1 = "", cumulativequery2 = ""; string cumulativequery1part = "", cumulativequery2part = "";
    DataTable dtstudent = new DataTable();
    DataSet dsstudentlist = new DataSet();
    DataSet dsstudent = new DataSet();
    private void getstudent()
    {
        
        
        checksem();
        dt1 = new DataTable();
        dt1.Columns.Add("RollNo");
        dt1.Columns.Add("EnrollmentNo");
        dt1.Columns.Add("ApplicantName");
        dt1.Columns.Add("Branch");
        dt1.Columns.Add("Semester");
        dt1.Columns.Add("CumPRcredit");
        dt1.Columns.Add("CumERCredit");
        dt1.Columns.Add("CGPA");
        dt1.Columns.Add("TotalGrdPoint");
        dt1.Columns.Add("Status");
        dt1.Columns.Add("TotalPaperFmarks");
        dt1.Columns.Add("TotalMarksObt");
        dt1.Columns.Add("TotalPRCObt");
        dt1.Columns.Add("Year");

        dtstudent.Columns.Add("AckNo");
        dtstudent.Columns.Add("ApplicantName");
        dtstudent.Columns.Add("StreamCode");
        dtstudent.Columns.Add("RegNo");
        dtstudent.Columns.Add("UnivRollNo");
       
        object strtypecode = fnrev.singlevalue("Select StreamTypeCode From STREAM Where StreamCode = '" + ddlbranch.SelectedValue + "'");
        string frmexamsession = ddlfrexamsession.SelectedItem.ToString().Substring(8, 4) + "-" + ddlfrexamsession.SelectedItem.ToString().Substring(4, 3) + "-01";
        string toexamsession = ddltoexamsession.SelectedItem.ToString().Substring(8, 4) + "-" + ddltoexamsession.SelectedItem.ToString().Substring(4, 3) + "-01";
        if (strtypecode.ToString() == "01")
        {
            if (ddlsemester.SelectedValue.ToString() == "0")
            {
                dsstudentlist = fnrev.SelectDataset("Select Distinct UnivRollNo,RegNo From TRBtec Where (CAST(SUBSTRING(ExamSession, 5, 3) + SUBSTRING(ExamSession,9,4) AS DATETIME) BETWEEN '" + frmexamsession + "' AND  '" + toexamsession + "')");
                cumulativequery1part = "Where ";
            }
            else
            {
                dsstudentlist = fnrev.SelectDataset("Select Distinct UnivRollNo,RegNo From cgpa Where semno = '" + sem + "' and STREAMPART = '" + ddlsemester.SelectedValue + "' AND (CAST(SUBSTRING(cgpa.ExamSession, 5, 3) + SUBSTRING(cgpa.ExamSession,9,4) AS DATETIME) BETWEEN '" + frmexamsession + "' AND  '" + toexamsession + "')");
                cumulativequery1part = " where (semno between '1' and '" + sem + "') And ";
            }
            cumulativequery1 = "select SUM(Convert(float,Credit)) as CumPapercredit,SUM(Convert(float,ER_CREDIT)) as CumER_CREDIT, " +
                        " SUM(Convert(float,Grade_Point)) As CUM_GradePoint,ROUND(CASE WHEN SUM(Credit) = SUM(ER_CREDIT) THEN " +
                        " SUM(CONVERT(float, Grade_Point)) / SUM(CONVERT(float,ER_CREDIT)) ELSE NULL END, 2) AS CGPA," +
                        " CASE WHEN SUM(Credit) = SUM(ER_CREDIT) THEN 'P' ELSE 'F' END AS Status from cgpa " + cumulativequery1part;
            cumulativequery2 = "Select SUM(Convert(float,a.Credit)) as Totalpapercredit," +
                        " SUM(Convert(float,b.FullMarks) + Convert(float,ISNULL(c.FullMarks, 0))) AS TotalPapermarks, " +
                        " SUM(CONVERT(float, a.Total_PMO)*(Convert(float,b.FullMarks) + Convert(float,ISNULL(c.FullMarks, 0))) / 100) AS Marksobtained," +
                        " ROUND(SUM(CONVERT(float, a.Total_PMO)*(Convert(float,b.FullMarks) + Convert(float,ISNULL(c.FullMarks, 0))) / 100) * 100 / " +
                        "SUM(Convert(float,b.FullMarks) + Convert(float,ISNULL(c.FullMarks, 0))),2) AS PercentObtained " +
                        " From cgpa a Inner Join COURSEPAPERS b On a.SubPaperCode = b.SubPaperCode Left Outer join PRACTICALPAPERS c on " +
                        " b.SubPaperCode = c.SubPaperCode " + cumulativequery1part;
        }
        else if ((strtypecode.ToString() == "02") || (strtypecode.ToString() == "04"))
        {
            if (ddlsemester.SelectedValue.ToString() == "0")
            {
                dsstudentlist = fnrev.SelectDataset("Select Distinct UnivRollNo,RegNo From TRMtec Where (CAST(SUBSTRING(ExamSession, 5, 3) + SUBSTRING(ExamSession,9,4) AS DATETIME) BETWEEN '" + frmexamsession + "' AND  '" + toexamsession + "')");
                cumulativequery1part = "Where ";
            }
            else
            {
                dsstudentlist = fnrev.SelectDataset("Select Distinct UnivRollNo,RegNo From cgpa_Mtec Where semno = '" + sem + "' and STREAMPART = '" + ddlsemester.SelectedValue + "' AND (CAST(SUBSTRING(cgpa_Mtec.ExamSession, 5, 3) + SUBSTRING(cgpa_Mtec.ExamSession,9,4) AS DATETIME) BETWEEN '" + frmexamsession + "' AND  '" + toexamsession + "')");
                cumulativequery1part = " where (semno between '1' and '" + sem + "') And ";
            }
            
            cumulativequery1 = "select SUM(Convert(float,Credit)) as CumPapercredit,SUM(Convert(float,ER_CREDIT)) as CumER_CREDIT, " +
                        " SUM(Convert(float,Grade_Point)) As CUM_GradePoint,ROUND(CASE WHEN SUM(Credit) = SUM(ER_CREDIT) THEN " +
                        " SUM(CONVERT(float, Grade_Point)) / SUM(CONVERT(float,ER_CREDIT)) ELSE NULL END, 2) AS CGPA," +
                        " CASE WHEN SUM(Credit) = SUM(ER_CREDIT) THEN 'P' ELSE 'F' END AS Status from cgpa_Mtec " + cumulativequery1part;
            cumulativequery2 = "Select SUM(Convert(float,a.Credit)) as Totalpapercredit," +
                        " SUM(Convert(float,b.FullMarks) + Convert(float,ISNULL(c.FullMarks, 0))) AS TotalPapermarks, " +
                        " SUM(CONVERT(float, a.Total_PMO)*(Convert(float,b.FullMarks) + Convert(float,ISNULL(c.FullMarks, 0))) / 100) AS Marksobtained," +
                        " ROUND(SUM(CONVERT(float, a.Total_PMO)*(Convert(float,b.FullMarks) + Convert(float,ISNULL(c.FullMarks, 0))) / 100) * 100 / " +
                        "SUM(Convert(float,b.FullMarks) + Convert(float,ISNULL(c.FullMarks, 0))),2) AS PercentObtained " +
                        " From cgpa_Mtec a Inner Join COURSEPAPERS b On a.SubPaperCode = b.SubPaperCode Left Outer join PRACTICALPAPERS c on " +
                        " b.SubPaperCode = c.SubPaperCode " + cumulativequery1part;
        }

       // DataSet dsstudentlist = fnrev.SelectDataset("Select Distinct UnivRollNo From cgpa Where semno = '" + sem + "' and STREAMPART = '" + ddlsemester.SelectedValue + "'");
        if (dsstudentlist.Tables[0].Rows.Count > 0)
        {
           /* for (int u=0;u<dsstudentlist.Tables[0].Rows.Count; u++)
            {
                if (strtypecode.ToString() == "01")
                {
                    dsstudent = fnrev.SelectDataset("SELECT Distinct REGISTRATION.AckNo, REGISTRATION.ApplicantName, REGISTRATION.StreamCode, TRBTec.RegNo, TRBTec.UnivRollNo FROM REGISTRATION INNER JOIN TRBTec ON REGISTRATION.RegNo = TRBTec.RegNo WHERE " +
                    " TRBTec.StreamCode = '" + ddlbranch.SelectedValue + "' and (CAST(SUBSTRING(TRBTec.ExamSession, 5, 3) + TRBTec.ExamYear AS DATETIME) BETWEEN '" + frmexamsession + "' AND " +
                    " '" + toexamsession + "') and UnivRollNo = '" + dsstudentlist.Tables[0].Rows[u]["Univrollno"].ToString() + "'");
                }
                else
                {
                    dsstudent = fnrev.SelectDataset("SELECT Distinct REGISTRATION.AckNo, REGISTRATION.ApplicantName, REGISTRATION.StreamCode, TRMTec.RegNo, TRMTec.UnivRollNo FROM REGISTRATION INNER JOIN TRMTec ON REGISTRATION.RegNo = TRMTec.RegNo WHERE " +
                     " TRMTec.StreamCode = '" + ddlbranch.SelectedValue + "' and (CAST(SUBSTRING(TRMTec.ExamSession, 5, 3) + TRMTec.ExamYear AS DATETIME) BETWEEN '" + frmexamsession + "' AND " +
                     " '" + toexamsession + "') and UnivRollNo = '" + dsstudentlist.Tables[0].Rows[u]["Univrollno"].ToString() + "'");
                }
            if (dsstudent.Tables[0].Rows.Count > 0)
            {
               for (int t =0;t<dsstudent.Tables[0].Rows.Count;t++)
               {
                   dtstudent.Rows.Add(dsstudent.Tables[0].Rows[0]["AckNo"].ToString(), dsstudent.Tables[0].Rows[0]["ApplicantName"].ToString(), dsstudent.Tables[0].Rows[0]["StreamCode"].ToString(),
                       dsstudent.Tables[0].Rows[0]["RegNo"].ToString(), dsstudent.Tables[0].Rows[0]["UnivRollNo"].ToString());
               }
            }
            } */
            for (int u = 0; u < dsstudentlist.Tables[0].Rows.Count; u++)
            {
                dsstudent = fnrev.SelectDataset("SELECT Distinct REGISTRATION.AckNo, REGISTRATION.ApplicantName, REGISTRATION.StreamCode,REGISTRATION.RegNo FROM REGISTRATION WHERE REGISTRATION.StreamCode = '" + ddlbranch.SelectedValue + "' and RegNo = '" + dsstudentlist.Tables[0].Rows[u]["RegNo"].ToString() + "'");
                if (dsstudent.Tables[0].Rows.Count > 0)
                {
                    dtstudent.Rows.Add(dsstudent.Tables[0].Rows[0]["AckNo"].ToString(), dsstudent.Tables[0].Rows[0]["ApplicantName"].ToString(), dsstudent.Tables[0].Rows[0]["StreamCode"].ToString(),
                      dsstudent.Tables[0].Rows[0]["RegNo"].ToString(), dsstudentlist.Tables[0].Rows[u]["Univrollno"].ToString());

                }
            }

           // DataSet dsstudent = fnrev.SelectDataset(studentquery);
            if (dtstudent.Rows.Count > 0)
            {
                for (int e = 0; e < dtstudent.Rows.Count; e++)
                {
                    string cumulativequery3 = cumulativequery1 + " RegNo= '" + dtstudent.Rows[e]["RegNo"].ToString() + "' Group by RegNo";
                    string cumulativequery4 = cumulativequery2 + " a.RegNo = '" + dtstudent.Rows[e]["RegNo"].ToString() + "'";
                    DataSet cumulative1 = fnrev.SelectDataset(cumulativequery3);
                    DataSet cumulative2 = fnrev.SelectDataset(cumulativequery4);
                    DataRow dr1 = dt1.NewRow();
                    dr1[0] = dtstudent.Rows[e]["UnivRollNo"].ToString();
                    dr1[1] = dtstudent.Rows[e]["AckNo"].ToString();
                    dr1[2] = dtstudent.Rows[e]["ApplicantName"].ToString();
                    dr1[3] = ddlbranch.SelectedItem.ToString();
                    if (ddlsemester.SelectedValue.ToString() == "0")
                    {
                        if (strtypecode.ToString() == "01")
                        {
                            dr1[4] = (fnrev.singlevalue("SELECT Top(1) STREAMPART.StreamPart AS Semester FROM cgpa INNER JOIN STREAMPART ON " +
                                " cgpa.StreamPart = STREAMPART.StreamPartCode WHERE (cgpa.RegNo = '" + dtstudent.Rows[e]["RegNo"].ToString() + "') ORDER BY cgpa.semno DESC")).ToString();
                        }
                        else
                        {
                            dr1[4] = (fnrev.singlevalue("SELECT Top(1) STREAMPART.StreamPart AS Semester FROM cgpa_Mtec INNER JOIN STREAMPART ON " +
                                                           " cgpa_Mtec.StreamPart = STREAMPART.StreamPartCode WHERE (cgpa_Mtec.RegNo = '" + dtstudent.Rows[e]["RegNo"].ToString() + "') ORDER BY cgpa_Mtec.semno DESC")).ToString();
                        }
                    }
                    else
                    {
                        dr1[4] = ddlsemester.SelectedItem.ToString();
                    }
                    if (cumulative1.Tables[0].Rows.Count > 0)
                    {
                        dr1[5] = cumulative1.Tables[0].Rows[0]["CumPapercredit"].ToString();
                        dr1[6] = cumulative1.Tables[0].Rows[0]["CumER_CREDIT"].ToString();
                        dr1[7] = cumulative1.Tables[0].Rows[0]["CGPA"].ToString();
                        dr1[8] = cumulative1.Tables[0].Rows[0]["CUM_GradePoint"].ToString();
                        dr1[9] = cumulative1.Tables[0].Rows[0]["Status"].ToString();
                    }
                    if (cumulative2.Tables[0].Rows.Count > 0)
                    {
                        dr1[10] = cumulative2.Tables[0].Rows[0]["TotalPapermarks"].ToString();
                        dr1[11] = cumulative2.Tables[0].Rows[0]["Marksobtained"].ToString();
                        dr1[12] = cumulative2.Tables[0].Rows[0]["PercentObtained"].ToString();
                    }
                    string lastexamyear = "";
                    if (strtypecode.ToString() == "01")
                    {
                        lastexamyear = "Select Top(1) CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4) AS DATETIME)  as lastrec FROM cgpa " +
                        " WHERE UnivRollNo = '" + dtstudent.Rows[e]["UnivRollNo"].ToString() + "' order by CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4) AS DATETIME) DESC ";
                    }
                    else
                    {
                        lastexamyear = "Select Top(1) CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4) AS DATETIME)  as lastrec FROM cgpa_Mtec " +
                        " WHERE UnivRollNo = '" + dtstudent.Rows[e]["UnivRollNo"].ToString() + "' order by CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4) AS DATETIME) DESC ";
                    }
                    object examsession = fnrev.singlevalue(lastexamyear);
                    if (examsession.ToString() != "")
                        dr1[13] = examsession.ToString(); // Add Examsession ----
                    else
                        dr1[13] = "";
                    dt1.Rows.Add(dr1);
                }
                ViewState["dt"] = dt1;
            }
        }
        
    }       

    private void checksem()
    {
        if (ddlsemester.SelectedItem.ToString() == "sem 1-A")
            sem = "1";
        else if (ddlsemester.SelectedItem.ToString() == "sem 1-B")
            sem = "1";
        else if (ddlsemester.SelectedItem.ToString() == "sem 1")
            sem = "1";
        else if (ddlsemester.SelectedItem.ToString() == "sem 2-A")
            sem = "2";
        else if (ddlsemester.SelectedItem.ToString() == "sem 2-B")
            sem = "2";
        else if (ddlsemester.SelectedItem.ToString() == "sem 2")
            sem = "2";
        else if (ddlsemester.SelectedItem.ToString() == "sem 3")
            sem = "3";
        else if (ddlsemester.SelectedItem.ToString() == "sem 4")
            sem = "4";
        else if (ddlsemester.SelectedItem.ToString() == "sem 5")
            sem = "5";
        else if (ddlsemester.SelectedItem.ToString() == "sem 6")
            sem = "6";
        else if (ddlsemester.SelectedItem.ToString() == "sem 7")
            sem = "7";
        else if (ddlsemester.SelectedItem.ToString() == "sem 8")
            sem = "8";
        else if (ddlsemester.SelectedItem.ToString() == "sem 9")
            sem = "9";
        else if (ddlsemester.SelectedItem.ToString() == "sem 10")
            sem = "10";
    }
    protected void ddltoexamsession_SelectedIndexChanged(object sender, EventArgs e)
    {
        Fillbranch();
    }
}
