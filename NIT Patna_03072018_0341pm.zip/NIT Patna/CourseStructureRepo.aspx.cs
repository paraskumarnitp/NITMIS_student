using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Text;

public partial class CourseStructureRepo : System.Web.UI.Page
{
    Functionreviseed dut = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "10")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(ExamSession, "EXAMPAPERDETAIL", "select DIStinct ExamSession from EXAMPAPERDETAIL", "ExamSession", "ExamSession");
            // select DIStinct ExamSession from EXAMPAPERDETAIL
            ExamSession.Items.Insert(0, new ListItem("--Select--", "00"));
        }
        
    }

    protected void rdoUC_CheckedChanged(object sender, EventArgs e)
    {
        string criteria = "UG";
        string query = "SELECT STREAM.StreamAbbr FROM  STREAM INNER JOIN "+                 

                     " STREAMTYPE ON STREAM.StreamTypeCode = STREAMTYPE.StreamTypeCode and StreamTypeName='"+criteria+"' ";

        if (rdoUC.Checked)
        {
        }
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(cmbDepartment, "STREAM", query, "StreamAbbr", "StreamAbbr");
        cmbDepartment.Items.Insert(0, new ListItem("ALL", "00"));
        cmbSemester.Items.Insert(0, new ListItem("ALL", "00"));
         
    }
    protected void rdoPC_CheckedChanged(object sender, EventArgs e)
    {
        string criteria = "PG";
        string query = "SELECT STREAM.StreamAbbr FROM  STREAM INNER JOIN " +

                     " STREAMTYPE ON STREAM.StreamTypeCode = STREAMTYPE.StreamTypeCode and StreamTypeName='" + criteria + "' ";

        if (rdoUC.Checked)
        {
        }
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(cmbDepartment, "STREAM", query, "StreamAbbr", "StreamAbbr");
        cmbDepartment.Items.Insert(0, new ListItem("ALL", "00"));
        cmbSemester.Items.Insert(0, new ListItem("ALL", "00"));
    }
    protected void rdoDD_CheckedChanged(object sender, EventArgs e)
    {
        string criteria = "DD";
        string query = "SELECT STREAM.StreamAbbr FROM  STREAM INNER JOIN " +

                     " STREAMTYPE ON STREAM.StreamTypeCode = STREAMTYPE.StreamTypeCode and StreamTypeName='" + criteria + "' ";

        if (rdoUC.Checked)
        {
        }
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(cmbDepartment, "STREAM", query, "StreamAbbr", "StreamAbbr");
        cmbDepartment.Items.Insert(0, new ListItem("ALL", "00"));
        cmbSemester.Items.Insert(0, new ListItem("ALL", "00"));
    }
    protected void cmbDepartment_SelectedIndexChanged(object sender, EventArgs e)
    {
        string query = "SELECT STREAMPART.StreamPart,STREAMPART.StreamPartCode FROM  STREAM INNER JOIN  STREAMPART ON STREAM.StreamCode = STREAMPART.StreamCode INNER JOIN   STREAMTYPE ON STREAM.StreamTypeCode = STREAMTYPE.StreamTypeCode where StreamAbbr='" + cmbDepartment.SelectedItem.ToString() + "' ";
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(cmbSemester, "STREAMPART", query, "StreamPart", "StreamPartCode");
        cmbSemester.Items.Insert(0, new ListItem("ALL", "00"));



    }
    protected void BtnGenerate_Click(object sender, EventArgs e)
    {
        BindGridview();

    }



    protected void BindGridview()
    {
        string query = "";

        try
        {

            if (cmbSemester.SelectedItem.ToString().Equals("ALL"))
            {
                query = "SELECT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName, COURSEPAPERS.FullMarks," +
                    " COURSEPAPERS.Credit, COURSEPAPERS.L, COURSEPAPERS.T, COURSEPAPERS.P, " +
                    "CASE WHEN COURSEPAPERS.PaperTypeCode = '01' THEN 'PT' WHEN COURSEPAPERS.PaperTypeCode = '02' THEN 'TH' Else 'TH + PT' End As PaperType ," +
                    "CoursePaperOfferedType.Name AS OfferedType   FROM CourseCodeOfferedDetail INNER JOIN   COURSEPAPERS ON CourseCodeOfferedDetail.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                    "INNER JOIN  CoursePaperOfferedType ON CourseCodeOfferedDetail.OfferedTypeId = CoursePaperOfferedType.Id   WHERE     (CourseCodeOfferedDetail.CourseCodeOfferedId IN  (SELECT     Id  FROM          CourseCodeOffered  WHERE      (ExamSession = '" + ExamSession.SelectedValue + "')  ))";
                DataSet dsmasterpaper = new DataSet();
                dsmasterpaper = dut.SelectDataset(query);
                grdcourseStructure.DataSource = dsmasterpaper.Tables[0];
                grdcourseStructure.DataBind();
            }
            else
            {
               query = "SELECT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName, COURSEPAPERS.FullMarks," +
                    " COURSEPAPERS.Credit, COURSEPAPERS.L, COURSEPAPERS.T, COURSEPAPERS.P, " +
                    "CASE WHEN COURSEPAPERS.PaperTypeCode = '01' THEN 'PT' WHEN COURSEPAPERS.PaperTypeCode = '02' THEN 'TH' Else 'TH + PT' End As PaperType ," +
                    "CoursePaperOfferedType.Name AS OfferedType   FROM CourseCodeOfferedDetail INNER JOIN   COURSEPAPERS ON CourseCodeOfferedDetail.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                    "INNER JOIN  CoursePaperOfferedType ON CourseCodeOfferedDetail.OfferedTypeId = CoursePaperOfferedType.Id   WHERE     (CourseCodeOfferedDetail.CourseCodeOfferedId IN  (SELECT     Id  FROM          CourseCodeOffered  WHERE      (ExamSession = '" + ExamSession.SelectedValue + "') AND (StreamPartCode = '" + cmbSemester.SelectedValue + "') ))";

               DataSet dsmasterpaper = new DataSet();
               dsmasterpaper = dut.SelectDataset(query);
               grdcourseStructure.DataSource = dsmasterpaper.Tables[0];
               grdcourseStructure.DataBind();

            }
           
        }
        catch (Exception ex)
        {
           
        }
    }
    protected void grdcourseStructure_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdcourseStructure.PageIndex = e.NewPageIndex;
        BindGridview();

    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        string query = "";

        if (cmbDepartment.SelectedItem.ToString().Equals("ALL"))
        {
            query = "SELECT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName, COURSEPAPERS.FullMarks," +
                  " COURSEPAPERS.Credit, COURSEPAPERS.L, COURSEPAPERS.T, COURSEPAPERS.P, " +
                  "CASE WHEN COURSEPAPERS.PaperTypeCode = '01' THEN 'PT' WHEN COURSEPAPERS.PaperTypeCode = '02' THEN 'TH' Else 'TH + PT' End As PaperType ," +
                  "CoursePaperOfferedType.Name AS OfferedType   FROM CourseCodeOfferedDetail INNER JOIN   COURSEPAPERS ON CourseCodeOfferedDetail.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                  "INNER JOIN  CoursePaperOfferedType ON CourseCodeOfferedDetail.OfferedTypeId = CoursePaperOfferedType.Id   WHERE     (CourseCodeOfferedDetail.CourseCodeOfferedId IN  (SELECT     Id  FROM          CourseCodeOffered  WHERE      (ExamSession = '" + ExamSession.SelectedValue + "')  ))";




            DataSet dsexportexcel = dut.SelectDataset(query);
            if (dsexportexcel.Tables[0].Rows.Count > 0)
            {
                //Create a dummy GridView
                GridView GridView1 = new GridView();
                GridView1.AllowPaging = false;
                GridView1.DataSource = dsexportexcel.Tables[0];
                GridView1.DataBind();
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=Student_Marks_Data_" + DateTime.Now.Date + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                for (int i = 0; i < GridView1.Rows.Count; i++)
                {
                    //Apply text style to each Row
                    GridView1.Rows[i].Attributes.Add("class", "textmode");

                }
                GridView1.RenderControl(hw);
                //style to format numbers to string
                string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
        else
        {
            query = "SELECT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName, COURSEPAPERS.FullMarks," +
                   " COURSEPAPERS.Credit, COURSEPAPERS.L, COURSEPAPERS.T, COURSEPAPERS.P, " +
                   "CASE WHEN COURSEPAPERS.PaperTypeCode = '01' THEN 'PT' WHEN COURSEPAPERS.PaperTypeCode = '02' THEN 'TH' Else 'TH + PT' End As PaperType ," +
                   "CoursePaperOfferedType.Name AS OfferedType   FROM CourseCodeOfferedDetail INNER JOIN   COURSEPAPERS ON CourseCodeOfferedDetail.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                   "INNER JOIN  CoursePaperOfferedType ON CourseCodeOfferedDetail.OfferedTypeId = CoursePaperOfferedType.Id   WHERE     (CourseCodeOfferedDetail.CourseCodeOfferedId IN  (SELECT     Id  FROM          CourseCodeOffered  WHERE      (ExamSession = '" + ExamSession.SelectedValue + "') AND (StreamPartCode = '" + cmbSemester.SelectedValue + "') ))";


            DataSet dsexportexcel = dut.SelectDataset(query);
            if (dsexportexcel.Tables[0].Rows.Count > 0)
            {
                //Create a dummy GridView
                GridView GridView1 = new GridView();
                GridView1.AllowPaging = false;
                GridView1.DataSource = dsexportexcel.Tables[0];
                GridView1.DataBind();
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=Student_Marks_Data_" + DateTime.Now.Date + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                for (int i = 0; i < GridView1.Rows.Count; i++)
                {
                    //Apply text style to each Row
                    GridView1.Rows[i].Attributes.Add("class", "textmode");

                }
                GridView1.RenderControl(hw);
                //style to format numbers to string
                string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }





    }
}
