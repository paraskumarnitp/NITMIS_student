using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using CrystalDecisions.CrystalReports.Engine;
public partial class TranscriptGrade : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    PopulateDDL popddl = new PopulateDDL();
    string streamtypcode; String Streamvalue;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }



            //popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College where collcode in (select distinct collcode from TRHons) order by CollName", "CollName", "CollCode");
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College where collcode in (select distinct collcode from TRBTec) order by CollName", "CollName", "CollCode");
            //popddl.Popualate(ExamYear, "Exam", "Select distinct ExamYear from Exam order by ExamYear", "ExamYear", "ExamYear");
            popddl.Popualate(ExamYear, "Exam", "Select Distinct Examsession From Btecgrade order by Examsession", "Examsession", "Examsession");
            StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
            StreamPart.Items.Insert(0,new ListItem("--Select--","00"));

            // popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from TRHons) order by StreamAbbr", "StreamAbbr", "StreamCode");

            

        }
    }
    string remarks, sgpa, cgpa, gradesno, Thfmarks, PRFmarks;
    string totalercredit = "", Credit = "", totalpmo = "";
    object datevalue;
    object autono;
    string totalmarks = "", query1, query2;
    double markspercent;
    string Querystr1 = "", ncbpapers = "";
    DataSet dsncbklg;
    DataSet dsgradedata;
    DataRow[] dr;

    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = rdbgr.Checked || rdbrollno.Checked;
    }
    protected void CustomValidator2_ServerValidate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = rdbbtec.Checked || rdbmtec.Checked;
    }
    DataRow dr2; DataTable dt; DataRow[] dr1;
    protected void ViewTR_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            string Querystr;
            if (rdbbtec.Checked == true)
                streamtypcode = "01";
            else if (rdbmtec.Checked == true) streamtypcode = "02";
           
            string streampart = StreamPart.SelectedValue;
            string crit = "";
            if (StreamPart.SelectedItem.ToString().IndexOf('A') > 0 || StreamPart.SelectedItem.ToString().IndexOf('B') > 0)
            {
                streampart = StreamPart.SelectedItem.ToString();
            }
            if (rdbgr.Checked == true)
                crit = "semwise";
            else if (rdbrollno.Checked == true)
                crit = "rollwise";

            string strque = "transcriptprint.aspx?sc=" + StreamCode.SelectedValue + "&spc=" + streampart + "&ey=" + ExamYear.SelectedItem + "&prg=" + StreamCode.SelectedItem + "&sem=" + StreamPart.SelectedItem + "&stmtp=" + streamtypcode + "&crt=" + crit + "&urolno=" + rollno.Text.Trim();

ScriptManager.RegisterStartupScript(this,Page.GetType(), "", "window.open('" + strque + "','Graph','height=600,width=800,resizable=yes');", true);


          

        }
    }


   
    protected void CourseValue()
    {
        PopulateDDL popddl = new PopulateDDL();
        StreamPart.Items.Clear();
        popddl.Popualate(StreamPart, "StreamPart", "select distinct b.StreamPart,b.StreamPartCode from ExamPaperDetail a inner join STREAMPART b on a.StreamPartCode=b.StreamPartCode and b.StreamCode='" + StreamCode.SelectedValue + "' where   a.ExamSession='"+ExamYear.SelectedValue+"' ", "StreamPart", "StreamPartCode");
        // popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        StreamPart.Items.Insert(0,new ListItem("--Select--","00"));

    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        CourseValue();
    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }
    protected void rdbbtec_CheckedChanged(object sender, EventArgs e)
    {
        if (rdbbtec.Checked == true)
        {
            StreamCode.Items.Clear();
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from TRBTec) order by StreamAbbr", "StreamAbbr", "StreamCode");
            StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
            CourseValue();

        }

    }
    protected void rdbmtec_CheckedChanged(object sender, EventArgs e)
    {
        if (rdbmtec.Checked == true)
        {
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from TRMTec) order by StreamAbbr", "StreamAbbr", "StreamCode");
            CourseValue();

        }

    }
    protected void rdbrollno_CheckedChanged(object sender, EventArgs e)
    {
        if (rdbrollno.Checked == true)
        {
            rollno.Enabled = true;
            rollno.Text = "";
        }
    }
    protected void rdbgr_CheckedChanged(object sender, EventArgs e)
    {
        if (rdbgr.Checked == true)
        {
            rollno.Text = "";
            rollno.Enabled = false;
        }
    }
}
