using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.Collections.Generic;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.IO;
using System.Text;


public partial class TRMarksstatus : System.Web.UI.Page
{
    Functionreviseed fn = new Functionreviseed();
    PopulateDDL popddl = new PopulateDDL();
    DataSet dsmarksdata;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {

            try
            {

                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }
                //string role = Session["Role"].ToString();
                ViewState.Add("EditMode", "false");

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }

            DataSet dsExamsession = fn.SelectDataset("Select Distinct ExamSession,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4) AS DATETIME) as examyear From TRBtec order by CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4) AS DATETIME) DESC");
            ddlexamsession.DataSource = dsExamsession.Tables[0];
            ddlexamsession.DataTextField = "ExamSession";
            ddlexamsession.DataValueField = "ExamSession";
            ddlexamsession.DataBind();
            ddlexamsession.Items.Insert(0, new ListItem("--Select--", "0"));

        }

    }


    protected void btnsumit_Click(object sender, EventArgs e)
    {

        gvParentGrid.Columns[2].Visible = true;
        gvParentGrid.Columns[14].Visible = true;
        BindGridview();
        gvParentGrid.Columns[2].Visible = false;
        gvParentGrid.Columns[14].Visible = false;
    }
    /* public string getWhileLoopData()
     {
         string htmlStr = "";
         string conn = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ToString();
         SqlConnection sqlCon = new SqlConnection(conn);
         SqlCommand Command = sqlCon.CreateCommand();
         Command.CommandText = "SELECT TRBTec.SubPaperCode,COURSEPAPERS.PaperAbbr, STREAM.StreamAbbr ,TRBTec.CA_MSM_TH, TRBTec.TH_ESM, " +
             " TRBTec.TH_PMO, TRBTec.CA_MSM_PT, TRBTec.PT_ESM, TRBTec.PT_PMO, TRBTec.Total_PMO, TRBTec.Grade_Point, " +
             " TRBTec.ER_CREDIT, TRBTec.Grade, TRBTec.Remarks, TRBTec.ExamType, TRBTec.ExamSession FROM TRBTec INNER JOIN " +
             " STREAM ON TRBTec.StreamCode = STREAM.StreamCode INNER JOIN COURSEPAPERS ON " +
             " TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE (TRBTec.UnivRollNo = '13B1010     ') AND " +
             " (TRBTec.StreamPart = '137')";
         sqlCon.Open();
         SqlDataReader reader = Command.ExecuteReader();

         while (reader.Read())
         {
             string CourseCode = reader.GetString(0);
             string CA_MSM_TH = reader.GetString(2);
             string TH_ESM = reader.GetString(3);
             string TH_PMO = reader.GetString(4);
             string CA_MSM_PT = reader.GetString(5);
             string PT_ESM = reader.GetString(6);
             string PT_PMO = reader.GetString(7);
             string Total_PMO = reader.GetString(8);
             string Grade_Point = reader.GetString(9);
             string ER_CREDIT = reader.GetString(10);
             string Grade = reader.GetString(11);
             string Remarks = reader.GetString(12);
             string ExamType = reader.GetString(13);
             htmlStr += "<tr><td>" + CourseCode + "</td><td>" + CA_MSM_TH + "</td><td>" + TH_ESM + "</td><td>" + TH_PMO + "</td><td>" + CA_MSM_PT + "</td><td>" + PT_ESM + "</td><td>" + PT_PMO + "</td><td>" + Total_PMO + "</td><td>" + Grade_Point + "</td><td>" + ER_CREDIT + "</td><td>" + Grade + "</td><td>" + Remarks + "</td><td>" + ExamType + "</td></tr>";

         }

         sqlCon.Close();
         return htmlStr;
     } */
    DataSet dschildmarks = new DataSet();
    DataSet dsparentmarks = new DataSet();
    protected void BindGridview()
    {
        dschildmarks = null;
        dsparentmarks = null;
        object strtypecode = fn.singlevalue("Select StreamTypeCode From Stream Where StreamCode = '" + ddlprogram.SelectedValue + "'");
        if (strtypecode.ToString() == "01")
        {
            string querypart = "WHERE TRBtec.StreamPart = '" + Streampart.SelectedValue + "' AND TRBtec.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "'";
            if (txtrollno.Text.Trim() != "")
            {
                querypart = querypart + "AND TRBtec.UnivRollNo = '" + txtrollno.Text.Trim().ToString() + "'";
            }
            dsparentmarks = fn.SelectDataset("SELECT TRBTec.UnivRollNo, TRBTec.SubPaperCode, COURSEPAPERS.PaperAbbr, COURSEPAPERS.Credit, TRBTec.CA_MSM_TH, TRBTec.TH_ESM, TRBTec.TH_PMO, TRBTec.CA_MSM_PT, " +
                     " TRBTec.PT_ESM, TRBTec.PT_PMO, TRBTec.Total_PMO, TRBTec.Grade_Point, TRBTec.ER_CREDIT, TRBTec.Grade, TRBTec.Remarks, TRBTec.ExamType, " +
                     " TRBTec.ExamSession FROM TRBTec INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode " + querypart + " Order by TRBTec.UnivRollNo");
        }
        else
        {
            string querypart = "WHERE TRMtec.StreamPart = '" + Streampart.SelectedValue + "' AND TRMtec.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "'";
            if (txtrollno.Text.Trim() != "")
            {
                querypart = querypart + "AND TRMtec.UnivRollNo = '" + txtrollno.Text.Trim().ToString() + "'";
            }
            dsparentmarks = fn.SelectDataset("SELECT TRMTec.UnivRollNo, TRMTec.SubPaperCode, COURSEPAPERS.PaperAbbr, COURSEPAPERS.Credit, TRMTec.CA_MSM_TH, TRMTec.TH_ESM, TRMTec.TH_PMO, TRMTec.CA_MSM_PT, " +
                     " TRMTec.PT_ESM, TRMTec.PT_PMO, TRMTec.Total_PMO, TRMTec.Grade_Point, TRMTec.ER_CREDIT, TRMTec.Grade, TRMTec.Remarks, TRMTec.ExamType, " +
                     " TRMTec.ExamSession FROM TRMTec INNER JOIN COURSEPAPERS ON TRMTec.SubPaperCode = COURSEPAPERS.SubPaperCode " + querypart + " Order by TRMTec.UnivRollNo");
        }
        gvParentGrid.DataSource = dsparentmarks.Tables[0];
        gvParentGrid.DataBind();

    }
    // string querypart2 = "";
    protected void gvUserInfo_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            GridView gv = (GridView)e.Row.FindControl("gvChildGrid");
            string subpapercode = e.Row.Cells[2].Text.ToString();
            string univrollno = e.Row.Cells[1].Text.ToString();
            string Examsession = e.Row.Cells[14].Text.ToString();
            string examtype = e.Row.Cells[15].Text.ToString();
            if (examtype == "N")
            {
                dschildmarks = fn.SelectDataset("Select top(1) ClassTest1, ClassTest2, TH_Attendance, Midsem, PR_Attendance, " +
                    " PracticalRecord, PRClassPerfor, Prpreendsemviva From Exampaperdetail Where univrollno = '" + univrollno + "' " +
                    " and Subpapercode = '" + subpapercode + "' and (CAST(SUBSTRING(ExamSession,5,3)+ ExamYear AS DATETIME)) < '2014-12-01 00:00:00.000' order by CAST(SUBSTRING(ExamSession,5,3)+ ExamYear AS DATETIME) desc");
            }
            else
            {
                dschildmarks = fn.SelectDataset("SELECT EXAMPAPERDETAIL.ClassTest1, EXAMPAPERDETAIL.ClassTest2," +
                    "EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem,EXAMPAPERDETAIL.PR_Attendance," +
                    "EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor, EXAMPAPERDETAIL.Prpreendsemviva" +
                    " FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                    " WHERE COURSEPAPERS.SubPaperCode = '" + subpapercode + "' AND EXAMPAPERDETAIL.UnivrollNo = '" + univrollno + "' AND " +
                    " EXAMPAPERDETAIL.ExamSession = '" + Examsession + "'");
            }
            gv.DataSource = dschildmarks.Tables[0];
            gv.DataBind();
        }
    }
    protected void ddlprogram_SelectedIndexChanged(object sender, EventArgs e)
    {
        bindsemester();
    }

    private void bindsemester()
    {
        DataSet dssemester = new DataSet();
        object strtypecode = fn.singlevalue("Select StreamTypeCode From Stream Where StreamCode = '" + ddlprogram.SelectedValue + "'");
        if (strtypecode.ToString() == "01")
        {
            dssemester = fn.SelectDataset("SELECT Distinct STREAMPART.StreamPart, STREAMPART.StreamPartCode FROM cgpa INNER " +
                     " JOIN STREAMPART ON cgpa.StreamPart = STREAMPART.StreamPartCode WHERE STREAMPART.StreamCode = '" + ddlprogram.SelectedValue + "' order by STREAMPART.StreamPart");
        }
        else
        {
            dssemester = fn.SelectDataset("SELECT Distinct STREAMPART.StreamPart, STREAMPART.StreamPartCode FROM cgpa_Mtec INNER " +
                                " JOIN STREAMPART ON cgpa_Mtec.StreamPart = STREAMPART.StreamPartCode WHERE STREAMPART.StreamCode = '" + ddlprogram.SelectedValue + "' order by STREAMPART.StreamPart");
        }
        Streampart.DataSource = dssemester.Tables[0];
        Streampart.DataTextField = "StreamPart";
        Streampart.DataValueField = "StreamPartCode";
        Streampart.DataBind();
        Streampart.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void ddlexamsession_SelectedIndexChanged(object sender, EventArgs e)
    {
        bindprogram();
    }
    string sqlpart = "";
    private void bindprogram()
    {
        if (Session["Role"].ToString() == "13")
        {
            sqlpart = " AND (HODSettings.UserID = '" + Session["UserId"].ToString() + "')";
        }
        else
        {
            sqlpart = "";
        }
        DataSet dsstream = fn.SelectDataset("WITH cte AS (SELECT StreamCode, StreamPart, ExamSession FROM TRBTec UNION SELECT StreamCode, StreamPart, " +
            " ExamSession FROM TRMTec) SELECT DISTINCT STREAM.StreamAbbr, STREAM.StreamCode FROM cte AS cte_1 INNER JOIN STREAM ON " +
            " cte_1.StreamCode = STREAM.StreamCode LEFT OUTER JOIN HODSettings ON STREAM.StreamCode = HODSettings.StreamCode WHERE " +
            " cte_1.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "'" + sqlpart + " ORDER BY STREAM.StreamCode");
        ddlprogram.DataSource = dsstream.Tables[0];
        ddlprogram.DataTextField = "StreamAbbr";
        ddlprogram.DataValueField = "StreamCode";
        ddlprogram.DataBind();
        ddlprogram.Items.Insert(0, new ListItem("--Select--", "0"));

    }

    string query;
    protected void exportinexcel_Click(object sender, EventArgs e)
    {
        object strtypecode = fn.singlevalue("Select StreamTypeCode From Stream Where StreamCode = '" + ddlprogram.SelectedValue + "'");
        if (strtypecode.ToString() == "01")
        {
            if (Streampart.SelectedValue.ToString() == "0")
            {
                query = " SELECT a.StreamAbbr, COURSEPAPERS.STREAMPART as Semester, EXAMPAPERDETAIL.UnivRollNo, COURSEPAPERS.PaperAbbr,COURSEPAPERS.PaperName,b.TheoryTotalCl AS totalTheoryCls,b.TheoryAttendance,b.ThMedRelaxation, EXAMPAPERDETAIL.ClassTest1, EXAMPAPERDETAIL.ClassTest2, " +
                           " EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, TRBTec.CA_MSM_TH, TRBTec.TH_ESM, TRBTec.TH_PMO,b.PracticalTotalCl as totalPracticalCls,b.PracticalAttendance,b.PrMedRelaxation,  EXAMPAPERDETAIL.PR_Attendance, " +
                            " EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor, EXAMPAPERDETAIL.Prpreendsemviva, TRBTec.CA_MSM_PT, TRBTec.PT_ESM, " +
                            " TRBTec.PT_PMO, TRBTec.Total_PMO,b.status as AttendanceStatus, TRBTec.Grade_Point, TRBTec.ER_CREDIT, TRBTec.Grade, TRBTec.ExamType, TRBTec.ExamSession " +
                            " FROM EXAMPAPERDETAIL INNER JOIN TRBTec ON EXAMPAPERDETAIL.RegNo = TRBTec.RegNo AND EXAMPAPERDETAIL.SubPaperCode = TRBTec.SubPaperCode AND " +
                            " EXAMPAPERDETAIL.ExamSession = TRBTec.ExamSession INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                            " inner join STREAM a on COURSEPAPERS.StreamCode=a.StreamCode " +
                            " left join Attendance b on EXAMPAPERDETAIL.SubPaperCode=b.SubPaperCode and b.RegNo=EXAMPAPERDETAIL.RegNo " +
                            " and b.ExamSession=EXAMPAPERDETAIL.ExamSession " +
                            " WHERE TRBTec.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "'";
            }
            else
            {
                query = " SELECT a.StreamAbbr as program, COURSEPAPERS.STREAMPART as Semester, EXAMPAPERDETAIL.UnivRollNo, COURSEPAPERS.PaperAbbr,COURSEPAPERS.PaperName,b.TheoryTotalCl AS totalTheoryCls,b.TheoryAttendance,b.ThMedRelaxation, EXAMPAPERDETAIL.ClassTest1, EXAMPAPERDETAIL.ClassTest2, " +
                           " EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, TRBTec.CA_MSM_TH, TRBTec.TH_ESM, TRBTec.TH_PMO,b.PracticalTotalCl as totalPracticalCls,b.PracticalAttendance,b.PrMedRelaxation,  EXAMPAPERDETAIL.PR_Attendance, " +
                            " EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor, EXAMPAPERDETAIL.Prpreendsemviva, TRBTec.CA_MSM_PT, TRBTec.PT_ESM, " +
                            " TRBTec.PT_PMO, TRBTec.Total_PMO,b.status as AttendanceStatus, TRBTec.Grade_Point, TRBTec.ER_CREDIT, TRBTec.Grade, TRBTec.ExamType, TRBTec.ExamSession " +
                            " FROM EXAMPAPERDETAIL INNER JOIN TRBTec ON EXAMPAPERDETAIL.RegNo = TRBTec.RegNo AND EXAMPAPERDETAIL.SubPaperCode = TRBTec.SubPaperCode AND " +
                            " EXAMPAPERDETAIL.ExamSession = TRBTec.ExamSession INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                            " inner join STREAM a on COURSEPAPERS.StreamCode=a.StreamCode " +
                            " left join Attendance b on EXAMPAPERDETAIL.SubPaperCode=b.SubPaperCode and b.RegNo=EXAMPAPERDETAIL.RegNo " +
                            " and b.ExamSession=EXAMPAPERDETAIL.ExamSession WHERE TRBTec.StreamPart = '" + Streampart.SelectedValue + "' AND " +
                    " TRBTec.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "'";
            }
        }
        else if (strtypecode.ToString() == "02")
        {
            if (Streampart.SelectedValue.ToString() == "0")
            {
                query =    " SELECT a.StreamAbbr as program, COURSEPAPERS.STREAMPART as Semester,EXAMPAPERDETAIL.UnivRollNo, COURSEPAPERS.PaperAbbr,COURSEPAPERS.PaperName,b.TheoryTotalCl AS totalTheoryCls,b.TheoryAttendance,b.ThMedRelaxation,  EXAMPAPERDETAIL.ClassTest1, EXAMPAPERDETAIL.ClassTest2, "+
                           " EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, TRMTec.CA_MSM_TH, TRMTec.TH_ESM, TRMTec.TH_PMO,b.PracticalTotalCl as totalPracticalCls,b.PracticalAttendance,b.PrMedRelaxation,  EXAMPAPERDETAIL.PR_Attendance, "+
                          " EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor, EXAMPAPERDETAIL.Prpreendsemviva, TRMTec.CA_MSM_PT, TRMTec.PT_ESM, "+
                          " TRMTec.PT_PMO, TRMTec.Total_PMO,b.status AS AttendanceStatus,  TRMTec.Grade_Point, TRMTec.ER_CREDIT, TRMTec.Grade, TRMTec.ExamType, TRMTec.ExamSession "+
                            " FROM EXAMPAPERDETAIL INNER JOIN TRMTec ON EXAMPAPERDETAIL.RegNo = TRMTec.RegNo AND EXAMPAPERDETAIL.StreamPartCode = TRMTec.StreamPart AND "+
                            " EXAMPAPERDETAIL.ExamSession = TRMTec.ExamSession INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode "+
                            " AND TRMTec.SubPaperCode = COURSEPAPERS.SubPaperCode "+
                            " inner join STREAM a on COURSEPAPERS.StreamCode=a.StreamCode "+
                            " left join Attendance b on EXAMPAPERDETAIL.SubPaperCode=b.SubPaperCode and b.RegNo=EXAMPAPERDETAIL.RegNo "+
                            " and b.ExamSession=EXAMPAPERDETAIL.ExamSession "+
                            " WHERE TRMTec.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "'";
            }
            else
            {
                query = " SELECT a.StreamAbbr as program, COURSEPAPERS.STREAMPART as Semester,EXAMPAPERDETAIL.UnivRollNo, COURSEPAPERS.PaperAbbr,COURSEPAPERS.PaperName,b.TheoryTotalCl AS totalTheoryCls,b.TheoryAttendance,b.ThMedRelaxation,  EXAMPAPERDETAIL.ClassTest1, EXAMPAPERDETAIL.ClassTest2, " +
                           " EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.Midsem, TRMTec.CA_MSM_TH, TRMTec.TH_ESM, TRMTec.TH_PMO,b.PracticalTotalCl as totalPracticalCls,b.PracticalAttendance,b.PrMedRelaxation,  EXAMPAPERDETAIL.PR_Attendance, "+
                          " EXAMPAPERDETAIL.PracticalRecord, EXAMPAPERDETAIL.PRClassPerfor, EXAMPAPERDETAIL.Prpreendsemviva, TRMTec.CA_MSM_PT, TRMTec.PT_ESM, "+
                          " TRMTec.PT_PMO, TRMTec.Total_PMO,b.status AS AttendanceStatus,  TRMTec.Grade_Point, TRMTec.ER_CREDIT, TRMTec.Grade, TRMTec.ExamType, TRMTec.ExamSession "+
                            " FROM EXAMPAPERDETAIL INNER JOIN TRMTec ON EXAMPAPERDETAIL.RegNo = TRMTec.RegNo AND EXAMPAPERDETAIL.StreamPartCode = TRMTec.StreamPart AND "+
                            " EXAMPAPERDETAIL.ExamSession = TRMTec.ExamSession INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode "+
                            " AND TRMTec.SubPaperCode = COURSEPAPERS.SubPaperCode "+
                            " inner join STREAM a on COURSEPAPERS.StreamCode=a.StreamCode "+
                            " left join Attendance b on EXAMPAPERDETAIL.SubPaperCode=b.SubPaperCode and b.RegNo=EXAMPAPERDETAIL.RegNo "+
                            " and b.ExamSession=EXAMPAPERDETAIL.ExamSession  WHERE TRMTec.StreamPart = '" + Streampart.SelectedValue + "' AND " +
                    " TRMTec.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "'";
            }
        }
        DataSet dsexportexcel = fn.SelectDataset(query);
        if (dsexportexcel.Tables[0].Rows.Count > 0)
        {
            //Create a dummy GridView
            GridView GridView1 = new GridView();
            GridView1.AllowPaging = false;
            GridView1.DataSource = dsexportexcel.Tables[0];
            GridView1.DataBind();
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=Student_Marks_Data_" + DateTime.Now.Date + ".xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                //Apply text style to each Row
                GridView1.Rows[i].Attributes.Add("class", "textmode");

            }
            GridView1.RenderControl(hw);
            //style to format numbers to string
            string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }

}
