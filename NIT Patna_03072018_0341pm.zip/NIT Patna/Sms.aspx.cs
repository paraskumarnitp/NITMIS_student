using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using CrystalDecisions.CrystalReports.Engine;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;


public partial class Sms : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    DataTable dttrbtec;
    bool Check = false;
    DSTRBtec dstrrecord = new DSTRBtec();
    string papertype = "";
    int trcount;
    int yrvalue = 0;
    string prexamdate = "";
    EmailService es = new EmailService();


    DataSet dsstudentreginfo; DataSet dsstudentregnc;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //Panel1.Visible = true;
            try
            {

                if ((Session["Role"].ToString() != "14") && (Session["Role"].ToString() != "4"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
                if (Session["Role"].ToString() == "7")
                {
                   // BtnGenerate.Visible = false;

                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();

            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College where collcode in (select distinct collcode from exam) order by CollName", "CollName", "CollCode");
            popddl.Popualate(ExamYear, "Exam", "Select distinct ExamYear from Exam order by ExamYear", "ExamYear", "ExamYear");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from stream) order by StreamAbbr", "StreamAbbr", "StreamCode");
            Examsession.Items.Insert(0, new ListItem("--Select--", "0"));
            ExamYear.Items.Insert(0, new ListItem("--Select--", "0"));
            StreamCode.Items.Insert(0, new ListItem("--ALL--","0"));
            CourseValue();
            pnlSingle.Visible = false;
            



        }
    }
    

    // Generate Button.....
    DataTable dtpaperc = new DataTable();
 
    
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        CourseValue();
        bindddlcoursespl();
    }
    protected void CourseValue()
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart, StreamPartCode from StreamPart where streamcode='" + StreamCode.SelectedValue + "' and streampartcode in (select distinct streampartcode from streampart) order by StreamPartCode", "StreamPart", "StreamPartCode");
        StreamPart.Items.Insert(0, new ListItem("--ALL--", "0"));
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");


    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }
    protected void btnTrprint_Click(object sender, EventArgs e)
    {
        string grprint = "";


        //string examsession = "";//(SUBSTRING(ExamSession,10,4) = '" + ExamYear.SelectedItem + "') and
        //DataSet dsexamsession = fnrev.SelectDataset("Select ExamSession from AssignCoursePaper Where SUBSTRING(ExamSession,9,4)='" + ExamYear.SelectedItem + "' and Semester ='" + StreamPart.SelectedItem + "'");
        //if (dsexamsession.Tables[0].Rows.Count > 0)
        //    examsession = dsexamsession.Tables[0].Rows[0]["ExamSession"].ToString();
        //else examsession = "";

        //Response.Redirect("TRBTecPrint.aspx?sc=" + StreamCode.SelectedValue + "&spc=" + StreamPart.SelectedValue + "&ey=" + ExamYear.SelectedItem + "&prg=" + StreamCode.SelectedItem + "&sem=" + StreamPart.SelectedItem + "&exses=" + Examsession.SelectedItem.ToString() + "&splc=" + Splcode.SelectedValue + "&spart=" + StreamPart.SelectedItem.ToString() + "&grp=" + grprint);
        //ReportDocument crystalReport = new ReportDocument();
        //filldatatable();

        //crystalReport.Load(Server.MapPath("~/Report/TrbtecPrint.rpt"));

        //dstrrecord.Tables[0].Merge(dttrbtec);
        //crystalReport.SetDataSource(dstrrecord);
        //CR.ReportSource = crystalReport;
        //Panel1.Visible = true;
    }
    protected void bindddlcoursespl()
    {
        Functionreviseed appfn = new Functionreviseed();
        DataSet dscrsespl = appfn.SelectDataset(" SELECT Stream_Specialization.StreamCode, Stream_Specialization.SplCode, " +
            " CourseSpecialization.SpDescription, CourseSpecialization.Spvalue, CourseSpecialization.SPCode FROM Stream_Specialization " +
            " INNER JOIN CourseSpecialization ON Stream_Specialization.SplCode = CourseSpecialization.SPCode WHERE Stream_Specialization.StreamCode = " +
            "'" + StreamCode.SelectedValue + "'");
        if (dscrsespl.Tables[0].Rows.Count > 0)
        {
            Splcode.Items.Clear();
            Splcode.DataSource = dscrsespl.Tables[0];
            Splcode.DataTextField = "SPCode";
            Splcode.DataValueField = "SPCode";
            Splcode.DataBind();
            Splcode.Items.Insert(0, "--Select--");
        }
        else
        {
            Splcode.Items.Clear();
            Splcode.Items.Insert(0, "NA");
        }
    }
    protected void ExamYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(Examsession, "ExamPaperdetail", "Select Distinct ExamSession From EXAMPAPERDETAIL Where ExamYear = '" + ExamYear.SelectedItem.ToString() + "'", "ExamSession", "ExamSession");
    }
    
    protected void rdSingle_CheckedChanged(object sender, EventArgs e)
    {
        if (rdSingle.Checked)
        {
            Panel3.Visible = false;
            pnlSingle.Visible = true;
        }
        else
        {
            Panel3.Visible = true;
            pnlSingle.Visible = false;
        }
    }
    protected void rdGroup_CheckedChanged(object sender, EventArgs e)
    {
        
    }
    protected void rdGroup_CheckedChanged1(object sender, EventArgs e)
    {
        Panel3.Visible = true;
        pnlSingle.Visible = false;
    }

    int sendSMS(string numbers, string message,int mode)
    {
        int totalSend = 0;
        if (mode == 1)
        {
           
            string mobileNo = "";
            string[] mobileNos = numbers.Split(',');
            try
            {
                for (int i = 0; i < mobileNos.Length; i++)
                {
                    mobileNo = mobileNos[i].Trim();

                    if ((!string.IsNullOrEmpty(mobileNo)) && mobileNo.Length == 10)
                    {
                        string tmpurl = @"http://sms.smvinfotech.com/rest/services/sendSMS/sendGroupSms?AUTH_KEY="
                              + Server.UrlEncode("94e53c428eda2f833ab232cbfca86f1") + "&message="
                              + Server.UrlEncode(message) + "&senderId="
                              + Server.UrlEncode("NITPAT") + "&routeId="
                              + Server.UrlEncode("1") + "&mobileNos="
                              + Server.UrlEncode(mobileNo) + "&smsContentType="
                              + Server.UrlEncode("english");




                        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(tmpurl);//
                        request.Method = "Get";
                        request.KeepAlive = true;

                        HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                        string myResponse = "";
                        using (System.IO.StreamReader sr = new System.IO.StreamReader(response.GetResponseStream()))
                        {
                            myResponse = sr.ReadToEnd();
                            if (myResponse.Contains("3001"))
                                totalSend++;
                        }

                    }
                }

            }
            catch (Exception esms)
            {
                LblMsg.Text = "";
            }
        }
        else
        {
            int candCount = 0;
            string  tmpSqlStm;

            try
            {
                
                                      UnivService.Service1 NicService = new UnivService.Service1();

                if (StreamCode.SelectedValue == "0")
                {
                    tmpSqlStm = "SELECT  REGISTRATION.ApplicantName,REGISTRATION.AckNo,REGISTRATION.EmailId,REGISTRATION.ContactNo  FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
                                " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND EXAM.ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND REGISTRATION.ContactNo IS NOT NULL  ";

                }
                else if(StreamPart.SelectedValue=="0")
                {
                tmpSqlStm = "SELECT  REGISTRATION.ApplicantName,REGISTRATION.AckNo,REGISTRATION.EmailId,REGISTRATION.ContactNo  FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
                             " Exam.StreamCode='" + StreamCode.SelectedValue + "'  and " +
                             " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND EXAM.ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND REGISTRATION.ContactNo IS NOT NULL  ";

                }
                else
                {
                    tmpSqlStm = "SELECT  REGISTRATION.ApplicantName,REGISTRATION.AckNo,REGISTRATION.EmailId,REGISTRATION.ContactNo  FROM EXAM INNER JOIN REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo Where " +
                             " Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "'  and " +
                             " Exam.ExamYear='" + ExamYear.SelectedValue + "' AND EXAM.ExamSession = '" + Examsession.SelectedItem.ToString() + "' AND REGISTRATION.ContactNo IS NOT NULL  ";

                }
                dsstudentreginfo = fnrev.SelectDataset(tmpSqlStm);


                candCount = dsstudentreginfo.Tables[0].Rows.Count;
                if (candCount > 0)
                {
                    for (int i = 0; i < dsstudentreginfo.Tables[0].Rows.Count; i++)
                    {
                         string mobileNo = "";
                         mobileNo = dsstudentreginfo.Tables[0].Rows[i]["ContactNo"].ToString();
                        if ((!string.IsNullOrEmpty(mobileNo)) && mobileNo.Length == 10)
                        {
                            string tmpurl = @"http://sms.smvinfotech.com/rest/services/sendSMS/sendGroupSms?AUTH_KEY="
                           + Server.UrlEncode("94e53c428eda2f833ab232cbfca86f1") + "&message="
                           + Server.UrlEncode(message) + "&senderId="
                           + Server.UrlEncode("NITPAT") + "&routeId="
                           + Server.UrlEncode("1") + "&mobileNos="
                           + Server.UrlEncode(mobileNo) + "&smsContentType="
                           + Server.UrlEncode("english");


                            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(tmpurl);//
                            request.Method = "Get";
                            request.KeepAlive = true;

                            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                            string myResponse = "";
                            using (System.IO.StreamReader sr = new System.IO.StreamReader(response.GetResponseStream()))
                            {
                                myResponse = sr.ReadToEnd();
                                if (myResponse.Contains("3001"))
                                    totalSend++;
                            }

                        }
                    }
                }
            }catch(Exception eSMSG){}
        }
        return (totalSend);


    }
    protected void btnSMS_Click(object sender, EventArgs e)
    {

        if (rdSingle.Checked)
        {

            LblMsg.Text = "Message Sending....";
            sendSMS(txtbox1.Text.Trim(), txtMessage.Text.Trim(),1);

            LblMsg.Text = "Message Sending Complete";
        }
        else if (rdGroup.Checked)
        {

            LblMsg.Text = "Message Sending....";
           if( sendSMS("", txtMessage.Text.Trim(), 2)>0)
            LblMsg.Text = "Message Sending  Complete";
           else
            LblMsg.Text = "Record Not Found!!!";
                                //int InsRec = fnrev.InsertUpdateDelete("INSERT INTO EmailRecords(RecipintEmailId, Subject, Status, SentTime, UserId) " +
                                //    " VALUES('" + tmpEmail + "','" + msgSubject + "','SENT',GETDATE(),'" + Session["UserId"].ToString() + "')");
                                //mailCount++;
                           

                    

        }
     
    }
}

