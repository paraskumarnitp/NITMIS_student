using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class StudentHistory : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "14") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "12") && (Session["Role"].ToString() != "10"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }
            }
            catch
            {
                Response.Redirect("default.aspx");
            }

        }
    }  

    private void bindRegistrations(string RegNo)
    {
        gvRedg.DataSource = GetData("SELECT EXAM.RegNo, EXAM.UnivRollNo, EXAM.ExamSession, EXAM.ExamFeeAmt, EXAM.PaymentId, replace(convert(NVARCHAR, EXAM.PaymentDate, 106), ' ', '/') AS PaymentDate, " + 
            " EXAM.ExamFormNo, EXAM.ModeOfPayment, EXAM.Bank, STREAMPART.StreamPart, EXAM.UserId, EXAM.StreamPartCode FROM EXAM INNER JOIN " + 
            " STREAMPART ON EXAM.StreamPartCode = STREAMPART.StreamPartCode WHERE (EXAM.RegNo = '"+RegNo+"') order by SUBSTRING(ExamSession,9,4) DESC");
        gvRedg.DataBind();
    }

    private static DataTable GetData(string query)
    {
        string strConnString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        using (SqlConnection con = new SqlConnection(strConnString))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = query;
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    using (DataSet ds = new DataSet())
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        return dt;
                    }
                }
            }
        }
    }
    protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
    {        
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string streampart = gvRedg.DataKeys[e.Row.RowIndex].Values[1].ToString();
            string regno = gvRedg.DataKeys[e.Row.RowIndex].Values[0].ToString();
            string ExamSession = e.Row.Cells[4].Text;
            GridView gvsubjects = e.Row.FindControl("gvsubjects") as GridView;
            gvsubjects.DataSource = GetData(string.Format("SELECT COURSEPAPERS.PaperAbbr, EXAMPAPERDETAIL.PaperType, EXAMPAPERDETAIL.IsAppeared, " + 
                " EXAMPAPERDETAIL.StudentStatus, EXAMPAPERDETAIL.ClassTest1, EXAMPAPERDETAIL.ClassTest2, EXAMPAPERDETAIL.TH_Attendance, " + 
                " EXAMPAPERDETAIL.Midsem, EXAMPAPERDETAIL.THEndsem, EXAMPAPERDETAIL.PR_Attendance, EXAMPAPERDETAIL.PracticalRecord, " + 
                " EXAMPAPERDETAIL.PRClassPerfor, EXAMPAPERDETAIL.PREndSem, EXAMPAPERDETAIL.Prpreendsemviva, EXAMPAPERDETAIL.UMCode, " + 
                " EXAMPAPERDETAIL.ExamType FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                " WHERE (EXAMPAPERDETAIL.ExamSession = '" + ExamSession + "') AND (EXAMPAPERDETAIL.RegNo = '" + regno + "') AND (EXAMPAPERDETAIL.StreamPartCode = '" + streampart + "')"));
            gvsubjects.DataBind();
        }
    }
    protected void btngetdetails_Click(object sender, EventArgs e)
    {
        
        object RegNo = fnrev.singlevalue("SELECT Regno FROM REGISTRATION WHERE TempRollno = '"+txtrollno.Text.Trim().ToString()+"'");
        if (RegNo != null)
        {
            bindRegistrations(RegNo.ToString());
            bindbasicdetails(RegNo.ToString());
            object StreamTypeCode = fnrev.singlevalue("SELECT STREAM.StreamTypeCode FROM REGISTRATION INNER JOIN STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode WHERE (REGISTRATION.RegNo = '" + RegNo + "')");
            if (StreamTypeCode != null)
                bindTRMarks(RegNo.ToString(), StreamTypeCode.ToString());

            display1.Visible = true;
            display2.Visible = true;
            display3.Visible = true;
        }
        else
        {
            lblmsg.Text = "Invalid Roll No Entered.";
            display1.Visible = false;
            display2.Visible = false;
            display3.Visible = false;
        }        
    }

    string query ="";
    private void bindTRMarks(string RegNo, string streamTypeCode)
    {
        if (streamTypeCode == "01")
        {
            query = "WITH cte AS (SELECT DISTINCT TRBTec.UnivRollNo, STREAMPART.StreamPart,TRBTec.ExamSession,TRBTec.RegNo, STREAMPART.StreamPartCode, STREAM.StreamTypeCode FROM TRBTec INNER JOIN " +
                " STREAMPART ON TRBTec.StreamPart = STREAMPART.StreamPartCode INNER JOIN STREAM ON TRBTec.StreamCode = STREAM.StreamCode WHERE (TRBTec.RegNo = '" + RegNo + "') AND (TRBTec.Is_active = 'Y')) " +
                " SELECT UnivRollNo, StreamPart, ExamSession, RegNo, StreamPartCode,StreamTypeCode FROM cte ORDER BY StreamPartCode DESC";
        }
        else
        {
            query = "WITH cte As (SELECT DISTINCT TRMTec.UnivRollNo, STREAMPART.StreamPart,TRMTec.ExamSession, TRMTec.RegNo, STREAMPART.StreamPartCode, STREAM.StreamTypeCode FROM TRMTec INNER JOIN " +
                           " STREAMPART ON TRMTec.StreamPart = STREAMPART.StreamPartCode INNER JOIN STREAM ON TRMTec.StreamCode = STREAM.StreamCode WHERE (TRMTec.RegNo = '" + RegNo + "') AND (TRMTec.Is_active = 'Y'))" +
                           " SELECT UnivRollNo, StreamPart, ExamSession, RegNo, StreamPartCode,StreamTypeCode FROM cte ORDER BY StreamPartCode DESC";
        }
        gvtr.DataSource = GetData(query);
        gvtr.DataBind();
    }
    string childquery = "";
    protected void gvtr_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string streampart = gvtr.DataKeys[e.Row.RowIndex].Values[1].ToString();
            string regno = gvtr.DataKeys[e.Row.RowIndex].Values[0].ToString();
            string strpartcode = gvtr.DataKeys[e.Row.RowIndex].Values[2].ToString();
            string ExamSession = e.Row.Cells[3].Text;
            if (strpartcode == "01")
            {
                childquery = "SELECT TRBTec.CA_MSM_TH, TRBTec.TH_ESM, TRBTec.TH_PMO, TRBTec.CA_MSM_PT, " +
                " TRBTec.PT_ESM, TRBTec.PT_PMO, TRBTec.Total_PMO, TRBTec.Grade_Point * COURSEPAPERS.Credit AS Grade_Point, COURSEPAPERS.Credit AS ER_CREDIT, TRBTec.Grade, TRBTec.ExamType, " +
                " COURSEPAPERS.PaperAbbr FROM TRBTec INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                " (TRBTec.RegNo = '" + regno + "') AND (TRBTec.ExamSession = '" + ExamSession + "') AND (TRBTec.StreamPart = '" + streampart + "')";
            }
            else
            {
                childquery = "SELECT TRMTec.CA_MSM_TH, TRMTec.TH_ESM, TRMTec.TH_PMO, TRMTec.CA_MSM_PT, " +
                " TRMTec.PT_ESM, TRMTec.PT_PMO, TRMTec.Total_PMO,  TRMTec.Grade_Point * COURSEPAPERS.Credit AS Grade_Point, COURSEPAPERS.Credit AS ER_CREDIT, TRMTec.Grade, TRMTec.ExamType, " +
                " COURSEPAPERS.PaperAbbr FROM TRMTec INNER JOIN COURSEPAPERS ON TRMTec.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                " (TRMTec.RegNo = '" + regno + "') AND (TRMTec.ExamSession = '" + ExamSession + "') AND (TRMTec.StreamPart = '" + streampart + "')";
            }
            GridView gvsubjects1 = e.Row.FindControl("gvsubjects1") as GridView;
            gvsubjects1.DataSource = GetData(childquery);
            gvsubjects1.DataBind();
        }
    }

    private void bindbasicdetails(string regno)
    {
        DataTable dtbasic = fnrev.SelectDatatable("SELECT REGISTRATION.ApplicantName, REGISTRATION.AckNo, REGISTRATION.CourseSession, CourseSpecialization.SpDescription, REGISTRATION.AdhaarNo, REGISTRATION.AdmFormNo, " +
                     " REGISTRATION.AdmissionDate, REGISTRATION.FatherName, REGISTRATION.MotherName, replace(convert(NVARCHAR, REGISTRATION.DOB, 106), ' ', '/') AS DOB, Religion.Religion, REGISTRATION.Gender, REGISTRATION.MaritalStatus, " +
                     " NATIONALITY.Nationality, REGISTRATION.BloodGroup, REGISTRATION.EmailId, REGISTRATION.ContactNo, REGISTRATION.AdmFeeAmt, REGISTRATION.PermanentAddress1, " +
                     " REGISTRATION.PermanentAddress2, DISTRICT_1.DistName, REGISTRATION.PermanentPinCode, REGISTRATION.PresentAddress1, REGISTRATION.PresentAddress2, DISTRICT.DistName AS Expr1, " +
                     " REGISTRATION.PresentPinCode, STREAM.StreamAbbr, State.state, State_1.state AS mailingstate, CATEGORY.Category " +
                     " FROM State AS State_1 INNER JOIN DISTRICT AS DISTRICT_1 ON State_1.StateCode = DISTRICT_1.StateCode RIGHT OUTER JOIN DISTRICT INNER JOIN State ON " + 
                     " DISTRICT.StateCode = State.StateCode RIGHT OUTER JOIN REGISTRATION ON DISTRICT.DistCode = REGISTRATION.PresentDistrictCode LEFT OUTER JOIN STREAM ON " + 
                     " REGISTRATION.StreamCode = STREAM.StreamCode ON DISTRICT_1.DistCode = REGISTRATION.PermanentDistCode LEFT OUTER JOIN NATIONALITY ON REGISTRATION.NationalityCode = NATIONALITY.NationalityCode " +
                     " LEFT OUTER JOIN Religion ON REGISTRATION.ReligionCode = Religion.ReligionCode LEFT OUTER JOIN CourseSpecialization ON REGISTRATION.SplCode = CourseSpecialization.SPCode " + 
                     " LEFT OUTER JOIN CATEGORY on REGISTRATION.CastCode = CATEGORY.CategoryCode WHERE (REGISTRATION.RegNo = '"+regno+"')");
        if (dtbasic.Rows.Count > 0)
        {
            branch.Text = dtbasic.Rows[0]["StreamAbbr"].ToString();
            applicantname.Text = dtbasic.Rows[0]["ApplicantName"].ToString();
            enrollmentno.Text = dtbasic.Rows[0]["AckNo"].ToString();
            coursesession.Text = dtbasic.Rows[0]["CourseSession"].ToString();
            specialization.Text = dtbasic.Rows[0]["SpDescription"].ToString();
            adhaarno.Text = dtbasic.Rows[0]["AdhaarNo"].ToString();
            category.Text = dtbasic.Rows[0]["Category"].ToString();
            admissionform.Text = dtbasic.Rows[0]["AdmFormNo"].ToString();
            admissiondate.Text = dtbasic.Rows[0]["AdmissionDate"].ToString();
            fathername.Text = dtbasic.Rows[0]["FatherName"].ToString();
            mothername.Text = dtbasic.Rows[0]["MotherName"].ToString();
            dob.Text = dtbasic.Rows[0]["DOB"].ToString();
            Religion.Text = dtbasic.Rows[0]["Religion"].ToString();
            Gender.Text = dtbasic.Rows[0]["Gender"].ToString();
            maritalstatus.Text = dtbasic.Rows[0]["MaritalStatus"].ToString();
            nationality.Text = dtbasic.Rows[0]["Nationality"].ToString();
            bloodgroup.Text = dtbasic.Rows[0]["BloodGroup"].ToString();
            emailid.Text = dtbasic.Rows[0]["EmailId"].ToString();
            contactno.Text = dtbasic.Rows[0]["ContactNo"].ToString();
            permanentadd.Text = dtbasic.Rows[0]["PermanentAddress1"].ToString() + dtbasic.Rows[0]["PermanentAddress2"].ToString() + "\n" + dtbasic.Rows[0]["DistName"].ToString() + "\n" + dtbasic.Rows[0]["state"].ToString() + "\n" + dtbasic.Rows[0]["PermanentPinCode"].ToString();
            mailingAddress.Text = dtbasic.Rows[0]["PresentAddress1"].ToString() + dtbasic.Rows[0]["PresentAddress2"].ToString() + "\n" + dtbasic.Rows[0]["Expr1"].ToString() + "\n" + dtbasic.Rows[0]["mailingstate"].ToString() + "\n" + dtbasic.Rows[0]["PresentPinCode"].ToString();
            admissionfee.Text = dtbasic.Rows[0]["AdmFeeAmt"].ToString();
            studimage.ImageUrl = "~/ImageHandler.aspx?AckNo=" + dtbasic.Rows[0]["AckNo"].ToString();
            studimage.DataBind();
        }
    }
}
