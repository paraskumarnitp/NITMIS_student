using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class MapCodeRoll : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "3")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
                ViewState.Add("EditMode", "false");
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }


           
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //SqlCommand SqlCmd = new SqlCommand();
        //SqlConnection SqlCon = new SqlConnection();
        //SqlCon.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        //SqlCon.Open();
        //SqlCmd.Connection = SqlCon;
        //SqlCmd.CommandType = CommandType.StoredProcedure;
        //SqlCmd.CommandText = "MapCodeRoll";
        //int i = SqlCmd.ExecuteNonQuery();
        //if (i > 0)
        //{
        //    string msg = " Mapping is done successfully";
        //    string popupScript = "<script language='javascript'>" +
        //                       " alert('Mapping is done successfully ')" +
        //                        "</script>";
        //    Page.RegisterStartupScript("PopupScript", popupScript);

        //}
        //else
        //{
        //    string popupScript = "<script language='javascript'>" +
        //                        " alert('Error ocurred in processing...... ')" +
        //                         "</script>";
        //    Page.RegisterStartupScript("PopupScript", popupScript);
        //}
        //SqlCon.Close();
        //SqlCon.Dispose();
        //SqlCmd.Dispose();
    }



    protected void MapOldCode_Click(object sender, EventArgs e)
    {

    }
}
