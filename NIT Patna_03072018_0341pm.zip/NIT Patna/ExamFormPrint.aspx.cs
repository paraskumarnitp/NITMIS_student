using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using CrystalDecisions.CrystalReports.Engine;
public partial class ExamFormPrint : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    PopulateDDL popddl = new PopulateDDL();

    ReportDocument crystalreport = new ReportDocument();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "4" && Session["Role"].ToString() != "10")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

          


            //popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College where collcode in (select distinct collcode from TRHons) order by CollName", "CollName", "CollCode");
            popddl.Popualate(ExamSession, "ExamSession", "Select Distinct ExamSession from ExamPaperDetail", "ExamSession", "ExamSession");
            ExamSession.Items.Insert(0,new ListItem("--SELECT--", "0"));
            //popddl.Popualate(ExamYear, "Exam", "Select distinct ExamYear from Exam order by ExamYear", "ExamYear", "ExamYear");
           
            // popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from TRHons) order by StreamAbbr", "StreamAbbr", "StreamCode");


        }
    }

    

  
    //    
    //}
   


    
}