using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class RollDetailsUpdate : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "5")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }

                AckNo.Focus();
                //ViewState.Add("EditMode", "false");
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
        }
    }

    protected void BtnSave_Click(object sender, EventArgs e)
    {
        try
        {



            UnivService.Service1 ss = new UnivService.Service1();
            string UpdateRoll = ss.GetNewCode("Update RollBackDetails set OldRollNo='" + OldRoll.Text.Trim()+ "'   where AckNo=" + AckNo.Text);
            //if (UpdateRoll == "ok")
            //{
                LblMsg2.Text = "Successfully Updated. Ackno - " +AckNo.Text + " - Roll-" +OldRoll.Text ;
            //}
            //else
            //{
            //    LblMsg2.Text = "Error in saving";
            //}
                AckNo.Text = "";
                OldRoll.Text = "";
                AckNo.Focus();

        }
        catch (Exception ex)
        {
            LblMsg2.Text = "Error";
        }
    }
    protected void btnOk_Click(object sender, EventArgs e)
    {
        try
        {
            UnivService.Service1 ss = new UnivService.Service1();
            OldRoll.Text = ss.GetNewCode("SELECT OldRollNo from RollBackDetails where AckNo=" + AckNo.Text);
            if (OldRoll.Text == "error")
            {
                OldRoll.Text = "";
                LblMsg2.Text = "Please check Ack No.";
                AckNo.Focus();
            }
            else
            {
                OldRoll.Focus();
            }

        }
        catch (Exception ex)
        {
            LblMsg2.Text = "Error";
        }
    }
}
