using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class RollDetailsView : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "5")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");

        }
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }

    }
    protected void BtnView_Click(object sender, EventArgs e)
    {
        BindGrid();
       
    }


    protected void BindGrid()
    {
        string sql = "select R.ackno AS [SID],oldrollNo AS [OROLL],R.RegNo AS [REG],E.UnivRollNo AS [NROLL],R.ApplicantName AS [NAME] from rollbackdetails B,Registration R left outer join Exam E on R.Regno=E.Regno where B.ackno=R.ackno and substring(R.ackno,3,3)='" + CollCode.SelectedValue + "' ";
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        SummaryView.DataSource = ds;
        SummaryView.DataBind();

    }

    protected void SummaryView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
       SummaryView.PageIndex = e.NewPageIndex;
        BindGrid();
    }
}
