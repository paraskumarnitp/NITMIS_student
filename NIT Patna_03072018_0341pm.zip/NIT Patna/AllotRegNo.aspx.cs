using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class AllotRegNo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2") //Role for EC
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }


            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(StreamCode1, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
           
            popddl.Popualate(Year, "Year", "Select Year from Year where year >= '2006' order by Year", "Year", "Year");
            DataSet ds = new DataSet();
            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select AckNo,RegNo,ApplicantName,FatherName,MotherName,DOB,CollCode,StreamCode from Registration where RegNo is null or RegNo=''");
            RegView.DataSource = ds;
            RegView.DataBind();

            TotStudent.Text = RegView.Rows.Count.ToString();
            Year.Text = System.DateTime.Now.Year.ToString();  
        }

    }
    protected void RegView_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
    protected void BtnAllotRegNo_Click(object sender, EventArgs e)
    {
        try
        {

            if (RegView.Rows.Count > 0)
            {
                SqlConnection con = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
                cmd.Connection = con;
                con.Open();
                SqlTransaction tran;

                string regno;
                string SQL = "";
                string SerialNo = "";

                UnivService.Service1 ss = new UnivService.Service1();

                //regno=  newkpus = string.Format("{0:D2}", RegView.Rows[i].Cells[0].Text

                int count = 0;
                string UnivCode = "";
                SQL = "select UnivCode from Install";
                UnivCode = ss.GetNewCode(SQL);

                for (int i = 0; i < int.Parse(RegView.Rows.Count.ToString()); i++)
                {
                    CheckBox myCheckBox = (CheckBox)RegView.Rows[i].FindControl("CheckBox1");
                    if (myCheckBox.Checked == true)
                    {
                        count = count + 1;
                        tran = con.BeginTransaction();
                        cmd.Transaction = tran;
                        //SQL = "select ISNULL(max(abs(substring (regno,7,11))),0)+1 from registration where RegYear='" + Year.Text + "' ";
                        SQL = "select ISNULL(max(abs(regno)),0)+1 from MaxRegNoYear where RegYear='" + Year.Text + "' ";
                        SerialNo = ss.GetNewCode(SQL);
                        SerialNo = string.Format("{0:D5}", Convert.ToInt32(SerialNo));

                        //Registration No. Format 
                        // # Begin - [UnivCode(2)+Year(4)+ SL No(5) ]=11 Digit
                        regno = UnivCode + Year.Text + SerialNo;


                        cmd.CommandText = " update Registration set  RegNo='" + regno + "', RegistrationDate='" + string.Format("{0:MM/dd/yyyy}", System.DateTime.Now) + "' where Ackno='" + RegView.Rows[i].Cells[1].Text + "'";
                        cmd.ExecuteNonQuery();
                       // Updated Temproraily on 6/12/2013s
                        //cmd.CommandText = "update PREREGQUALIFICATION set RegNo='" + regno + "' where Ackno='" + RegView.Rows[i].Cells[1].Text + "'";
                       // cmd.ExecuteNonQuery();
                       // cmd.CommandText = "update PREREGMIGRATION set RegNo='" + regno + "' where Ackno='" + RegView.Rows[i].Cells[1].Text + "'";
                        //cmd.ExecuteNonQuery();
                        cmd.CommandText = "update MAxRegNoYear set RegNo='" + SerialNo + "' where RegYear='" + Year.Text + "'";
                        cmd.ExecuteNonQuery();
                        tran.Commit();
                    }
                }

                string popupScript = "<script language='javascript'>" +
                                   " alert('Registration No. Alloted for   " + count + " Students. ')" +
                                    "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);


                BindGrid();
            }

        }
        catch (Exception ex)
        {
            TotStudent.Text = ex.Message;
        }


    }
    protected void RegView_PageIndexChanged(object sender, EventArgs e)
    {
        //RegView.PageIndex =int.Parse (ViewState["PageIndex"].ToString())+1;
        //RegView.PageIndex = Convert.ToInt32(ViewState["PageIndex"].ToString());    
           
    }
    protected void RegView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        
        //ViewState.Add("PageIndex", e.NewPageIndex);     
        RegView.PageIndex = e.NewPageIndex;
        BindGrid();
        //BindGrid(CollCode.SelectedValue.ToString(), Year.SelectedValue.ToString());
        
    }

    protected void LnkBtnAll_Click(object sender, EventArgs e)
    {
        
        foreach (GridViewRow row in RegView.Rows)
        {
            CheckBox myCheckBox = (CheckBox)row.FindControl("CheckBox1");
            myCheckBox.Checked = true;

        }
       

    }
    protected void LnkBtnNone_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow row in RegView.Rows)
        {
            CheckBox myCheckBox = (CheckBox)row.FindControl("CheckBox1");
            myCheckBox.Checked = false;
        }
    }

    void BindGrid()
    {
        DataSet ds = new DataSet();
        //ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select AckNo,RegNo,ApplicantName,FatherName,MotherName,DOB,CollCode,StreamCode from Registration where collcode='" + CollCode.SelectedValue.ToString() + "' and streamcode='" + StreamCode1.SelectedValue.ToString() + "' and subcode='" + SubCode1.SelectedValue.ToString() + "'  and (regno is NULL or regno='') and (VerifySUDateTime is not null or VerifySUDateTime='') and RegYear='" + Year.SelectedValue + "' order by " + OrderBy.SelectedValue + " ");
        //updated on 6/12/2013(Not nul Date is Made Null)
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select AckNo,RegNo,ApplicantName,FatherName,MotherName,DOB,CollCode,StreamCode from Registration where collcode='" + CollCode.SelectedValue.ToString() + "' and streamcode='" + StreamCode1.SelectedValue.ToString() + "' and subcode='" + SubCode1.SelectedValue.ToString() + "'  and (regno is NULL or regno='') and (VerifySUDateTime is  null or VerifySUDateTime='') and RegYear='" + Year.SelectedValue + "' order by " + OrderBy.SelectedValue + " ");
        RegView.DataSource = ds;
        RegView.DataBind();
    }
    protected void BtnView_Click(object sender, EventArgs e)
    {

        try
        {

            BindGrid();
            if (RegView.Rows.Count > 0)
            {
                TotStudent.Visible = true;
                TotStudent.Text = " Total Student =  " + RegView.Rows.Count.ToString();
                Panel1.Visible = true;
            }
            else
            {
                TotStudent.Visible = true;
                TotStudent.Text = "Not more  Records For Allotment";
                Panel1.Visible = false;
            }

        }
        catch (Exception ex)
        {
            TotStudent.Text = ex.Message;
        }

    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }
    protected void StreamCode1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (StreamCode1.SelectedValue == "00") return;

        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(SubCode1, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode1.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        //SubCode_SelectedIndexChanged(StreamCode, e); // call subcode selected index
        SubCode1.Focus();
    }
}
