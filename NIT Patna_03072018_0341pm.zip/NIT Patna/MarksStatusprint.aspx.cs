using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using System.IO;
using CrystalDecisions.Shared;

public partial class MarksStatusprint : System.Web.UI.Page
{
    ReportDocument rpt = new ReportDocument();
    Functionreviseed fn = new Functionreviseed();
    string examyear, stmp;
    protected void Page_Load(object sender, EventArgs e)
    {
        examyear = Request.QueryString["examyear"];
        stmp = Request.QueryString["stmp"];
        btechgrade();
    }
    protected void Page_Unload(object sender, EventArgs e)
    {
        if (rpt != null)
        {
            rpt.Close();
            rpt.Dispose();
        }
    }
    protected void btechgrade()
    {
        string whereSql = string.Empty;

        string sql = " SELECT c.StreamTypeCode, c.StreamAbbr as program, b.StreamPart as Semester,f.SplCode, " +
                        " B.PaperAbbr AS CourseCode,a.ExamSession,b.PaperName,COUNT(*) as TotalRegistered, " +
                        " SUM( case when (( CASE WHEN a.ExamType='N' THEN 'P' ELSE D.STATUS END='P' ) AND " +
                        " ((a.PaperType='X' and ISNULL( THEndsem,'')='' and ISNULL(PREndSem,'')='' and  a.opt1 IS not null and StudentStatus!='AE') " +
                        " or (a.PaperType='T' and ISNULL(THEndsem,'')='' and a.opt1 IS not null  and StudentStatus!='AE') " +
                        " OR (a.PaperType='P' and ISNULL(PREndSem,'')='' and a.opt1 IS not null and StudentStatus!='AE') " +
                        " or (a.opt1 IS null))) THEn 1 else  0 end) as InCompleteMarks, " +
                        " sum(case when d.opt1 IS null and a.ExamType!='N' THEn 1 else 0 end) as InCompleteAttendance, " +
                        " e.UserId,g.UserName,G.Designation FROM EXAMPAPERDETAIL a inner join " +
                        " COURSEPAPERS b on a.SubPaperCode=b.SubPaperCode inner join STREAM c on b.StreamCode=c.StreamCode " +
                        " inner join REGISTRATION f on a.RegNo=f.RegNo " +
                        " left join Attendance d on a.RegNo=d.RegNo and a.SubPaperCode=d.SubPaperCode and a.ExamSession=d.ExamSession " +
                        "  left join Faculty_paper_a e on a.ExamSession=e.ExamSession and a.SubPaperCode=e.SubPaperCode and f.SplCode=e.Splcode  " +
                        "   and e.Enabled='Y' and e.Is_Active='Y'  left join LogIn g on e.UserId=g.UserId " +
                        " where a.ExamSession='" + examyear + "'   group by b.PaperAbbr,b.StreamPart, c.StreamAbbr ,b.PaperName,e.UserId,f.SplCode,g.UserName, c.StreamTypeCode,a.ExamSession,G.Designation " +
                        " order by c.StreamTypeCode";
        DataTable dt = fn.SelectDatatable(sql);
        if (stmp == "1")
        {
            rpt.Load(Server.MapPath("~/Report/MarksStatusprint.rpt"));
        }
        else
        {
            rpt.Load(Server.MapPath("~/Report/MarksStatusprintbyDept.rpt"));
        }
        dt.TableName = "Marks_Status";
        // dt.WriteXmlSchema(Server.MapPath("~/MarksStatusprint1.xsd"));
        rpt.SetDataSource(dt);
        MemoryStream oStream = new MemoryStream();
        oStream = (MemoryStream)rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
        Response.Clear();
        Response.Buffer = true;
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "inline;filename=report.pdf");
        Response.BinaryWrite(oStream.ToArray());
        Response.End();

        //rpt.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, false, "PersonDetails");



    }


}




//protected void Page_LoadComplete(object sender, EventArgs e)
//{
//    CrystalReportViewer1.ReportSource = Session["btechgrage"];
//}

