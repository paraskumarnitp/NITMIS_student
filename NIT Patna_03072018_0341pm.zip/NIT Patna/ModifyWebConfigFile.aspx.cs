using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ModifyWebConfigFile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            ViewState.Add("flag", "0");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (ExamAdmin.Text == "exam4321" && NicAdmin.Text == "nic4321")
        {
            TxtDataBase.Text = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            TxtProvider.Text = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ProviderName;
            ViewState.Add("flag", "1");
            Panel1.Visible = true;
            TxtNewConfig.Text = TxtDataBase.Text;
            TxtNewProvider.Text = TxtProvider.Text;
            // TextBox1.Text = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["myDatabaseName"].ConnectionString;
            // TextBox2.Text = System.Web.Configuration.WebConfigurationManager.AppSettings["myKey"];
        }
        else
        {
            Label1.Text = " Please Contact to admin for any chnage"; 
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (ViewState["flag"].ToString() == "0")
            Label1.Text = "Please enter password";

        else if (TxtNewConfig.Text.Trim() == "")
            Label1.Text = "error..Please check new configuration";
        else if (TxtNewProvider.Text.Trim() == "")
            Label1.Text = "error..Please check new configuration";
        else
        {
            Configuration conf;
            conf = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration("~");
            conf.ConnectionStrings.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString = TxtNewConfig.Text.Trim();
            conf.ConnectionStrings.ConnectionStrings["UNIVERSITYConnectionString1"].ProviderName = TxtNewProvider.Text.Trim();
            conf.Save();
            Label1.Text = " Updated successfully";
            ViewState.Add("flag", "0");
            Panel1.Visible = false;
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("default.aspx");
    }
}
