using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using System.IO;
using System.Data.SqlClient;

public partial class AttendanceEntryPrint : System.Web.UI.Page
{
    ReportDocument rpt;
    Functionreviseed fn = new Functionreviseed();
    ReportDocument crystalReport = new ReportDocument();
    string ExamSession, month, SplCode, strprtcode, paperabbr;

    protected void Page_Load(object sender, EventArgs e)
    {
        rpt = new ReportDocument();
        ExamSession = Request.QueryString["es"];
        month = Request.QueryString["mn"];
        SplCode = Request.QueryString["spl"];
        strprtcode = Request.QueryString["spc"];
        paperabbr = Request.QueryString["par"];        
        BindReport(rpt);
    }
    protected void Page_Unload(object sender, EventArgs e)
    {
        if (rpt != null)
        {
            rpt.Close();
            rpt.Dispose();
        }
    }
    protected void bindreport()
    {

        rpt.Load(Server.MapPath("~/Report/Consoidatedmarks.rpt"));       
        System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
        doctoprint.PrinterSettings.PrinterName = "Microsoft XPS Document Writer";
        int i = 0;
        string filename = "ATTENDANCE_ENTRY_PRINT";
        for (i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count; i++)
        {
            int rawKind = 0;
            if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "consol")
            {
                rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                rpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
                break;
            }
        }
        MemoryStream oStream = new MemoryStream();
        oStream = (MemoryStream)rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
        Response.Clear();
        Response.Buffer = true;
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "inline;filename=" + filename + ".pdf");
        Response.BinaryWrite(oStream.ToArray());
        Response.End();
        //CrystalReportViewer1.ReportSource = rpt;
    }

    private void BindReport(ReportDocument crystalReport)
    {
        crystalReport.Load(Server.MapPath("~/Report/rptattendanceEntry.rpt"));
        rptAttendanceEntry dsattendanceentry = GetData("SELECT STREAM.StreamAbbr, COURSEPAPERS.StreamPart, AttendanceRegister.ExamSession, COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName, " +
                      "CASE WHEN AttendanceRegister.Month = '1' THEN 'January' WHEN AttendanceRegister.Month = '2' THEN 'February' WHEN AttendanceRegister.Month = '3' THEN 'March' WHEN AttendanceRegister.Month " +
                       "= '4' THEN 'April' WHEN AttendanceRegister.Month = '5' THEN 'May' WHEN AttendanceRegister.Month = '6' THEN 'June' WHEN AttendanceRegister.Month = '7' THEN 'July' WHEN AttendanceRegister.Month " +
                       "= '8' THEN 'August' WHEN AttendanceRegister.Month = '9' THEN 'September' WHEN AttendanceRegister.Month = '10' THEN 'October' WHEN AttendanceRegister.Month = '11' THEN 'November' WHEN " +
                       "AttendanceRegister.Month = '12' THEN 'December' END AS Month, REGISTRATION.ApplicantName, AttendanceDetail.UnivRollNo, AttendanceDetail.Count AS ClassTaken, AttendanceDetail.UserId, " +
                      "AttendanceDetail.ClassHeld, CASE WHEN AttendanceDetail.Day1 = '1' THEN 'P' WHEN AttendanceDetail.Day1 = '0' AND AttendanceDetail.Day1 IS NOT NULL THEN 'A' ELSE '' END AS Day1, " +
                      " CASE WHEN AttendanceDetail.Day2 = '1' THEN 'P' WHEN AttendanceDetail.Day2 = '0' AND AttendanceDetail.Day2 IS NOT NULL THEN 'A' ELSE '' END AS Day2, " +
                      " CASE WHEN AttendanceDetail.Day3 = '1' THEN 'P' WHEN AttendanceDetail.Day3 = '0' AND AttendanceDetail.Day3 IS NOT NULL THEN 'A' ELSE '' END AS Day3, " +
                      " CASE WHEN AttendanceDetail.Day4 = '1' AND AttendanceDetail.Day4 IS NOT NULL THEN 'P' WHEN AttendanceDetail.Day4 = '0' AND AttendanceDetail.Day4 IS NOT NULL " +
                      " THEN 'A' ELSE '' END AS Day4, CASE WHEN AttendanceDetail.Day5 = '1' THEN 'P' WHEN AttendanceDetail.Day5 = '0' AND AttendanceDetail.Day5 IS NOT NULL THEN 'A' ELSE '' END AS Day5, " +
                      " CASE WHEN AttendanceDetail.Day6 = '1' THEN 'P' WHEN AttendanceDetail.Day6 = '0' AND AttendanceDetail.Day6 IS NOT NULL THEN 'A' ELSE '' END AS Day6, " +
                      " CASE WHEN AttendanceDetail.Day7 = '1' THEN 'P' WHEN AttendanceDetail.Day7 = '0' AND AttendanceDetail.Day7 IS NOT NULL THEN 'A' ELSE '' END AS Day7, " +
                      " CASE WHEN AttendanceDetail.Day8 = '1' THEN 'P' WHEN AttendanceDetail.Day8 = '0' AND AttendanceDetail.Day8 IS NOT NULL THEN 'A' ELSE '' END AS Day8, " +
                      " CASE WHEN AttendanceDetail.Day9 = '1' THEN 'P' WHEN AttendanceDetail.Day9 = '0' AND AttendanceDetail.Day9 IS NOT NULL THEN 'A' ELSE '' END AS Day9, " +
                      " CASE WHEN AttendanceDetail.Day10 = '1' THEN 'P' WHEN AttendanceDetail.Day10 = '0' AND AttendanceDetail.Day10 IS NOT NULL THEN 'A' ELSE '' END AS Day10," + 
                      " CASE WHEN AttendanceDetail.Day11 = '1' THEN 'P' WHEN AttendanceDetail.Day11 = '0' AND AttendanceDetail.Day11 IS NOT NULL THEN 'A' ELSE '' END AS Day11, "+
                      " CASE WHEN AttendanceDetail.Day12 = '1' THEN 'P' WHEN AttendanceDetail.Day12 = '0' AND AttendanceDetail.Day12 IS NOT NULL THEN 'A' ELSE '' END AS Day12, " +
                      " CASE WHEN AttendanceDetail.Day13 = '1' THEN 'P' WHEN AttendanceDetail.Day13 = '0' AND AttendanceDetail.Day13 IS NOT NULL THEN 'A' ELSE '' END AS Day13, " +
                      " CASE WHEN AttendanceDetail.Day14 = '1' THEN 'P' WHEN AttendanceDetail.Day14 = '0' AND AttendanceDetail.Day14 IS NOT NULL THEN 'A' ELSE '' END AS Day14, " +
                      " CASE WHEN AttendanceDetail.Day15 = '1' THEN 'P' WHEN AttendanceDetail.Day15 = '0' AND AttendanceDetail.Day15 IS NOT NULL THEN 'A' ELSE '' END AS Day15, " +
                      " CASE WHEN AttendanceDetail.Day16 = '1' THEN 'P' WHEN AttendanceDetail.Day16 = '0' AND AttendanceDetail.Day16 IS NOT NULL THEN 'A' ELSE '' END AS Day16, " +
                      " CASE WHEN AttendanceDetail.Day17 = '1' THEN 'P' WHEN AttendanceDetail.Day17 = '0' AND AttendanceDetail.Day17 IS NOT NULL THEN 'A' ELSE '' END AS Day17," + 
                      " CASE WHEN AttendanceDetail.Day18 = '1' THEN 'P' WHEN AttendanceDetail.Day18 = '0' AND AttendanceDetail.Day18 IS NOT NULL THEN 'A' ELSE '' END AS Day18, " +
                      " CASE WHEN AttendanceDetail.Day19 = '1' THEN 'P' WHEN AttendanceDetail.Day19 = '0' AND AttendanceDetail.Day19 IS NOT NULL THEN 'A' ELSE '' END AS Day19, " +
                      " CASE WHEN AttendanceDetail.Day20 = '1' THEN 'P' WHEN AttendanceDetail.Day20 = '0' AND AttendanceDetail.Day20 IS NOT NULL THEN 'A' ELSE '' END AS Day20, " +
                      " Faculty_paper_a.UserId AS Expr1, Faculty_paper_a.SubPaperCode FROM Faculty_paper_a INNER JOIN STREAM INNER JOIN COURSEPAPERS ON STREAM.StreamCode = COURSEPAPERS.StreamCode " + 
                      " ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN REGISTRATION INNER JOIN AttendanceRegister INNER JOIN AttendanceDetail ON " + 
                      " AttendanceRegister.Id = AttendanceDetail.RegisterId ON REGISTRATION.RegNo = AttendanceDetail.RegNo ON Faculty_paper_a.SubPaperCode = AttendanceRegister.SubPaperCode " + 
                      " AND Faculty_paper_a.ExamSession = AttendanceRegister.ExamSession WHERE (Faculty_paper_a.Is_Active = 'Y') AND " +
                 " (AttendanceRegister.ExamSession = '" + ExamSession + "') AND (AttendanceRegister.Month = '" + month + "') AND (AttendanceRegister.SplCode = '" + SplCode + "') AND (COURSEPAPERS.StreamPartCode = '" + strprtcode + "') AND (COURSEPAPERS.PaperAbbr = '" + paperabbr + "')");
        crystalReport.SetDataSource(dsattendanceentry);
        //CrystalReportViewer1.ReportSource = crystalReport;
        //System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
        //doctoprint.PrinterSettings.PrinterName = "Microsoft XPS Document Writer";
        //int i = 0;
        string filename = "ATTENDANCE_ENTRY_PRINT";
        //for (i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count; i++)
        //{
        //    int rawKind = 0;
        //    if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "consol")
        //    {
        //        rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
        //        rpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
        //        break;
        //    }
        //}
        MemoryStream oStream = new MemoryStream();
        oStream = (MemoryStream)rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
        Response.Clear();
        Response.Buffer = true;
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "inline;filename=" + filename + ".pdf");
        Response.BinaryWrite(oStream.ToArray());
        Response.End();
    }

    private rptAttendanceEntry GetData(string query)
    {
        string conString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlCommand cmd = new SqlCommand(query);
        using (SqlConnection con = new SqlConnection(conString))
        {
            using (SqlDataAdapter sda = new SqlDataAdapter())
            {
                cmd.Connection = con;

                sda.SelectCommand = cmd;
                using (rptAttendanceEntry dsattendanceentry = new rptAttendanceEntry())
                {
                    sda.Fill(dsattendanceentry, "DataTable1");
                    return dsattendanceentry;
                }
            }
        }
    }
}
