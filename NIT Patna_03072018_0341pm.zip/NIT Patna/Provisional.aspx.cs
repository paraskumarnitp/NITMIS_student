using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using CrystalDecisions.CrystalReports.Engine;
using System.IO;
public partial class Provisional : System.Web.UI.Page
{
    Functionreviseed fn = new Functionreviseed();
    PopulateDDL popddl = new PopulateDDL();
    string streamtypcode; String Streamvalue;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            

            //popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College where collcode in (select distinct collcode from TRHons) order by CollName", "CollName", "CollCode");
                

        }
    }
 
    
    protected void ViewTR_Click(object sender, EventArgs e)
    {
   
        //dt.WriteXmlSchema(Server.MapPath("provisional.xsd"));

        string strque = "provisonalprint.aspx?urolno=" + rollno.Text.ToString().Trim() + "";


        //ClientScript.RegisterStartupScript(this.Page.GetType(), "", "window.open('"+strque+"','Graph','height=600,width=800,resizable=yes');", true);
        ScriptManager.RegisterStartupScript(this, this.Page.GetType(), "", "window.open('" + strque + "','Graph','height=600,width=800,resizable=yes');", true);

 
        


    }


}
