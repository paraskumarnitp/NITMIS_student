using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class ExamFormChkList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "4")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(Year, "Year", "Select Year from Year where Year >= 2008 order by Year", "Year", "Year");
            popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        }
       

    }
    
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode1, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");

        StreamCode.Focus(); 
    }
    protected void BtnGenAdmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        SqlConnection con1 = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        //SqlCommand cmd1 = new SqlCommand();
        SqlDataReader reader;
        cmd.Connection = con;
        //cmd1.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        con1.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        
        // Select Only those students whose admit card is generated ...

        string sql = "SELECT EXAM.RegNo, EXAM.UnivRollNo, REGISTRATION.ApplicantName, REGISTRATION.HindiName, REGISTRATION.FatherName, " +
                   "Registration.Gender, EXAM.ClassRollNo, Exam.Subcode,  SUBJECT.SubAbbr, " +
                   "EXAM.ExamType,Stream.StreamAbbr,StreamPart.StreamPart FROM EXAM , REGISTRATION ,SUBJECT, Stream,StreamPart where  EXAM.RegNo=Registration.RegNo and" +
                   " Subject.SubCode=Exam.SubCode and Exam.CollCode='"+ CollCode.SelectedValue  +"' and  EXAM.ExamYear='" + Year.SelectedValue + 
                   "' and EXAM.StreamCode='" + StreamCode.SelectedValue + "' and EXAM.StreamPartCode='" + StreamPart.SelectedValue + "' and  EXAM.SubCode='" + SubCode1.SelectedValue +
                   "' and Stream.StreamCode='" + StreamCode.SelectedValue + "' and StreamPart.StreamPartCode='" + StreamPart.SelectedValue +
                   "'";// and (Exam.UniVRollNo is Not Null or Exam.UnivRollNo <>'')  ";



        con.Open();
        cmd.CommandText = "Delete From RegCheckList";
        cmd.ExecuteNonQuery();
        cmd.CommandText = sql;
        reader = cmd.ExecuteReader();
        int count=0;
        // insert record in RegCheckList table
        string[] col = new string[17];
        string[] val = new string[17];
        string[] coltype = new string[17];
        for (int i = 0; i < 17; i++)
            coltype[i] = "0";
        coltype[3] = "1";
        col[0] = "RegNo";
        col[1] = "UnivRollNo";
        col[2] = "ApplicantName";
        col[3] = "HindiName";
        col[4] = "FatherName";
        col[5] = "CollCode";
        col[6] = "CollName";
        col[7] = "ClassRollNo";
        col[8] = "SubAbbr";
        col[9]="ExamType";
        col[10] = "ExamYear";
        col[11] = "StreamCode";
        col[12] = "StreamPartCode";
        col[13] = "Gender";
        col[14] = "SubCode";
        col[15] = "StreamAbbr";
        col[16] = "StreamPart";

        UnivService.Service1 ss = new UnivService.Service1();

        while (reader.Read ())
        {
            val[0] = reader["RegNo"].ToString();
            val[1] = reader["UnivRollNo"].ToString();
            val[2] = reader["ApplicantName"].ToString();
            val[3] = reader["HindiName"].ToString();
            val[4] = reader["FatherName"].ToString();
            val[5] = CollCode.SelectedValue;
            val[6] = CollCode.SelectedItem.Text.Trim();   
            val[7] = reader["ClassRollNo"].ToString();
            val[8] = reader["SubAbbr"].ToString();
            val[9] = reader["ExamType"].ToString();
            val[10] = Year.SelectedValue;
            val[11] = StreamCode.SelectedValue;
            val[12] = StreamPart.SelectedValue;
            val[13] = reader["Gender"].ToString();
            val[14] = reader["SubCode"].ToString();
            val[15] = reader["StreamAbbr"].ToString();
            val[16] = reader["StreamPart"].ToString();
            sql= ss.SaveDataUniCode("RegCheckList", col, val, coltype);
             if(sql=="1")  count ++;                 
        }
        reader.Close();
         
        //----------------
        // Set Center Code in Admit Gra
        
        //sql = " Select ExamCentre.SubCode,ExamCentre.Gender,ExamCentre.ExamCollCode,College.CollName,College.Address1,College.Address2,"+
        //      " District.DistName,ExamCentre.ExamStartDate from ExamCentre,College,District "+
        //      " Where College.CollCode=ExamCentre.ExamCollCode and District.DistCode=College.DistCode"+
        //      " and ExamCentre.CollCode='" + CollCode.SelectedValue + "' and  ExamCentre.ExamYear='" + Year.SelectedValue + "' and ExamCentre.StreamCode='" + StreamCode.SelectedValue + "' and ExamCentre.StreamPartCode='" + StreamPart.SelectedValue + "'";

        // SELECT EXAM CENTRE FROM EXAM TABLE
        //sql = " Select Exam.regno,Exam.univrollno,Exam.SubCode,Exam.Gender,Exam.ExamCollCode,College.CollName,College.Address1,College.Address2," +
        //      " District.DistName,Exam.ExamStartDate from Exam,College,District " +
        //      " Where College.CollCode=Exam.ExamCollCode and District.DistCode=College.DistCode" +
        //      " and Exam.CollCode='" + CollCode.SelectedValue + "' and  Exam.ExamYear='" + Year.SelectedValue + "' and Exam.StreamCode='" + StreamCode.SelectedValue + "' and Exam.StreamPartCode='" + StreamPart.SelectedValue + "' ";
               


        //cmd.CommandText = sql;
        //reader =cmd.ExecuteReader ();
        //con1.Open();
        //cmd.Connection = con1;
        //while (reader.Read ())
        //{
        //    string s = reader["Gender"].ToString();
        //    if (reader["Gender"].ToString() == "A")
        //    {
        //        sql = "Update RegCheckList set ExamCollCode='" + reader["ExamCollCode"].ToString() + "',ExamCollName='" + reader["CollName"].ToString() +
        //            "',CentreAddress1='" + reader["Address1"].ToString() + "',CentreAddress2='" + reader["Address2"].ToString() +
        //            "' ,DistName='" + reader["DistName"].ToString() +
        //            "', ExamStartDate='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(reader["ExamStartDate"].ToString())) +
        //            "' Where CollCode='" + CollCode.SelectedValue + "' and  ExamYear='" + Year.SelectedValue + "' and StreamCode='" + StreamCode.SelectedValue + "' and StreamPartCode='" + StreamPart.SelectedValue +
        //            "' and subcode='" + reader["SubCode"].ToString() + "'";
        //        cmd.CommandText = sql;
        //        cmd.ExecuteNonQuery();
        //    }
        //    else
        //    {
        //        sql = "Update RegCheckList set ExamCollCode='" + reader["ExamCollCode"].ToString() + "',ExamCollName='" + reader["CollName"].ToString() +
        //            "',CentreAddress1='" + reader["Address1"].ToString() + "',CentreAddress2='" + reader["Address2"].ToString() +
        //            "' ,DistName='" + reader["DistName"].ToString() +
        //            "', ExamStartDate='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(reader["ExamStartDate"].ToString())) +
        //            "' Where CollCode='" + CollCode.SelectedValue + "' and  ExamYear='" + Year.SelectedValue + "' and StreamCode='" + StreamCode.SelectedValue + "' and StreamPartCode='" + StreamPart.SelectedValue +
        //            "' and subcode='" + reader["SubCode"].ToString() + "' And Gender='"+reader["Gender"].ToString () +
        //            "' and regno='" + reader["regno"].ToString() + "' and  univrollno= '" +reader["univrollno"].ToString() + "' ";
        //        cmd.CommandText = sql;
        //        cmd.ExecuteNonQuery();

        //    }
        //}
        //reader.Close();
        //con1.Close();
        //push exampaper to RegCheckListpaper
        //
        cmd.Connection = con;
        // Clear RegCheckListPaper
        cmd.CommandText = " Delete From RegCheckListPaper";
        cmd.ExecuteNonQuery();
        //Composition
        sql = "insert into RegCheckListPaper  select RegNo,UnivRollNo,StreamPartCode,ExamYear,SubPaperCode,Abbr,PaperType from ExamPaperDetail,Composition " +
               " Where Composition.CompCode= RTrim(ExamPaperDetail.SubPaperCode) ";
        
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
        //Honours
        sql = "insert into RegCheckListPaper  select RegNo,UnivRollNo,ExamPaperDetail.StreamPartCode,ExamYear,ExamPaperDetail.SubPaperCode,PaperAbbr,PaperType from ExamPaperDetail,CoursePapers " +
              "Where CoursePapers.SubPaperCode= RTrim(ExamPaperDetail.SubPaperCode) And ExamPaperDetail.PaperType<>'P'";
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
        // Subsidiary 
        sql = "insert into RegCheckListPaper  select RegNo,UnivRollNo,StreamPartCode,ExamYear,SubPaperCode,SubAbbr,PaperType " +
              " from ExamPaperDetail,Subject Where Subject.SubCode= RTrim(ExamPaperDetail.SubPaperCode) And ExamPaperDetail.PaperType<>'P'";
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();


        con.Close ();

        //
        string popupScript = "<script language='javascript'>" +
                                " alert(' Check List Generated for - " + count  + " Students ')" +
                                "</script>";
        Page.RegisterStartupScript("PopupScript", popupScript);

       
       
          

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
              
        Panel1.Visible = true;
        CR.ReportSource = crs;
        CR.RefreshReport();
    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }
}
