using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;



public partial class ExamCollege : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                if (Session["Role"].ToString() != "1")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
                PopulateDDL popddl = new PopulateDDL();
                //popddl.Popualate(UnivCode, "University", "Select UnivCode,UnivName from University order by UnivName", "UnivName", "UnivCode");
                popddl.Popualate(DistCode, "District", "Select Distcode,DistName from District where statecode='05' order by DistName", "DistName", "DistCode");
                UnivService.Service1 ss = new UnivService.Service1();
                //string univcode = ss.GetNewCode("select univcode from install");
                //UnivCode.SelectedValue = univcode;
                ViewState.Add("EditMode", "false");
            }
        }
        catch (Exception ex)
        {
            Response.Redirect("default.aspx");
        }
    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {
        string abc = "";
        Panel2.Visible = false;
        if (ViewState["EditMode"].ToString() == "false")
        {

            string[] col = new string[12];
            string[] val = new string[12];

            //col[0] = "UnivCode"; val[0] = UnivCode.SelectedValue;
            // col[4] = "CollType"; val[4] = CollType.SelectedValue;
            // col[5] = "DateOfConst"; val[5] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(DateOfConst.Text));
            
            col[0] = "ExamCollCode";
            col[1] = "CollFullName"; val[1] = CollFullName.Text.Trim();
            col[2] = "CollName";     val[2] = CollName.Text.Trim();
            col[3] = "PrincipalName"; val[3] = PrincipalName.Text.Trim();
            col[4] = "Address1";      val[4] = Address1.Text.Trim();
            col[5] = "Address2"; val[5] = Address2.Text.Trim();
            col[6] = "DistCode"; val[6] = DistCode.SelectedValue;
            col[7] = "PinCode"; val[7] = PinCode.Text.Trim();
            col[8] = "PhoneNo"; val[8] = PhoneNo.Text.Trim();
            col[9] = "Fax"; val[9] = Fax.Text.Trim();
            col[10] = "Email"; val[10] = Email.Text.Trim();
            col[11] = "ExamCapacity"; val[11] = ExamCapacity.Text;


            //val[0] = UnivCode.Text.Trim();
            UnivService.Service1 ss = new UnivService.Service1();
            string SQL = "SELECT     ISNULL(MAX(Abs(ExamCollCode)), '700') + 1 AS NewCollCode FROM ExamCOLLEGE";
            string NewCollegeCode = ss.GetNewCode(SQL);
            NewCollegeCode = string.Format("{0:D3}", Convert.ToInt16(NewCollegeCode));

            val[0] = string.Format("{0:D3}", Convert.ToInt16(NewCollegeCode));


            abc = ss.SaveData("ExamCollege", col, val);

            if (abc == "1")
            {
                LblMsg.Text = " Exam Centre is saved successfully. College Code= " + NewCollegeCode;
                string popupScript = "<script language='javascript'>" +
                                " alert('College is saved successfully. College Code=   " + NewCollegeCode + " ')" +
                                 "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);

                CollName.Text = "";
                //DateOfConst.Text = "";
                PrincipalName.Text = "";
                Address1.Text = "";
                Address2.Text = "";
                PinCode.Text = "";
                PhoneNo.Text = "";
                Fax.Text = "";
                Email.Text = "";
                ExamCapacity.Text = "";
                CollName.Focus();


            }
            else
            {
                LblMsg.Text = abc.ToString();
            }
        }
        else
        {

            UnivService.Service1 ss = new UnivService.Service1();
            abc = " update ExamCollege set CollFullName='" + CollFullName.Text.Trim() + "', CollName='" + CollName.Text.Trim() +  
                  "', PrincipalName='" + PrincipalName.Text.Trim() + "', Address1='" + Address1.Text.Trim() + "', Address2='" + Address2.Text.Trim() + "', DistCode='" + DistCode.SelectedValue.Trim() + "', PinCode='" + PinCode.Text.Trim() + "', PhoneNo='" + PhoneNo.Text.Trim() + "', Email='" + Email.Text.Trim() + "' , Fax='" + Fax.Text.Trim() + "',ExamCapacity='" + ExamCapacity.Text.Trim() + "' where ExamCollCode='" + CollegeView.SelectedRow.Cells[1].Text + "'";
            abc = ss.UpdateData(abc);
            if (abc.ToString() == "ok")
            {
                ViewState.Add("EditMode", "false");
                LblMsg.Text = " Record is updated successfully.";
                CollName.Text = "";
                //DateOfConst.Text = "";
                PrincipalName.Text = "";
                Address1.Text = "";
                Address2.Text = "";
                PinCode.Text = "";
                PhoneNo.Text = "";
                Fax.Text = "";
                Email.Text = "";
                ExamCapacity.Text = "";
                CollName.Focus();


            }
            else
                LblMsg.Text = abc.ToString();

        }
    }
    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        Panel2.Visible = true;
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select * from ExamCollege   order by ExamCollCode");
        CollegeView.DataSource = ds;
        CollegeView.DataBind(); 
    }
    protected void CollegeView_SelectedIndexChanged(object sender, EventArgs e)
    {
        //UnivCode.SelectedValue = CollegeView.SelectedRow.Cells[1].Text;
        CollFullName.Text = CollegeView.SelectedRow.Cells[2].Text;
        CollName.Text = CollegeView.SelectedRow.Cells[3].Text;
        PrincipalName.Text = CollegeView.SelectedRow.Cells[5].Text;
        Address1.Text = CollegeView.SelectedRow.Cells[6].Text;
        Address2.Text = CollegeView.SelectedRow.Cells[7].Text; ;
        DistCode.SelectedValue = CollegeView.SelectedRow.Cells[8].Text;
        PinCode.Text = CollegeView.SelectedRow.Cells[9].Text;
        PhoneNo.Text = CollegeView.SelectedRow.Cells[10].Text;
        Email.Text = CollegeView.SelectedRow.Cells[11].Text;
        Fax.Text = CollegeView.SelectedRow.Cells[12].Text;
        ExamCapacity.Text = CollegeView.SelectedRow.Cells[13].Text;
        ViewState.Add("EditMode", "true");
        CollFullName.Focus(); 
    }
}
