using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class AllotUnivRollNo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "2") && (Session["Role"].ToString() != "10"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(Year, "Year", "Select Year from Year where year >= '2008' order by Year", "Year", "Year");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from exam where streamcode!='05') order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(drpTo, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in ('01','02','03','04','06','07') order by StreamAbbr", "StreamAbbr", "StreamCode");

            CourseValue();
            
            
            
            //DataSet ds = new DataSet();
            //ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select AckNo,RegNo,ApplicantName,FatherName,MotherName,DOB,CollCode,StreamCode from Registration where RegNo is null or RegNo=''");
            //ExamView.DataSource = ds;
            //ExamView.DataBind();

            //TotStudent.Text = ExamView.Rows.Count.ToString();
           
        }

    }

    protected void CourseValue()
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart, StreamPartCode from StreamPart where streamcode='" + StreamCode.SelectedValue + "' and streampartcode in (select distinct streampartcode from exam) order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");


    }
  
    string ddlyear;
    string  autono, midno;
    protected void BtnAllotRegNo_Click(object sender, EventArgs e)
    {
        try
        {

            if (ExamView.Rows.Count > 0)
            {
                SqlConnection con = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
                cmd.Connection = con;
                con.Open();
                SqlTransaction tran;

                string univrollno;
                string cexmst = "";
                UnivService.Service1 ss = new UnivService.Service1();

                //regno=  newkpus = string.Format("{0:D2}", RegView.Rows[i].Cells[0].Text

                int count = Convert.ToInt32(ss.GetNewCode(" select isnull(MAX(convert(int,substring(temprollno,5,3))),0) as TempRollNo from REGISTRATION where StreamCode='" + drpGroup.SelectedValue + "' and AdmYear='" + Year.SelectedValue + "' and SUBSTRING(temprollno,1,4)='" + Year.SelectedValue.Substring(2,2) + drpGroup.SelectedValue + "'"));
               


                for (int i = 0; i < int.Parse(ExamView.Rows.Count.ToString()); i++)
                {
                    CheckBox myCheckBox = (CheckBox)ExamView.Rows[i].FindControl("CheckBox1");
                    Label lblStreamCode = (Label)ExamView.Rows[i].FindControl("lblStreamCode");
                   Label lblRegno = (Label)ExamView.Rows[i].FindControl("lblRegno");
                    univrollno = ExamView.Rows[i].Cells[1].Text;
                    midno = univrollno.Substring(2, 2);
                    ddlyear = univrollno.Substring(0, 2);
                    autono = univrollno.Substring(4, 3);
                    count =count +1;
                    
                        midno = lblStreamCode.Text;
                        string auto= string.Format("{0:D3}",count);
                        univrollno = ddlyear + midno + auto;
                        tran = con.BeginTransaction();
                        cmd.Transaction = tran;
                        cmd.CommandText = "  update Registration set temprollno='" + univrollno + "' where  RegNo='" + lblRegno.Text + "' "
                          + " update Exam set ClassRollNo ='" + univrollno + "', FinalizeDateTime='" + string.Format("{0:MM/dd/yyyy}", System.DateTime.Now) + "' where Regno='" + lblRegno.Text + "' and streamcode='" + lblStreamCode.Text + "'  ";
                         

                        cmd.ExecuteNonQuery();
                        tran.Commit();
                    


                }

                string popupScript = "<script language='javascript'>" +
                                   " alert('University Roll No. Alloted for   " + count + " Students. ')" +
                                    "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);

                con.Close();
                BindGrid();
            }
        }
        catch (Exception ex)
        {
            TotStudent.Text = ex.Message;
        }



    }
    protected void RegView_PageIndexChanged(object sender, EventArgs e)
    {
        //RegView.PageIndex =int.Parse (ViewState["PageIndex"].ToString())+1;
        //RegView.PageIndex = Convert.ToInt32(ViewState["PageIndex"].ToString());    

    }
    protected void RegView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        //ViewState.Add("PageIndex", e.NewPageIndex);     
        ExamView.PageIndex = e.NewPageIndex;
        BindGrid();
        //BindGrid(CollCode.SelectedValue.ToString(), Year.SelectedValue.ToString());

    }

    protected void LnkBtnAll_Click(object sender, EventArgs e)
    {

        foreach (GridViewRow row in ExamView.Rows)
        {
            CheckBox myCheckBox = (CheckBox)row.FindControl("CheckBox1");
            myCheckBox.Checked = true;

        }


    }
    protected void LnkBtnNone_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow row in ExamView.Rows)
        {
            CheckBox myCheckBox = (CheckBox)row.FindControl("CheckBox1");
            myCheckBox.Checked = false;
        }
    }

    void BindGrid()
    {
        DataSet ds = new DataSet();
        string sql = "";
        /*   
         * change by Suraj on 20-DEC-2012...inner join depending upon two field value
         * 
         * sql = "SELECT EXAM.RegNo AS Reg, REGISTRATION.ApplicantName, REGISTRATION.FatherName, REGISTRATION.DOB," +
                "EXAM.StreamCode, EXAM.StreamPartCode, EXAM.SubCode, EXAM.ExamFormNo, EXAM.ExamType ,Exam.ClassRollNo " +
                "FROM  REGISTRATION INNER JOIN EXAM ON REGISTRATION.RegNo = EXAM.RegNo" +
                "where EXAM.CollCode='" + CollCode.SelectedValue + "' and ExamYear='" + Year.Text.Trim() + "' and EXAM.StreamCode='" + StreamCode.SelectedValue + "' and EXAM.StreamPartCode='" + StreamPart.SelectedValue + "'  and EXAM.SubCode='" + SubCode.SelectedValue + "'      " +
                "and (UnivRollNo is NULL or UnivRollNo='') and (Exam.VerifySUDateTime is not null or Exam.VerifySUDateTime<>'') and (Exam.verifyStatus='N') order by Exam." + OrderBy.SelectedValue + " ";
      */

        //string streamPart = drpGroup.SelectedValue.ToString();
        //streamPart = streamPart.Substring(3, 2);

        //sql = "SELECT EXAM.RegNo AS Reg, REGISTRATION.ApplicantName, REGISTRATION.FatherName, REGISTRATION.DOB," +
        //      "EXAM.StreamCode, EXAM.StreamPartCode, EXAM.SubCode, EXAM.ExamFormNo, EXAM.ExamType ,Exam.ClassRollNo " +
        //      "FROM  REGISTRATION INNER JOIN EXAM ON (REGISTRATION.RegNo = EXAM.RegNo and REGISTRATION.StreamCode = EXAM.StreamCode) " +
        //      "where EXAM.CollCode='" + CollCode.SelectedValue + "' and ExamYear='" + Year.Text.Trim() + "' and EXAM.StreamCode='" + StreamCode.SelectedValue + "' and EXAM.StreamPartCode='" + StreamPart.SelectedValue + "'  and EXAM.SubCode='" + SubCode.SelectedValue + "'      " +
        //      "and (UnivRollNo is NULL or UnivRollNo='') and (Exam.VerifySUDateTime is not null or Exam.VerifySUDateTime<>'') and (Exam.verifyStatus='Y') order by Exam." + OrderBy.SelectedValue + " ";
        //ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);

        //sql = "SELECT     RegNo AS Reg,TempRollNo, ApplicantName, Gender, AdmissionBranch,RegNo,streamcode,StreamPartCode" +
        //           " FROM         REGISTRATION ";
        sql = "SELECT     TempRollNo, ApplicantName, Gender, AdmissionBranch,RegNo as Reg,AdmissionBranch,StreamCode FROM  REGISTRATION ";
         if(Year.SelectedValue!="0")
        {
            sql = sql + " where    REGISTRATION.AdmYear='" + Year.Text.Trim() + "' ";
        }
        //if (StreamCode.SelectedValue != "0")
        //{
        //    sql = sql + " and  StreamCode='" + StreamCode.SelectedValue + "' ";
        //}
        if (drpGroup.SelectedValue != "0")
        {
            sql = sql + " and (TempRollNo LIKE '%A%' OR TempRollNo LIKE '%B%') AND StreamCode='"+drpGroup.SelectedValue +"' ";
        }
        sql = sql + "   order by REGISTRATION." + OrderBy.SelectedValue + " ";
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        ExamView.DataSource = ds;
        ExamView.DataBind();
    }
    protected void BtnView_Click(object sender, EventArgs e)
    {

        try
        {
            Panel3.Visible = false;
       
            BindGrid();
            if (ExamView.Rows.Count > 0)
            {
                TotStudent.Visible = true;
                TotStudent.Text = " Total Student =  " + ExamView.Rows.Count.ToString();
                Panel1.Visible = true;
            }
            else
            {
                TotStudent.Visible = true;
                TotStudent.Text = "Not more  Records For Allotment";
                Panel1.Visible = false;
            }
        }
        catch (Exception ex)
        {
            TotStudent.Text = ex.Message;
        }


    }

    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        CourseValue();
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
       
         
        Panel3.Visible = true;
        string streamPart = drpGroup.SelectedValue.ToString();
        streamPart = streamPart.Substring(3, 2);
        CR.ReportSource = crs;
        CR.SelectionFormula = @"{Registration.AdmYear}='" + Year.Text + "'";
        CR.RefreshReport();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.Connection = con;
        con.Open();
        SqlTransaction tran;
        tran = con.BeginTransaction();
        cmd.Transaction = tran;
        try
        {

            if (ExamView.Rows.Count > 0)
            {
                
               

                string univrollno;
                string cexmst = "";
                UnivService.Service1 ss = new UnivService.Service1();

                //regno=  newkpus = string.Format("{0:D2}", RegView.Rows[i].Cells[0].Text
                
                string query="select ISNULL(MAX(convert(int,substring(temprollno,5,3))),0) AS TempRollNo from REGISTRATION where StreamCode='" + drpTo.SelectedValue + "' and AdmYear='" + Year.SelectedValue + "' and SUBSTRING(temprollno,1,4)='" + Year.SelectedValue.Substring(2, 2) + drpTo.SelectedValue + "'";
                int count = Convert.ToInt32(ss.GetNewCode(query));



                for (int i = 0; i < int.Parse(ExamView.Rows.Count.ToString()); i++)
                {
                    CheckBox myCheckBox = (CheckBox)ExamView.Rows[i].FindControl("CheckBox1");
                    Label lblStreamCode = (Label)ExamView.Rows[i].FindControl("lblStreamCode");
                    Label lblRegno = (Label)ExamView.Rows[i].FindControl("lblRegno");
                    univrollno = ExamView.Rows[i].Cells[1].Text;
                    midno = univrollno.Substring(2, 2);
                    ddlyear = univrollno.Substring(0, 2);
                    autono = univrollno.Substring(4, 3);
                    
                    //new univ roll no (1st time)
                    if (myCheckBox.Checked == true)
                    {
                        midno = drpTo.SelectedValue;
                        count = count + 1;
                        //}
                        univrollno = ddlyear + midno + string.Format("{0:D3}", count);

                        cmd.CommandText = " update Exam set  ClassRollNo='" + univrollno + "', FinalizeDateTime='" + string.Format("{0:MM/dd/yyyy}", System.DateTime.Now) + "' where Regno='" + lblRegno.Text + "' ";
                        ////cmd.CommandText = " update Exam set  UnivRollNo='" + univrollno + "', FinalizeDateTime='" + string.Format("{0:MM/dd/yyyy}", System.DateTime.Now) + "' where Regno='" + ExamView.Rows[i].Cells[2].Text + "' And streamcode='" + ExamView.Rows[i].Cells[6].Text + "' And streampartcode='" + ExamView.Rows[i].Cells[7].Text + "' and ExamYear='" + Year.Text + "' ";
                        cmd.ExecuteNonQuery();
                        
                        // ADD Exam Year in Query - changed on 10 Apr 2012
                        //cmd.CommandText = " update Exam set  UnivRollNo='" + univrollno + "', FinalizeDateTime='" + string.Format("{0:MM/dd/yyyy}", System.DateTime.Now) + "' where Regno='" + ExamView.Rows[i].Cells[2].Text + "' And streamcode='" + ExamView.Rows[i].Cells[6].Text + "' And streampartcode='" + ExamView.Rows[i].Cells[7].Text + "'";
                        
                        //   + " update Exam set  UnivRollNo='" + univrollno + "', FinalizeDateTime='" + string.Format("{0:MM/dd/yyyy}", System.DateTime.Now) + "' where Regno='" + lblRegno.Text + "' and streamcode='" + lblStreamCode.Text + "'  And streampartcode='" + lblStreamPartCode.Text + "'  and ExamYear='" + Year.Text + "' "
                        //+ " update ExamPaperDetail set  UnivRollNo='" + univrollno + "'  where Regno='" + lblRegno.Text + "'  And streampartcode='" + lblStreamPartCode.Text + "' and ExamYear='" + Year.Text + "' ";

                        cmd.CommandText = "  update Registration set temprollno='" + univrollno + "',streamcode='" + midno + "' where  RegNo='" + lblRegno.Text + "' ";
                        cmd.ExecuteNonQuery();


                        cmd.CommandText = " update a set SubPaperCode=c.SubPaperCode,StreamPartCode=c.StreamPartCode from EXAMPAPERDETAIL a inner join COURSEPAPERS b on a.SubPaperCode=b.SubPaperCode inner join COURSEPAPERS c on b.PaperAbbr=c.PaperAbbr and b.StreamPart=c.StreamPart  where c.StreamCode='" + midno + "' and  regno='" + lblRegno.Text + "' ";
                        cmd.ExecuteNonQuery();
                        //add examyear - 10/04/2012
                        cmd.CommandText = " update a set SubPaperCode=c.SubPaperCode,StreamPartCode=c.StreamPartCode from Attendance a inner join COURSEPAPERS b on a.SubPaperCode=b.SubPaperCode inner join COURSEPAPERS c on b.PaperAbbr=c.PaperAbbr and b.StreamPart=c.StreamPart  where c.StreamCode='" + midno + "' and  regno='" + lblRegno.Text + "' ";
                        cmd.ExecuteNonQuery();

                        cmd.CommandText = " update a set SubPaperCode=c.SubPaperCode,StreamPart=c.StreamPartCode from TrBtec a inner join COURSEPAPERS b on a.SubPaperCode=b.SubPaperCode inner join COURSEPAPERS c on b.PaperAbbr=c.PaperAbbr and b.StreamPart=c.StreamPart  where c.StreamCode='" + midno + "' and  regno='" + lblRegno.Text + "' ";
                        cmd.ExecuteNonQuery();
                        
                        //add examyear - 10/04/2012
                        // cmd.CommandText = " update ExamPaperDetail set  UnivRollNo='" + univrollno + "'  where Regno='" + ExamView.Rows[i].Cells[2].Text + "'  And streampartcode='" + ExamView.Rows[i].Cells[7].Text + "' and ExamYear='" + Year.Text + "' ";

                        ////////tran.Commit();
                        //-------------------------------------------------------------
                        //update Current exam status
                        //add examyear - 10/04/2012

                        
                        


                    }
                   

                }
                tran.Commit();
                string popupScript = "<script language='javascript'>" +
                                   " alert('Branch Alloted for students. ')" +
                                    "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);

                
                
            }
        }
        catch (Exception ex)
        {
            tran.Rollback();
            TotStudent.Text = ex.Message;
        }
        finally
        {
            con.Close();
            BindGrid();
        }
    }
}
