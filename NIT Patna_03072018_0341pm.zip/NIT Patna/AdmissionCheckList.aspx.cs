using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AdmissionCheckList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "5")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(Year, "Year", "Select Year from Year where Year >= 2008 order by Year", "Year", "Year");
            CourseValue();


        }
    }
   
    protected void BtnView_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        CR.ReportSource = crs;
        string isOld = "";

        if (ChkIsOld.Checked == true)
        {
            isOld = "Y";
        }
        else
        {
            isOld = "N";
        }

        
        if (CheckBox1.Checked == true)
        {
            CR.SelectionFormula = @"{REGISTRATION.RegYear}='" + Year.Text.Trim() + "' AND {REGISTRATION.StreamCode}='" + StreamCode.SelectedValue.ToString() + "' AND {REGISTRATION.SubCode}='" + SubCode.SelectedValue.ToString() + "' AND {REGISTRATION.IsOld}='" + isOld + "' ";
        }
        else
        {
            CR.SelectionFormula = @"{REGISTRATION.RegYear}='" + Year.Text.Trim() + "' AND {REGISTRATION.CollCode}='" + InstCode.Text.Trim() + "' AND {REGISTRATION.StreamCode}='" + StreamCode.SelectedValue.ToString() + "' AND {REGISTRATION.SubCode}='" + SubCode.SelectedValue.ToString() + "' AND {REGISTRATION.IsOld}='" + isOld + "' ";
            //CR.SelectionFormula = @"{REGISTRATION.RegYear}='" + Year.Text.Trim() + "' AND {REGISTRATION.CollCode}='" + InstCode.Text.Trim() + "' AND {REGISTRATION.StreamCode}='" + StreamCode.SelectedValue.ToString() + "' AND {REGISTRATION.IsOld}='" + isOld + "' ";
            
        }
             CR.RefreshReport();
    }




    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        CourseValue();
    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBox1.Checked == true)
        {
            CollCode.SelectedIndex = 0;
            InstCode.Text = "";
            CollCode.Enabled = false;
            InstCode.Enabled = false;
        }
        else
        {
            CollCode.Enabled = true;
            InstCode.Enabled = true;
        }
    }

    protected void CourseValue()
    {
        PopulateDDL popddl = new PopulateDDL();
        //popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart, StreamPartCode from StreamPart where streamcode='" + StreamCode.SelectedValue + "' and streampartcode in (select distinct streampartcode from exam) order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");


    }
}
