using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class cgpa_analysis : System.Web.UI.Page
{
    Functionreviseed appfn = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "12"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }

            bindexamsession();
        }
    }

    protected void bindexamsession()
    {
        DataSet dsexamsession = appfn.SelectDataset("Select Distinct ExamSession,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4) AS DATETIME) as Examtime From TRMtec order by CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4) AS DATETIME) desc");
        ddlexamsession.DataSource = dsexamsession.Tables[0];
        ddlexamsession.DataTextField = "ExamSession";
        ddlexamsession.DataValueField = "ExamSession";
        ddlexamsession.DataBind();
        ddlexamsession.Items.Insert(0, new ListItem("--Select","0"));
    }
    string examdate = "", month="";
    string Total_PRCredit = "0", CUMERCREDIT = "0", CUMGRDPOINT = "0", TOTALFULLMARKS = "0", TOTALOBTMARKS = "0", TOTALPERCENT = "0", CGPA = "0", STATUS = "";
    protected void btnExport_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        dt.Columns.Add("UnivrollNo");
        dt.Columns.Add("EnrollmentNo");
        dt.Columns.Add("RegNo");
        dt.Columns.Add("ApplicantName");
        dt.Columns.Add("StreamAbbr");
        dt.Columns.Add("Semester");
        dt.Columns.Add("SemNo");
        dt.Columns.Add("SubPaperCode");
        dt.Columns.Add("TOTALPMO");
        dt.Columns.Add("ERCredit");
        dt.Columns.Add("GradePoint");
        dt.Columns.Add("Grade");
        dt.Columns.Add("ExamType");
        dt.Columns.Add("ExamSession");
        dt.Columns.Add("PaperFullMarks");
        dt.Columns.Add("PaperCredit");
        dt.Columns.Add("CA_MSM_TH");
        dt.Columns.Add("TH_ESM");
        dt.Columns.Add("CA_MSM_PT");
        dt.Columns.Add("PT_ESM");
        dt.Columns.Add("LASTSEM");

        // temp storage creation for finalconsolidated data

        DataTable dtfinalmarks = new DataTable();
        dtfinalmarks.Columns.Add("ROLLNO");
        dtfinalmarks.Columns.Add("ENROLLMENT_NO");
        dtfinalmarks.Columns.Add("APPLICANT_NAME");
        dtfinalmarks.Columns.Add("PROGRAM");
        dtfinalmarks.Columns.Add("LASTSEMESTER");
        dtfinalmarks.Columns.Add("CUM_PAPER_CREDIT");
        dtfinalmarks.Columns.Add("CUM_ER_CREDIT");
        dtfinalmarks.Columns.Add("TOTAL_GRADEPOINT");
        dtfinalmarks.Columns.Add("TOTAL_FULLMARKS");
        dtfinalmarks.Columns.Add("TOTAL_OBT_MARKS");
        dtfinalmarks.Columns.Add("TOTAL_PERCENT");
        dtfinalmarks.Columns.Add("CGPA");
        dtfinalmarks.Columns.Add("STATUS");
        dtfinalmarks.Columns.Add("TILL_EXAMSESSION");

        
        DataTable filterdt = new DataTable();
        filterdt = dt.Clone();
        
        if (ddlexamsession.SelectedItem.ToString().Substring(4, 3) == "JAN")
            month = "01";
        else if (ddlexamsession.SelectedItem.ToString().Substring(4, 3) == "JUN")
            month = "06";
        else if (ddlexamsession.SelectedItem.ToString().Substring(4, 3) == "JUL")
            month = "07";
        else if (ddlexamsession.SelectedItem.ToString().Substring(4, 3) == "DEC")
            month = "12";
        else if (ddlexamsession.SelectedItem.ToString().Substring(4, 3) == "MAY")
            month = "05";
        examdate = ddlexamsession.SelectedItem.ToString().Substring(8, 4)+"-"+month+"-01 00:00:00.000";
        DataSet dsstudentlist = appfn.SelectDataset("SELECT DISTINCT REGISTRATION.AckNo, REGISTRATION.ApplicantName, TRMtec.RegNo, TRMtec.UnivRollNo FROM " +
            " REGISTRATION INNER JOIN TRMtec ON REGISTRATION.RegNo = TRMtec.RegNo WHERE TRMtec.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "' ");
        if (dsstudentlist.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < dsstudentlist.Tables[0].Rows.Count; i++)
            {
                //if (dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() == "01200800349")
                //{
                //    string sfind = "break";
                //}
                DataSet dslastsem = appfn.SelectDataset("WITH CTE AS (SELECT Distinct TRMtec.StreamPart, TRMtec.ExamSession,STREAMPART.StreamPart AS Semester,case When Len(STREAMPART.StreamPart) = 6 and " +
                    " SUBSTRING(STREAMPART.StreamPart,6,1)= '0' then 10 else SUBSTRING(STREAMPART.StreamPart,5,1) end as semno FROM TRMtec INNER JOIN STREAMPART ON TRMtec.StreamPart = STREAMPART.StreamPartCode " +
                    " WHERE TRMtec.RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "' " +
                    " and ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "') Select distinct Examsession, Semno as LAST_SEMNO From CTE");
               
                if (dslastsem.Tables[0].Rows.Count > 0)
                {
                    for (int t = 0; t < dslastsem.Tables[0].Rows.Count;t++)
                    {
                        DataSet studPredetails = appfn.SelectDataset("WITH cte AS (SELECT CollCode, TRMtec.StreamCode, TRMtec.StreamPart, ExamYear, ExamHeldDate, UnivRollNo, EName, HName, FatherName, MotherName, Gender, RegNo, TRMtec.SubPaperCode, " +
                        " CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, ER_CREDIT as Grade_Point, case when UPPER(Grade)='I' OR UPPER(Grade)='X' OR UPPER(Grade)='F' OR " +
                        " Grade='' then 0 else Credit end as  ER_CREDIT, Pass, Promoted, Failed, Grade, Remarks,ExamType, GrandTotal, TotalPercentage, " +
                        " ExamSession, CAST(SUBSTRING(ExamSession, 5, 3) + SUBSTRING(ExamSession, 9, 4) AS DATETIME) AS ExamTime FROM TRMtec inner join COURSEPAPERS cour on " +
                        " TRMtec.SubPaperCode=cour.SubPaperCode WHERE (CAST(SUBSTRING(ExamSession, 5, 3) + SUBSTRING(ExamSession, 9, 4) AS DATETIME) <= '" + examdate + "') and " +
                        " RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "' UNION SELECT CollCode, StreamCode, StreamPart, ExamYear, ExamHeldDate, UnivRollNo, " +
                        " EName, HName, FatherName, MotherName, Gender, RegNo, SubPaperCode, CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, Total_PMO, Grade_Point, ER_CREDIT, " +
                        " Pass, Promoted, Failed, Grade, Remarks, ExamType, GrandTotal, TotalPercentage, ExamSession, CAST(SUBSTRING(ExamSession, 5, 3) + SUBSTRING(ExamSession, 9, 4) AS " +
                        " DATETIME) AS ExamTime FROM TRMtec_old WHERE (CAST(SUBSTRING(ExamSession, 5, 3) + SUBSTRING(ExamSession, 9, 4) AS DATETIME) <= '" + examdate + "') and " +
                        " RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "') SELECT cte_1.CollCode, cte_1.StreamCode, cte_1.StreamPart, cte_1.ExamYear, cte_1.ExamHeldDate, " +
                        " cte_1.UnivRollNo, cte_1.EName, cte_1.HName, cte_1.FatherName, cte_1.MotherName, cte_1.Gender, cte_1.RegNo, cte_1.SubPaperCode, cte_1.CA_MSM_TH, cte_1.TH_ESM, cte_1.TH_PMO, " +
                        " cte_1.CA_MSM_PT, cte_1.PT_ESM, cte_1.PT_PMO, cte_1.Total_PMO, cte_1.Grade_Point, cte_1.ER_CREDIT, cte_1.Pass, cte_1.Promoted, cte_1.Failed, cte_1.Grade, cte_1.Remarks, cte_1.ExamType, " +
                        " cte_1.GrandTotal, cte_1.TotalPercentage, cte_1.ExamSession, STREAMPART.StreamPart AS Semester, SUBSTRING(STREAMPART.StreamPart, 5, 1) AS semno, " +
                        " STREAM.StreamAbbr, CONVERT(float, COURSEPAPERS.FullMarks) + CONVERT(float, ISNULL(PRACTICALPAPERS.FullMarks, 0)) AS TotalPapermarks, COURSEPAPERS.Credit " +
                        " FROM cte AS cte_1 INNER JOIN STREAMPART ON cte_1.StreamPart = STREAMPART.StreamPartCode INNER JOIN STREAM ON cte_1.StreamCode = STREAM.StreamCode INNER JOIN " +
                        " COURSEPAPERS ON cte_1.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                        " WHERE (cte_1.RegNo = '" + dsstudentlist.Tables[0].Rows[i]["RegNo"].ToString() + "') AND (case When Len(STREAMPART.StreamPart) = 6 and  SUBSTRING(STREAMPART.StreamPart,6,1)= '0' then 10 else SUBSTRING(STREAMPART.StreamPart,5,1) end BETWEEN '1' " +
                        " AND '" + dslastsem.Tables[0].Rows[t]["LAST_SEMNO"].ToString() + "') ORDER BY cte_1.ExamTime DESC");

                        if (studPredetails.Tables[0].Rows.Count > 0)
                        {
                            for (int j = 0; j < studPredetails.Tables[0].Rows.Count; j++)
                            {
                                DataRow[] dr = studPredetails.Tables[0].Select("SubPaperCode = '" + studPredetails.Tables[0].Rows[j]["SubPaperCode"].ToString() + "'");
                                if (dr.Length > 1)
                                {
                                    DataRow[] dr3 = filterdt.Select("SubPaperCode = '" + dr[0]["SubPaperCode"].ToString() + "'");
                                    if (dr3.Length == 0)
                                    {
                                        DataRow dr5 = filterdt.NewRow();
                                        dr5[0] = dr[0]["UnivRollNo"].ToString();
                                        dr5[1] = dsstudentlist.Tables[0].Rows[i]["AckNo"].ToString();
                                        dr5[2] = dr[0]["RegNo"].ToString();
                                        dr5[3] = dr[0]["EName"].ToString();
                                        dr5[4] = dr[0]["StreamAbbr"].ToString();
                                        dr5[5] = dr[0]["Semester"].ToString();
                                        dr5[6] = dr[0]["semno"].ToString();
                                        dr5[7] = dr[0]["SubPaperCode"].ToString();
                                        dr5[8] = dr[0]["Total_PMO"].ToString();
                                        dr5[9] = dr[0]["ER_CREDIT"].ToString();
                                        dr5[10] = dr[0]["Grade_Point"].ToString();
                                        dr5[11] = dr[0]["Grade"].ToString();
                                        dr5[12] = dr[0]["ExamType"].ToString();
                                        dr5[13] = dr[0]["ExamSession"].ToString();
                                        dr5[14] = dr[0]["TotalPapermarks"].ToString();
                                        dr5[15] = dr[0]["Credit"].ToString();
                                        dr5[16] = dr[0]["CA_MSM_TH"].ToString();
                                        dr5[17] = dr[0]["TH_ESM"].ToString();
                                        dr5[18] = dr[0]["CA_MSM_PT"].ToString();
                                        dr5[19] = dr[0]["PT_ESM"].ToString();
                                        dr5[20] = dslastsem.Tables[0].Rows[t]["LAST_SEMNO"].ToString();
                                        filterdt.Rows.Add(dr5);
                                    }

                                }
                                else
                                {
                                    DataRow dr1 = dt.NewRow();
                                    dr1[0] = dr[0]["UnivRollNo"].ToString();
                                    dr1[1] = dsstudentlist.Tables[0].Rows[i]["AckNo"].ToString();
                                    dr1[2] = dr[0]["RegNo"].ToString();
                                    dr1[3] = dr[0]["EName"].ToString();
                                    dr1[4] = dr[0]["StreamAbbr"].ToString();
                                    dr1[5] = dr[0]["Semester"].ToString();
                                    dr1[6] = dr[0]["semno"].ToString();
                                    dr1[7] = dr[0]["SubPaperCode"].ToString();
                                    dr1[8] = dr[0]["Total_PMO"].ToString();
                                    dr1[9] = dr[0]["ER_CREDIT"].ToString();
                                    dr1[10] = dr[0]["Grade_Point"].ToString();
                                    dr1[11] = dr[0]["Grade"].ToString();
                                    dr1[12] = dr[0]["ExamType"].ToString();
                                    dr1[13] = dr[0]["ExamSession"].ToString();
                                    dr1[14] = dr[0]["TotalPapermarks"].ToString();
                                    dr1[15] = dr[0]["Credit"].ToString();
                                    dr1[16] = dr[0]["CA_MSM_TH"].ToString();
                                    dr1[17] = dr[0]["TH_ESM"].ToString();
                                    dr1[18] = dr[0]["CA_MSM_PT"].ToString();
                                    dr1[19] = dr[0]["PT_ESM"].ToString();
                                    dr1[20] = dslastsem.Tables[0].Rows[t]["LAST_SEMNO"].ToString();
                                    dt.Rows.Add(dr1);
                                }
                            }
                            dt.Merge(filterdt);
                            if (dt.Rows.Count > 0)
                            {
                                DataTable dtdistinct = dt.DefaultView.ToTable(true, "RegNo");
                                for (int k = 0; k < dtdistinct.Rows.Count; k++)
                                {
                                    DataRow[] dr = dt.Select("RegNo = '" + dtdistinct.Rows[k]["RegNo"].ToString() + "'");
                                    if (dr.Length > 0)
                                    {
                                        for (int l = 0; l < dr.Length; l++)
                                        {
                                            Total_PRCredit = (float.Parse(Total_PRCredit) + float.Parse(dr[l]["PaperCredit"].ToString() == "" ? "0" : dr[l]["PaperCredit"].ToString())).ToString();
                                            CUMERCREDIT = (float.Parse(CUMERCREDIT) + float.Parse(dr[l]["ERCredit"].ToString() == "" ? "0" : dr[l]["ERCredit"].ToString())).ToString();
                                            CUMGRDPOINT = (float.Parse(CUMGRDPOINT) + float.Parse(dr[l]["GradePoint"].ToString() == "" ? "0" : dr[l]["GradePoint"].ToString())).ToString();
                                            TOTALFULLMARKS = (float.Parse(TOTALFULLMARKS) + float.Parse(dr[l]["PaperFullMarks"].ToString() == "" ? "0" : dr[l]["PaperFullMarks"].ToString())).ToString();
                                            TOTALOBTMARKS = (float.Parse(TOTALOBTMARKS) + float.Parse(dr[l]["CA_MSM_TH"].ToString() == "" ? "0" : dr[l]["CA_MSM_TH"].ToString()) +
                                                float.Parse(dr[l]["TH_ESM"].ToString() == "" ? "0" : dr[l]["TH_ESM"].ToString()) +
                                                float.Parse(dr[l]["CA_MSM_PT"].ToString() == "" ? "0" : dr[l]["CA_MSM_PT"].ToString()) +
                                                float.Parse(dr[l]["PT_ESM"].ToString() == "" ? "0" : dr[l]["PT_ESM"].ToString())).ToString();

                                        }
                                        if (CUMERCREDIT.ToString() == Total_PRCredit.ToString())
                                        {
                                            CGPA = (float.Parse(CUMGRDPOINT) / float.Parse(CUMERCREDIT)).ToString();
                                            STATUS = "p";
                                        }
                                        else
                                        {
                                            CGPA = "";
                                            STATUS = "F";
                                        }
                                        TOTALPERCENT = ((float.Parse(TOTALOBTMARKS) / float.Parse(TOTALFULLMARKS)) * 100).ToString();

                                        dtfinalmarks.Rows.Add(dr[0]["UnivrollNo"].ToString(), dr[0]["EnrollmentNo"].ToString(), dr[0]["ApplicantName"].ToString(),
                                         dr[0]["StreamAbbr"].ToString(), dr[0]["LASTSEM"].ToString(), Total_PRCredit, CUMERCREDIT, CUMGRDPOINT, TOTALFULLMARKS, TOTALOBTMARKS, TOTALPERCENT,
                                         CGPA, STATUS, dslastsem.Tables[0].Rows[t]["Examsession"].ToString());

                                    }
                                    Total_PRCredit = "0"; CUMERCREDIT = "0"; CUMGRDPOINT = "0"; TOTALFULLMARKS = "0"; TOTALOBTMARKS = "0"; TOTALPERCENT = "0"; CGPA = "0"; STATUS = "";
                                    dt.Rows.Clear(); filterdt.Rows.Clear();
                                }
                                dtdistinct.Rows.Clear();
                            }
                        }
                    }
            }
            }
            

            GridView GridView1 = new GridView();
            GridView1.AllowPaging = false;
            GridView1.DataSource = dtfinalmarks;
            GridView1.DataBind();
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=Consolidated_Data_Sessionwise_" + DateTime.Now + ".xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                //Apply text style to each Row
                GridView1.Rows[i].Attributes.Add("class", "textmode");

            }
            GridView1.RenderControl(hw);
            //style to format numbers to string
            string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End(); 
        }
    }
    protected void ddlexamsession_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataSet dsstream = appfn.SelectDataset("SELECT DISTINCT STREAMPART.StreamPart FROM EXAMPAPERDETAIL INNER JOIN STREAMPART ON " + 
            " EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode WHERE EXAMPAPERDETAIL.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "' " + 
            " order by STREAMPART ");
        ddlstreamcode.DataSource = dsstream.Tables[0];
        ddlstreamcode.DataTextField = "StreamPart";
        ddlstreamcode.DataValueField = "StreamPart";
        ddlstreamcode.DataBind();
        ddlstreamcode.Items.Insert(0, new ListItem("--Select--", "0"));
    }   
    }

