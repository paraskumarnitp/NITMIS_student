using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class ViewRejectedRegistration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(Year, "Year", "Select Year from Year where year > '2006' order by Year", "Year", "Year");
             
            

        }
    }
    protected void BtnView_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true; 
        BindGrid();


    }
    void BindGrid()
    {
        DataSet ds = new DataSet();
        string SQL = "SELECT  REGISTRATION.AckNo , REGISTRATION.RegFormNo, REGISTRATION.ApplicantName, REGISTRATION.FatherName, REGISTRATION.DOB, " +
                    "RejectedRegistration.ReasonOfRejection FROM         REGISTRATION LEFT OUTER JOIN RejectedRegistration ON REGISTRATION.AckNo = RejectedRegistration.AckNo " +
                    "WHERE     (REGISTRATION.VerifySUDateTime IS NULL) and Registration.CollCode='" + CollCode.SelectedValue.ToString() + "' and  YEAR(CollegeAdmissionDate) ='" + Year.SelectedValue.ToString() + "'";

        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, SQL) ;
        RegView.DataSource = ds;
        RegView.DataBind();
        TotStudent.Text = RegView.Rows.Count.ToString();
    }
}
