using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using Microsoft.Reporting.WebForms; 

public partial class CollegeCategoryStudentDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(Year, "Year", "Select Year from Year where year >= '2009' order by Year", "Year", "Year");
        }
    }
    protected void BtnView_Click(object sender, EventArgs e)
    {
        
        if (RadioButton2.Checked)
        {
            Panel1.Visible = true;
            CR.ReportSource = crs2;
            CR.SelectionFormula = " {REGISTRATION.RegYear}='" + Year.SelectedValue + "' ";
            CR.RefreshReport();
        }
        else
        {
            getData();
            CR.SelectionFormula = " {RegMISCasteCategory.Year}='" + Year.SelectedValue + "' ";
            Panel1.Visible = true;
            CR.ReportSource = crs;
            CR.RefreshReport();
        }
        
        //RV.ServerReport.ReportPath = "/UniversityReport/CategoryStudentDetails";
        //ReportParameter[] rp;
        //rp = new ReportParameter[1];
        //rp = new ReportParameter[2];

        //rp[0] = new ReportParameter("CollCode", CollCode.SelectedValue);
        //rp[1] = new ReportParameter("year", Year.SelectedValue);
        //RV.ServerReport.SetParameters(rp);

        //-----------------------------------------------------------------------------
        // Written Into text file

        //TextWriter tw = new StreamWriter(Server.MapPath(@"Report\CollegeCategoryStudentDetails.htm"));
        
        //tw.WriteLine("<HTML>");
        //tw.WriteLine("<HEAD>");
        //tw.WriteLine("<link rel='stylesheet' type='text/css' href='style.css'>");
        //tw.WriteLine("<TITLE>Report :: CollegeCategoryStudentDetails</TITLE>");
        //tw.WriteLine("<style>");
        //tw.WriteLine(".noprint, .print {display:none;}");
        //tw.WriteLine("@media screen {");
        //tw.WriteLine(".noprint, .printns {display:block;}");
        //tw.WriteLine(".print {display:none;}");
        //tw.WriteLine("}");
        //tw.WriteLine("@media print {");
        //tw.WriteLine(".print {display:block;}");
        //tw.WriteLine(".noprint, .printns, {display:none;}");
        //tw.WriteLine("}");
        //tw.WriteLine("</style>");


        //tw.WriteLine("</HEAD>");
        //tw.WriteLine("<body topmargin='0' marginheight='0' marginwidth='0' bottommargin='0' leftmargin='0' rightmargin='0'>");
        //tw.WriteLine("<table width='720' border='0' cellpadding='4' cellspacing='3'>");
        //tw.WriteLine("<tr>");
        //tw.WriteLine("<td valign='top'>");
        //tw.WriteLine("<table width='720' align='center'>");
        //tw.WriteLine("<tr>");
        //tw.WriteLine("<td class='heading'>Magadh University , Gaya </td>");
        //tw.WriteLine("</tr>");
        


        //tw.WriteLine("</table>");
        //tw.WriteLine("<br>");
        ////tw.WriteLine("</td>");
        ////tw.WriteLine("</tr>");
        ////tw.WriteLine("</table>");
        //// Table2 Begin
        //tw.WriteLine("<table width='720' border='0'>");
        //tw.WriteLine("<tr> <td colspan='7' align='center' id='subhead'>College Category Wise Student Details (Year - " + Year.SelectedValue + ")  <p></p></td></tr>");
        //tw.WriteLine("<tr class='main'>");


        //tw.WriteLine("<td>College Name </td>");
        //tw.WriteLine("<td>General</td>");
        //tw.WriteLine("<td>OBC</td>");
        //tw.WriteLine("<td>SC</td>");
        //tw.WriteLine("<td>ST</td>");
        //tw.WriteLine("<td>Others</td>");
        //tw.WriteLine("<td>Total Students</td>");



        //tw.WriteLine("</tr>");


        //tw.WriteLine(getData());

        //tw.WriteLine("</table>");


        ////Table2 Close


        //tw.WriteLine("<table width='720' align='center' >");
        //tw.WriteLine("<tr><td align='center'><p id='sml'><br>IT Solution Provided by National Informatics Centre, Bihar State Center, Patna </p>  </td>");
        //tw.WriteLine("</tr>");
        //tw.WriteLine("<tr><td valign='top'>");
        //tw.WriteLine("<div class='printns' align='Center'><a href='javascript:window.print()'><img src='Print.gif' alt='Print' width='110' height='25' border='0'></a></div>");
        //tw.WriteLine("</td></tr>");

        //tw.WriteLine("</table>");
        //tw.WriteLine("</td>");
        //tw.WriteLine("</tr>");
        //tw.WriteLine("</table>");
        //tw.WriteLine("</body>");
        //tw.WriteLine("</html>");

        //tw.Close();

        ////System.Diagnostics.Process.Start(Server.MapPath(@"Report\test.htm"));
        //string s = "window.open('report/CollegeCategoryStudentDetails.htm','Default','height=600,width=800,status=yes,toolbar=no,menubar=no,location=no'); ";

        //string popupScript = "<script language='javascript'>" + s + "</script>";

        //Page.RegisterStartupScript("PopupScript", popupScript);

    }

    protected void getData()
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        con.Open();
        cmd.CommandText = "select distinct collcode from registration where regyear='" + Year.SelectedValue + "' ";
        SqlDataReader sdr;
        sdr = cmd.ExecuteReader();
        string gen = "", obc = "", bc = "", sc = "", st = "", oth = "", tot = "";
        string gencountm = "", obccountm = "", sccountm = "", stcountm = "", bccountm = "", totmale = "", othmale="";

        UnivService.Service1 ss = new UnivService.Service1();
        string str = "";
        
        //Delete from table


        str=ss.GetNewCode("Delete from RegMisCasteCategory");

        while (sdr.Read())
        {

            gen = ss.GetNewCode("select count(1) from registration where castcode='01' and Collcode='" + sdr[0].ToString() + "' and regyear='" + Year.SelectedValue + "' and regno is not null");
            gencountm = ss.GetNewCode("select count(1) from registration  where castcode='01' and Collcode='" + sdr[0].ToString() + "' and regyear='" + Year.SelectedValue + "' and gender='M' and regno is not null");
            obc = ss.GetNewCode("select count(1) from registration where castcode='02' and Collcode='" + sdr[0].ToString() + "' and regyear='" + Year.SelectedValue + "' and regno is not null");
            obccountm = ss.GetNewCode("select count(1) from registration  where castcode='02' and Collcode='" + sdr[0].ToString() + "' and regyear='" + Year.SelectedValue + "' and gender='M' and regno is not null");
            sc = ss.GetNewCode("select count(1) from registration where castcode='03' and Collcode='" + sdr[0].ToString() + "'  and regyear='" + Year.SelectedValue + "' and regno is not null");
            sccountm = ss.GetNewCode("select count(1) from registration  where castcode='03' and Collcode='" + sdr[0].ToString() + "' and regyear='" + Year.SelectedValue + "' and gender='M' and regno is not null");
            st = ss.GetNewCode("select count(1) from registration where castcode='04' and Collcode='" + sdr[0].ToString() + "'  and regyear='" + Year.SelectedValue + "' and regno is not null");
            stcountm = ss.GetNewCode("select count(1) from registration  where castcode='04' and Collcode='" + sdr[0].ToString() + "' and regyear='" + Year.SelectedValue + "' and gender='M' and regno is not null");
            bc = ss.GetNewCode("select count(1) from registration where castcode='05' and Collcode='" + sdr[0].ToString() + "'  and regyear='" + Year.SelectedValue + "' and regno is not null");
            bccountm = ss.GetNewCode("select count(1) from registration  where castcode='05' and Collcode='" + sdr[0].ToString() + "' and regyear='" + Year.SelectedValue + "' and gender='M' and regno is not null");            
            
            //Total Student Count
            tot = ss.GetNewCode("select count(1) from registration  where Collcode='" + sdr[0].ToString() + "'and regyear='" + Year.SelectedValue + "' and regno is not null");
            int oth1 = int.Parse(tot) - (int.Parse(gen) + int.Parse(obc) + int.Parse(bc) + int.Parse(sc) + int.Parse(st));
            oth = oth1.ToString();
            
            //Total Male Count

            totmale = ss.GetNewCode("select count(1) from registration  where Collcode='" + sdr[0].ToString() + "'and regyear='" + Year.SelectedValue + "' and gender='M' and regno is not null");
            int othmale1 = int.Parse(totmale) - (int.Parse(gencountm) + int.Parse(obccountm) + int.Parse(bccountm) + int.Parse(sccountm) + int.Parse(stcountm));
            othmale = othmale1.ToString();





            //Save in Table 

            string[] col = new string[14];
            string[] val = new string[14];

            col[0] = "CollCode";
            col[1] = "General";
            col[2] = "GeneralM";
            col[3] = "BC";
            col[4] = "BCM";
            col[5] = "OBC";
            col[6] = "OBCM";
            col[7] = "SC";
            col[8] = "SCM";
            col[9] = "ST";
            col[10] = "STM";
            col[11] = "Others";
            col[12] = "OthersM";
            col[13] = "Year";

            val[0] = sdr[0].ToString();
            val[1] = gen;
            val[2] = gencountm;
            val[3] = bc;
            val[4] = bccountm;
            val[5] = obc;
            val[6] = obccountm;
            val[7] = sc;
            val[8] = sccountm;
            val[9] = st;
            val[10] = stcountm;
            val[11] = oth;
            val[12] = othmale;
            val[13] = Year.SelectedValue; 

           
            string abc = ss.SaveData("RegMISCasteCategory", col, val);
            

        }
        
        
        sdr.Dispose();
        con.Close();


    }

}
