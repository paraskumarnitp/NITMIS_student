using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class UpdateAdmissionrefundaccount : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmitLogin_Click(object sender, EventArgs e)
    {
        try
        {
            DateTime dob = Convert.ToDateTime(txt_dob.Text.Trim());
            string date = dob.ToString("yyyy-MM-dd");
            string strWhere = string.Empty;
            LblMsg.Text = string.Empty;
                        
       
                DataTable dt = new DataTable();
                dt = fnrev.SelectDatatable("SELECT Receipt_Challan_No, AccountNo, IFSC, AccountHolderName, " + 
                    " branchname, BranchDetails, ProcessDatetime FROM PrePaymentDetails WHERE " +
              " (SelectionRollNo = '" + txtackno.Text.Trim().ToString() + "') AND " +
              " ( DOB = '" + dob + "') AND " +
              " (AccountNo <>'NIL')");
                if (dt.Rows.Count > 0)
                {
                    accountno.Text = dt.Rows[0]["AccountNo"].ToString();
                    ifsccode.Text = dt.Rows[0]["IFSC"].ToString();
                    accountholder.Text = dt.Rows[0]["AccountHolderName"].ToString();
                    branchname.Text = dt.Rows[0]["branchname"].ToString();
                    branchdetails.Text = dt.Rows[0]["BranchDetails"].ToString(); checquedetails.Visible = true;                   
                }
                else
                {
                    LblMsg.Text = "No Record(S) Found.";
                    return;
                }

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.ToString();
        }
        finally
        {
            //con.Close();
        }
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {

    }
}
