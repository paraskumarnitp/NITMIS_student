using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class ViewCoursePapers : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamCode, "Stream", "Select * from Stream order by Stream", "Stream", "StreamCode");
            //popddl.Popualate(StreamPartCode, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart where StreamCode='" + StreamCode.SelectedValue + "' order by StreamPart", "StreamPart", "StreamPartCode");
            popddl.Popualate(SubCode, "Subject", "Select subcode,SubjectName from Subject order by SubjectName", "SubjectName", "subCode");
        }
       

    }
    protected void BtnCourse_Click(object sender, EventArgs e)
    {
        DataSet ds = new DataSet();
        string SqlQuery = "SELECT     dbo.COURSEPAPERS.SubPaperCode, dbo.PaperType.PaperType,  dbo.COURSEPAPERS.PaperAbbr,dbo.COURSEPAPERS.FullMarks, dbo.COURSEPAPERS.PassMarks, dbo.PRACTICALPAPERS.FullMarks AS PraMarks1, " +
                          " dbo.PRACTICALPAPERS.PassMarks AS PraMarks2 FROM     dbo.COURSEPAPERS INNER JOIN " +
                          " dbo.SUBJECT ON dbo.COURSEPAPERS.SubCode = dbo.SUBJECT.SubCode INNER JOIN " +
                          " dbo.PaperType ON dbo.COURSEPAPERS.PaperTypeCode = dbo.PaperType.PaperTypeCode LEFT OUTER JOIN " +
                          " dbo.PRACTICALPAPERS ON dbo.COURSEPAPERS.SubPaperCode = dbo.PRACTICALPAPERS.SubPaperCode " +
                          " where (dbo.COURSEPAPERS.StreamCode='" + StreamCode.SelectedValue + "'and dbo.COURSEPAPERS.streamPartCode='" + StreamPartCode.SelectedValue + "' and dbo.COURSEPAPERS.SubCode='" + SubCode.SelectedValue + "') ORDER BY PaperType.PaperType";
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, SqlQuery);
        CoursePaperView.DataSource = ds;
        CoursePaperView.DataBind();
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl=new PopulateDDL() ;
        
        popddl.Popualate(StreamPartCode, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart where StreamCode='" + StreamCode.SelectedValue + "' order by StreamPart", "StreamPart", "StreamPartCode");

    }
    protected void StreamPartCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        
    }
}
