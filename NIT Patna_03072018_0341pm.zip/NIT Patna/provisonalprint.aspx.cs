using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using System.IO;

public partial class provisonalprint : System.Web.UI.Page
{
    Functionreviseed fn = new Functionreviseed();
    ReportDocument crystalReport = new ReportDocument();
    string streamcode, streampartcode, examyear, str, univrollno, crt, sem, stmtp;
    protected void Page_Load(object sender, EventArgs e)
    {
        crt = Request.QueryString["crt"];
        streamcode = Request.QueryString["sc"];
        streampartcode = Request.QueryString["spc"];
        examyear = Request.QueryString["ey"];
        univrollno = Request.QueryString["r"];
        sem = Request.QueryString["sem"];
        stmtp = Request.QueryString["stmtp"];
        btechgrade();
    }
    protected void Page_Unload(object sender, EventArgs e)
    {
        if (crystalReport != null)
        {
            crystalReport.Close();
            crystalReport.Dispose();
        }

    }
    protected void btechgrade()
    {
        crystalReport.Load(Server.MapPath("~/Report/Provisional.rpt"));
        if (univrollno != "")
            crystalReport.SetParameterValue(0, null);
        else
            crystalReport.SetParameterValue(0, streamcode);
        crystalReport.SetParameterValue(1, examyear);
        crystalReport.SetParameterValue(2, univrollno);

        string filename = univrollno != "" ? univrollno : examyear;
        MemoryStream oStream = new MemoryStream();
        oStream = (MemoryStream)crystalReport.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
        Response.Clear();
        Response.Buffer = true;
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "inline;filename=" + filename + ".pdf");
        Response.BinaryWrite(oStream.ToArray());
        Response.End();
    }
}
       
        
        
    

   





    //protected void Page_LoadComplete(object sender, EventArgs e)
    //{
    //    CrystalReportViewer1.ReportSource = Session["btechgrage"];
    //}

