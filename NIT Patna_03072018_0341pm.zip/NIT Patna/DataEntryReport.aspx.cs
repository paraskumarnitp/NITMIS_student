using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class DataEntryReport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "6")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
                //Calendar1.SelectedDate = System.DateTime.Now;
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(ExamYear, "Year", "Select Year from Year where Year > '2008'  order by Year", "Year", "Year");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream where streamcode in (select distinct streamcode from registration) order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(DDLUserID, "Registration", "Select distinct Userid from registration order by UserID", "Userid", "Userid");
                


        }
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {

    }


    void BindGrid()
    {
        Panel2.Visible = true;
      
        string sql = "";
        //sql = "select row_number() OVER (order by convert (varchar,entryoptdatetime,103),userid) as  SLNO, count(1),userid,convert (varchar,entryoptdatetime,103) AS CreateDate  " +
        //"from registration where regyear='2009' and streamcode='04'  and userid='ex013' and entryoptdatetime > '05/18/2010' and  entryoptdatetime < '05/20/2010'  " +
        //"group by userid,convert (varchar,entryoptdatetime,103) order by createdate,userid";

        string where = "";

        where += " Where Login.Userid=registration.userid  and regyear=" + ExamYear.SelectedValue;
        where += " and streamcode='" + StreamCode.SelectedValue + "' ";

        if (CheckBox1.Checked != true)
           where += " and registration.userid='" + DDLUserID.SelectedValue + "' ";
        if (Date1.Text != "")
           where += " and entryoptdatetime >= '" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(Date1.Text)) + "' ";
        if (Date2.Text != "")
            where += " and entryoptdatetime <= '" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(Date2.Text)) + "' ";
                



        //sql = "select row_number() OVER (order by convert (varchar,entryoptdatetime,103),registration.userid) as  SLNO, convert (varchar,entryoptdatetime,103) AS CreateDate,registration.userid as USERID,LogIn.UserName as NAME,count(1) as Total "+
        //"from Registration,LogIn where Login.Userid=registration.userid   and regyear='2009' and streamcode='04'  and registration.userid='ex007' and entryoptdatetime > '05/01/2010' and  entryoptdatetime < '05/20/2010' "+
        //"group by registration.userid,convert (varchar,entryoptdatetime,103),Login.UserName "+
        //"order by createdate,registration.userid";


        sql = "select row_number() OVER (order by convert (varchar,entryoptdatetime,103),registration.userid) as  SLNO, convert (varchar,entryoptdatetime,103) AS CreateDate,registration.userid as USERID,LogIn.UserName as NAME,count(1) as Total " +
        "from Registration,LogIn " + where + " group by registration.userid,convert (varchar,entryoptdatetime,103),Login.UserName order by createdate,registration.userid";


        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        SearchView.DataSource = ds;
        SearchView.DataBind();
    }



    protected void btnView_Click(object sender, EventArgs e)
    {
        SearchView.Visible = true;
        BindGrid();
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBox1.Checked == true)
        {
            DDLUserID.SelectedIndex = 0;
            DDLUserID.Enabled = false;
        }
        else
        {
            DDLUserID.SelectedIndex = 0;
            DDLUserID.Enabled = true;
        }
    }
    protected void SearchView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        SearchView.PageIndex = e.NewPageIndex;
        BindGrid();
    }
}
