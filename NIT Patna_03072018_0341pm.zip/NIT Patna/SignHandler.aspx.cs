using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;

public partial class SignHandler : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString.Count > 0)
            {
                if (Request.QueryString["AckNo"] != null)
                {

                    SqlConnection con = new SqlConnection();
                    con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
                    string AckNo = Request.QueryString["AckNo"].ToString();

                    try
                    {
                        con.Open();
                        SqlCommand cmdSelect = new SqlCommand("select Signature from Registration where AckNo=@AckNo", con);
                        SqlParameter cmdSelectParameters = new SqlParameter("@AckNo", SqlDbType.Char);

                        if (AckNo.Equals(""))
                            cmdSelectParameters.Value = "";
                        else
                            cmdSelectParameters.Value = AckNo;
                        cmdSelect.Parameters.Add(cmdSelectParameters);
                        byte[] barrImg = (byte[])cmdSelect.ExecuteScalar();


                        Response.OutputStream.Write(barrImg, 0, barrImg.Length);
                        Response.OutputStream.Flush();
                    }
                    catch (Exception ex)
                    {
                        Response.WriteFile(Server.MapPath("~\\Image\\UploadSIGN.JPG"));


                    }
                    finally
                    {
                        con.Close();
                    }

                }
            }
        }

    }
}
