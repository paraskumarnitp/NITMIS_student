using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using MarksAuditTableAdapters;
using CrystalDecisions.CrystalReports.Engine;
public partial class AuditTrail : System.Web.UI.Page
{
    
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "11") && (Session["Role"].ToString() != "14") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "15") && (Session["Role"].ToString() != "16"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            
        }
    }

    protected void ViewTR_Click(object sender, EventArgs e)
    {
      MarksAuditTableTableAdapter ma =new MarksAuditTableTableAdapter();
      DataTable dt = ma.GetData((Convert.ToDateTime(frmdt.Text)).ToString("MM/dd/yyyy"), (Convert.ToDateTime(todt.Text)).ToString("MM/dd/yyyy"));
      MarksAudit matable = new MarksAudit();
    
      matable.Tables[0].Merge(dt);
       
       ReportDocument rpt = new ReportDocument();
       rpt.Load(Server.MapPath("~/Report/AuditRegister.rpt"));
        rpt.SetDataSource(matable);
        Response.Write("<SCRIPT language=javascript>var  pdf=window.open('default.aspx','pdf','width=600,height=400');pdf.moveTo(0,0);</SCRIPT>");
        MemoryStream oStream = new MemoryStream();
        oStream = (MemoryStream)rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
        Response.Clear();
        Response.Buffer = true;
        Response.ContentType = "application/pdf";
        Response.BinaryWrite(oStream.ToArray());
        Response.End();

    }
}
