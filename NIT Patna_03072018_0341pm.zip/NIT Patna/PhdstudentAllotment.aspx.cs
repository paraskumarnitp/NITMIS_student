using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;                                                              
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
public partial class PhdstudentAllotment : System.Web.UI.Page
{
 static int memtypecount = 0, comemtypecount = 0, exmemtypecount = 0, eexmemtypecount = 0, cmemtypecount=0;
   static String memberty="";
    static string  memtype="";
    DataRow dr = null;
    DataTable dt1 = new DataTable();
   
    static string userid,uname;
   
    Functionreviseed fnrev = new Functionreviseed();

    protected void Page_Load(object sender, EventArgs e)
           {
        popupcontent.Visible = false;
        Panel2.Visible = false;

      

       Panel3.Visible = false;
    

        if (!Page.IsPostBack)
        {
            userid=" ";
     
        uname = " ";
        saveHOD();

           // Panel4.Visible = true;
            try
            {
                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "9") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "15"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }        
        }

    }




    private void saveHOD()
    {
        try
        {
            string query = "select UserName from LogIn where Userid='" + Session["UserId"].ToString() + "'";
            DataSet dsmasterpaper = new DataSet();
            dsmasterpaper = fnrev.SelectDataset(query);

            string uname = dsmasterpaper.Tables[0].Rows[0]["UserName"].ToString();

            string query1 = "INSERT INTO dscallotment(rollno,regno, membertype,memuserid,member,cuid,ctime) VALUES  ('" + Session["roll"].ToString() + "','" + Session["regno"].ToString() + "','HOD','" + Session["UserId"].ToString() + "','" + uname + "','" + Session["UserId"].ToString() + "',GETDate())";
            fnrev.InsertUpdateDelete(query1);
       
        }
        catch (Exception ex)
        {
        }
    }



    protected void btnsearch_Click(object sender, EventArgs e)
    {
       // Panel4.Visible = true;
       getStudentDetails();
       // txtroll.Enabled = false;
    }


    public void getStudentDetails()
    {
        try
        {
            
 
        }
        catch (Exception ex)
        {
        }
    }


    protected void cmbdsctype_SelectedIndexChanged(object sender, EventArgs e)
    {

        txttype1.Text = "";
         if (cmbdsctype.SelectedIndex == 1)
        {
           
            lbltype.Text = "Supervisor";
             lbltype.Visible = true;
            Panel2.Visible = true;
            //Panel1.Visible = false;
            Panel3.Visible = false;
        }
        else if (cmbdsctype.SelectedIndex == 2)
        {
         
        //   Panel1.Visible = true;
           lbltype.Text = "Co-Supervisor";
            Panel2.Visible = true;
            Panel3.Visible = false;
                        
        }

        else if (cmbdsctype.SelectedIndex == 3)
        {
             Panel2.Visible = true;
            lbltype.Text = "Care Taker :";
              txttype1.Visible = true;
            lbltype.Visible = true;
        }
        else if (cmbdsctype.SelectedIndex == 4)
        {
          //  Panel1.Visible = false;
          
            lbltype.Text = "Expert:";
            Panel2.Visible = true;
          
            lbltype.Visible = true;
          

        }
        else if (cmbdsctype.SelectedIndex == 5)
        {
           
            //Panel1.Visible = false;
            Panel2.Visible = false;
         
            Panel3.Visible = true;
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    
    {

        btnconfirm.Visible = true;

        string query1 = "INSERT INTO phdallotment(rollno,regno, membertype,memuserid,member,cuid,ctime) VALUES  ('" + Session["roll"].ToString() + "','" + Session["regno"].ToString() + "','" + cmbdsctype.SelectedItem.ToString() + "','" + userid + "','" + uname + "','" + Session["UserId"].ToString() + "',GETDate())";
        fnrev.InsertUpdateDelete(query1);
         

            
            Panel2.Visible = false;
          
            grdsup1.Visible = false;
            grdexternal.Visible = false;
            grdsupervisor.Visible = false;
            try
            {

               string strConnString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
               SqlConnection con = new SqlConnection(strConnString);

                dt1.Columns.Add(new DataColumn("id", typeof(int)));
                dt1.Columns.Add(new DataColumn("rollno", typeof(string)));
                dt1.Columns.Add(new DataColumn("regno", typeof(string)));
                dt1.Columns.Add(new DataColumn("membertype", typeof(string)));
                dt1.Columns.Add(new DataColumn("memuserid", typeof(string)));
                dt1.Columns.Add(new DataColumn("member", typeof(string)));
                dt1.Columns.Add(new DataColumn("cuid", typeof(string)));
                dt1.Columns.Add(new DataColumn("ctime", typeof(string)));

                con.Open();

                string query = "select * from phdallotment where rollno='" + Session["roll"].ToString() + "' order by id";

           
               SqlDataReader dr1;
                SqlCommand cmd = new SqlCommand(query, con);

                dr1 = cmd.ExecuteReader();
               
            if  (dr1.Read())
              {


                  dr = dt1.NewRow();
              
              
                    dr["id"] = 1;
                    dr["rollno"] = Session["roll"].ToString();
                    dr["regno"] = Session["regno"].ToString();
                   
                    dr["membertype"] = cmbdsctype.SelectedItem.ToString();
                    dr["memuserid"] = userid;
                    dr["member"] = uname;


                    dr["cuid"] = Session["UserId"].ToString();
                    dr["ctime"] = DateTime.Now.ToString();
                    dt1.Rows.Add(dr);
                    ViewState["phdstudent"] = dt1;
                    grdregdetails.DataSource = dt1;
                    grdregdetails.DataBind();
                
               }
               
                
             

            }
            catch (Exception ex)
            {

            }
            if (cmbdsctype.SelectedItem.ToString() == "Supervisor")
            {
                memberty = "Supervisor";
                memtypecount++;
            }
            if (cmbdsctype.SelectedItem.ToString() == "Co-Supervisor")
            {
                memberty = "Co-Supervisor";
                comemtypecount++;
            }
            if (cmbdsctype.SelectedItem.ToString() == "Care Taker")
            {
                memberty = "Care Taker";
                cmemtypecount++;
            }
            if (cmbdsctype.SelectedItem.ToString() == "Expert")
            {
                memberty = "Expert";
                exmemtypecount++;
            }
            if (cmbdsctype.SelectedItem.ToString() == "External Expert")
            {
                memberty = "External Expert";
                eexmemtypecount++;
            }
    }




    public void bindData()
    {

        dt1.Columns.Add(new DataColumn("id", typeof(int)));
        dt1.Columns.Add(new DataColumn("rollno", typeof(string)));
        dt1.Columns.Add(new DataColumn("regno", typeof(string)));
        dt1.Columns.Add(new DataColumn("membertype", typeof(string)));
        dt1.Columns.Add(new DataColumn("memuserid", typeof(string)));
        dt1.Columns.Add(new DataColumn("member", typeof(string)));
        dt1.Columns.Add(new DataColumn("cuid", typeof(string)));
        dt1.Columns.Add(new DataColumn("ctime", typeof(string)));

                
        string strConnString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlConnection con = new SqlConnection(strConnString);

                string query = "select * from phdallotment where rollno='" + Session["roll"].ToString() + "' order by id";

               // DataSet ds = new DataSet();
               // ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, query);
                con.Open();
               SqlDataReader dr1;
                SqlCommand cmd = new SqlCommand(query, con);

                dr1 = cmd.ExecuteReader();
               
          if   (dr1.Read())
              {


                  dr = dt1.NewRow();
              
              
                    dr["id"] = 1;
                    dr["rollno"] = Session["roll"].ToString();
                    dr["regno"] = Session["regno"].ToString();
                   
                    dr["membertype"] = cmbdsctype.SelectedItem.ToString();
                    dr["memuserid"] = userid;
                    dr["member"] = uname;


                    dr["cuid"] = Session["UserId"].ToString();
                    dr["ctime"] = DateTime.Now.ToString();
                    dt1.Rows.Add(dr);
                    ViewState["phdstudent"] = dt1;
                    grdregdetails.DataSource = dt1;
                    grdregdetails.DataBind();
                
               }

    }
        
protected void BindGridData()
{
  
}
    protected void grdsupervisor_SelectedIndexChanged(object sender, EventArgs e)
    {


   
       // Panel4.Visible = true;
        userid = (grdsupervisor.SelectedRow.FindControl("lbluid") as Label).Text;
        uname = (grdsupervisor.SelectedRow.FindControl("lbluname") as Label).Text;
        
        if (cmbdsctype.SelectedIndex == 2)
        {
            grdsupervisor.Visible = true;
            grdsup1.Visible = true;
           // Panel1.Visible = true;
        }
        grdexternal.Visible = false;
        grdsup1.Visible = false;
    }


    protected void btnsearch1_Click(object sender, EventArgs e)
    {
     //   Panel4.Visible = true;
          grdsup1.Visible = false;
        grdsupervisor.Visible = true;
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select UserId,UserName from LogIn where username like '%"+txttype1.Text.Trim() +"' ");
        grdsupervisor.DataSource = ds;
        grdsupervisor.DataBind(); 

    }



    protected void btnsearch2_Click(object sender, EventArgs e)
    {
     //   Panel4.Visible = true;
        // grdsup1.Visible = true;
        grdsupervisor.Visible = true;
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select UserId,UserName from LogIn where username like '%" + txttype1.Text.Trim() + "' ");
        grdsup1.DataSource = ds;
        grdsup1.DataBind();
        grdsup1.Visible = true;
       // Panel1.Visible = true;

    }
    protected void grdsup1_SelectedIndexChanged(object sender, EventArgs e)
    {
       // Panel4.Visible = true;
        userid = (grdsup1.SelectedRow.FindControl("lbluid1") as Label).Text;
        uname = (grdsup1.SelectedRow.FindControl("lbluname1") as Label).Text;
        if (cmbdsctype.SelectedIndex == 2)
        {
            grdsupervisor.Visible = true;
            grdsup1.Visible = true;
           // Panel1.Visible = true;
        }
           grdsupervisor.Visible = false;
        grdexternal.Visible = false;
    }



  

    protected void btnexternal_Click1(object sender, EventArgs e)
    {
      //  Panel4.Visible = true;
        
        //Panel3.Visible = false;
        grdexternal.Visible = false;

    }
   
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    protected void btnexternal_Click(object sender, EventArgs e)
    {
       // Panel4.Visible = true;
        try
        {
            uname = txtname.Text.Trim();
            string org = txtorgname.Text.Trim();
            string contact = txtcontact.Text.Trim();
            string email = txtemail.Text.Trim();

            string query1 = "INSERT INTO externalexpert(exname,orgname,contact,email) VALUES  ('" + uname + "','" + org + "','" + contact + "','" + email + "')";

            string strConnString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            SqlConnection con = new SqlConnection(strConnString);
            SqlCommand command = new SqlCommand(query1, con);
            con.Open();
            command.ExecuteNonQuery();
            con.Close();
            string query2 = "select max(id) from externalexpert";

            command = new SqlCommand(query2, con);
            con.Open();
            SqlDataReader dr = command.ExecuteReader();
            if (dr.Read())
            {
                userid = dr[0].ToString();
               
            }
            con.Close();
        }
        catch (Exception ex)
        {
        }
     

    }
   

    
    protected void grdregdetails_SelectedIndexChanged(object sender, EventArgs e)
    {
   


    }
    protected void btngetexternal_Click(object sender, EventArgs e)
    {



       

    }
    protected void grdexternal_SelectedIndexChanged(object sender, EventArgs e)
    {
      
        userid = (grdexternal.SelectedRow.FindControl("lblid1") as Label).Text;
        uname= (grdexternal.SelectedRow.FindControl("lblexname") as Label).Text;
         
        grdsup1.Visible = false;
        grdsupervisor.Visible = false;
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
       
        uname = txtname.Text.Trim();
        string org = txtorgname.Text.Trim();
        string contact = txtcontact.Text.Trim();
        string email = txtemail.Text.Trim();

        string query1 = "INSERT INTO externalexpert(exname,orgname,contact,email) VALUES  ('" + uname + "','" + org + "','" + contact + "','" + email + "')";

        fnrev.InsertUpdateDelete(query1);

        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select id,exname,orgname from externalexpert where exname like '%" + uname + "'");
        grdexternal.DataSource = ds;
        grdexternal.DataBind();
       
        grdexternal.Visible = true;


    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
      
        popupcontent.Visible = false;
    }
    protected void btnexsearch_Click(object sender, EventArgs e)
    {
      
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select id,exname,orgname from externalexpert where exname like '%" + txtexternal.Text.Trim() + "'");
        grdexternal.DataSource = ds;
        grdexternal.DataBind();
        grdexternal.Visible = true;
        grdexternal.Visible = true;
    }
    protected void btnaddexternal_Click(object sender, EventArgs e)
    {
      
        popupcontent.Visible = true;
    }
    
    protected void txttype2_TextChanged(object sender, EventArgs e)
    {

    }
    

    protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string roll = grdregdetails.DataKeys[e.Row.RowIndex].Value.ToString();
            GridView grdmember = e.Row.FindControl("gvmember") as GridView;


            grdmember.DataSource = GetData(string.Format("select membertype ,memuserid ,member  from phdallotment where rollno='" + roll + "'  "));
            grdmember.DataBind();
           
        }
    }

    private static DataTable GetData(string query)
    {
        string strConnString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        using (SqlConnection con = new SqlConnection(strConnString))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = query;
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    using (DataSet ds = new DataSet())
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        return dt;
                    }
                }
            }
        }
    }

    protected void btnconfirm_Click(object sender, EventArgs e)
          
        {
            int flag = 0;
            int flag1 = 0;
            try
            {
                String membertype = "", memberid = "", member = "";
                DataTable dt4 = new DataTable();
                dt4 = (DataTable)ViewState["phdstudent"];

                if (ViewState["phdstudent"] != null)
                {
                    dt4 = (DataTable)ViewState["phdstudent"];
                    if (dt4.Rows.Count > 0)
                    {

                        foreach (GridViewRow row in grdregdetails.Rows)
                        {

                            if (row.RowType == DataControlRowType.DataRow)
                            {

                                GridView gvChild = (GridView)row.FindControl("gvmember");

                                for (int j = 0; j < gvChild.Rows.Count; j++)
                                {


                                    Label memtype = (Label)gvChild.Rows[j].Cells[1].FindControl("lblmemtype");
                                    membertype = memtype.Text;
                                    memtype = (Label)gvChild.Rows[j].Cells[2].FindControl("lblmemid");
                                    memberid = memtype.Text;
                                    memtype = (Label)gvChild.Rows[j].Cells[3].FindControl("lblmemname");
                                    member = memtype.Text;

                                    //string query1 = "INSERT INTO dscallotment(rollno,regno, membertype,memuserid,member,cuid,ctime) VALUES  ('" + Session["roll"].ToString() + "','" + Session["regno"].ToString() + "','" + membertype + "','" + memberid + "','" + member + "','" + Session["UserId"].ToString() + "',GETDate())";

                                    //fnrev.InsertUpdateDelete(query1);
                                   
                                    if (memtypecount > 1 || memtypecount <= 0)
                                    {
                                        Label2.Text = " One  " + " Supervisor" + " Allowed";

                                    }
                                    else    if (comemtypecount != 2)
                                    {
                                        Label2.Text = "  Two " + " Co-Supervisor " + " Allowed";

                                    }

                                    else   if (exmemtypecount > 1 || exmemtypecount <= 0)
                                    {
                                        Label2.Text = " One " + " Expert " + " Allowed";

                                    }
                                    else   if (eexmemtypecount > 1 || eexmemtypecount <= 0)
                                    {
                                        Label2.Text = " One " + " External Expert " + " Allowed";

                                    }

                                    else
                                    {

                                        Label2.Text = "";
                                        string query1 = "INSERT INTO dscallotment(rollno,regno, membertype,memuserid,member,cuid,ctime) VALUES  ('" + Session["roll"].ToString() + "','" + Session["regno"].ToString() + "','" + membertype + "','" + memberid + "','" + member + "','" + Session["UserId"].ToString() + "',GETDate())";

                                        fnrev.InsertUpdateDelete(query1);
                                      
                                        flag = 1;
                                    }


                                }


                                if (flag == 1)
                                {

                                    string query2 = "delete from phdallotment";

                                    fnrev.InsertUpdateDelete(query2);
                                    Label3.Text = "DSC alloted Sucessfully..";
                                    memtypecount = 0;
                                    comemtypecount = 0;
                                    exmemtypecount = 0;
                                    eexmemtypecount = 0;
                                    cmemtypecount = 0;

                                }
                            }
                        }


                    }
                }


            }
            catch (Exception ex)
            {
            }
        


    }


    protected void gvmember_OnRowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        GridView gvmember = sender as GridView;
        string memid = (gvmember.DataKeys[e.RowIndex].Value).ToString();
        string name = ((Label)gvmember.Rows[e.RowIndex].FindControl("lblmemtype")).Text;
        if (name == "Supervisor")
        {
            memtypecount--;
        }
        else if (name == "Co-Supervisor")
        {
            comemtypecount--;

        }
        else if (name == "Expert")
        {
           exmemtypecount--;

        }
        else if (name == "External Expert")
        {
            eexmemtypecount--;

        }
        this.Delete(memid);
        //
        //
        bindData();
        
       
    }


    private void Delete(string memid)
    {
        string constr = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        string sqlStatment = "DELETE FROM  phdallotment WHERE memuserid = @memuserid";
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand(sqlStatment, con))
            {
                con.Open();
                cmd.Parameters.AddWithValue("@memuserid", memid);
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }


    }

   
    protected void grdregdetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {


        //GridView gvmember = sender as GridView;
        //string memid = (gvmember.DataKeys[e.RowIndex].Value).ToString();
        //this.Delete(memid);

    }
}
