using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class Backup : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void BtnBackup_Click(object sender, EventArgs e)
    {
        string backupfile;
        UnivService.Service1 ss = new UnivService.Service1();
        backupfile =  System.DateTime.Now.Day+""+ System.DateTime.Now.Month + ""+System.DateTime.Now.Year +"-"+System.DateTime.Now.Hour+"-"+System.DateTime.Now.Minute + ".bak";
        ss.UpdateData(@"BACKUP DATABASE MMHAPU TO DISK='D:\UnivDataBackUp\" + backupfile + "' WITH FORMAT");
        string popupScript = "<script language='javascript'>" +
                        " alert('Backup is successfully completed ')" +
                         "</script>";
        Page.RegisterStartupScript("PopupScript", popupScript);
        LblMsg.Text = @"Backup is Successfully Completed - D:\UnivDataBackUp\" + backupfile;
    }
}
