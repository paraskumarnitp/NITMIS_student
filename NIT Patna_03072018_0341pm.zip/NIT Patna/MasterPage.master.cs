using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
     

        if (!Page.IsPostBack)
        {

            //LblUser.Text = Session["UserName"].ToString();
            try
            {
                string Role = Session["Role"].ToString();
                string RoleName = "";

                switch (Role)
                {
                    case "1"://Admin
                        RoleName = "Administrator";
                        break;
                    case "2"://EC
                        RoleName = "Exam Controller";
                        break;
                    case "3"://dy
                        RoleName = "Dy. Exam Controller";
                        break;
                    case "4"://opt
                        RoleName = "Operator";
                        break;
                    case "5"://spo
                        RoleName = "Spl. Operator";
                        break;
                    case "6"://VC
                        RoleName = "Vice Chancellor";
                        break;
                    case "7"://VC
                        RoleName = "Academic";
                        break;
                    case "8"://VC
                        RoleName = "Student";
                        break;
                    case "9"://VC
                        RoleName = "Faculty";
                        break;
                    case "10":
                         RoleName = "Deanacademic";
                        break;
                    case "11":
                        RoleName = "Director";
                        break;
                    case "12":
                        RoleName = "Placement";
                        break;
                    case "13":
                        RoleName = "HOD";
                        break;
                    case "14":
                        RoleName = "EXAM-PI";
                        break;
                    case "15":
                        RoleName = "MISIncharge";
                        break;
                    case "16":
                        RoleName = "Registrar";
                        break;
                    case "17":
                        RoleName = "AccountMenu";
                        break;
                    case "18":
                        RoleName = "HMCMenu";
                        break;
                    default:
                        RoleName = "";
                        break;
                }
                //UserId
                LblUser.Text = "Welcome " + Session["UserName"].ToString() + " [ "  + Session["UserId"].ToString() + " - " + RoleName + " ] - " + string.Format("{0:d MMMM, yyyy}", System.DateTime.Now); 
               // string UnivName=Session["UnivName"].ToString();
                LblUnivName.Text = "National Institute Of Technology Patna";
                Panel2.Visible = false;

            switch (Role)
            {
                case "1"://Admin
                    AdminMenu.Visible = true;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "2"://EC
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = true;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = false;
                    Deanacademic.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "3"://dy
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = true;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = false;
                    Deanacademic.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "4": //opt
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = true;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = false;
                    Deanacademic.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "5"://spo
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = true;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = false;
                    Deanacademic.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "6"://vc
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = true;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = false;
                    Deanacademic.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "7"://spo
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = true;
                    Deanacademic.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "8"://spo
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = true;
                    ExamMenu.Visible = false;
                    Deanacademic.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "9"://fc
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = true;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = false;
                    Deanacademic.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "10"://fc
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = false;
                    Deanacademic.Visible = true;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "11"://fc
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = false;
                    Deanacademic.Visible = false;
                    director.Visible = true;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "12"://placement
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = false;
                    Deanacademic.Visible = false;
                    director.Visible = false;
                    Placement.Visible = true;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "13"://placement
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = false;
                    Deanacademic.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = true;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "14"://EXAMPI
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = true;
                    Deanacademic.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = true;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "15"://MISPI
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = false;
                    Deanacademic.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = true;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "16"://Registrar
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = false;
                    Deanacademic.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = true;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = false;
                    break;
                case "17"://Accounts
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = false;
                    Deanacademic.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = true;
                    HMCMenu.Visible = false;
                    break;
                case "19"://Accounts
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    ExamMenu.Visible = false;
                    Deanacademic.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    HMCMenu.Visible = true;
                    break;
                default:
                    AdminMenu.Visible = false;
                    SPOMenu.Visible = false;
                    OperatorMenu.Visible = false;
                    DyECMenu.Visible = false;
                    ECMenu.Visible = false;
                    VCMenu.Visible = false;
                    AcademicMenu.Visible = false;
                    //studentMenu.Visible = false;
                    director.Visible = false;
                    Placement.Visible = false;
                    HOD.Visible = false;
                    SuperExamMenu.Visible = false;
                    MISIncharge.Visible = false;
                    Registrar.Visible = false;
                    AccountMenu.Visible = false;
                    break;

            }

        }
   
            catch(Exception ex)
            {
                Response.Redirect("default.aspx", false);
             }
         }
     }
    protected void SignOut_Click(object sender, EventArgs e)
    {

        try
        {

            UnivService.Service1 ss = new UnivService.Service1();
            string abc = " update UserLogTime set Online='N',LogoutTime=GetDate()  where Online='Y' and LoginId='" + Session["UserId"].ToString() + "' ";
            abc = ss.UpdateData(abc);

            ss.Dispose();


            Session["userName"] = null;
            Session.Clear();
            Session.RemoveAll();
            Session.Abandon();
            FormsAuthentication.SignOut();
            Response.Redirect("default.aspx", false);

        }

        catch (Exception ex)
        {
            Session["userName"] = null;
            Session.Clear();
            Session.RemoveAll();
            Session.Abandon();
            FormsAuthentication.SignOut();
            Response.Redirect("default.aspx", false);
        }



    }
    protected void LinkHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx",false ); 
    }
    protected void LinkSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("Search.aspx", false); 
    }
    protected void AdminMenu_TreeNodeExpanded(object sender, TreeNodeEventArgs e)
    {

        //if (e.Node.Parent == null)            return;
        
        //string strNodeValue = e.Node.Value;
        //foreach (TreeNode node in e.Node.Parent.ChildNodes)
        //{
        //    if (node.Value != strNodeValue)
        //        node.Collapse();
        //}



        //string currValue = e.Node.Value.Trim();
        //foreach (TreeNode tnode in AdminMenu.Nodes)
        //{

        //   if (tnode.Value != currValue)
        //    {
        //       tnode.Collapse();
        //    }
        //}
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        Functionreviseed fn = new Functionreviseed();
        int maxima = (int)fn.singlevalue("select max(convert(int,substring(FeedbckID,4,4)))+1 as maxima from Feedback");
        string complaintid = "F" + DateTime.Now.Year.ToString().Substring(2) + string.Format("{0:D4}", maxima);
        int i = fn.InsertUpdateDelete("INSERT INTO Feedback (FeedbckID,userid, messagetype, message, UserName,status) " +
                            " VALUES     ('"+complaintid+"','" + Session["UserId"].ToString() + "','" + ddlformtype.SelectedValue + "','" + txtmesag.Text.ToString() + "','" + Session["UserName"].ToString() + "','2' )");
        if (i > 0)
        {
            string msg = " Thankyou For Feedback!!! Your FeedBack No - "+complaintid;
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            Panel2.Visible = false;
            txtmesag.Text = "";
        }
        else
        {
            txtmesag.Text = "";
            string msg = " Unable to send your feedback.Please Try Later !!! ";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            Panel2.Visible = false;
        }
    }


    protected void lnkfdb_Click(object sender, EventArgs e)
    {
        Panel2.Visible = true;
    }
}
