using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Data.SqlClient;
using System.IO;

public partial class ConsolidatedList : System.Web.UI.Page
{
    ReportDocument crystalReport = new ReportDocument();
    Functionreviseed fnrev = new Functionreviseed();
    string query;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {

                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "12") && (Session["Role"].ToString() != "10"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }

                ViewState.Add("EditMode", "false");

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }

            FillExamsession();
        }
        
        if (ViewState["dt"] != null)
        {
           
            crystalReport.Load(Server.MapPath("~/Report/rptconsomarkslist.rpt"));
            dsconsolidatedlist objdsmarksdetails = new dsconsolidatedlist();
            objdsmarksdetails = (dsconsolidatedlist)ViewState["dt"];
            crystalReport.SetDataSource(objdsmarksdetails);
            CrystalReportViewer1.ReportSource = crystalReport;
            panel1.Visible = true;
        }
        
    }

    protected void Page_Unload(object sender, EventArgs e)
    {
        if (crystalReport != null)
        {
            crystalReport.Close();
            crystalReport.Dispose();
        }

    }

    protected void ddlbranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        FillSemester();
    }
    string sem = "";
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        criteria();
    
        crystalReport.Load(Server.MapPath("~/Report/rptconsomarkslist.rpt"));
        dsconsolidatedlist objdsmarksdetails = GetData(query);
        crystalReport.SetDataSource(objdsmarksdetails);
        CrystalReportViewer1.ReportSource = crystalReport;
        panel1.Visible = true;
        //LblMsg.Text = "";

        //gvsearch.DataSource = dssearch.Tables[0];
        //gvsearch.DataBind();
    }
    protected void Fillbranch()
    {
        DataSet dsbranch = fnrev.SelectDataset("SELECT Distinct STREAM.StreamCode,STREAM.StreamAbbr FROM EXAMPAPERDETAIL " + 
            " INNER JOIN STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN STREAM ON " + 
            " STREAMPART.StreamCode = STREAM.StreamCode WHERE EXAMPAPERDETAIL.ExamSession = '" + ddlexamsession.SelectedItem.ToString() + "'");
    
        ddlbranch.DataTextField = "StreamAbbr";
        ddlbranch.DataValueField = "StreamCode";
        ddlbranch.DataSource = dsbranch.Tables[0];
        ddlbranch.DataBind();
        
        ddlbranch.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void FillExamsession()
    {
        DataSet dsexamsession = fnrev.SelectDataset("Select Distinct ExamSession From EXAMPAPERDETAIL");
        ddlexamsession.DataTextField = "ExamSession";
        ddlexamsession.DataValueField = "ExamSession";
        ddlexamsession.DataSource = dsexamsession.Tables[0];
        ddlexamsession.DataBind();
        ddlexamsession.Items.Insert(0, new ListItem("--Select--", "0"));
        Fillbranch();
    }
    protected void FillSemester()
    {
        DataSet dssemester = fnrev.SelectDataset("Select StreamPart,StreamPartCode From StreamPart Where StreamCode = '" + ddlbranch.SelectedValue + "' order by STREAMPART");
    
        ddlsemester.DataTextField = "StreamPart";
        ddlsemester.DataValueField = "StreamPartCode";
        
        ddlsemester.DataSource = dssemester.Tables[0];
        ddlsemester.DataBind();
        ddlsemester.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    private dsconsolidatedlist GetData(string query)
    {
        string conString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlCommand cmd = new SqlCommand(query);
        using (SqlConnection con = new SqlConnection(conString))
        {
            using (SqlDataAdapter sda = new SqlDataAdapter())
            {
                cmd.Connection = con;
                sda.SelectCommand = cmd;
                using (dsconsolidatedlist objdsmarksdetails = new dsconsolidatedlist())
                {
                    sda.Fill(objdsmarksdetails, "DataTable1");
                    ViewState["dt"] = objdsmarksdetails;
                    return objdsmarksdetails;
                }
            }
        }
    }

    protected void btnexport_Click(object sender, EventArgs e)
    {

        criteria();
        DataSet dsexportexcel = fnrev.SelectDataset(query);
        if (dsexportexcel.Tables[0].Rows.Count > 0)
        {
            //Create a dummy GridView
            GridView GridView1 = new GridView();
            GridView1.AllowPaging = false;
            GridView1.DataSource = dsexportexcel.Tables[0];
            GridView1.DataBind();
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=Consolidated_Data_" + DateTime.Now.Date + ".xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                //Apply text style to each Row
                GridView1.Rows[i].Attributes.Add("class", "textmode");

            }
            GridView1.RenderControl(hw);
            //style to format numbers to string
            string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }

    string querypart = "";
    private void criteria()
    {
        if (ddlsemester.SelectedItem.ToString() == "sem 1-A")
            sem = "1";
        else if (ddlsemester.SelectedItem.ToString() == "sem 1-B")
            sem = "1";
        else if (ddlsemester.SelectedItem.ToString() == "sem 1")
            sem = "1";
        else if (ddlsemester.SelectedItem.ToString() == "sem 2-A")
            sem = "2";
        else if (ddlsemester.SelectedItem.ToString() == "sem 2-B")
            sem = "2";
        else if (ddlsemester.SelectedItem.ToString() == "sem 2")
            sem = "2";
        else if (ddlsemester.SelectedItem.ToString() == "sem 3")
            sem = "3";
        else if (ddlsemester.SelectedItem.ToString() == "sem 4")
            sem = "4";
        else if (ddlsemester.SelectedItem.ToString() == "sem 5")
            sem = "5";
        else if (ddlsemester.SelectedItem.ToString() == "sem 6")
            sem = "6";
        else if (ddlsemester.SelectedItem.ToString() == "sem 7")
            sem = "7";
        else if (ddlsemester.SelectedItem.ToString() == "sem 8")
            sem = "8";
        else if (ddlsemester.SelectedItem.ToString() == "sem 9")
            sem = "9";
        else if (ddlsemester.SelectedItem.ToString() == "sem 10")
            sem = "10";
        string streamtypecode = (fnrev.singlevalue("SELECT StreamTypeCode FROM STREAM WHERE StreamCode = '" + ddlbranch.SelectedValue + "'")).ToString();
        if (ddlsemester.SelectedValue != "0")
        {
            querypart = "Sem='" + sem + "' and";
        }
        else
        {
            querypart = "";
        }
        if (streamtypecode == "01")
        {
            query = "With CTE1 As (SELECT cgpa.UnivRollNo AS RollNo, cgpa.EName as ApplicantName, STREAM.StreamAbbr AS Branch, MAX(cgpa.semno) AS Sem," +
                " SUM(cgpa.Credit) AS Total_Cumulative_paper_Credit, SUM(cgpa.ER_CREDIT) AS Cumulative_ER_Credit," +
                " SUM(COURSEPAPERS.FullMarks + ISNULL(PRACTICALPAPERS.FullMarks, 0)) AS TotalPapermarks, " +
                " SUM(CONVERT(float, cgpa.Total_PMO)*(COURSEPAPERS.FullMarks + ISNULL(PRACTICALPAPERS.FullMarks, 0)) / 100) AS " +
                " Marksobtained, ROUND(SUM(CONVERT(float, cgpa.Total_PMO)*(COURSEPAPERS.FullMarks + ISNULL(PRACTICALPAPERS.FullMarks, 0)) / 100) * 100 / " +
                " SUM(COURSEPAPERS.FullMarks + ISNULL(PRACTICALPAPERS.FullMarks, 0)),2) AS PercentObtained, " +
                " ROUND(CASE WHEN SUM(cgpa.Credit) = SUM(cgpa.ER_CREDIT) THEN SUM(CONVERT(float, cgpa.Grade_Point)) / SUM(CONVERT(float, " +
                " cgpa.ER_CREDIT)) ELSE NULL END, 2) AS SGPA, SUM(CONVERT(Float, cgpa.Grade_Point)) AS Total_Grade_point, " +
                " CASE WHEN SUM(cgpa.Credit) = SUM(cgpa.ER_CREDIT) THEN 'P' ELSE 'F' END AS Status, cgpa.ExamSession " +
                " FROM cgpa INNER JOIN COURSEPAPERS ON cgpa.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN STREAMPART ON " +
                " cgpa.StreamPart = STREAMPART.StreamPartCode INNER JOIN STREAM ON STREAMPART.StreamCode = STREAM.StreamCode " +
                " LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode GROUP BY " +
                " cgpa.UnivRollNo, STREAM.StreamAbbr, cgpa.ExamSession, cgpa.EName HAVING (SUM(cgpa.ER_CREDIT) > 0)) " +
                " Select * From CTE1 Where " + querypart + "  Branch = '" + ddlbranch.SelectedItem.ToString() + "' and " +
                " Examsession = '" + ddlexamsession.SelectedItem.ToString() + "'";
        }
        else if (streamtypecode == "02" || streamtypecode == "04")
        {
            query = "With CTE1 As (SELECT cgpa_Mtec.UnivRollNo AS RollNo, cgpa_Mtec.EName as ApplicantName, STREAM.StreamAbbr AS Branch, MAX(cgpa_Mtec.semno) AS Sem," +
                           " SUM(cgpa_Mtec.Credit) AS Total_Cumulative_paper_Credit, SUM(cgpa_Mtec.ER_CREDIT) AS Cumulative_ER_Credit," +
                           " SUM(COURSEPAPERS.FullMarks + ISNULL(PRACTICALPAPERS.FullMarks, 0)) AS TotalPapermarks, " +
                           " SUM(CONVERT(float, cgpa_Mtec.Total_PMO)*(COURSEPAPERS.FullMarks + ISNULL(PRACTICALPAPERS.FullMarks, 0)) / 100) AS " +
                           " Marksobtained, ROUND(SUM(CONVERT(float, cgpa_Mtec.Total_PMO)*(COURSEPAPERS.FullMarks + ISNULL(PRACTICALPAPERS.FullMarks, 0)) / 100) * 100 / " +
                           " SUM(COURSEPAPERS.FullMarks + ISNULL(PRACTICALPAPERS.FullMarks, 0)),2) AS PercentObtained, " +
                           " ROUND(CASE WHEN SUM(cgpa_Mtec.Credit) = SUM(cgpa_Mtec.ER_CREDIT) THEN SUM(CONVERT(float, cgpa_Mtec.Grade_Point)) / SUM(CONVERT(float, " +
                           " cgpa_Mtec.ER_CREDIT)) ELSE NULL END, 2) AS SGPA, SUM(CONVERT(Float, cgpa_Mtec.Grade_Point)) AS Total_Grade_point, " +
                           " CASE WHEN SUM(cgpa_Mtec.Credit) = SUM(cgpa_Mtec.ER_CREDIT) THEN 'P' ELSE 'F' END AS Status, cgpa_Mtec.ExamSession " +
                           " FROM cgpa_Mtec INNER JOIN COURSEPAPERS ON cgpa_Mtec.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN STREAMPART ON " +
                           " cgpa_Mtec.StreamPart = STREAMPART.StreamPartCode INNER JOIN STREAM ON STREAMPART.StreamCode = STREAM.StreamCode " +
                           " LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode GROUP BY " +
                           " cgpa_Mtec.UnivRollNo, STREAM.StreamAbbr, cgpa_Mtec.ExamSession, cgpa_Mtec.EName HAVING (SUM(cgpa_Mtec.ER_CREDIT) > 0)) " +
                           " Select * From CTE1 Where " + querypart + " Branch = '" + ddlbranch.SelectedItem.ToString() + "' and " +
                           " Examsession = '" + ddlexamsession.SelectedItem.ToString() + "'";
        }

    }

    protected void ddlexamsession_SelectedIndexChanged(object sender, EventArgs e)
    {
        Fillbranch();
    }
}
