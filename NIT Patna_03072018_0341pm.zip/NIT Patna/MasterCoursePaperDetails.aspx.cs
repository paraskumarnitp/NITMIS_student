using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Text;


public partial class MasterCoursePaperDetails : System.Web.UI.Page
{
  
    Functionreviseed dut = new Functionreviseed();
  //  DataSet dsmasterpaper;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "10")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
      
            string query = "select distinct DepartmentId from MasterCoursePaper";


                PopulateDDL popddl = new PopulateDDL();
                popddl.Popualate(cmbDepartment, "MasterCoursePaper", query, "DepartmentId", "DepartmentId");

                cmbDepartment.Items.Insert(0, new ListItem("ALL", "00"));
            }
        
    }
    protected void BindGridview()
    {
        if (cmbDepartment.SelectedItem.ToString().Equals("ALL"))
        {
            string query = "select ROW_NUMBER()OVER(ORDER BY  DepartmentId ASC) as 'SerialNO', CourseCode, Title, L,T,P,Credit, FullMarks, PaperType ," +
                "case when(IsElective='1') then 'Yes' else '' END as 'Elective'," +
    "case when(IsOpenElective='1') THEN 'Yes' else '' End as 'OpenElective',DepartmentId  " +
     "from MasterCoursePaper m inner join  PaperType p on m.PaperTypeCode=p.PaperTypeCode ";
            DataSet dsmasterpaper = new DataSet();
            dsmasterpaper = dut.SelectDataset(query);
            grdMaterpaperReport.DataSource = dsmasterpaper.Tables[0];
            grdMaterpaperReport.DataBind();
        }
        else
        {

            string query = "  select ROW_NUMBER()OVER(ORDER BY  DepartmentId ASC) as 'SerialNO',CourseCode, Title, L,T,P,Credit, FullMarks, PaperType ," +
                "case when(IsElective='1') then 'Yes' else '' END as 'Elective'," +
    "case when(IsOpenElective='1') THEN 'Yes' else '' End as 'OpenElective' " +
     "from MasterCoursePaper m inner join  PaperType p on m.PaperTypeCode=p.PaperTypeCode and DepartmentId='" + cmbDepartment.SelectedValue + "' order by  DepartmentId, CourseCode,PaperType";
            DataSet dsmasterpaper = new DataSet();
            dsmasterpaper = dut.SelectDataset(query);
            grdMaterpaperReport.DataSource = dsmasterpaper.Tables[0];
            grdMaterpaperReport.DataBind();

        }
    }
    protected void BtnGenerate_Click(object sender, EventArgs e)
    {
        BindGridview();
    }
    protected void grdMaterpaperReport_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdMaterpaperReport.PageIndex = e.NewPageIndex;
        BindGridview();
    }
  
    protected void BtnGenerate_Click1(object sender, EventArgs e)
    {
        BindGridview();
    }
    protected void grdMaterpaperReport_PageIndexChanging1(object sender, GridViewPageEventArgs e)
    {
          grdMaterpaperReport.PageIndex = e.NewPageIndex;
          BindGridview();

    }
    protected void btnexcel_Click(object sender, EventArgs e)
    {
        string query = "select CourseCode, Title, L,T,P,Credit, FullMarks, PaperType ," +
     "case when(IsElective='1') then 'Yes' else '' END as 'Elective'," +
"case when(IsOpenElective='1') THEN 'Yes' else '' End as 'OpenElective' , DepartmentId " +
"from MasterCoursePaper m inner join  PaperType p on m.PaperTypeCode=p.PaperTypeCode order by  DepartmentId, CourseCode,PaperType";

        DataSet dsexportexcel = dut.SelectDataset(query);
        if (dsexportexcel.Tables[0].Rows.Count > 0)
        {
            //Create a dummy GridView
            GridView GridView1 = new GridView();
            GridView1.AllowPaging = false;
            GridView1.DataSource = dsexportexcel.Tables[0];
            GridView1.DataBind();
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=Student_Marks_Data_" + DateTime.Now.Date + ".xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                //Apply text style to each Row
                GridView1.Rows[i].Attributes.Add("class", "textmode");

            }
            GridView1.RenderControl(hw);
            //style to format numbers to string
            string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }

    }
}
