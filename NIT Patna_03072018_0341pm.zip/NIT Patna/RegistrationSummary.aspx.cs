using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class RegistrationSummary : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "6")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(Year, "Year", "Select Year from Year where year >= '2008' order by Year", "Year", "Year");
        }



    }
    protected void BtnView_Click(object sender, EventArgs e)
    {
        string sql = "SELECT     dbo.COLLEGE.CollCode, dbo.COLLEGE.CollName, COUNT(dbo.REGISTRATION.AckNo) AS [TotApp], COUNT(dbo.REGISTRATION.RegNo) " +
                     " AS [TotalAlloted] ,COUNT(dbo.REGISTRATION.AckNo)-COUNT(dbo.REGISTRATION.RegNo) as [Pending] FROM  dbo.REGISTRATION ,dbo.COLLEGE " +
                     " WHERE  (dbo.REGISTRATION.CollCode = dbo.COLLEGE.CollCode) and   (dbo.REGISTRATION.RegYear = '"+Year.Text  +"')" +
                     " GROUP BY dbo.COLLEGE.CollCode, dbo.COLLEGE.CollName";
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        RegSummaryView.DataSource = ds;
        RegSummaryView.DataBind();

        sql = "SELECT    COUNT(dbo.REGISTRATION.AckNo) AS [TotApp], COUNT(dbo.REGISTRATION.RegNo) " +
                     " AS [TotalAlloted] ,COUNT(dbo.REGISTRATION.AckNo)-COUNT(dbo.REGISTRATION.RegNo) as [Pending] FROM "+
                     "dbo.REGISTRATION  WHERE     (dbo.REGISTRATION.RegYear = '" + Year.Text + "')";
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        GridView1.DataSource = ds;
        GridView1.DataBind();
        Panel1.Visible = true; 
        Label1.Text = GridView1.Rows[0].Cells[1].Text;
        Label2.Text = GridView1.Rows[0].Cells[2].Text;
        Label3.Text = GridView1.Rows[0].Cells[3].Text;  
        


    }
}
