using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ProcessLogic : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "1")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
                    
        
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            SaveRecord();
            
        }
        catch (Exception ex)
        {
           LblMsg.Text = ex.Message;
        }
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        StreamPart.Focus();    
    }

    protected void SaveRecord()
    
    {
        

        string[] col = new string[30];
        string[] val = new string[30];
       

        // Colume Variable--Field Name
        col[0] ="StreamCode";               val[0] = StreamCode.SelectedValue.ToString ();
        col[1] ="StreamPartCode";           val[1] = StreamPart.SelectedValue;
        col[2] = "NCompPaper";              val[2] =NCompPaper.Text.ToString();
        col[3] = "CompFullMarks";           val[3] =CompFullMarks.Text.ToString();
        col[4] = "CompPassMarks";           val[4] =CompPassMarks.Text.ToString();
        col[5] = "NCompPaperNH";            val[5] =NCompPaperNH.Text.ToString();
        col[6] = "CompNHPaperFullMarks";    val[6] =CompNHPaperFullMarks.Text.ToString();       
        col[7] = "CompNHPaperPassMarks";    val[7] =CompNHPaperPassMarks.Text.ToString();
        col[8] = "CompNHFullMarks";         val[8] =CompNHFullMarks.Text.ToString();
        col[9] = "CompNHPassMarks";         val[9] =CompNHPassMarks.Text.ToString();
        col[10] = "NHonsPaper";             val[10]= NHonsPaper.Text.ToString();
        col[11] = "HonsFullMarks";          val[11]=HonsFullMarks.Text.ToString();
        col[12] = "HonsPassMarks";          val[12]=HonsPassMarks.Text.ToString();
        col[13] = "NHonsPaperWithPrac";     val[13]=NHonsPaperWithPrac.Text.ToString();        
        col[14] = "HonsTheoryFullMarks";    val[14]=HonsTheoryFullMarks.Text.ToString();
        col[15] = "HonsTheoryPassMarks";    val[15]=HonsTheoryPassMarks.Text.ToString();
        col[16] = "HonsPraFullMarks";       val[16]=HonsPraFullMarks.Text.ToString();
        col[17] = "HonsPraPassMarks";       val[17]=HonsPraPassMarks.Text.ToString();
        col[18] = "HonsTotFullMarks";       val[18]=HonsTotFullMarks.Text.ToString();
        col[19] = "HonsTotPassMarks";       val[19]=HonsTotPassMarks.Text.ToString();
        col[20] = "NSubPaper";              val[20]= NSubPaper.Text.ToString();
        col[21] = "SubFullMarks";           val[21]= SubFullMarks.Text.ToString();
        col[22] = "SubPassMarks";           val[22]=SubPassMarks.Text.ToString();
        col[23] = "NSubPaperWithPrac";      val[23]=NSubPaperWithPrac.Text.ToString();
        col[24] = "SubTheoryFullMarks";     val[24]=SubTheoryFullMarks.Text.ToString();
        col[25] = "SubTheoryPassMarks";     val[25]= SubTheoryPassMarks.Text.ToString();
        col[26] = "SubPraFullMarks";        val[26]=SubPraFullMarks.Text.ToString();
        col[27] = "SubPraPassMarks";        val[27]=SubPraPassMarks.Text.ToString();
        col[28] = "SubTotFullMarks";        val[28]=SubTotFullMarks.Text.ToString();
        col[29] = "SubTotPassMarks";        val[29]=SubTotPassMarks.Text.ToString();

        try
        {
            string SaveFlag = "";
            UnivService.Service1 NicService = new UnivService.Service1();
            SaveFlag = NicService.SaveData("ProcessLogic", col, val);

            if (SaveFlag == "1")
            {
                LblMsg.Text = "Successfully Saved";
            }
        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

    }

    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {

    }
}
