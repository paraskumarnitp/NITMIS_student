using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class AttendanceTracking : System.Web.UI.Page
{
    Functionreviseed chkfn = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {            
            try
            {
                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "11") && (Session["Role"].ToString() != "14") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "15"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }             

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }        
            PopulateDDL popddl = new PopulateDDL();        
            popddl.Popualate(ExamYear, "Year", "select distinct ExamSession from Faculty_paper_a where is_active='Y'  order by ExamSession desc", "ExamSession", "ExamSession");
            ExamYear.Items.Insert(0, new ListItem("--Select--", "00"));          
      
        }
    }
    DataRow[] dr1; string SubpaperCode;
    protected void btnexportinexcel_Click(object sender, EventArgs e)
    {
        DataTable dtTrakingData = new DataTable();
        dtTrakingData.Columns.Add("Program");
        dtTrakingData.Columns.Add("Semester");
        dtTrakingData.Columns.Add("Course_Code");
        dtTrakingData.Columns.Add("Course_Name");
        dtTrakingData.Columns.Add("Course_Type");
        dtTrakingData.Columns.Add("UserID");
        dtTrakingData.Columns.Add("UserName");
        dtTrakingData.Columns.Add("ContactNo");
        dtTrakingData.Columns.Add("EmailID");
        dtTrakingData.Columns.Add("Status");

        string query = "SELECT DISTINCT AttendanceRegister.PaperType, Faculty_paper_a.UserId, " + 
              " COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName, COURSEPAPERS.SubPaperCode, COURSEPAPERS.StreamPart, STREAM.StreamAbbr, LogIn.UserName, LogIn.EmailId, LogIn.ContactNo, '' AS Status FROM LogIn INNER JOIN " + 
              " Faculty_paper_a ON LogIn.UserId = Faculty_paper_a.UserId RIGHT OUTER JOIN EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " + 
              " STREAM ON COURSEPAPERS.StreamCode = STREAM.StreamCode ON Faculty_paper_a.SubPaperCode = EXAMPAPERDETAIL.SubPaperCode LEFT OUTER JOIN AttendanceRegister ON " +
              " EXAMPAPERDETAIL.SubPaperCode = AttendanceRegister.SubPaperCode AND AttendanceRegister.Month = '" + ddlMonth.SelectedValue.ToString() + "' WHERE (EXAMPAPERDETAIL.ExamSession = '" + ExamYear.SelectedItem.ToString() + "') AND " + 
              " (EXAMPAPERDETAIL.ExamType IN ('R', 'B')) AND (Faculty_paper_a.Is_Active = 'Y')";
        DataTable dtexportexcel = chkfn.SelectDatatable(query);

        DataTable dtvalidateStatus = chkfn.SelectDatatable("SELECT DISTINCT AttendanceDetail.UserId, AttendanceRegister.SubPaperCode FROM AttendanceRegister INNER JOIN AttendanceDetail " + 
            " ON AttendanceRegister.Id = AttendanceDetail.RegisterId and (AttendanceRegister.ExamSession = '"+ExamYear.SelectedItem.ToString()+"') AND (AttendanceRegister.Month = '"+ddlMonth.SelectedValue.ToString()+"')");
        if (dtexportexcel.Rows.Count > 0 && dtvalidateStatus.Rows.Count > 0)
        {
            for (int y = 0;y < dtexportexcel.Rows.Count; y++)
            {
                SubpaperCode = dtexportexcel.Rows[y]["SubPaperCode"].ToString();
                dr1 = dtvalidateStatus.Select("SubPaperCode ='"+ SubpaperCode +"'");
                if (dr1.Length > 0)
                {
                    dtTrakingData.Rows.Add(dtexportexcel.Rows[y]["StreamAbbr"].ToString(), dtexportexcel.Rows[y]["StreamPart"].ToString(), dtexportexcel.Rows[y]["PaperAbbr"].ToString(), dtexportexcel.Rows[y]["PaperName"].ToString(), dtexportexcel.Rows[y]["PaperType"].ToString(), dtexportexcel.Rows[y]["UserId"].ToString(), dtexportexcel.Rows[y]["UserName"].ToString(), dtexportexcel.Rows[y]["ContactNo"].ToString(), dtexportexcel.Rows[y]["EmailId"].ToString(), "Complete");
                }
                else
                {
                    dtTrakingData.Rows.Add(dtexportexcel.Rows[y]["StreamAbbr"].ToString(), dtexportexcel.Rows[y]["StreamPart"].ToString(), dtexportexcel.Rows[y]["PaperAbbr"].ToString(), dtexportexcel.Rows[y]["PaperName"].ToString(), dtexportexcel.Rows[y]["PaperType"].ToString(), dtexportexcel.Rows[y]["UserId"].ToString(), dtexportexcel.Rows[y]["UserName"].ToString(), dtexportexcel.Rows[y]["ContactNo"].ToString(), dtexportexcel.Rows[y]["EmailId"].ToString(), "Pending");
                }
            }            
        }

        if (dtTrakingData.Rows.Count > 0)
        {
            //Create a dummy GridView
            GridView GridView1 = new GridView();
            GridView1.AllowPaging = false;
            GridView1.DataSource = dtTrakingData;
            GridView1.DataBind();
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=Attendance_Entry_Status_Data_" + DateTime.Now.Date + ".xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                //Apply text style to each Row
                GridView1.Rows[i].Attributes.Add("class", "textmode");

            }
            GridView1.RenderControl(hw);
            //style to format numbers to string
            string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
}
