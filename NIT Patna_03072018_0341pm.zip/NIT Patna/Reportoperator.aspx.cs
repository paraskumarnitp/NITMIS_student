using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.Collections.Generic;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

public partial class Reportoperator : System.Web.UI.Page
{
    Functionreviseed fn = new Functionreviseed();
    PopulateDDL popddl = new PopulateDDL();
    DataSet dsmarksdata;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            Session["checkclear"] = criteria;
            try
            {

                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "12") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }

                ViewState.Add("EditMode", "false");

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }
            string strrole = "";
            if (Session["Role"].ToString() == "9")
                strrole = " and UserId='" + Session["UserId"].ToString() + "'";

            
           
            popddl.Popualate(ExamYear, "Year", "select distinct ExamSession from EXAMPAPERDETAIL order by ExamSession desc", "ExamSession", "ExamSession");

            ExamYear.Items.Insert(0, new ListItem("--Select--", "00"));
            StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
            StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
            
            //  ExamYear.Focus();
        }
        if (ViewState["dt"] != null)
        {
            try
            {
                if (Paperwise.Checked == true)
                {
                    ReportDocument crystalReport = new ReportDocument();
                    crystalReport.Load(Server.MapPath("~/Report/rptmarkspercent.rpt"));
                    dsmarksdetails1 objdsmarksdetails = new dsmarksdetails1();
                    objdsmarksdetails = (dsmarksdetails1)ViewState["dt"];
                    crystalReport.SetDataSource(objdsmarksdetails);
                    CrystalReportViewer1.ReportSource = crystalReport;
                    panelinterthpract.Visible = true;
                    LblMsg.Text = "";
                }
                else if (Sgpawise.Checked == true)
                {
                    ReportDocument crystalReport = new ReportDocument();
                    crystalReport.Load(Server.MapPath("~/Report/rptmarkspercent2.rpt"));
                    dsmarksdetails2 objdsmarksdetails = new dsmarksdetails2();
                    objdsmarksdetails = (dsmarksdetails2)ViewState["dt"];
                    crystalReport.SetDataSource(objdsmarksdetails);
                    CrystalReportViewer1.ReportSource = crystalReport;
                    panelinterthpract.Visible = true;
                    LblMsg.Text = "";
                }
            }
            catch (Exception ex)
            {
 
            }
        } 

    }

    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = Sgpawise.Checked || Paperwise.Checked;
    }

    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {

        StreamPart.Items.Clear();       
        PopulateDDL popddl = new PopulateDDL();
        string strstreampart = "SELECT DISTINCT EXAMPAPERDETAIL.StreamPartCode, STREAMPART.StreamPart FROM EXAMPAPERDETAIL " + 
            " INNER JOIN STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode WHERE " + 
            " (STREAMPART.StreamCode = '"+ StreamCode.SelectedValue +"') AND (EXAMPAPERDETAIL.ExamSession = '" + ExamYear.SelectedItem.ToString() + "') " + 
            " ORDER BY StreamPart ";
        popddl.Popualate(StreamPart, "StreamPart", strstreampart, "StreamPart", "StreamPartCode");
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
       criteria.SelectedIndex = 0;
        Sgpawise.Checked = false;
        Paperwise.Checked = false;
        StreamPart.Focus();
    }
      
       
    //bool HasRecords(DataSet dataSet)
    //{
    //    foreach (DataTable dt in dataSet.Tables) if (dt.Rows.Count > 0) return true;
    //    return false;
    //}
  
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Panel3.Enabled = true;
        ExamYear.SelectedIndex = 0;
        StreamCode.SelectedIndex = 0;
        StreamPart.SelectedIndex = 0;
        criteria.SelectedIndex = 0;
        Sgpawise.Enabled = true;
        Paperwise.Enabled = true;
        ViewState["dt"] = null;
        percentvalue.Text = "";
        Sgpawise.Checked = false;
        Paperwise.Checked = false;
        panelinterthpract.Visible = false;             
        LblMsg.Text = "";
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            Sgpawise.Enabled = false;
            Paperwise.Enabled = false;
            printreport();
        }
    }

    string query = "";
    protected void printreport()
    {
       
        string Querystr = "";
        if (StreamPart.SelectedItem.ToString().IndexOf('A') > 0 || StreamPart.SelectedItem.ToString().IndexOf('B') > 0)
        {
            Querystr = " (COURSEPAPERS.StreamPart = '" + StreamPart.SelectedItem.ToString() + "' )";
        }
        else
        {
            Querystr = " (COURSEPAPERS.StreamPartCode='" + StreamPart.SelectedValue + "')";

        }
        string streamtype = fn.singlevalue("Select StreamTypeCode From STREAM Where StreamCode = '" + StreamCode.SelectedValue + "'").ToString();
        if (Paperwise.Checked == true)
        {
            if (streamtype == "01")
            {
                query = "SELECT TRBTec.UnivRollNo, TRBTec.EName, TRBTec.ExamSession, STREAM.StreamAbbr, " +
                " STREAMPART.StreamPart, COURSEPAPERS.PaperAbbr, TRBTec.CA_MSM_TH, TRBTec.TH_ESM, TRBTec.TH_PMO, TRBTec.CA_MSM_PT," +
                " TRBTec.PT_ESM, TRBTec.PT_PMO, TRBTec.Total_PMO, TRBTec.Grade_Point, TRBTec.ER_CREDIT, TRBTec.Grade, TRBTec.ExamType " +
                " FROM TRBTec INNER JOIN STREAM ON TRBTec.StreamCode = STREAM.StreamCode INNER JOIN STREAMPART ON " +
                " TRBTec.StreamPart = STREAMPART.StreamPartCode INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                " WHERE (Convert(float,TRBTec.Total_PMO) " + criteria.SelectedItem.ToString() + "'" + percentvalue.Text.Trim().ToString() + "') AND " +
                " (TRBTec.ExamSession = '" + ExamYear.SelectedItem.ToString() + "') AND " + Querystr + " ORDER BY TRBTec.UnivRollNo";
            }
            else if (streamtype == "02")
            {
                query = "SELECT TRMTec.UnivRollNo, TRMTec.EName, TRMTec.ExamSession, STREAM.StreamAbbr, " +
                " STREAMPART.StreamPart, COURSEPAPERS.PaperAbbr, TRMTec.CA_MSM_TH, TRMTec.TH_ESM, TRMTec.TH_PMO, TRMTec.CA_MSM_PT," +
                " TRMTec.PT_ESM, TRMTec.PT_PMO, TRMTec.Total_PMO, TRMTec.Grade_Point, TRMTec.ER_CREDIT, TRMTec.Grade, TRMTec.ExamType " +
                " FROM TRMTec INNER JOIN STREAM ON TRMTec.StreamCode = STREAM.StreamCode INNER JOIN STREAMPART ON " +
                " TRMTec.StreamPart = STREAMPART.StreamPartCode INNER JOIN COURSEPAPERS ON TRMTec.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                " WHERE (Convert(float,TRMTec.Total_PMO) " + criteria.SelectedItem.ToString() + "'" + percentvalue.Text.Trim().ToString() + "') AND " +
                " (TRMTec.ExamSession = '" + ExamYear.SelectedItem.ToString() + "') AND " + Querystr + " ORDER BY TRMTec.UnivRollNo";
            }
        }
        else if (Sgpawise.Checked == true)
        {
            if (streamtype == "01")
            {
                query = "SELECT BtecGrade.UnivRollNo, REGISTRATION.ApplicantName, BtecGrade.ExamSession, BtecGrade.StreamAbbr," +
                    " BtecGrade.StreamPart, BtecGrade.Marks_percent, BtecGrade.Remarks, BtecGrade.SGPA, BtecGrade.CGPA " +
                    " FROM BtecGrade INNER JOIN REGISTRATION ON BtecGrade.UnivRollNo = REGISTRATION.TempRollNo WHERE " +
                    " (BtecGrade.ExamSession = '" + ExamYear.SelectedItem + "') AND (BtecGrade.StreamAbbr = '" + StreamCode.SelectedItem + "')" +
                    " AND (BtecGrade.StreamPart = '" + StreamPart.SelectedItem + "') AND " +
                    " (BtecGrade.Marks_percent " + criteria.SelectedItem.ToString() + "'" + percentvalue.Text.Trim().ToString() + "')";
            }
            else if (streamtype == "02")
            {
                query = "SELECT MtecGrade.UnivRollNo, REGISTRATION.ApplicantName, MtecGrade.ExamSession, MtecGrade.StreamAbbr," +
                   " MtecGrade.StreamPart, MtecGrade.Marks_percent, MtecGrade.Remarks, MtecGrade.SGPA, MtecGrade.CGPA " +
                   " FROM MtecGrade INNER JOIN REGISTRATION ON MtecGrade.UnivRollNo = REGISTRATION.TempRollNo WHERE " +
                   " (MtecGrade.ExamSession = '" + ExamYear.SelectedItem + "') AND (MtecGrade.StreamAbbr = '" + StreamCode.SelectedItem + "')" +
                   " AND (MtecGrade.StreamPart = '" + StreamPart.SelectedItem + "') AND " +
                   " (MtecGrade.Marks_percent " + criteria.SelectedItem.ToString() + "'" + percentvalue.Text.Trim().ToString() + "')";
            }
        }
        dsmarksdata = fn.SelectDataset(query);
        if (dsmarksdata.Tables[0].Rows.Count > 0)
        {
            if (Paperwise.Checked == true)
            {
                ReportDocument crystalReport = new ReportDocument();
                crystalReport.Load(Server.MapPath("~/Report/rptmarkspercent.rpt"));
                dsmarksdetails1 objdsmarksdetails = GetData(query);
                crystalReport.SetDataSource(objdsmarksdetails);
                CrystalReportViewer1.ReportSource = crystalReport;
                panelinterthpract.Visible = true;
                LblMsg.Text = "";
            }
            else if (Sgpawise.Checked == true)
            {
                ReportDocument crystalReport = new ReportDocument();
                crystalReport.Load(Server.MapPath("~/Report/rptmarkspercent2.rpt"));
                dsmarksdetails2 objdsmarksdetails = GetData1(query);
                crystalReport.SetDataSource(objdsmarksdetails);
                CrystalReportViewer1.ReportSource = crystalReport;
                panelinterthpract.Visible = true;
                LblMsg.Text = "";
            }
        }
        else
        {
            LblMsg.Text = "<b style=" + "Font-size:13px;" + ">Record(S) not found according to above criteria!";
            panelinterthpract.Visible = false;
            dsmarksdata = null;

        }
    

    }   
   
   
    private dsmarksdetails1 GetData(string query)
    {
        string conString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlCommand cmd = new SqlCommand(query);
        using (SqlConnection con = new SqlConnection(conString))
        {
            using (SqlDataAdapter sda = new SqlDataAdapter())
            {
                cmd.Connection = con;

                sda.SelectCommand = cmd;
                using (dsmarksdetails1 objdsmarksdetails = new dsmarksdetails1())
                {
                    sda.Fill(objdsmarksdetails, "DataTable1");
                    ViewState["dt"] = objdsmarksdetails;
                    return objdsmarksdetails;
                }
            }
        }
    }

    private dsmarksdetails2 GetData1(string query)
    {
        string conString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlCommand cmd = new SqlCommand(query);
        using (SqlConnection con = new SqlConnection(conString))
        {
            using (SqlDataAdapter sda = new SqlDataAdapter())
            {
                cmd.Connection = con;

                sda.SelectCommand = cmd;
                using (dsmarksdetails2 objdsmarksdetails = new dsmarksdetails2())
                {
                    sda.Fill(objdsmarksdetails, "DataTable1");
                    ViewState["dt"] = objdsmarksdetails;
                    return objdsmarksdetails;
                }
            }
        }
    }


    protected void ExamYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        string strstream = "SELECT DISTINCT STREAM.StreamAbbr, STREAM.StreamCode FROM EXAMPAPERDETAIL INNER JOIN " +
          " STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN STREAM ON " + 
          " STREAMPART.StreamCode = STREAM.StreamCode WHERE (EXAMPAPERDETAIL.ExamSession = '" + ExamYear.SelectedItem.ToString() + "') " + 
          " ORDER BY STREAM.StreamAbbr";
        popddl.Popualate(StreamCode, "Stream", strstream, "StreamAbbr", "StreamCode");
        StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
        StreamPart.Items.Clear();
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        criteria.SelectedIndex = 0;
        Sgpawise.Checked = false;
        Paperwise.Checked = false;
    }

   
}
