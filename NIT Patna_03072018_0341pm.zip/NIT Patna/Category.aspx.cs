using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.IO;
public partial class Category : System.Web.UI.Page
{
    Functionreviseed dut = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "1") && (Session["Role"].ToString() != "10"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
                ViewState.Add("EditMode", "false");
            }
            catch (Exception ex)
            {
              Response.Redirect("default.aspx");
            }

        }
        if (!Page.IsPostBack)
        {
            Panel2.Visible = true;
            DataSet ds = new DataSet();
            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select * from Category  order by CategoryCode");
            CateGoryView.DataSource = ds;
            CateGoryView.DataBind();
        }


    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {
        string abc = "";
        Panel2.Visible = false;
        if (ViewState["EditMode"].ToString () == "false")
        {
            string[] col = new string[2];
            string[] val = new string[2];
            col[0] = "CategoryCode";
            col[1] = "Category";
            Panel2.Visible = false;
            val[1] = CategoryNm.Text.Trim();

            UnivService.Service1 ss = new UnivService.Service1();
            string SQL = "SELECT     ISNULL(MAX(ABS(CategoryCode)), '0') + 1 AS NewCategoryCode FROM CATEGORY";
            string NewCategoryCode = ss.GetNewCode(SQL);
            NewCategoryCode = string.Format("{0:D2}", Convert.ToInt16(NewCategoryCode));

            val[0] = NewCategoryCode;
            
            abc = ss.SaveData("Category", col, val);

            if (abc == "1")
            {
                LblMsg.Text = " Category is saved successfully. Category Code= " + NewCategoryCode;
                string popupScript = "<script language='javascript'>" +
                                " alert('Category is saved successfully. Category Code=   " + NewCategoryCode + " ')" +
                                 "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);

                CategoryNm.Text = "";
                CategoryNm.Focus();

            }
            else
            {
                LblMsg.Text = abc.ToString();
            }
        }
        else
        {
            
            UnivService.Service1 ss = new UnivService.Service1();
            abc = " update category set category='" + CategoryNm.Text + "' where CategoryCode='" + CateGoryView.SelectedRow.Cells[1].Text+"'";
            abc = ss.UpdateData(abc);
            if (abc.ToString() == "ok")
            {
                ViewState.Add("EditMode", "false");
                LblMsg.Text = " Record is updated successfully.";
                CategoryNm.Text = "";
                CategoryNm.Focus();

            }
            else
                LblMsg.Text = abc.ToString();

        }



    }
    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
       
        
    }
   
    protected void CateGoryView_SelectedIndexChanged(object sender, EventArgs e)
    {
        CategoryNm.Text = CateGoryView.SelectedRow.Cells[2].Text.ToString();
        ViewState.Add("EditMode", "true");
        CategoryNm.Focus(); 
        


    }


    
    //protected void GridView1_RowCommand(object sender,GridViewCommandEventArgs e)
    //    {
    //        if (e.CommandName == "Delete1")
    //        {
    //            // get the categoryCode of the clicked row
    //            //int categoryID = Convert.ToInt32(e.CommandArgument);
                
    //            UnivService.Service1 ss = new UnivService.Service1();
    //            string abc = " delete from category where CategoryCode='" + e.CommandArgument.ToString() + "'";
    //            abc = ss.UpdateData(abc);
    //            if (abc.ToString() == "ok")
    //            {

    //                LblMsg.Text = " Record is deleted successfully.";
    //                CategoryNm.Text = "";
    //                    DataSet ds = new DataSet();
    //                    ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select * from Category order by CategoryCode");
    //                    CateGoryView.DataSource = ds;
    //                    CateGoryView.DataBind();
    //                CategoryNm.Focus();
    //                //LblMsg.Text = "";
    //            }
    //            else
    //                LblMsg.Text = abc.ToString();

    //        }
            
    //    }

    protected void CateGoryView_Sorting(object sender, GridViewSortEventArgs e)
    {
          
            


    }


    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {


      
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Panel2.Visible = true;
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select * from Category where Category='" + CategoryNm.Text.Trim() + "' order by CategoryCode");
        CateGoryView.DataSource = ds;
        CateGoryView.DataBind(); 

    }
    protected void btnexport_Click(object sender, EventArgs e)
    {
        try
        {
            string query = "select * from Category  order by CategoryCode";
            DataSet dsmasterpaper = new DataSet();
            DataSet dsexportexcel = dut.SelectDataset(query);
            if (dsexportexcel.Tables[0].Rows.Count > 0)
            {
                //Create a dummy GridView
                GridView GridView1 = new GridView();
                GridView1.AllowPaging = false;
                GridView1.DataSource = dsexportexcel.Tables[0];
                GridView1.DataBind();
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=Student_Update_Name_" + DateTime.Now.Date + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                for (int i = 0; i < GridView1.Rows.Count; i++)
                {
                    //Apply text style to each Row
                    GridView1.Rows[i].Attributes.Add("class", "textmode");

                }
                GridView1.RenderControl(hw);
                //style to format numbers to string
                string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
        catch (Exception ex)
        {
        }

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {



        string abc = "";
        Panel2.Visible = false;
        if (ViewState["EditMode"].ToString() == "false")
        {
            string[] col = new string[2];
            string[] val = new string[2];
            col[0] = "CategoryCode";
            col[1] = "Category";
            Panel2.Visible = false;
            val[1] = CategoryNm.Text.Trim();

            UnivService.Service1 ss = new UnivService.Service1();
            string SQL = "SELECT     ISNULL(MAX(ABS(CategoryCode)), '0') + 1 AS NewCategoryCode FROM CATEGORY";
            string NewCategoryCode = ss.GetNewCode(SQL);
            NewCategoryCode = string.Format("{0:D2}", Convert.ToInt16(NewCategoryCode));

            val[0] = NewCategoryCode;

            abc = ss.SaveData("Category", col, val);

            if (abc == "1")
            {
                LblMsg.Text = " Category is saved successfully. Category Code= " + NewCategoryCode;
                string popupScript = "<script language='javascript'>" +
                                " alert('Category is saved successfully. Category Code=   " + NewCategoryCode + " ')" +
                                 "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);

                CategoryNm.Text = "";
                CategoryNm.Focus();

            }
            else
            {
                LblMsg.Text = abc.ToString();
            }
        }
        else
        {

            UnivService.Service1 ss = new UnivService.Service1();
            abc = " update category set category='" + CategoryNm.Text + "' where CategoryCode='" + CateGoryView.SelectedRow.Cells[1].Text + "'";
            abc = ss.UpdateData(abc);
            if (abc.ToString() == "ok")
            {
                ViewState.Add("EditMode", "false");
                LblMsg.Text = " Record is updated successfully.";
                CategoryNm.Text = "";
                CategoryNm.Focus();

            }
            else
                LblMsg.Text = abc.ToString();

        }

    }
}
