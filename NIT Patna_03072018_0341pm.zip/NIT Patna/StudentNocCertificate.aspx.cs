using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;


public partial class StudentNocCertificate : System.Web.UI.Page
{
    SqlDataReader dr;
    Functionreviseed fnrev = new Functionreviseed();
 
    string userid = "";
    string refno = "";
    string id = "1";
    protected void Page_Load(object sender, EventArgs e)
    {
       

        if (!Page.IsPostBack)
        {
           
            try
            {
                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "10") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
        }
    }

    protected void btngetdetails_Click(object sender, EventArgs e)
    {

        try
        {

            string query = "select Ename  from cgpa where UnivRollNo='" + txtrollno.Text.Trim() + "' ";
            object RegNo = fnrev.singlevalue(query);

            txtName.Text = RegNo.ToString();
            query = "select MAX(semno)  from cgpa where UnivRollNo='" + txtrollno.Text.Trim() + "' ";
            RegNo = fnrev.singlevalue(query);
            txtsem.Text = RegNo.ToString();

    

            query = "SELECT  distinct STREAM.StreamAbbr FROM  STREAM INNER JOIN  STREAMPART ON STREAM.StreamCode = STREAMPART.StreamCode INNER JOIN  EXAMPAPERDETAIL ON STREAMPART.StreamPartCode = EXAMPAPERDETAIL.StreamPartCode and UnivRollNo='" + txtrollno.Text.Trim() + "' ";
            RegNo = fnrev.singlevalue(query);
            txtprogram.Text = RegNo.ToString();

            

            decimal year = decimal.Parse(txtsem.Text); ;
            decimal year1 = year / 2;
            decimal d = Math.Ceiling(year1);
            txtaccyear.Text = d.ToString();

        }
        catch (Exception ex)
        {
        }
            
        
  
    
        }
    

   
    
 


    string branch = "";
    private void branchbind()
    {
        if (txtprogram.Text == "B.Arch")
        {
            branch = "Architecture";
        }
        else if (txtprogram.Text == "B.Tech-CSE")
        {
            branch = "Computer Science & Engineering";
        }
        else if (txtprogram.Text == "B.Tech-IT")
        {
            branch = "Information Technology";
        }
        else if (txtprogram.Text == "B.Tech-ECE")
        {
            branch = "Electronics & Comm. Engineering";
        }
        else if (txtprogram.Text == "B.Tech-CE")
        {
            branch = "Civil Engineering";
        }
        else if (txtprogram.Text == "B.Tech-EE")
        {
            branch = "Electrical Engineering";
        }
        else if (txtprogram.Text == "B.Tech-ME")
        {
            branch = "Mechanical Engineering";
        }
    }
    protected void txtsubmit_Click(object sender, EventArgs e)
    {
      
       

        try
        {

            int saverec = 0;



            string refId = "", yearcode = "";
            if (txtaccyear.Text.Trim() == "1")
                yearcode = "1st";
            else if (txtaccyear.Text.Trim() == "2")
                yearcode = txtaccyear.Text.Trim().ToString() + "nd";
            else if (txtaccyear.Text.Trim() == "3")
                yearcode = txtaccyear.Text.Trim().ToString() + "rd";
            else
                yearcode = txtaccyear.Text.Trim().ToString() + "th";
            object prevrefno = fnrev.singlevalue("SELECT RefNo FROM studentNoc WHERE RollNo = '" + txtrollno.Text.Trim() + "' and year = '" + yearcode + "' order by gentime DESC");


            if (prevrefno == null)
            {
                string maxid = fnrev.singlevalue("SELECT ISNULL(MAX(ID),1) AS maxId FROM BonafiedCertificates").ToString();
                if (maxid.Length == 1)
                {
                    refId = "NITP/NC/" + DateTime.Now.Year.ToString().Substring(2, 2) + "/00" + maxid;
                }
                else if (maxid.Length == 2)
                {
                    refId = "NITP/NC/" + DateTime.Now.Year.ToString().Substring(2, 2) + "/0" + maxid;
                }
                else
                    refId = "NITP/NC/" + DateTime.Now.Year.ToString().Substring(2, 2) + "/" + maxid;

                saverec = fnrev.InsertUpdateDelete("INSERT INTO studentNoc (refno,rollno,year,nocfor,period,place,userid,gentime) VALUES " +
                   " ('" + refId + "','" + txtrollno.Text + "','" + yearcode + "','" + txtnoc.Text.Trim() + "','" + txtperiod.Text.Trim() + "','" + txtplace.Text.Trim() + "','" + Session["UserId"].ToString() + "',GETDATE())");

            }
            else
            {
                refId = prevrefno.ToString();
                saverec = 1;
            }






            branchbind();

            Session["refno"] = refId;
            Session["Sname"] = txtName.Text;
            Session["rollno"] = txtrollno.Text;
            Session["year"] = yearcode;
            Session["program"] = branch;
            Session["nocfor"] = txtnoc.Text;
            Session["period"] = txtperiod.Text;
            Session["place"] = txtplace.Text;

            Response.Redirect("studentnoc.aspx");

        }
        catch (Exception ex)
        {
        }
    }
}
    

