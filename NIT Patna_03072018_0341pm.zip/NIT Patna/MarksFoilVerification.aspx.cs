using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
 
using NIC.Connection;
using NIC.ApplicationFramework.Data;
public partial class MarksFoilVerification : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "3")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
                ViewState.Add("EditMode", "false");
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }


            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(ExamCollCode, "College", "Select CollName,CollCode from College Where CollCode in (Select Distinct ExamCollCode from Exam)order by CollName", "CollName", "CollCode");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(ExamYear, "Year", "Select Year from Year where year >='2008'order by Year", "Year", "Year");
            ExamYear.Focus();
        }
    }



    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        StreamCode.Focus();  
    }
    protected void RBHons_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Hons");
    }
    protected void RBComp_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Comp");
    }
    protected void RBSubs_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Subs");
    }
    private void GetPaperCode(string PaperType )
    {
        PopulateDDL popddl = new PopulateDDL();

        if (PaperType == "Hons")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", "Select PaperName,SubPaperCode from COURSEPAPERS Where StreamCode='" + StreamCode.SelectedValue + "' And StreamPartCode='" + StreamPart.SelectedValue + "' And SubCode='" + SubCode.SelectedValue + "' order by SubPaperCode", "PaperName", "SubPaperCode");
        }
        else if (PaperType == "Comp")
        {
            popddl.Popualate(Subject, "COMPOSITION", "Select Name,CompCode from COMPOSITION order by Name", "Name", "CompCode");
        }
        else if (PaperType == "Subs")
        {
            popddl.Popualate(Subject, "SUBJECT", "Select SubCode,SubjectName from SUBJECT Where StreamCode='" + StreamCode.SelectedValue + "' and subcode<>'" + SubCode.SelectedValue + "'  order by SubjectName", "SubjectName", "SubCode");
        }

          Subject.Focus();

    }
    protected void SubCode_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Panel2.Visible = false;
        BindGrid();
        
    }
    void BindGrid()
    {
        DataSet ds = new DataSet();
        string sql = "";
        char papertype = 'N';
        if (RBHons.Checked) papertype = 'H';
        else if (RBPraH.Checked) papertype = 'P';
        else if (RBSubs.Checked) papertype = 'S';
        else if (RBPraS.Checked) papertype = 'P';
        else if (RBComp.Checked) papertype = 'C'; 
        
        //sql = "SELECT compcode from exampaperdetail";
        //Marks entered by operator1

        // changed in sql query on 5 july 2011 ...

        if (CheckBox1.Checked == true)
            //sql = "SELECT UnivRollNo,compcode as Code ,ClassTest1 As Marks,IsAppeared as Appeared from exampaperdetail where univrollno in (SELECT UnivRollNo FROM EXAM WHERE ExamYear = '" + ExamYear.SelectedValue + "' AND (ExamCollCode = '" + ExamCollCode.SelectedValue + "') and streampartcode='" + StreamPart.SelectedValue + "' and subcode='" + SubCode.SelectedValue + "') and streampartcode='" + StreamPart.SelectedValue + "' and SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + papertype + "' And ClassTest1 <> ClassTest2";
            sql = "SELECT UnivRollNo,compcode as Code ,ClassTest1 As Marks,IsAppeared as Appeared from exampaperdetail where univrollno in (SELECT UnivRollNo FROM EXAM WHERE ExamYear = '" + ExamYear.SelectedValue + "' AND (ExamCollCode = '" + ExamCollCode.SelectedValue + "') and streampartcode='" + StreamPart.SelectedValue + "' and subcode='" + SubCode.SelectedValue + "') and streampartcode='" + StreamPart.SelectedValue + "' and SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + papertype + "' And ( (ClassTest1 <> ClassTest2) or (ClassTest1 is null and ClassTest2 is not null) or (ClassTest2 is null and ClassTest1 is not null) ) order by UnivRollNo";
        else
            sql = "SELECT UnivRollNo,compcode as Code ,ClassTest1 As Marks,IsAppeared as Appeared from exampaperdetail where univrollno in (SELECT UnivRollNo FROM EXAM WHERE ExamYear = '" + ExamYear.SelectedValue + "'  and streampartcode='" + StreamPart.SelectedValue + "' and subcode='" + SubCode.SelectedValue + "') and streampartcode='" + StreamPart.SelectedValue + "' and SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + papertype + "' And ( (ClassTest1 <> ClassTest2) or (ClassTest1 is null and ClassTest2 is not null) or (ClassTest2 is null and ClassTest1 is not null) ) order by UnivRollNo";
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        Opt1MarksGrid.DataSource = ds;
        Opt1MarksGrid.DataBind();
        //Marks entered by operator2
        if (CheckBox1.Checked ==true )
            sql = "SELECT UnivRollNo,compcode as Code,ClassTest2 As Marks,IsAppeared as Appeared from exampaperdetail where univrollno in (SELECT UnivRollNo FROM EXAM WHERE ExamYear = '" + ExamYear.SelectedValue + "' AND (ExamCollCode = '" + ExamCollCode.SelectedValue + "') and streampartcode='" + StreamPart.SelectedValue + "' and subcode='" + SubCode.SelectedValue + "') and streampartcode='" + StreamPart.SelectedValue + "' and SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + papertype + "'  And ( (ClassTest1 <> ClassTest2) or (ClassTest1 is null and ClassTest2 is not null) or (ClassTest2 is null and ClassTest1 is not null) ) order by UnivRollNo";
        else
            sql = "SELECT UnivRollNo,compcode as Code,ClassTest2 As Marks,IsAppeared as Appeared from exampaperdetail where univrollno in (SELECT UnivRollNo FROM EXAM WHERE ExamYear = '" + ExamYear.SelectedValue + "' and streampartcode='" + StreamPart.SelectedValue + "' and subcode='" + SubCode.SelectedValue + "') and streampartcode='" + StreamPart.SelectedValue + "' and SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + papertype + "' And ( (ClassTest1 <> ClassTest2) or (ClassTest1 is null and ClassTest2 is not null) or (ClassTest2 is null and ClassTest1 is not null) ) order by UnivRollNo";
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        Opt2MarksGrid.DataSource = ds;
        Opt2MarksGrid.DataBind();
        
        //Verify opt1 & opt2
        for (int i = 0; i < int.Parse(Opt1MarksGrid.Rows.Count.ToString()); i++)
        {
            if (Opt1MarksGrid.Rows[i].Cells[3].Text != Opt2MarksGrid.Rows[i].Cells[2].Text)
            {
                Opt1MarksGrid.Rows[i].ForeColor = System.Drawing.Color.Red;
                Opt2MarksGrid.Rows[i].ForeColor = System.Drawing.Color.Red;
            }
        }
             


    }

    protected void Opt1MarksGrid_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (Opt1MarksGrid.SelectedRow.Cells[3].Text != Opt2MarksGrid.Rows[Opt1MarksGrid.SelectedIndex].Cells[2].Text)
        {
            LblRoll.Text = Opt1MarksGrid.SelectedRow.Cells[1].Text;
            Lblcode.Text = Opt1MarksGrid.SelectedRow.Cells[2].Text;
            Panel1.Visible = true;
        }
        else
            Panel1.Visible = false; 


    }
    protected void BtnUpdate_Click(object sender, EventArgs e)
    {
        char PaperType = 'P';
        if (RBHons.Checked) PaperType = 'H';
        else if (RBComp.Checked) PaperType = 'C';
        else if (RBSubs.Checked) PaperType = 'S';
        else if (RBPraH.Checked) PaperType = 'P';
        else if (RBPraS.Checked) PaperType = 'P';


        char app='N';
        if(Appeared.Checked )
            app='P';
        else
            app='A';
        UnivService.Service1 NicService = new UnivService.Service1();
        string sql="Update ExamPaperDetail set ClassTest1='"+ TxtMarks.Text +"' , ClassTest2='"+ TxtMarks.Text +
                   "', IsAppeared='"+app+"' where  UnivRollNo='"+LblRoll.Text  +"' And streampartcode='" + StreamPart.SelectedValue + "' and examyear='" + ExamYear.SelectedValue + "' And SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "'";
        sql=NicService.UpdateData (sql);
        
        Panel1.Visible = false; 
        //Entry in ExamPaperMarksLog
        
            string[] col = new string[5];
            string[] val = new string[5];
            col[0] = "UnivRollNo";
            col[1] = "CompCode";
            col[2] = "OldMarks";
            col[3] = "NewMarks";
            col[4] = "opt";
            
            
            val[0] = LblRoll.Text;  
            val[1] = Lblcode.Text ;
            val[2] = "";    
            if(Opt1MarksGrid.SelectedRow.Cells[3].Text.Trim ()!="&nbsp;")
                val[2] = Opt1MarksGrid.SelectedRow.Cells[3].Text.Trim ();
            val[2] += ",";
            if (Opt2MarksGrid.Rows[Opt1MarksGrid.SelectedIndex].Cells[2].Text.Trim() != "&nbsp;")
                val[2] += Opt2MarksGrid.Rows[Opt1MarksGrid.SelectedIndex].Cells[2].Text.Trim();
            
       
        
            val[3]=TxtMarks.Text ;
            val[4]=Session["UserId"].ToString ();
            sql=NicService.SaveData("ExamPaperMarksLog", col, val);
            if (sql == "1")
            {
                string popupScript = "<script language='javascript'>" +
                                " alert('Updated successfully  ')" +
                                 "</script>";
                Page.RegisterStartupScript("PopupScript", popupScript);
            }
            TxtMarks.Text = ""; 
            BindGrid();
 

//----

        

 
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string str = "";
        str = "Course - " + StreamCode.SelectedItem.Text + ",   " + StreamPart.SelectedItem.Text + ",    Dept. Name - " + SubCode.SelectedItem.Text + ",   Subject- " + Subject.SelectedItem.Text;
        CrystalDecisions.Shared.ParameterFields myParams = new CrystalDecisions.Shared.ParameterFields();
        CrystalDecisions.Shared.ParameterField myParam = new CrystalDecisions.Shared.ParameterField();
        CrystalDecisions.Shared.ParameterDiscreteValue myDiscreteValue = new CrystalDecisions.Shared.ParameterDiscreteValue();
        myParam.ParameterFieldName = "STR";
        myDiscreteValue.Value = str;
        myParam.CurrentValues.Add(myDiscreteValue);
        myParams.Add(myParam);
//        CR.RefreshReport();
        CR.ReportSource = null;
        CR.ParameterFieldInfo = myParams;
        Panel2.Visible = true;
        CR.ReportSource = crs;
        CR.SelectionFormula = @"{EXAMPAPERDETAIL.StreamPartCode} = '" + StreamPart.SelectedValue + "' And {EXAMPAPERDETAIL.ExamYear} ='" + ExamYear.SelectedValue + "' And {EXAMPAPERDETAIL.SubPaperCode} ='" + Subject.SelectedValue + "'";
        

    }
}
