using System;
using System.Data.OracleClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.Data;

namespace SPMS.Classes
{
	/// <summary>
	/// Summary description for GetName.
	/// </summary>
	public class GetName
	{
		public string ColDetail;
		public GetName()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		public bool GetIt(string ItsCode)
		{			
			string sql="Select empname   from employee where EmpCode=:pEmpCode";
			OracleParameter oracleparameter=new OracleParameter ("pEmpCode",OracleType.Char,10 );
			oracleparameter.Value=ItsCode;
			
			OracleDataReader odr;

			odr = (OracleHelper.ExecuteReader(SqlConnectionMgmt.GetConnectionString(),CommandType.Text,sql,oracleparameter));
			
			if (odr.Read())
			{
				ColDetail=odr.GetString(0);
				return true;
			}
			else
				return false;
	}
	}
}
