using System;
using System.Data;
using NIC.Connection;
using NIC.ApplicationFramework.Data ;

namespace SPMS.Classes
{
	/// <summary>
	/// Summary description for GetDate.
	/// </summary>
	public class GetDates
	{
		public GetDates()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		public string Display()
		{
			string sql="Select substring(convert(char,getdate(),106),1,11)";
			return (OracleHelper.ExecuteScalar(SqlConnectionMgmt.GetConnectionString(),CommandType.Text,sql)).ToString();

		}
	}
}
