using System;
namespace SPMS.Classes
{
    /// <summary>
    /// Summary description for ConvertDate.
    /// </summary>
    public class ConvertDate
    {
        public ConvertDate()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public string FuncChangeDate(string InputDate)
        {
            try
            {
                string vDay;
                string vMon;
                string vYear;

                vDay = InputDate.Substring(0, 2);

                switch (Convert.ToInt32(InputDate.Substring(3, 2)))
                {
                    case 1:
                        vMon = "01";
                        break;

                    case 2:
                        vMon = "02";
                        break;
                    case 3:
                        vMon = "03";
                        break;
                    case 4:
                        vMon = "04";
                        break;
                    case 5:
                        vMon = "05";
                        break;
                    case 6:
                        vMon = "06";
                        break;
                    case 7:
                        vMon = "07";
                        break;
                    case 8:
                        vMon = "08";
                        break;
                    case 9:
                        vMon = "09";
                        break;
                    case 10:
                        vMon = "10";
                        break;
                    case 11:
                        vMon = "11";
                        break;
                    case 12:
                        vMon = "12";
                        break;
                    default:
                        vMon = "01";
                        break;
                }

                vYear = InputDate.Substring(6, 4);
                return (vDay + " " + vMon + " " + vYear);
            }
            catch
            {
                return ("0");
            }

        }

        public string FuncChangeDate(string InputDate,bool IsNew)
        {
            string vDay;
            string vMon;
            string vYear;

            vDay = InputDate.Substring(0, 2);

            switch (Convert.ToInt32(InputDate.Substring(3, 2)))
            {
                case 1:
                    vMon = "Jan";
                    break;

                case 2:
                    vMon = "Feb";
                    break;
                case 3:
                    vMon = "Mar";
                    break;
                case 4:
                    vMon = "Apr";
                    break;
                case 5:
                    vMon = "May";
                    break;
                case 6:
                    vMon = "Jun";
                    break;
                case 7:
                    vMon = "Jul";
                    break;
                case 8:
                    vMon = "Aug";
                    break;
                case 9:
                    vMon = "Sep";
                    break;
                case 10:
                    vMon = "Oct";
                    break;
                case 11:
                    vMon = "Nov";
                    break;
                case 12:
                    vMon = "Dec";
                    break;
                default:
                    vMon = "Jan";
                    break;
            }

            vYear = InputDate.Substring(6, 4);
            return (vDay + " " + vMon + " " + vYear);

        }

        public string FuncReChangeDate(string InputDate)
        {
            try
            {
                string vDay;
                string vMon;
                string vYear;

                string vsDay;
                string vsMon;
                string vsYear;

                int vstartIndex;
                int vstartIndex1;
                int vstartIndex2;
                vstartIndex = 0;

                vstartIndex = InputDate.IndexOf("/", vstartIndex + 1);
                vsMon = InputDate.Substring(0, vstartIndex);

                switch (Convert.ToInt32(vsMon))
                {
                    case 1:
                        vMon = "01";
                        break;
                    case 2:
                        vMon = "02";
                        break;
                    case 3:
                        vMon = "03";
                        break;
                    case 4:
                        vMon = "04";
                        break;
                    case 5:
                        vMon = "05";
                        break;
                    case 6:
                        vMon = "06";
                        break;
                    case 7:
                        vMon = "07";
                        break;
                    case 8:
                        vMon = "08";
                        break;
                    case 9:
                        vMon = "09";
                        break;
                    case 10:
                        vMon = "10";
                        break;
                    case 11:
                        vMon = "11";
                        break;
                    case 12:
                        vMon = "12";
                        break;
                    default:
                        vMon = "01";
                        break;
                }


                vstartIndex1 = InputDate.IndexOf("/", vstartIndex + 1);

                vsDay = InputDate.Substring(vstartIndex + 1, vstartIndex1 - (vstartIndex + 1));


                if (vsDay.Length == 1)
                    vDay = "0" + vsDay;
                else
                    vDay = vsDay;

                vstartIndex2 = InputDate.IndexOf(" ", vstartIndex1 + 1);
                if (vstartIndex2 == -1)
                    vstartIndex2 = InputDate.Length;
                vsYear = InputDate.Substring(vstartIndex1 + 1, vstartIndex2 - (vstartIndex1 + 1));
                if (vsYear.Length == 2)
                    vYear = "20" + vsYear;
                else
                    vYear = vsYear;

                return (vDay + "/" + vMon + "/" + vYear);
            }
            catch (System.Exception ee)
            {
                return("Error");
            }

        }
    }
}
