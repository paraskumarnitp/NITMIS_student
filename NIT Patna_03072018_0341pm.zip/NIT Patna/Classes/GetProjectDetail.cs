using System;
using System.Data.OracleClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.Data;
namespace SPMS.Classes
{
	/// <summary>
	/// Summary description for GetProjectDetail.
	/// </summary>
	public class GetProjectDetail
	{
		public string ProjectName;
		public string ProjectDesc;
		public string DIVCODE;
		public string FINYEAR;
		public string TSREFNO;
		public DateTime TSREFDATE;
		public string Location;
		public OracleNumber FUNDALLOCACATED;

		public GetProjectDetail()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		public bool GetDetail(string ProjectCode)
		{
			string sql="Select pname,pdesc, DivCODE , FINYEAR , TSREFNO , TSDATE , LOCATION , FUNDALLOCACATED   from Project where PCode=:pPCode";
			OracleParameter oracleparameter=new OracleParameter ("pPCode",OracleType.Char,12 );
			oracleparameter.Value=ProjectCode;
			
			OracleDataReader odr;

			odr = (OracleHelper.ExecuteReader(SqlConnectionMgmt.GetConnectionString(),CommandType.Text,sql,oracleparameter));
			
			if (odr.Read())
			{
				ProjectName=odr.GetString(0);
				ProjectDesc=odr.GetString(1);
				DIVCODE=odr.GetString(2);
				FINYEAR=odr.GetString(3);
				TSREFNO=odr.GetString(4);
				TSREFDATE=odr.GetDateTime(5);
				Location=odr.GetString(6);
				FUNDALLOCACATED=odr.GetOracleNumber(7);
				return true;
			}
			else
				return false;

			
		}
	}
}
