using System;
using System.Data.OracleClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.Data;
namespace SPMS.Classes
{
    /// <summary>
    /// Summary description for GetName.
    /// </summary>
    public class GetAnyName
    {
        public string ColDetail;
        public GetAnyName()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        public string  GetIt(string PKCode,string TableName,string PKField, string DescField)
        {

            string sql = "Select :pDescField from :pTableName where :pPKField=:pPKCode";

            OracleParameter[] oracleParameter = new OracleParameter[4];


            oracleParameter[0] = new OracleParameter("pDescField", OracleType.VarChar, 20);
            oracleParameter[1] = new OracleParameter("pTableName", OracleType.VarChar, 20);
            oracleParameter[2] = new OracleParameter("pPKField", OracleType.VarChar, 20);
            oracleParameter[3]= new OracleParameter("pPKCode", OracleType.VarChar, 20);
            
            oracleParameter[0].Value = DescField ;
            oracleParameter[1].Value = TableName  ;
            oracleParameter[2].Value = PKField;
            oracleParameter[3].Value = PKCode ;

            OracleDataReader odr;
            
            odr = (OracleHelper.ExecuteReader(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql, oracleParameter));

            if (odr.Read())
            {
                ColDetail = odr.GetString(0);
                return ColDetail ;
            }
            else
                return "";

        }

        public string GetThat(string PKCode, string TableName, string PKField, string DescField)
        {

            string sql = "Select " +  DescField + " from " + TableName + " where " + PKField + "=" + PKCode;

            OracleDataReader odr;
            odr = (OracleHelper.ExecuteReader(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql));

            if (odr.Read())
            {
                ColDetail = odr.GetString(0);
                return ColDetail;
            }
            else
                return "";
        }
    }
}
