using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class User : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "6") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "16"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                   
                }
                for (int i = 3; i <= DeptName.Items.Count - 1; i++)
                {
                    DeptName.Items[i].Enabled = false;
                }
                if (Session["Role"].ToString() == "7")
                {
                    

                    ListItem last = Userrole.Items[7];
                    Userrole.Items.Clear();
                    Userrole.Items.Add(last);

                    DeptName.Items.Clear();
                    DeptName.Items.Insert(0, new ListItem("Math", "MA"));
                    DeptName.Items.Insert(1, new ListItem("HSS", "HS"));
                    DeptName.Items.Insert(2, new ListItem("CSE", "CS"));
                    DeptName.Items.Insert(3, new ListItem("ECE", "EC"));
                    DeptName.Items.Insert(4, new ListItem("EE", "EE"));
                    DeptName.Items.Insert(5, new ListItem("ME", "ME"));
                    DeptName.Items.Insert(6, new ListItem("CE", "CE"));
                    DeptName.Items.Insert(7, new ListItem("Arch.", "AR"));
                    DeptName.Items.Insert(7, new ListItem("Chemistry", "CH"));
                    DeptName.Items.Insert(7, new ListItem("Physics", "PH"));
           
                }
            }
              
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

           
        }
    }
    protected void BtnAdd_Click(object sender, ImageClickEventArgs e)
    {
        //ViewState.Add("AddFlag", "true"); 
    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {

        if (UserName.Text.Trim() != "")
        {
 
       
            string abc = "";
            Encryption enc = new Encryption();
            string[] col = new string[7];
            string[] val = new string[7];
            col[0] = "UserId";
            col[1] = "UserName";
            col[2] = "Password";
            col[3] = "Userrole";
            col[4] = "DeptName";
            col[5] = "Designation";
            col[6] = "DepartmentId";
        

            pwdrand pwd = new pwdrand();
            string pwdd = pwd.generate();
            val[1] = UserName.Text.Trim();
            val[2] = enc.EncryptPassword(pwdd.Trim());
            val[3] = Userrole.Text.Trim();
            val[4] = DeptName.SelectedValue.ToString();
            val[5] = Designation.Text.Trim();
            val[6] = DeptName.SelectedValue.ToString();    

            UnivService.Service1 ss = new UnivService.Service1();
            string SQL = "SELECT     ISNULL(MAX(ABS(SUBSTRING(UserId, 3, 5))), '0') + 1 AS NewUserID FROM LogIn WHERE Userrole = '9'";
            string NewUserId = string.Format("{0:D3}", Convert.ToInt16(ss.GetNewCode(SQL)));
            val[0] = "Fc" + NewUserId;
            abc = ss.SaveData("LogIn", col, val);
            int insdata;
            Functionreviseed fn = new Functionreviseed();
            insdata = fn.InsertUpdateDelete("INSERT INTO tempregister (UserId,temppass) VALUES ('" + val[0] + "','" + pwdd.Trim() + "')");
            if (abc == "1" && insdata>0)
            {
                LblMsg.Text = " User " + val[0] + " and Password "+ pwdd.Trim() +" created successfully";
               // Page.RegisterStartupScript(@"startup", @"<script>altert('New User Id is " + val[0]  + "');</script>");
                
                ViewState.Add("AddFlag", "");
                UserName.Text = "";
                Password.Text="";
                rePassword.Text = "";
                Designation.Text = "";
                UserName.Focus();

            }
            else
            {
                LblMsg.Text = abc.ToString();
            }


        }

            // Panel2.Visible = false;
        }



    protected void Userrole_SelectedIndexChanged(object sender, EventArgs e)
    {
        int facultyindex=3;
        if (Userrole.SelectedValue == "9")
        {
            for (int i = facultyindex; i <= DeptName.Items.Count - 1; i++)
                DeptName.Items[i].Enabled = true;
            for (int i = 0; i < facultyindex; i++)
                DeptName.Items[i].Enabled = false;

        }
        else
        {
            for (int i = 0; i < facultyindex; i++)
                DeptName.Items[i].Enabled = true;
            for (int i = facultyindex; i <= DeptName.Items.Count - 1; i++)
                DeptName.Items[i].Enabled = false;
        }           
    }

   
}
