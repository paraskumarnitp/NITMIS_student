using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class failedStudentList : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    PopulateDDL popddl = new PopulateDDL();  
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch 
            {
                Response.Redirect("default.aspx");
            }
            popddl.Popualate(Year, "Year", "select distinct ExamSession from Faculty_paper_a where is_active='Y'  order by ExamSession desc", "ExamSession", "ExamSession");            
            Year.Items.Insert(0, new ListItem("--Select--", "00"));
            StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
            StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
            ddlcourseCourse.Items.Insert(0, new ListItem("--Select--", "00"));
            ddlcourseCourse.Enabled = false;
            txtrollno.Enabled = false;

            
                      
           

            //popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        }
    }
    protected void BtnGenAdmit_Click(object sender, EventArgs e)
    {
        DataTable dtgetdata = new DataTable();
        if (ddlpassfail.SelectedValue.ToString() == "P")
        {
            if (rdbcriteria.SelectedValue.ToString() == "S")
            {
                dtgetdata = fnrev.SelectDatatable("SELECT TRBTec.UnivRollNo, TRBTec.EName, COURSEPAPERS.PaperAbbr, TRBTec.CA_MSM_TH, TRBTec.TH_ESM, " + 
                    " TRBTec.TH_PMO, TRBTec.CA_MSM_PT, TRBTec.PT_ESM, TRBTec.PT_PMO, TRBTec.Total_PMO, TRBTec.Grade_Point, TRBTec.ER_CREDIT, TRBTec.Grade, " + 
                    " TRBTec.ExamType FROM TRBTec INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " + 
                    " (TRBTec.ExamSession = '"+Year.SelectedValue.ToString()+"') AND (TRBTec.SubPaperCode = '"+ddlcourseCourse.SelectedValue.ToString()+"') AND " + 
                    " (TRBTec.StreamPart = '"+StreamPart.SelectedValue.ToString()+"') AND (TRBTec.Grade NOT IN ('F', 'I', 'X')) AND (TRBTec.Is_active = 'Y')");
            }
            else if (rdbcriteria.SelectedValue.ToString() == "M")
            {
                dtgetdata = fnrev.SelectDatatable("SELECT TRBTec.UnivRollNo, TRBTec.EName, COURSEPAPERS.PaperAbbr, TRBTec.CA_MSM_TH, TRBTec.TH_ESM, " +
                    " TRBTec.TH_PMO, TRBTec.CA_MSM_PT, TRBTec.PT_ESM, TRBTec.PT_PMO, TRBTec.Total_PMO, TRBTec.Grade_Point, TRBTec.ER_CREDIT, " +
                    " TRBTec.Grade, TRBTec.ExamType FROM TRBTec INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                    " WHERE (TRBTec.ExamSession = '" + Year.SelectedValue.ToString() + "') AND (TRBTec.StreamPart = '" + StreamPart.SelectedValue.ToString() + "') AND " +
                    " (TRBTec.Grade NOT IN ('F', 'I', 'X')) AND (TRBTec.Is_active = 'Y') order by UnivRollNo");
            }
            else if (rdbcriteria.SelectedValue.ToString() == "R")
            {
                dtgetdata = fnrev.SelectDatatable("SELECT UnivRollNo, EName, COURSEPAPERS.PaperAbbr, CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, " +
                    " Total_PMO, Grade_Point, ER_CREDIT, Grade, ExamType FROM TRBTec INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE (ExamSession = '" + Year.SelectedValue.ToString() + "') " +
                    " AND (UnivRollNo = '" + txtrollno.Text.Trim() + "') AND (StreamPart = '" + StreamPart.SelectedValue.ToString() + "')  AND " +
                    " (Grade NOT IN ('F', 'I', 'X')) AND (Is_active = 'Y')");
            }
        }
        else
        {
            if (rdbcriteria.SelectedValue.ToString() == "S")
            {
                dtgetdata = fnrev.SelectDatatable("SELECT TRBTec.UnivRollNo, TRBTec.EName, COURSEPAPERS.PaperAbbr, TRBTec.CA_MSM_TH, TRBTec.TH_ESM, " +
                    " TRBTec.TH_PMO, TRBTec.CA_MSM_PT, TRBTec.PT_ESM, TRBTec.PT_PMO, TRBTec.Total_PMO, TRBTec.Grade_Point, TRBTec.ER_CREDIT, TRBTec.Grade, " +
                    " TRBTec.ExamType FROM TRBTec INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE " +
                    " (TRBTec.ExamSession = '" + Year.SelectedValue.ToString() + "') AND (TRBTec.SubPaperCode = '" + ddlcourseCourse.SelectedValue.ToString() + "') AND " +
                    " (TRBTec.StreamPart = '" + StreamPart.SelectedValue.ToString() + "') AND (TRBTec.Grade IN ('F', 'I', 'X')) AND (TRBTec.Is_active = 'Y')");

            }
            else if (rdbcriteria.SelectedValue.ToString() == "M")
            {
                dtgetdata = fnrev.SelectDatatable("SELECT TRBTec.UnivRollNo, TRBTec.EName, COURSEPAPERS.PaperAbbr, TRBTec.CA_MSM_TH, TRBTec.TH_ESM, " + 
                    " TRBTec.TH_PMO, TRBTec.CA_MSM_PT, TRBTec.PT_ESM, TRBTec.PT_PMO, TRBTec.Total_PMO, TRBTec.Grade_Point, TRBTec.ER_CREDIT, " + 
                    " TRBTec.Grade, TRBTec.ExamType FROM TRBTec INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode " + 
                    " WHERE (TRBTec.ExamSession = '"+Year.SelectedValue.ToString()+"') AND (TRBTec.StreamPart = '"+StreamPart.SelectedValue.ToString()+"') AND " + 
                    " (TRBTec.Grade IN ('F', 'I', 'X')) AND (TRBTec.Is_active = 'Y') order by UnivRollNo");
            }
            else if (rdbcriteria.SelectedValue.ToString() == "R")
            {
                dtgetdata = fnrev.SelectDatatable("SELECT UnivRollNo, EName, COURSEPAPERS.PaperAbbr, CA_MSM_TH, TH_ESM, TH_PMO, CA_MSM_PT, PT_ESM, PT_PMO, " + 
                    " Total_PMO, Grade_Point, ER_CREDIT, Grade, ExamType FROM TRBTec INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE (ExamSession = '"+Year.SelectedValue.ToString()+"') " + 
                    " AND (UnivRollNo = '"+txtrollno.Text.Trim()+"') AND (StreamPart = '"+StreamPart.SelectedValue.ToString()+"')  AND " + 
                    " (Grade IN ('F', 'I', 'X')) AND (Is_active = 'Y')");
            }
        }

        gvData.DataSource = dtgetdata;
        gvData.DataBind();
    }
    protected void Year_SelectedIndexChanged(object sender, EventArgs e)
    {
        popddl.Popualate(StreamCode, "Stream", "SELECT DISTINCT STREAM.StreamAbbr, STREAM.StreamCode FROM EXAMPAPERDETAIL INNER JOIN " +
              " STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN STREAM ON STREAMPART.StreamCode = STREAM.StreamCode WHERE (EXAMPAPERDETAIL.ExamSession = '" + Year.SelectedValue + "')", "StreamAbbr", "StreamCode");
        
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {       
        popddl.Popualate(StreamPart, "StreamPart", "SELECT DISTINCT STREAMPART.StreamPart, STREAMPART.StreamPartCode FROM EXAMPAPERDETAIL " + 
            " INNER JOIN STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode WHERE (EXAMPAPERDETAIL.ExamSession = '"+Year.SelectedValue+"') AND (STREAMPART.StreamCode = '"+StreamCode.SelectedValue+"')", "StreamPart", "StreamPartCode");
    }
    protected void rdbcriteria_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rdbcriteria.SelectedValue == "S")
        {
            bindcourse();
            ddlcourseCourse.Enabled = true;
            txtrollno.Enabled = false;

        }
        else if (rdbcriteria.SelectedValue == "M")
        {
            ddlcourseCourse.Enabled = false;
            txtrollno.Enabled = false;
        }
        else if (rdbcriteria.SelectedValue == "R")
        {
            ddlcourseCourse.Enabled = false;
            txtrollno.Enabled = true;
        }
    }

    public void bindcourse()
    {
        DataTable dtcourse = fnrev.SelectDatatable("SELECT DISTINCT EXAMPAPERDETAIL.SubPaperCode, COURSEPAPERS.PaperAbbr " + 
                " FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode " +  
                " WHERE (EXAMPAPERDETAIL.ExamSession = '"+ Year.SelectedItem +"') AND (EXAMPAPERDETAIL.StreamPartCode = '"+StreamPart.SelectedValue+"')");
        ddlcourseCourse.DataSource = dtcourse;
        ddlcourseCourse.DataTextField = "PaperAbbr";
        ddlcourseCourse.DataValueField = "SubPaperCode";
        ddlcourseCourse.DataBind();
        ddlcourseCourse.Items.Insert(0, new ListItem("--SELECT--", "0"));
    }
}
