using System;
using System.IO;
using System.Data;
using System.Data.SqlClient ;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;


public partial class StudentDetails : System.Web.UI.Page
{


    Functionreviseed fn = new Functionreviseed();
    PopulateDDL popddl = new PopulateDDL();
    protected void Page_Load(object sender, EventArgs e)
    {
        string checkreg, checkquery;

        //checkquery = "select isnull(Is_completed,'Y') from REGISTRATION WHERE AckNo='" + Session["UserId"].ToString() + "'";
        //checkreg = ((string)fn.singlevalue(checkquery)).ToUpper().Trim();
        //if (checkreg == "N")
        //{
        //    Response.Redirect("RegistrationEntry.aspx");
        //}
        if (!Page.IsPostBack)
        {
            try
            {
                string roolo = Session["Role"].ToString();
                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "11") && (Session["Role"].ToString() != "14") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "15") && (Session["Role"].ToString() != "16"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
                
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

        }

    }

    private void assignvalue()
    {
        try
        {
            DataTable dt;
            string str;
            str = "SELECT REGISTRATION.AckNo, REGISTRATION.AdmFormNo, REGISTRATION.ApplicantName, REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.DOB, " +
                  " Religion.Religion, REGISTRATION.Gender, REGISTRATION.MaritalStatus, CATEGORY.Category, NATIONALITY.Nationality, REGISTRATION.BloodGroup, REGISTRATION.EmailId,REGISTRATION.Identification  , REGISTRATION.ContactNo, " +
                  " REGISTRATION.PresentAddress1, REGISTRATION.PresentAddress2, REGISTRATION.PresentDistrictCode, REGISTRATION.PresentPinCode, STREAM.StreamAbbr, REGISTRATION.TempRollNo, " +
                  " REGISTRATION.PermanentAddress1, REGISTRATION.PermanentAddress2, REGISTRATION.PermanentDistCode, REGISTRATION.PermanentPinCode, " +
                  " REGISTRATION.CourseSession, REGISTRATION.AdmFeeAmt, REGISTRATION.paymentID, REGISTRATION.paymentDate, REGISTRATION.Photo, REGISTRATION.Signature, REGISTRATION.RegYear, " +
                  " REGISTRATION.AdmYear, REGISTRATION.ExamAppeared, REGISTRATION.YearAppeared, REGISTRATION.AllIndiaRank, REGISTRATION.SelectionExamScore, REGISTRATION.QualifingExam, " +
                  " REGISTRATION.AdmissionDate, REGISTRATION.Remarks, REGISTRATION.PaymentMode, REGISTRATION.Bank, REGISTRATION.AdmissionBranch, REGISTRATION.SelectionExamRollNo, " +
                  " REGISTRATION.StreamCode, State.state, DISTRICT.DistName, DISTRICT_1.DistName AS presentdistrict, State_1.state AS presentstate, PREREGQUALIFICATION.ExamName, " +
                  " PREREGQUALIFICATION.CollName, PREREGQUALIFICATION.MainSubject, PREREGQUALIFICATION.PassYear, PREREGQUALIFICATION.Marks, CourseSpecialization.SpDescription, " +
                  " PHCategory.PHCategory FROM PREREGQUALIFICATION RIGHT OUTER JOIN Religion RIGHT OUTER JOIN State AS State_1 INNER JOIN DISTRICT AS DISTRICT_1 ON " +
                  " State_1.StateCode = DISTRICT_1.StateCode RIGHT OUTER JOIN REGISTRATION INNER JOIN STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode INNER JOIN " +
                  " CourseSpecialization ON CourseSpecialization.SPCode = REGISTRATION.SplCode ON DISTRICT_1.DistCode = REGISTRATION.PresentDistrictCode LEFT OUTER JOIN " +
                  " CATEGORY ON REGISTRATION.CastCode = CATEGORY.CategoryCode ON Religion.ReligionCode = REGISTRATION.ReligionCode LEFT OUTER JOIN DISTRICT INNER JOIN " +
                  " State ON DISTRICT.StateCode = State.StateCode ON REGISTRATION.PermanentDistCode = DISTRICT.DistCode LEFT OUTER JOIN NATIONALITY ON " +
                  " REGISTRATION.NationalityCode = NATIONALITY.NationalityCode ON PREREGQUALIFICATION.AckNo = REGISTRATION.AckNo LEFT OUTER JOIN PHCategory ON REGISTRATION.PhCategory = PHCategory.PHCode " +
                  " WHERE (REGISTRATION.TempRollNo = '" + textrollno.Text.Trim() + "') ORDER BY PREREGQUALIFICATION.PassYear";

            dt = fn.SelectDatatable(str);
            if (dt.Rows.Count > 0)
            {
                //HindiName.Text=dt.Rows[0]["HindiName"].ToString();
                ApplicantName.Text = dt.Rows[0]["ApplicantName"].ToString();
                FatherName.Text = dt.Rows[0]["FatherName"].ToString();
                MotherName.Text = dt.Rows[0]["MotherName"].ToString();
                DOB.Text = Convert.ToDateTime(dt.Rows[0]["DOB"].ToString()).ToString("dd/MM/yyyy");
                ReligionCode.Text = dt.Rows[0]["Religion"].ToString();
                Gender.Text = dt.Rows[0]["Gender"].ToString() == "M" ? "Male" : "Female";
                MaritalStatus.Text = dt.Rows[0]["MaritalStatus"].ToString() == "N" ? "Single" : "Married";
                BloodGroup.Text = dt.Rows[0]["BloodGroup"].ToString();
                CastCode.Text = dt.Rows[0]["Category"].ToString();
                NationalityCode.Text = dt.Rows[0]["Nationality"].ToString();
                ContactNo.Text = dt.Rows[0]["ContactNo"].ToString();
                EmailId.Text = dt.Rows[0]["EmailId"].ToString();
                phcategory.Text = dt.Rows[0]["PHCategory"].ToString();

                MOIdentification.Text = dt.Rows[0]["Identification"].ToString();

                PermanentAddress1.Text = dt.Rows[0]["PermanentAddress1"].ToString();
                PermanentAddress2.Text = dt.Rows[0]["PermanentAddress2"].ToString();
                State1.Text = dt.Rows[0]["state"].ToString();
                PermanentDistCode.Text = dt.Rows[0]["DistName"].ToString();
                PermanentPinCode.Text = dt.Rows[0]["PermanentPinCode"].ToString();
                PresentAddress1.Text = dt.Rows[0]["PresentAddress1"].ToString();
                PresentAddress2.Text = dt.Rows[0]["PresentAddress2"].ToString();
                State2.Text = dt.Rows[0]["presentstate"].ToString();
                PresentDistrictCode.Text = dt.Rows[0]["presentdistrict"].ToString();
                PresentPinCode.Text = dt.Rows[0]["PresentPinCode"].ToString();
                ddlExamAppeared.Text = dt.Rows[0]["ExamAppeared"].ToString();
                txtYearAppeared.Text = dt.Rows[0]["YearAppeared"].ToString();
                txtSelectionExamRollNo.Text = dt.Rows[0]["SelectionExamRollNo"].ToString();
                txtAllIndiaRank.Text = dt.Rows[0]["AllIndiaRank"].ToString();
                txtExamScore.Text = dt.Rows[0]["SelectionExamScore"].ToString();
                txtQualifingExamDegree.Text = dt.Rows[0]["QualifingExam"].ToString();


                StreamCode.Text = dt.Rows[0]["StreamAbbr"].ToString();
                ddlSplCode.Text = dt.Rows[0]["SpDescription"].ToString();
                Year1.Text = dt.Rows[0]["CourseSession"].ToString().Substring(5, 4);
                Year2.Text = dt.Rows[0]["CourseSession"].ToString().Substring(0, 4);
                if (dt.Rows[0]["AdmissionDate"] == DBNull.Value)
                {
                    CollegeAdmissionDate.Text = "";
                }
                else
                {
                    CollegeAdmissionDate.Text = Convert.ToDateTime(dt.Rows[0]["AdmissionDate"]).ToString("dd/MM/yyyy");
                }
                ddlPaymentMode.Text = dt.Rows[0]["PaymentMode"].ToString();

                RegFeeAmt.Text = dt.Rows[0]["AdmFeeAmt"].ToString();
                SCBNo.Text = dt.Rows[0]["paymentID"].ToString();
                if (dt.Rows[0]["paymentDate"] == DBNull.Value)
                {
                    SCBDate.Text = "";
                }
                else
                {
                    SCBDate.Text = Convert.ToDateTime(dt.Rows[0]["paymentDate"]).ToString("dd/MM/yyyy");
                }
                txtBank.Text = dt.Rows[0]["Bank"].ToString();
                RegYear.Text = dt.Rows[0]["PaymentMode"].ToString();
                RBDoc.Text = dt.Rows[0]["PaymentMode"].ToString();

                DocRemarks.Text = dt.Rows[0]["Remarks"].ToString();
                String[] arr = new string[5];

                TextBox txtassign;
                int i = 1;

                foreach (DataRow dr in dt.Rows)
                {


                    if (dr["ExamName"].ToString() != "")
                    {
                        arr[0] = "ExamCode" + i.ToString();
                        arr[1] = "CollCode" + i.ToString();
                        arr[2] = "Subject" + i.ToString();
                        arr[3] = "PassYear" + i.ToString();
                        arr[4] = "marks" + i.ToString();

                        for (int k = 1; k <= 5; k++)
                        {
                            txtassign = (TextBox)Panel2.FindControl(arr[k - 1]);
                            txtassign.Text = dr[48 + k].ToString();


                        }


                    }
                    i += 1;
                }

                Ackno.Text = dt.Rows[0]["Ackno"].ToString();
                RegYear.Text = dt.Rows[0]["RegYear"].ToString();
                regno.Text = dt.Rows[0]["AdmFormNo"].ToString();
                trollno.Text = dt.Rows[0]["TempRollNo"].ToString();

                Image1.ImageUrl = "~/ImageHandler.aspx?TempRollNo=" + textrollno.Text.Trim();
                Image1.DataBind();



                Image2.ImageUrl = "~/SignHandler.aspx?AckNo=" + Ackno.Text.Trim();
                Image2.DataBind();

            }
            else
            {
                LblMsg.Text = "Detail(s) not Found.";
            }
        }
        catch
        {
            LblMsg.Text = "Error Occurred: Contact to Administrator";
        }

    }

    protected void BtnReg_Click(object sender, EventArgs e)
    {
        assignvalue();
    }
}

  