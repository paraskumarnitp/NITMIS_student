using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class ViewUnivStudents : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(Year, "Year", "Select Year from Year where year >= '2008' order by Year", "Year", "Year");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            BindGrid();
            //DataSet ds = new DataSet();
            //ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select AckNo,RegNo,ApplicantName,FatherName,MotherName,DOB,CollCode from Registration where RegNo is null or RegNo=''");
            //UnivView.DataSource = ds;
            //UnivView.DataBind();
            TotStudent.Text = UnivView.Rows.Count.ToString();
        }


    }
    protected void BtnView_Click(object sender, EventArgs e)
    {
        BindGrid();
        if (UnivView.Rows.Count > 0)
        {
            TotStudent.Visible = true;
            TotStudent.Text = " Total Student =  " + UnivView.Rows.Count.ToString();
            Panel1.Visible = true;
        }
        else
        {
            TotStudent.Visible = true;
            TotStudent.Text = "No Records Found";
            Panel1.Visible = false;
        }

    }
    
  
    void BindGrid()
    {
        string sql = "";
        DataSet ds = new DataSet();
        sql = "SELECT EXAM.RegNo AS RegNo,Exam.UnivRollNo, REGISTRATION.ApplicantName, REGISTRATION.FatherName," +
                      "EXAM.StreamCode, EXAM.StreamPartCode,Exam.subcode,EXAM.ExamFormNo, EXAM.ExamType" +
                      " FROM  REGISTRATION INNER JOIN EXAM ON REGISTRATION.RegNo = EXAM.RegNo" +
                      " where EXAM.CollCode='" + CollCode.SelectedValue + "' and ExamYear='" + Year.SelectedValue + "' and EXAM.StreamCode='" + StreamCode.SelectedValue + "' and EXAM.SubCode='" + SubCode.SelectedValue + "'  " +
                      "and (UnivRollNo is NOT NULL or UnivRollNo<>'') and " +
                      "(Exam.FinalizeDateTime is not null or Exam.FinalizeDateTime<>'')" +
                      "and (Exam.verifyStatus='N') order by Exam."+OrderBy.SelectedValue+" ";

        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        UnivView.DataSource = ds;
        UnivView.DataBind();
    }
   
   
    protected void UnivView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        UnivView.PageIndex = e.NewPageIndex;
        BindGrid();
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");

        StreamCode.Focus(); 
    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            CollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            CollCode.SelectedIndex = 0;
        }
    }
    protected void CollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = CollCode.SelectedValue.ToString();
    }
}
