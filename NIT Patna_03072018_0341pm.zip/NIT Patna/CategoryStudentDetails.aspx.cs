using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using Microsoft.Reporting.WebForms; 

public partial class CategoryStudentDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(Year, "Year", "Select Year from Year where year > '2008' order by Year", "Year", "Year");
        }
    }
    protected void BtnView_Click(object sender, EventArgs e)
    {
        //RV.ServerReport.ReportPath = "/UniversityReport/CategoryStudentDetails";
        //ReportParameter[] rp;
        //rp = new ReportParameter[1];
        //rp = new ReportParameter[2];

        //rp[0] = new ReportParameter("CollCode", CollCode.SelectedValue);
        //rp[1] = new ReportParameter("year", Year.SelectedValue);
        //RV.ServerReport.SetParameters(rp);

       //----------------------------------------------------
        
        //TextWriter tw = new StreamWriter(Server.MapPath(@"Report\CategoryStudentDetails.htm"));

        //tw.WriteLine("<HTML>");
        //tw.WriteLine("<HEAD>");
        //tw.WriteLine("<link rel='stylesheet' type='text/css' href='style.css'>");
        //tw.WriteLine("<TITLE>Report :: CategoryStudentDetails</TITLE>");
        //tw.WriteLine("<style>");
        //tw.WriteLine(".noprint, .print {display:none;}");
        //tw.WriteLine("@media screen {");
        //tw.WriteLine(".noprint, .printns {display:block;}");
        //tw.WriteLine(".print {display:none;}");
        //tw.WriteLine("}");
        //tw.WriteLine("@media print {");
        //tw.WriteLine(".print {display:block;}");
        //tw.WriteLine(".noprint, .printns, {display:none;}");
        //tw.WriteLine("}");
        //tw.WriteLine("</style>");


        //tw.WriteLine("</HEAD>");
        //tw.WriteLine("<body topmargin='0' marginheight='0' marginwidth='0' bottommargin='0' leftmargin='0' rightmargin='0'>");
        //tw.WriteLine("<table width='720' border='0' cellpadding='4' cellspacing='3'>");
        //tw.WriteLine("<tr>");
        //tw.WriteLine("<td valign='top'>");
        //tw.WriteLine("<table width='720' align='center'>");
        //tw.WriteLine("<tr>");
        //tw.WriteLine("<td class='heading'>Magadh University , Gaya </td>");
        //tw.WriteLine("</tr>");
        //tw.WriteLine("<tr>");
        //tw.WriteLine("<td id='subhead'>College Name - "+ CollCode.SelectedItem.Text.ToString() +" </td>");
        //tw.WriteLine("</tr>");





        //tw.WriteLine("</table>");
        //tw.WriteLine("<br>");
        ////tw.WriteLine("</td>");
        ////tw.WriteLine("</tr>");
        ////tw.WriteLine("</table>");
        //// Table2 Begin
        //tw.WriteLine("<table width='720' border='0'>");
        //tw.WriteLine("<tr> <td colspan='4' align='center' id='subhead'>Category Wise Student Details (Year - "+ Year.SelectedValue +")  <p></p></td></tr>");
        //tw.WriteLine("<tr class='main'>");
        //tw.WriteLine("<td>Category</td>");
        //tw.WriteLine("<td>Male</td>");
        //tw.WriteLine("<td>Female</td>");
        //tw.WriteLine("<td>Total Students</td>");
        //tw.WriteLine("</tr>");


        //tw.WriteLine(getData());

        //tw.WriteLine("</table>");


        ////Table2 Close

       
        //tw.WriteLine("<table width='720' align='center' >");
        //tw.WriteLine("<tr><td align='center'><p id='sml'><br>IT Solution Provided by National Informatics Centre, Bihar State Center, Patna </p>  </td>");
        //tw.WriteLine("</tr>");
        //tw.WriteLine("<tr><td valign='top'>");
        //tw.WriteLine("<div class='printns' align='Center'><a href='javascript:window.print()'><img src='Print.gif' alt='Print' width='110' height='25' border='0'></a></div>");
        //tw.WriteLine("</td></tr>");

        //tw.WriteLine("</table>");
        //tw.WriteLine("</td>");
        //tw.WriteLine("</tr>");
        //tw.WriteLine("</table>");
        //tw.WriteLine("</body>");
        //tw.WriteLine("</html>");

        //tw.Close();

        ////System.Diagnostics.Process.Start(Server.MapPath(@"Report\test.htm"));
        //string s = "window.open('report/CategoryStudentDetails.htm','Default','height=600,width=800,status=yes,toolbar=no,menubar=no,location=no'); ";

        //string popupScript = "<script language='javascript'>" + s + "</script>";

        //Page.RegisterStartupScript("PopupScript", popupScript);

    }


    public string getData()
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        con.Open();

        
        cmd.CommandText = "select distinct castcode from registration where regyear='" + Year.SelectedValue + "' and collcode='"+ CollCode.SelectedValue +"' ";
        SqlDataReader sdr;
        sdr = cmd.ExecuteReader();


        string CategoryName = "", countm = "", countf = "";
        int countTotal = 0;
        UnivService.Service1 ss = new UnivService.Service1();
        string str = "";
        
        while (sdr.Read())
        {

            CategoryName = ss.GetNewCode("select Category from category where categorycode='" + sdr[0].ToString() + "'");
            countm = ss.GetNewCode("select count(*) from registration where collcode='" + CollCode.SelectedValue + "' and castcode='" + sdr[0].ToString() + "' and gender='M'");
            countf = ss.GetNewCode("select count(*) from registration where collcode='" + CollCode.SelectedValue + "' and castcode='" + sdr[0].ToString() + "' and gender='F'");
            countTotal = int.Parse(countm) + int.Parse(countf);


            //str += "<tr id='data'>";
            //str += "<td>" + CategoryName + " </td>";
            //str += "<td>" + countm + "</td>";
            //str += "<td>" + countf + "</td>";
            //str += "<td>" + countTotal + "</td>";
            //str += "</tr>";



        }
        sdr.Dispose();
        con.Close();

        return str;
    }
}
