using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Data.Odbc;

public partial class Demandlatterreport : System.Web.UI.Page
{
    DataSet ds;
    string adyear = "";
    string query = "";
    int odeven = 0;
    string totalquery,totalsum="";
    //double total=0.0;
    string roll = "";
    string stramtypecode = "";
    string name="", sem1, nextsem, program1, fname1,session1="";
    string num="";
    Functionreviseed fnrev = new Functionreviseed();
   
    protected void Page_Load(object sender, EventArgs e)
    {
       
        


     session1=   ConfigurationManager.AppSettings["ddexamsession"].ToString();

 if (Session["roll"] != null)
        {
            roll = Session["roll"].ToString();

        }
        if (Session["year"] != null)
        {
            adyear = Session["year"].ToString();
        }

        if (Session["oddeven"] != null)
        {
            odeven = Convert.ToInt32(Session["oddeven"].ToString());

        }
        if (Session["name"] != null)
        {
            name = Session["name"].ToString();

        }
       
        if (Session["sem"] != null)
        {
            sem1 = Session["sem"].ToString();

        }

        if (Session["nextsem"] != null)
        {
           nextsem = Session["nextsem"].ToString();

        }
        if (Session["program"] != null)
        {
            program1 = Session["program"].ToString();

        }

        if (Session["fname"] != null)
        {
            fname1 = Session["fname"].ToString();

        }

        if (Session["stramtypecode"] != null)
        {
            stramtypecode = Session["stramtypecode"].ToString();
        }



      



        if (odeven % 2 == 1)
        {
            query = "SELECT Fee_Details.Description, Fee_Details.Amount FROM Feetype INNER JOIN  Fee_Details " +
                              " ON Feetype.ID = Fee_Details.Fee_Id WHERE (Feetype.StreamTypeCode = '" + stramtypecode + "') AND  (Fee_Details.IsOdd = 1) AND " +
                              " (ISNULL(Feetype.FrmAdmYear, '1990') <='" + adyear + "' )  AND (ISNULL(Feetype.ToAdmYear, year(getdate())) >=  '" + adyear + "')";
        }
        else
        {
            query = "SELECT Fee_Details.Description, Fee_Details.Amount FROM Feetype INNER JOIN  Fee_Details " +
                                         " ON Feetype.ID = Fee_Details.Fee_Id WHERE (Feetype.StreamTypeCode = '" + stramtypecode + "') AND  (Fee_Details.IsEven = 1) AND " +
                                         " (ISNULL(Feetype.FrmAdmYear, '1990') <='" + adyear + "' )  AND (ISNULL(Feetype.ToAdmYear, year(getdate())) >=  '" + adyear + "')";

        }
        if (odeven % 2 == 1)
        {
            totalquery = "SELECT SUM(amount) FROM Feetype INNER JOIN  Fee_Details " +
                      " ON Feetype.ID = Fee_Details.Fee_Id WHERE (Feetype.StreamTypeCode = '" + stramtypecode + "') AND  (Fee_Details.IsOdd = 1) AND " +
                    " (ISNULL(Feetype.FrmAdmYear, '1990') <='" + adyear + "' )  AND (ISNULL(Feetype.ToAdmYear, year(getdate())) >=  '" + adyear + "')";
        }
        else
        {
            totalquery = "SELECT SUM(amount) FROM Feetype INNER JOIN  Fee_Details " +
            " ON Feetype.ID = Fee_Details.Fee_Id WHERE (Feetype.StreamTypeCode = '" + stramtypecode + "') AND  (Fee_Details.IsEven = 1) AND " +
            " (ISNULL(Feetype.FrmAdmYear, '1990') <='" + adyear + "' )  AND (ISNULL(Feetype.ToAdmYear, year(getdate())) >=  '" + adyear + "')";

        }



        string conString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;


        object RegNo = fnrev.singlevalue(totalquery);
        totalsum = RegNo.ToString();
        int idx=totalsum.IndexOf('.');
        string substr = totalsum.Substring(0, idx);

        int suminword = Convert.ToInt32(substr);

    num=  NumbersToWords(suminword);
    num = num + " only";

       OdbcCommand cmd = new OdbcCommand(query);
      
        using (OdbcConnection con = new OdbcConnection(conString))
        {
            using (OdbcDataAdapter sda = new OdbcDataAdapter())
            {
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                sda.SelectCommand = cmd;
                ds = new DataSet();
                sda.Fill(ds, "DataTable1");
            }

            ReportDocument myReportDocument = new ReportDocument();
            myReportDocument.Load(Server.MapPath("Report\\demandletter.rpt"));
            myReportDocument.SetDataSource(ds);

            myReportDocument.SetParameterValue("name", name);
            myReportDocument.SetParameterValue("roll", roll);
           myReportDocument.SetParameterValue("sem", sem1);
           myReportDocument.SetParameterValue("nsem", nextsem);
           myReportDocument.SetParameterValue("program",program1);
           myReportDocument.SetParameterValue("session",session1);
          myReportDocument.SetParameterValue("fname",fname1);
          myReportDocument.SetParameterValue("total", totalsum);
          myReportDocument.SetParameterValue("totalinword", num);
            CrystalReportViewer1.ReportSource = myReportDocument;


            //Crystalnoccertificate.ReportSource = myReportDocument;
            CrystalReportViewer1.DisplayGroupTree = false;


            CrystalReportViewer1.HasToggleGroupTreeButton = false;
            CrystalReportViewer1.DataBind();



            con.Close();
        }


    }

    public static string NumbersToWords(int inputNumber)
    {
        int inputNo = inputNumber;
        if (inputNo == 0)
            return "Zero";
        int[] numbers = new int[4];
        int first = 0;
        int u, h, t;
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        if (inputNo < 0)
        {
            sb.Append("Minus ");
            inputNo = -inputNo;
        }
        string[] words0 = {"" ,"One ", "Two ", "Three ","Four ",
            "Five " ,"Six ", "Seven ", "Eight ", "Nine "};
        string[] words1 = {"Ten ", "Eleven ", "Twelve ", "Thirteen ", "Fourteen ",
            "Fifteen ","Sixteen ","Seventeen ","Eighteen "," Nineteen "};
        string[] words2 = {"Twenty ", "Thirty ", "Forty ", "Fifty ", "Sixty ",
            "Seventy ","Eighty ", "Ninety "};
        string[] words3 = { "Thousand ", "Lakh ", "Crore " };
        numbers[0] = inputNo % 1000; // units
        numbers[1] = inputNo / 1000;
        numbers[2] = inputNo / 100000;
        numbers[1] = numbers[1] - 100 * numbers[2]; // thousands
        numbers[3] = inputNo / 10000000; // crores
        numbers[2] = numbers[2] - 100 * numbers[3]; // lakhs
        for (int i = 3; i > 0; i--)
        {
            if (numbers[i] != 0)
            {
                first = i;
                break;
            }
        }
        for (int i = first; i >= 0; i--)
        {
            if (numbers[i] == 0) continue;
            u = numbers[i] % 10; // ones
            t = numbers[i] / 10;
            h = numbers[i] / 100; // hundreds
            t = t - 10 * h; // tens
            if (h > 0) sb.Append(words0[h] + "Hundred ");
            if (u > 0 || t > 0)
            {
                if (h > 0 || i == 0) sb.Append("");
                if (t == 0)
                    sb.Append(words0[u]);
                else if (t == 1)
                    sb.Append(words1[u]);
                else
                    sb.Append(words2[t - 2] + words0[u]);
            }
            if (i != 0) sb.Append(words3[i - 1]);
        }
        return sb.ToString().TrimEnd();
    }




}






