using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.Text;

public partial class AssigningCoursePaper : System.Web.UI.Page
{
    Functionreviseed fn = new Functionreviseed();
    Functionreviseed chkfn = new Functionreviseed();
    // static int CountCourse = 0;
    //static int CountElective = 0;
    DataTable dt1;
    DataRow dr = null;
    DataRow dr2 = null;
    DataRow[] dr1;
    string querypart = "";

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "13"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            string deptcode = string.Empty;
            if (Session["Role"].ToString() == "13")
            {
                deptcode = (fn.singlevalue("Select departmentId From Login Where Userid = '" + Session["UserId"].ToString() + "'")).ToString();
                querypart = "and DepartmentId='" + deptcode + "'";
            }
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, Stream.StreamCode from Stream INNER JOIN Department_Stream on Stream.StreamCode=Department_Stream.StreamCode Where STUDY='Y'" + querypart + " order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(Year3, "Year", "Select Year from Year where year > '2016' order by Year", "Year", "Year");
            StreamCode.Items.Insert(0, new ListItem("-Select", "0"));
            Year3.Text = System.DateTime.Now.Year.ToString();
            ViewState["action"] = "Save";
            Panel1.Visible = false;


        }


    }

    protected void BtnSave_Click(object sender, EventArgs e)
    {
        try
        {
            //SaveExam();
            clear();

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

    }

    void InstCode_Enter(object sender, EventArgs e)
    {
        LblMsg.Text = "Enter Pressed";
    }

    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        clear();

        if (StreamCode.SelectedValue == "00") return;

        UnivService.Service1 NicService = new UnivService.Service1();
        string y = NicService.GetNewCode("Select Duration from stream Where StreamCode='" + StreamCode.SelectedValue + "'");

        PopulateDDL popddl = new PopulateDDL();
        int semValue = 0;
        if (month1.SelectedValue != "JAN")
        {
            semValue = 1;
        }
        popddl.Popualate(Semester, "StreamPart", "Select STREAMPART,StreamPartCode from STREAMPART where StreamCode in ('" + StreamCode.SelectedValue + "','00') and " +
            " (CONVERT(int, LEFT(SUBSTRING(StreamPart, PATINDEX('%[0-9]%', StreamPart), 8000), PATINDEX('%[^0-9]%', SUBSTRING(StreamPart, PATINDEX('%[0-9]%', " +
            " StreamPart), 8000) + 'X') - 1))%2=" + semValue.ToString() + " OR CONVERT(int, LEFT(SUBSTRING(StreamPart, PATINDEX('%[0-9]%', StreamPart), 8000), PATINDEX('%[^0-9]%', " +
            " SUBSTRING(StreamPart, PATINDEX('%[0-9]%', StreamPart), 8000) + 'X') - 1)) = 3) order by StreamPart", "StreamPart", "StreamPartCode");
        //        popddl.Popualate(Semester, "StreamPart", "Select STREAMPART,StreamPartCode from STREAMPART where StreamCode in ('" + StreamCode.SelectedValue + "','00') and CONVERT(int, LEFT(SUBSTRING(StreamPart, PATINDEX('%[0-9]%', StreamPart), 8000), " +
        // " PATINDEX('%[^0-9]%', SUBSTRING(StreamPart, PATINDEX('%[0-9]%', " +
        //" StreamPart), 8000) + 'X') - 1))%2=" + semValue.ToString() + "  order by StreamPart", "StreamPart", "StreamPartCode");
        StreamCode.Focus();

        DataSet dssplcode = fn.SelectDataset("SELECT Stream_Specialization.SplCode as SPCode, CourseSpecialization.SpDescription FROM Stream_Specialization " +
            " INNER JOIN CourseSpecialization ON Stream_Specialization.SplCode = CourseSpecialization.SPCode WHERE Stream_Specialization.StreamCode = '" + StreamCode.SelectedValue + "'");
        if (dssplcode.Tables[0].Rows.Count > 0)
        {
            drpsplType.Items.Clear();
            drpsplType.DataSource = dssplcode.Tables[0];
            drpsplType.DataTextField = "SpDescription";
            drpsplType.DataValueField = "SPCode";
            drpsplType.DataBind();
        }
        else
        {
            drpsplType.Items.Clear();
            drpsplType.Items.Insert(0, new ListItem("NA", "00"));
        }

        GetData();
    }

    protected void Year1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            UnivService.Service1 NicService = new UnivService.Service1();
            string y = NicService.GetNewCode("Select Duration from stream Where StreamCode='" + StreamCode.SelectedValue + "'");

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }
    DataSet dscrsespl;
    protected void bindddlcoursespl()
    {
        Functionreviseed appfn = new Functionreviseed();
        dscrsespl = appfn.SelectDataset("select * from Stream_Specialization where ISNULL(streamcode,'')=case when (select COUNT(StreamCode) from Stream_Specialization where StreamCode='" + StreamCode.SelectedValue + "')>0 then '" + StreamCode.SelectedValue + "' else '' end");
        drpsplType.DataSource = dscrsespl.Tables[0];
        drpsplType.DataTextField = "SPCode";
        drpsplType.DataValueField = "SPCode";
        drpsplType.DataBind();
        drpsplType.Items.Insert(0, "--Select--");
        //popddl.Popualate(drpsplType, "CourseSpecialization", "", "", "SPCode");
    }

    protected void Semester_SelectedIndexChanged(object sender, EventArgs e)
    {
        GetData();

    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Home.aspx");

    }
    private void GetData()
    {
        rptCompulsaryPaper.DataSource = null;
        rptCompulsaryPaper.DataBind();
        ViewState["CurrentTable"] = null;

        LblMsg.Text = "";
        btnsubmit.Text = "Save";
        string examsession = month1.SelectedItem.ToString() + "-" + month2.SelectedItem.ToString() + "_" + Year3.SelectedItem.ToString();
        DataSet dsassignedcourse = fn.SelectDataset(" sELECT a.SubPaperCode, b.PaperAbbr as txtcoursecode, b.PaperName as txtcoursetitle, " +
                                                    " b.Credit as txtcredit,c.UserId " +
                                                    " FROM CourseCodeOfferedDetail AS A inner join CourseCodeOffered d  on a.CourseCodeOfferedId=d.Id INNER JOIN " +
                                                    " COURSEPAPERS AS B ON A.SubPaperCode = B.SubPaperCode " +
                                                    " left join Faculty_paper_a c on c.SubPaperCode=a.SubPaperCode and c.Splcode=d.Splcode and d.ExamSession=c.ExamSession and Is_Active='Y' " +
                                                   " WHERE     (d.ExamSession = '" + examsession + "') AND (d.StreamPartCode = '" + Semester.SelectedValue + "') AND (A.OfferedTypeId = '1') and (d.SplCode='" + drpsplType.SelectedValue + "') ");
        dsassignedcourse.Tables[0].PrimaryKey = new DataColumn[] { dsassignedcourse.Tables[0].Columns["SubPaperCode"] };
        ViewState["CurrentTable"] = dsassignedcourse.Tables[0];
        dt1 = dsassignedcourse.Tables[0];
        rptCompulsaryPaper.DataSource = dsassignedcourse.Tables[0];
        rptCompulsaryPaper.DataBind();
        object count = fn.singlevalue(" select Convert(varchar,OpenElectiveCount) from CourseCodeOffered where SplCode='" + drpsplType.SelectedValue + "' and StreamPartCode='" + Semester.SelectedValue + "'  and ExamSession='" + examsession + "'");
        if (count == DBNull.Value)
        {
            ddlNoOfPaper.SelectedValue = "00";
        }
        else
        {
            ddlNoOfPaper.SelectedValue = (string)count;
        }
        BindElectivePaperControl();
        ViewState["action"] = "Update";
        if (dt1.Rows.Count > 0)
        {
            Panel1.Visible = true;
            btnsubmit.Text = "UPDATE";
            btnsubmit.Visible = true;
        }
        else
        {
            Panel1.Visible = false;
            btnsubmit.Text = "UPDATE";
            btnsubmit.Visible = false;
        }
    }

    private void BindElectivePaperControl()
    {
        PopulateDDL populateDDL = new PopulateDDL();
        populateDDL.Popualate(ddlElectiveCourse, "CoursepaperofferedType", "select Id,Name from CoursepaperofferedType where categoryId=2", "Name", "Id");
        string examsession = month1.SelectedItem.ToString() + "-" + month2.SelectedItem.ToString() + "_" + Year3.SelectedItem.ToString();
        DataTable dscourse = fn.SelectDatatable("select Id,CourseCode from MasterCoursePaper inner join Department_Stream k on MasterCoursePaper.DepartmentId=k.DepartmentId where isElective=1 and k.StreamCode='" + StreamCode.SelectedValue + "'  and  Id not in (  select e.Id from CourseCodeOfferedDetail a inner join CourseCodeOffered d on a.CourseCodeOfferedId=d.Id INNER JOIN COURSEPAPERS AS B ON A.SubPaperCode = B.SubPaperCode inner join MasterCoursePaper e on e.Id=b.masterpaperId " +
                                                " inner join coursepaperofferedtype h on h.Id=a.offeredTypeId where (d.ExamSession = '" + examsession + "') AND (d.StreamPartCode = '" + Semester.SelectedValue + "') AND (A.OfferedTypeId != 1) and (d.SplCode='" + drpsplType.SelectedValue + "') )");
        dscourse.PrimaryKey = new DataColumn[] { dscourse.Columns["Id"] };
        ViewState["CoursePaper"] = dscourse;
        drpdlcoursecode.DataSource = dscourse;
        drpdlcoursecode.DataTextField = "CourseCode";
        drpdlcoursecode.DataValueField = "Id";
        drpdlcoursecode.DataBind();
        drpdlcoursecode.Items.Insert(0, new ListItem("Select CourseCode", "00"));
        populateDDL.Popualate(drpddlfaculty, "Login", "select UserName+'-'+Designation AS UserName,RTRIM( UserId) as UserId from LogIn a inner Join Department_Stream d on a.DepartmentId=d.DepartmentId where IsLock='N' and (Userrole='9' or Userrole='13' or Userrole='15') and StreamCode='" + StreamCode.SelectedValue + "' ", "UserName", "UserId");
        string strDataBindQuery = "  select e.Id,e.CourseCode,e.Title,e.Credit,offeredTypeId,h.Name as offeredType,c.userId,k.UserName " +
                                " from CourseCodeOfferedDetail a INNER JOIN CourseCodeOffered d on a.CourseCodeOfferedId=d.Id  INNER JOIN  COURSEPAPERS AS B ON A.SubPaperCode = B.SubPaperCode inner join MasterCoursePaper e on e.Id=b.masterpaperId  inner join coursepaperofferedtype h on h.Id=a.offeredTypeId left join " +
                                " Faculty_paper_a c on c.SubPaperCode=a.SubPaperCode and c.Splcode=d.Splcode " +
                                " and d.ExamSession=c.ExamSession and Is_Active='Y' left join LogIn k on c.UserId=k.UserId  WHERE     (d.ExamSession = '" + examsession + "') AND (d.StreamPartCode = '" + Semester.SelectedValue + "') AND (A.OfferedTypeId != 1) and (d.SplCode='" + drpsplType.SelectedValue + "')";

        DataTable dtElectiveCourse = fn.SelectDatatable(strDataBindQuery);
        dtElectiveCourse.PrimaryKey = new DataColumn[] { dtElectiveCourse.Columns["Id"] };
        ViewState["gvElectiveCourse"] = dtElectiveCourse;
        gvcourse.DataSource = dtElectiveCourse;
        gvcourse.DataBind();
    }
    public void clear()
    {


    }
    protected void month1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (month1.SelectedIndex == 1)
        {
            month2.SelectedIndex = 1;
        }
        else if (month1.SelectedIndex == 2)
        {
            month2.SelectedIndex = 2;
        }
        else
        {
            month2.SelectedIndex = 0;
        }
        GetData();
    }
    protected void Year3_SelectedIndexChanged(object sender, EventArgs e)
    {
        //retrievevalue();
    }

    string paperabbr;

    protected void drpsplType_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        string txtSearchText = txtSearch.Text;
        string subPaperCode = (string)fn.singlevalue("Select Convert(varchar,Id) From MasterCoursePaper Where CourseCode ='" + txtSearchText + "'");
        if (subPaperCode == string.Empty)
        {
            drpdlcoursecode.SelectedValue = "0";
            CourseSelectionChanged();
        }
        else
        {
            ListItem listItem = drpdlcoursecode.Items.FindByText(txtSearchText.ToUpper());
            if (listItem != null)
            {
                drpdlcoursecode.SelectedValue = listItem.Value;
            }
        }
        CourseSelectionChanged();
    }
    private void CourseSelectionChanged()
    {
        DataSet dscoursedetails = fn.SelectDataset("Select Title,Credit,L+'-'+T+'-'+P AS LTP From MasterCoursePaper Where Id = " + drpdlcoursecode.SelectedValue);
        if (dscoursedetails.Tables[0].Rows.Count > 0)
        {
            coursetitle.Text = dscoursedetails.Tables[0].Rows[0]["Title"].ToString();
            credit.Text = dscoursedetails.Tables[0].Rows[0]["Credit"].ToString();
            ltp.Text = dscoursedetails.Tables[0].Rows[0]["LTP"].ToString();
        }
        else
        {
            coursetitle.Text = "";
            credit.Text = "";
            ltp.Text = "";
        }
    }
    protected void btnshow_Click(object sender, EventArgs e)
    {
        string sqlQuery = " select Id,CourseCode,Title,Credit," + ddlElectiveCourse.SelectedValue + " as offeredTypeId,'" + ddlElectiveCourse.SelectedItem.Text + "' as offeredType,userId,UserName  from masterCoursePaper " +
                           " cross apply (select * from login where userid='" + drpddlfaculty.SelectedValue + "') a " +
                            " where id=" + drpdlcoursecode.SelectedValue;
        DataTable dt = fn.SelectDatatable(sqlQuery);
        dt.PrimaryKey = new DataColumn[] { dt.Columns["Id"] };
        DataTable dtElectiveCourse = (DataTable)ViewState["gvElectiveCourse"];
        if (dtElectiveCourse == null)
        {
            ViewState["gvElectiveCourse"] = dt;
            dtElectiveCourse = dt;
        }
        else
        {
            dtElectiveCourse.Merge(dt);
        }
        DataTable dtCoursePaper = (DataTable)ViewState["CoursePaper"];
        DataRow foundRow = dtCoursePaper.Rows.Find(drpdlcoursecode.SelectedValue);
        if (foundRow != null)
        {
            dtCoursePaper.Rows.Remove(foundRow);
            ViewState["CoursePaper"] = dtCoursePaper;
        }
        BindBothDDLCourseCode(dtCoursePaper);
        gvcourse.DataSource = dtElectiveCourse;
        gvcourse.DataBind();
    }
    protected void drpdlcoursecode_SelectedIndexChanged(object sender, EventArgs e)
    {
        CourseSelectionChanged();
    }
    protected void gvcourse_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "remove")
        {
            GridViewRow gvr = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
            int RowIndex = gvr.RowIndex;

            string masterPaperId = Convert.ToString(gvcourse.DataKeys[RowIndex][0]);
            if (ViewState["gvElectiveCourse"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["gvElectiveCourse"];
                DataRow foundRow = dtCurrentTable.Rows.Find(masterPaperId);
                if (foundRow != null)
                {
                    foundRow.Delete();
                    DataTable dtCoursePaper = (DataTable)ViewState["CoursePaper"];
                    DataRow foundCourseRow = dtCoursePaper.Rows.Find(masterPaperId);
                    if (foundCourseRow == null)
                    {
                        DataTable dscourse = fn.SelectDatatable("select Id,CourseCode from MasterCoursePaper where isElective=1 and Id=" + masterPaperId);
                        dtCoursePaper.Merge(dscourse);
                        dtCoursePaper.AcceptChanges();
                        ViewState["CoursePaper"] = dtCoursePaper;
                        BindBothDDLCourseCode(dtCoursePaper);
                    }
                }
                dtCurrentTable.AcceptChanges();
                ViewState["gvElectiveCourse"] = dtCurrentTable;
                gvcourse.DataSource = dtCurrentTable;
                gvcourse.DataBind();
            }
        }
    }

    private void BindBothDDLCourseCode(DataTable dtCoursePaper)
    {
        drpdlcoursecode.DataSource = dtCoursePaper;
        drpdlcoursecode.DataTextField = "CourseCode";
        drpdlcoursecode.DataValueField = "Id";
        drpdlcoursecode.DataBind();
    }

    protected void Year3_SelectedIndexChanged1(object sender, EventArgs e)
    {
        GetData();
    }
    protected void drpsplType_SelectedIndexChanged1(object sender, EventArgs e)
    {
        GetData();
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        Dictionary<string, string> dict = new Dictionary<string, string>();
        Dictionary<string, string> dictFaculty = new Dictionary<string, string>();
        string[] subPaperCodeList = new string[gvcourse.Rows.Count];
        string examsession = month1.SelectedItem.ToString() + "-" + month2.SelectedItem.ToString() + "_" + Year3.SelectedItem.ToString();
        int courseCodeOfferedId = (int)fn.singlevalue(" select Id from CourseCodeOffered where SplCode='" + drpsplType.SelectedValue + "' and StreamPartCode='" + Semester.SelectedValue + "'  and ExamSession='" + examsession + "'");
        string updateOpenElective = " Update CourseCodeOffered set OpenElectiveCount=" + ddlNoOfPaper.SelectedValue + ",ModifiedDate=getdate(),UserId='" + Session["UserId"].ToString() + "'  where Id=" + courseCodeOfferedId.ToString();
        int resultouter = fn.InsertUpdateDelete(updateOpenElective);
        for (int i = 0; i <= gvcourse.Rows.Count - 1; i++)
        {
            int masterPaperId = (int)gvcourse.DataKeys[i].Value;
            string subPaperCode = (string)fn.singlevalue(" select SubPaperCode from MasterCoursePaper a  inner join CoursePapers b on a.Id=b.MasterPaperId where a.Id=" + masterPaperId + " and b.StreampartCode='" + Semester.SelectedValue + "'");
            if (subPaperCode == null)
            {
                string newCourseCode = " INSERT INTO COURSEPAPERS " +
                                        " (MasterPaperId, PaperAbbr, PaperName, L, T, P, Credit, FullMarks, PassMarks, " +
                                        " PaperTypeCode, StreamPart, StreamPartCode,StreamCode, SubPaperCode, SubCode) " +
                                        " SELECT Id, CONVERT(varchar, LEFT(SUBSTRING('" + Semester.SelectedItem.Text.Trim() + "', PATINDEX('%[0-9]%', '" + Semester.SelectedItem.Text.Trim() + "'), 8000), PATINDEX('%[^0-9]%', SUBSTRING('" + Semester.SelectedItem.Text.Trim() + "', PATINDEX('%[0-9]%', '" + Semester.SelectedItem.Text.Trim() + "'), 8000) + 'X') - 1))+ CourseCode, Title, L, T, P, Credit, FullMarks, PassMarks, PaperTypeCode, '" + Semester.SelectedItem.Text.Trim() + "','" + Semester.SelectedValue + "','" + StreamCode.SelectedValue + "',(select max(Subpapercode)+1 from CoursePapers),(select SubCode from Subject where streamCode='" + StreamCode.SelectedValue + "') " +
                                        " FROM MasterCoursePaper AS a WHERE (Id = " + masterPaperId.ToString() + ")";
                int result = fn.InsertUpdateDelete(newCourseCode);
                if (result == -1000)
                {
                    result = fn.InsertUpdateDelete("Update COURSEPAPERS SET MasterPaperId = '" + masterPaperId.ToString() + "' WHERE PaperAbbr =  CONVERT(varchar, LEFT(SUBSTRING('" + Semester.SelectedItem.Text.Trim() + "', PATINDEX('%[0-9]%', '" + Semester.SelectedItem.Text.Trim() + "'), 8000), PATINDEX('%[^0-9]%', SUBSTRING('" + Semester.SelectedItem.Text.Trim() + "', PATINDEX('%[0-9]%', '" + Semester.SelectedItem.Text.Trim() + "'), 8000) + 'X') - 1))+ (select CourseCode from MasterCoursePaper where Id='" + masterPaperId.ToString() + "')");
                }
                subPaperCode = (string)fn.singlevalue(" select SubPaperCode from MasterCoursePaper a  inner join CoursePapers b on a.Id=b.MasterPaperId where a.Id=" + masterPaperId.ToString() + " and b.StreampartCode='" + Semester.SelectedValue + "'");
                string paperTypeCode = (string)fn.singlevalue("select PaperTypeCode from CoursePapers where SubpaperCode='" + subPaperCode + "'");
                if (paperTypeCode == "04")
                {
                    string practicalPapers = " INSERT INTO PRACTICALPAPERS (FullMarks, PassMarks, Credit,SubPaperCode) " +
                                            " SELECT    Credit, FullMarks, '00','" + subPaperCode + "' FROM         MasterCoursePaper  ";
                    result = fn.InsertUpdateDelete(practicalPapers);
                }
            }
            HiddenField hfSubpaperCodeControl = (HiddenField)gvcourse.Rows[i].FindControl("hfSubpaperCode");
            HiddenField hfUserIdControl = (HiddenField)gvcourse.Rows[i].FindControl("hfUserId");
            dict.Add(subPaperCode, hfSubpaperCodeControl.Value);
            dictFaculty.Add(subPaperCode, hfUserIdControl.Value);
            subPaperCodeList[i] = subPaperCode;
        }

        string restInactive = " INSERT INTO CourseCodeOfferedDetailHistory (SubPaperCode,  OfferedTypeId,CourseCodeOfferedId ,DeletedDate, UserId) SELECT     SubPaperCode,  OfferedTypeId, CourseCodeOfferedId, GetDate(), '" + Session["UserId"].ToString() + "' FROM         CourseCodeOfferedDetail where   OfferedTypeId!=1 and CourseCodeOfferedId=" + courseCodeOfferedId.ToString() + "; " +
                                " Delete FROM CourseCodeOfferedDetail  where  OfferedTypeId!=1 and CourseCodeOfferedId=" + courseCodeOfferedId.ToString() + ";";
        resultouter = fn.InsertUpdateDelete(restInactive);
        foreach (string insertSubPaper in subPaperCodeList)
        {

            string insertNew = " INSERT INTO CourseCodeOfferedDetail (SubPaperCode,  OfferedTypeId, CourseCodeOfferedId,  ModifiedDate, UserId) VALUES  " +
                              " ('" + insertSubPaper + "'," + dict[insertSubPaper] + "," + courseCodeOfferedId.ToString() + ",getdate(),'" + Session["UserId"].ToString() + "') ";
            resultouter = fn.InsertUpdateDelete(insertNew);

            string insertFacultyQuery = " Update Faculty_paper_a set Is_Active='N' where SubPaperCode='" + insertSubPaper + "' and Splcode='" + drpsplType.SelectedValue + "' and ExamSession='" + examsession + "';" +
                                        " INSERT INTO Faculty_paper_a (UserId, SubPaperCode, Is_Active, EntryDt,  Splcode, ExamSession) " +
                                        " VALUES     ('" + dictFaculty[insertSubPaper] + "','" + insertSubPaper + "','Y',getdate(),'" + drpsplType.SelectedValue + "','" + examsession + "')";
            resultouter = fn.InsertUpdateDelete(insertFacultyQuery);
        }
        LblMsg.Text = "Saved Successfully";
    }
}
