using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;

public partial class ImageHandler : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


        if (!IsPostBack)
        {
            if (Request.QueryString.Count > 0)
            {
                if (Request.QueryString["AckNo"] != null)
                {

                    SqlConnection con = new SqlConnection();
                    con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
                    string TempRollNo = Request.QueryString["AckNo"].ToString();

                    try
                    {
                        con.Open();
                        SqlCommand cmdSelect = new SqlCommand("select Photo from Registration where ackno=@TempRollNo", con);
                        SqlParameter cmdSelectParameters = new SqlParameter("@TempRollNo", SqlDbType.Char);

                        if (TempRollNo.Equals(""))
                            cmdSelectParameters.Value = "";
                        else
                            cmdSelectParameters.Value = TempRollNo;
                        cmdSelect.Parameters.Add(cmdSelectParameters);
                        byte[] barrImg = (byte[])cmdSelect.ExecuteScalar();


                        Response.OutputStream.Write(barrImg, 0, barrImg.Length);
                        Response.OutputStream.Flush();
                    }
                    catch (Exception ex)
                    {
                      Response.WriteFile( Server.MapPath("~\\Image\\UploadPhoto.JPG"));
                      
                      
                    }
                    finally
                    {
                        con.Close();
                    }

                }
            }
        }


    }

}


