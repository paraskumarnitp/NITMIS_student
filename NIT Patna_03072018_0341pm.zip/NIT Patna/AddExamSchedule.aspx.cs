using System;
using System.IO;
using System.Data;
using System.Data.SqlClient ;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class AddexamSchedule : System.Web.UI.Page
{

    Functionreviseed fn = new Functionreviseed();
    Functionreviseed chkfn = new Functionreviseed();

    protected void Page_Load(object sender, EventArgs e)
    {

       if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "4")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            

            PopulateDDL popddl = new PopulateDDL();

            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            //popddl.Popualate(LPassYear, "Year", "Select Year from Year order by Year", "Year", "Year");
            //popddl.Popualate(MPassYear, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(Year1, "Year", "Select Year from Year where year >'2008'order by Year", "Year", "Year");
            popddl.Popualate(Year2, "Year", "Select Year from Year where year > '2008'order by Year", "Year", "Year");
           
          
    
           
           
            Year1.Text = System.DateTime.Now.Year.ToString();
            popddl.Popualate(Year3, "Year", "Select Year from Year where year >= '" + Year1.SelectedValue + "'order by Year", "Year", "Year");
            Year2.Text = System.DateTime.Now.Year.ToString();
           
         

            //ExamPercentage.Attributes.Add("onkeydown", "if(event.which || event.keyCode)" + "{if ((event.which == 9) || (event.keyCode == 9)) " + "{document.getElementById('" + SCBNo.ClientID + "').focus();return false;}} else {return true}; ");
        }

      

      
    }

 protected void BtnSave_Click(object sender, EventArgs e)
    {
        try
        {
            SaveExamShedule(); 
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

        
    }

    void InstCode_Enter(object sender, EventArgs e)
    {
        LblMsg.Text = "Enter Pressed";
    }
  
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (StreamCode.SelectedValue == "00") return; 
       
        //popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPart", "StreamPart", "StreamPartCode");
       // popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        //set Session
        UnivService.Service1 NicService = new UnivService.Service1();
        string y = NicService.GetNewCode ("Select Duration from stream Where StreamCode='"+StreamCode.SelectedValue  +"'");
        Year2.Text = (int.Parse(Year1.Text) + int.Parse(y))+"";
      

       // string streamcode = "";
       // streamcode = NicService.GetNewCode("select streamcode  from stream where StreamAbbr='" + StreamCode.SelectedItem + "'");
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(Semester, "StreamPart", "Select STREAMPART,StreamPartCode from STREAMPART where StreamCode in ('"+StreamCode.SelectedValue+"','00') order by StreamPart", "StreamPart", "StreamPartCode");
       // SubCode_SelectedIndexChanged(StreamCode, e); // call subcode selected index
        //034

       

        StreamCode.Focus();    

        



    }
   
    protected void Year1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            PopulateDDL popddl = new PopulateDDL();
            UnivService.Service1 NicService = new UnivService.Service1();
            string y = NicService.GetNewCode("Select Duration from stream Where StreamCode='" + StreamCode.SelectedValue + "'");
            Year2.Text = (int.Parse(Year1.Text) + int.Parse(y)) + "";
            popddl.Popualate(Year3, "Year", "Select Year from Year where year >= '" + Year1.SelectedValue + "'order by Year", "Year", "Year");
           // SubCode_SelectedIndexChanged(sender, e);

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }
 protected void btnOk_Click1(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.Connection = con;
        SqlDataReader reader;
        con.Open();
        LblMsg.Text = "";
      

        UnivService.Service1 NicService = new UnivService.Service1();

       
        con.Close();

        cmd.CommandText = " select CoreCourseCode1,CoreCourseCode2,CoreCourseCode3,CoreCourseCode4,CoreCourseCode5,CoreCourseCode6, " +
            " CoreCourseCode7,EleCourseCode1,EleCourseCode2,EleCourseCode3,EleCourseCode4 from AssignCoursePaper where " +
            " program='" + StreamCode.SelectedItem + "' and Semester='" + Semester.SelectedItem + "' and " +
            " coursesession= '" + Year1.SelectedValue + "-" + Year2.SelectedValue + "' AND " + 
            " ExamSession ='"+ month1.SelectedValue +"-"+month2.SelectedValue+"_"+ Year3.SelectedValue +"'";
     
        LblMsg.Text = "";
        con.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            reader.Read();

            txtcc1.Text = reader["CoreCourseCode1"].ToString();
            txtcc2.Text = reader["CoreCourseCode2"].ToString();
            txtcc3.Text = reader["CoreCourseCode3"].ToString();
            txtcc4.Text = reader["CoreCourseCode4"].ToString();
            txtcc5.Text = reader["CoreCourseCode5"].ToString();
            txtcc6.Text = reader["CoreCourseCode6"].ToString();
            txtcc7.Text = reader["CoreCourseCode7"].ToString();
             
            txtElecCourse1.Text = reader["EleCourseCode1"].ToString();
            txtElecCourse2.Text = reader["EleCourseCode2"].ToString();
            txtElecCourse3.Text = reader["EleCourseCode3"].ToString();
            txtElecCourse4.Text = reader["EleCourseCode4"].ToString();
            //if (reader["CDate1"].ToString() != "")
            //{
            //    txtEamDatecc1.Text = reader["CDate1"].ToString().Substring(0, 10); drpDateon1.SelectedValue = reader["CDate1"].ToString().Substring(11);
            //}
            //if (reader["CDate2"].ToString() != "")
            //{
            //    txtEamDatecc2.Text = reader["CDate2"].ToString().Substring(0, 10); drpDateon2.SelectedValue = reader["CDate2"].ToString().Substring(11);
            //}
            //if (reader["CDate3"].ToString() != "")
            //{
            //    txtEamDatecc3.Text = reader["CDate3"].ToString().Substring(0, 10); drpDateon3.SelectedValue = reader["CDate3"].ToString().Substring(11);
            //}
            //if (reader["CDate4"].ToString() != "")
            //{
            //    txtEamDatecc4.Text = reader["CDate4"].ToString().Substring(0, 10); drpDateon4.SelectedValue = reader["CDate4"].ToString().Substring(11);
            //}
            //if (reader["CDate5"].ToString() != "")
            //{
            //    txtEamDatecc5.Text = reader["CDate5"].ToString().Substring(0, 10); drpDateon5.SelectedValue = reader["CDate5"].ToString().Substring(11);
            //}
            //if (reader["CDate6"].ToString() != "")
            //{
            //    txtEamDatecc6.Text = reader["CDate6"].ToString().Substring(0, 10); drpDateon6.SelectedValue = reader["CDate6"].ToString().Substring(11);
            //}
            //if (reader["CDate7"].ToString() != "")
            //{
            //    txtEamDatecc7.Text = reader["CDate7"].ToString().Substring(0, 10); drpDateon7.SelectedValue = reader["CDate7"].ToString().Substring(11);
            //}
            //if (reader["EDate1"].ToString() != "")
            //{
            //    txtEleExamDate1.Text = reader["EDate1"].ToString().Substring(0, 10); drpDateon8.SelectedValue = reader["EDate1"].ToString().Substring(11);
            //}
            //if (reader["EDate2"].ToString() != "")
            //{
            //    txtEleExamDate2.Text = reader["EDate2"].ToString().Substring(0, 10); drpDateon9.SelectedValue = reader["EDate2"].ToString().Substring(11);
            //}
            //if (reader["EDate3"].ToString() != "")
            //{
            //    txtEleExamDate3.Text = reader["EDate3"].ToString().Substring(0, 10); drpDateon10.SelectedValue = reader["EDate3"].ToString().Substring(11);
            //}
            //if (reader["EDate4"].ToString() != "")
            //{
            //    txtEleExamDate4.Text = reader["EDate4"].ToString().Substring(0, 10); drpDateon11.SelectedValue = reader["EDate4"].ToString().Substring(11);
            //}
            //txteccredit1.Text = reader["CreditEle1"].ToString();
            //txteccredit2.Text = reader["CreditEle2"].ToString();
            //txteccredit3.Text = reader["CreditEle3"].ToString();
            //txteccredit4.Text = reader["CreditEle4"].ToString();

            DataSet dspapers1 = chkfn.SelectDataset("Select PaperName as PaperName1,Credit as Credit1 From COURSEPAPERS Where paperabbr = '" + txtcc1.Text + "'"
                + "Select PaperName as PaperName2,Credit as Credit2 From COURSEPAPERS Where paperabbr = '" + txtcc2.Text + "'"
                + "Select PaperName as PaperName3,Credit as Credit3 From COURSEPAPERS Where paperabbr = '" + txtcc3.Text + "'"
                + "Select PaperName as PaperName4,Credit as Credit4 From COURSEPAPERS Where paperabbr = '" + txtcc4.Text + "'"
                + "Select PaperName as PaperName5,Credit as Credit5 From COURSEPAPERS Where paperabbr = '" + txtcc5.Text + "'"
                + "Select PaperName as PaperName6,Credit as Credit6 From COURSEPAPERS Where paperabbr = '" + txtcc6.Text + "'"
                + "Select PaperName as PaperName7,Credit as Credit7 From COURSEPAPERS Where paperabbr = '" + txtcc7.Text + "'"
                + "Select PaperName as PaperName8,Credit as Credit8 From COURSEPAPERS Where paperabbr = '" + txtElecCourse1.Text + "'"
                + "Select PaperName as PaperName9,Credit as Credit9 From COURSEPAPERS Where paperabbr = '" + txtElecCourse2.Text + "'"
                + "Select PaperName as PaperName10,Credit as Credit10 From COURSEPAPERS Where paperabbr = '" + txtElecCourse3.Text + "'"
                + "Select PaperName as PaperName11,Credit as Credit11 From COURSEPAPERS Where paperabbr = '" + txtElecCourse4.Text + "'");

           
            
            if (dspapers1.Tables[0].Rows.Count > 0)
            {
                txtcoursen1.Text = dspapers1.Tables[0].Rows[0]["PaperName1"].ToString();
                txtccredit1.Text = dspapers1.Tables[0].Rows[0]["Credit1"].ToString();
            }
            if (dspapers1.Tables[1].Rows.Count > 0)
            {
                txtcoursen2.Text = (dspapers1.Tables[1].Rows[0]["PaperName2"].ToString() == "" ? "" : dspapers1.Tables[1].Rows[0]["PaperName2"].ToString());
                txtccredit2.Text = (dspapers1.Tables[1].Rows[0]["Credit2"].ToString() == "" ? "" : dspapers1.Tables[1].Rows[0]["Credit2"].ToString());
            }
            if (dspapers1.Tables[2].Rows.Count > 0)
            {
                txtcoursen3.Text = (dspapers1.Tables[2].Rows[0]["PaperName3"].ToString() == "" ? "" : dspapers1.Tables[2].Rows[0]["PaperName3"].ToString());
                txtccredit3.Text = (dspapers1.Tables[2].Rows[0]["Credit3"].ToString() == "" ? "" : dspapers1.Tables[2].Rows[0]["Credit3"].ToString());
            }
            if (dspapers1.Tables[3].Rows.Count > 0)
            {
                txtcoursen4.Text = (dspapers1.Tables[3].Rows[0]["PaperName4"].ToString() == "" ? "" : dspapers1.Tables[3].Rows[0]["PaperName4"].ToString());
                txtccredit4.Text = (dspapers1.Tables[3].Rows[0]["Credit4"].ToString() == "" ? "" : dspapers1.Tables[3].Rows[0]["Credit4"].ToString());
            }
            if (dspapers1.Tables[4].Rows.Count > 0)
            {
                txtcoursen5.Text = (dspapers1.Tables[4].Rows[0]["PaperName5"].ToString() == "" ? "" : dspapers1.Tables[4].Rows[0]["PaperName5"].ToString());
                txtccredit5.Text = (dspapers1.Tables[4].Rows[0]["Credit5"].ToString() == "" ? "" : dspapers1.Tables[4].Rows[0]["Credit5"].ToString());
            }
            if (dspapers1.Tables[5].Rows.Count > 0)
            {
                txtcoursen6.Text = (dspapers1.Tables[5].Rows[0]["PaperName6"].ToString() == "" ? "" : dspapers1.Tables[5].Rows[0]["PaperName6"].ToString());
                txtccredit6.Text = (dspapers1.Tables[5].Rows[0]["Credit6"].ToString() == "" ? "" : dspapers1.Tables[5].Rows[0]["Credit6"].ToString());
            }
            if (dspapers1.Tables[6].Rows.Count > 0)
            {
                txtcoursen7.Text = (dspapers1.Tables[6].Rows[0]["PaperName7"].ToString() == "" ? "" : dspapers1.Tables[6].Rows[0]["PaperName7"].ToString());
                txtccredit7.Text = (dspapers1.Tables[6].Rows[0]["Credit7"].ToString() == "" ? "" : dspapers1.Tables[6].Rows[0]["Credit7"].ToString());
            }
            if (dspapers1.Tables[7].Rows.Count > 0)
            {
                txtec1.Text = (dspapers1.Tables[7].Rows[0]["PaperName8"].ToString() == "" ? "" : dspapers1.Tables[7].Rows[0]["PaperName8"].ToString());
                txteccredit1.Text = (dspapers1.Tables[7].Rows[0]["Credit8"].ToString() == "" ? "" : dspapers1.Tables[7].Rows[0]["Credit8"].ToString());
            }
            if (dspapers1.Tables[8].Rows.Count > 0)
            {
                txtec2.Text = (dspapers1.Tables[8].Rows[0]["PaperName9"].ToString() == "" ? "" : dspapers1.Tables[8].Rows[0]["PaperName9"].ToString());
                txteccredit2.Text = (dspapers1.Tables[8].Rows[0]["Credit9"].ToString() == "" ? "" : dspapers1.Tables[8].Rows[0]["Credit9"].ToString());
            }
            if (dspapers1.Tables[9].Rows.Count > 0)
            {
                txtec3.Text = (dspapers1.Tables[9].Rows[0]["PaperName10"].ToString() == "" ? "" : dspapers1.Tables[9].Rows[0]["PaperName10"].ToString());
                txteccredit3.Text = (dspapers1.Tables[9].Rows[0]["Credit10"].ToString() == "" ? "" : dspapers1.Tables[9].Rows[0]["Credit10"].ToString());
            }
            if (dspapers1.Tables[10].Rows.Count > 0)
            {
                txtec4.Text = (dspapers1.Tables[10].Rows[0]["PaperName11"].ToString() == "" ? "" : dspapers1.Tables[10].Rows[0]["PaperName11"].ToString());
                txteccredit4.Text = (dspapers1.Tables[10].Rows[0]["Credit11"].ToString() == "" ? "" : dspapers1.Tables[10].Rows[0]["Credit11"].ToString());
            }


            reader.Close();

            // Code for Disable row , which contain corsecode = NA
            if (txtcc1.Text == "NA" || txtcc1.Text == "") { txtEamDatecc1.Enabled = false; drpDateon1.Enabled = false; }
            else { txtEamDatecc1.Enabled = true; drpDateon1.Enabled = true; }

            if (txtcc2.Text == "NA" || txtcc2.Text == "") { txtEamDatecc2.Enabled = false; drpDateon2.Enabled = false; }
            else { txtEamDatecc2.Enabled = true; drpDateon2.Enabled = true; }

            if (txtcc3.Text == "NA" || txtcc3.Text == "") { txtEamDatecc3.Enabled = false; drpDateon3.Enabled = false; }
            else { txtEamDatecc3.Enabled = true; drpDateon3.Enabled = true; }

            if (txtcc4.Text == "NA" || txtcc4.Text == "") { txtEamDatecc4.Enabled = false; drpDateon4.Enabled = false; }
            else { txtEamDatecc4.Enabled = true; drpDateon4.Enabled = true; }

            if (txtcc5.Text == "NA" || txtcc5.Text == "") { txtEamDatecc5.Enabled = false; drpDateon5.Enabled = false; }
            else { txtEamDatecc5.Enabled = true; drpDateon5.Enabled = true; }

            if (txtcc6.Text == "NA" || txtcc6.Text == "") { txtEamDatecc6.Enabled = false; drpDateon6.Enabled = false; }
            else { txtEamDatecc6.Enabled = true; drpDateon6.Enabled = true; }

            if (txtcc7.Text == "NA" || txtcc7.Text == "") { txtEamDatecc7.Enabled = false; drpDateon7.Enabled = false; }
            else { txtEamDatecc7.Enabled = true; drpDateon7.Enabled = true; }

            if (txtec1.Text == "NA" || txtec1.Text == "") { txtEleExamDate1.Enabled = false; drpDateon8.Enabled = false; }
            else { txtEleExamDate1.Enabled = true; drpDateon8.Enabled = true; }

            if (txtec2.Text == "NA" || txtec2.Text == "") { txtEleExamDate2.Enabled = false; drpDateon9.Enabled = false; }
            else { txtEleExamDate2.Enabled = true; drpDateon9.Enabled = true; }

            if (txtec3.Text == "NA" || txtec3.Text == "") { txtEleExamDate3.Enabled = false; drpDateon10.Enabled = false; }
            else { txtEleExamDate3.Enabled = true; drpDateon10.Enabled = true; }

            if (txtec4.Text == "NA" || txtec4.Text == "") { txtEleExamDate4.Enabled = false; drpDateon11.Enabled = false; }
            else { txtEleExamDate4.Enabled = true; drpDateon11.Enabled = true; }

        }

    }


   //Code for Save Exam Course Code------------------------------
    int InsRec;
    protected void SaveExamShedule()
    {
        
        if (txtcc1.Text != "NA")
        {
            string examsession = month1.SelectedItem + "-" + month2.SelectedItem + "_" + Year3.SelectedItem;
            string examdate = txtEamDatecc1.Text + ":" + drpDateon1.SelectedItem;
            InsRec = chkfn.InsertUpdateDelete("UPDATE AddExamSchedule SET ExamDate ='" + examdate + "' WHERE Program = '" + StreamCode.SelectedItem + "' " + 
                " AND (StreamPartCode = '" + Semester.SelectedValue + "') AND (SemType = '" + drpSemType.SelectedItem + "') AND (PaperAbbr = '" + txtcc1.Text.Trim() + "') AND ExamSession ='"+examsession+"'");
        }

        if (txtcc2.Text != "NA")
        {
            string examsession = month1.SelectedItem + "-" + month2.SelectedItem + "_" + Year3.SelectedItem;
            string examdate = txtEamDatecc2.Text + ":" + drpDateon2.SelectedItem;
            InsRec = chkfn.InsertUpdateDelete("UPDATE AddExamSchedule SET ExamDate ='" + examdate + "' WHERE Program = '" + StreamCode.SelectedItem + "' " +
                " AND (StreamPartCode = '" + Semester.SelectedValue + "') AND (SemType = '" + drpSemType.SelectedItem + "') AND (PaperAbbr = '" + txtcc2.Text.Trim() + "') AND ExamSession ='" + examsession + "'");
        }

        if (txtcc3.Text != "NA")
        {
            string examsession = month1.SelectedItem + "-" + month2.SelectedItem + "_" + Year3.SelectedItem;
            string examdate = txtEamDatecc3.Text + ":" + drpDateon3.SelectedItem;
            InsRec = chkfn.InsertUpdateDelete("UPDATE AddExamSchedule SET ExamDate ='" + examdate + "' WHERE Program = '" + StreamCode.SelectedItem + "' " +
                " AND (StreamPartCode = '" + Semester.SelectedValue + "') AND (SemType = '" + drpSemType.SelectedItem + "') AND (PaperAbbr = '" + txtcc3.Text.Trim() + "') AND ExamSession ='" + examsession + "'");
        }
        if (txtcc4.Text != "NA")
        {
            string examsession = month1.SelectedItem + "-" + month2.SelectedItem + "_" + Year3.SelectedItem;
            string examdate = txtEamDatecc4.Text + ":" + drpDateon4.SelectedItem;
            InsRec = chkfn.InsertUpdateDelete("UPDATE AddExamSchedule SET ExamDate ='" + examdate + "' WHERE Program = '" + StreamCode.SelectedItem + "' " +
                " AND (StreamPartCode = '" + Semester.SelectedValue + "') AND (SemType = '" + drpSemType.SelectedItem + "') AND (PaperAbbr = '" + txtcc4.Text.Trim() + "') AND ExamSession ='" + examsession + "'");
        }
        if (txtcc5.Text != "NA")
        {
            string examsession = month1.SelectedItem + "-" + month2.SelectedItem + "_" + Year3.SelectedItem;
            string examdate = txtEamDatecc5.Text + ":" + drpDateon5.SelectedItem;
            InsRec = chkfn.InsertUpdateDelete("UPDATE AddExamSchedule SET ExamDate ='" + examdate + "' WHERE Program = '" + StreamCode.SelectedItem + "' " +
                " AND (StreamPartCode = '" + Semester.SelectedValue + "') AND (SemType = '" + drpSemType.SelectedItem + "') AND (PaperAbbr = '" + txtcc5.Text.Trim() + "') AND ExamSession ='" + examsession + "'");
        }
        if (txtcc6.Text != "NA")
        {
            string examsession = month1.SelectedItem + "-" + month2.SelectedItem + "_" + Year3.SelectedItem;
            string examdate = txtEamDatecc6.Text + ":" + drpDateon6.SelectedItem;
            InsRec = chkfn.InsertUpdateDelete("UPDATE AddExamSchedule SET ExamDate ='" + examdate + "' WHERE Program = '" + StreamCode.SelectedItem + "' " +
                " AND (StreamPartCode = '" + Semester.SelectedValue + "') AND (SemType = '" + drpSemType.SelectedItem + "') AND (PaperAbbr = '" + txtcc6.Text.Trim() + "') AND ExamSession ='" + examsession + "'");
        }
        if (txtcc7.Text != "NA")
        {
            string examsession = month1.SelectedItem + "-" + month2.SelectedItem + "_" + Year3.SelectedItem;
            string examdate = txtEamDatecc7.Text + ":" + drpDateon7.SelectedItem;
            InsRec = chkfn.InsertUpdateDelete("UPDATE AddExamSchedule SET ExamDate ='" + examdate + "' WHERE Program = '" + StreamCode.SelectedItem + "' " +
                " AND (StreamPartCode = '" + Semester.SelectedValue + "') AND (SemType = '" + drpSemType.SelectedItem + "') AND (PaperAbbr = '" + txtcc7.Text.Trim() + "') AND ExamSession ='" + examsession + "'");
        }
        if (txtElecCourse1.Text != "NA")
        {
            string examsession = month1.SelectedItem + "-" + month2.SelectedItem + "_" + Year3.SelectedItem;
            string examdate = txtEleExamDate1.Text + ":" + drpDateon8.SelectedItem;
            InsRec = chkfn.InsertUpdateDelete("UPDATE AddExamSchedule SET ExamDate ='" + examdate + "' WHERE Program = '" + StreamCode.SelectedItem + "' " +
                " AND (StreamPartCode = '" + Semester.SelectedValue + "') AND (SemType = '" + drpSemType.SelectedItem + "') AND (PaperAbbr = '" + txtElecCourse1.Text.Trim() + "') AND ExamSession ='" + examsession + "'");
        }
        if (txtElecCourse2.Text != "NA")
        {
            string examsession = month1.SelectedItem + "-" + month2.SelectedItem + "_" + Year3.SelectedItem;
            string examdate = txtEleExamDate2.Text + ":" + drpDateon9.SelectedItem;
            InsRec = chkfn.InsertUpdateDelete("UPDATE AddExamSchedule SET ExamDate ='" + examdate + "' WHERE Program = '" + StreamCode.SelectedItem + "' " +
                " AND (StreamPartCode = '" + Semester.SelectedValue + "') AND (SemType = '" + drpSemType.SelectedItem + "') AND (PaperAbbr = '" + txtElecCourse2.Text.Trim() + "') AND ExamSession ='" + examsession + "'");
        }
        if (txtElecCourse3.Text != "NA")
        {
            string examsession = month1.SelectedItem + "-" + month2.SelectedItem + "_" + Year3.SelectedItem;
            string examdate = txtEleExamDate3.Text + ":" + drpDateon10.SelectedItem;
            InsRec = chkfn.InsertUpdateDelete("UPDATE AddExamSchedule SET ExamDate ='" + examdate + "' WHERE Program = '" + StreamCode.SelectedItem + "' " +
                " AND (StreamPartCode = '" + Semester.SelectedValue + "') AND (SemType = '" + drpSemType.SelectedItem + "') AND (PaperAbbr = '" + txtElecCourse3.Text.Trim() + "') AND ExamSession ='" + examsession + "'");
        }
        if (txtElecCourse4.Text != "NA")
        {
            string examsession = month1.SelectedItem + "-" + month2.SelectedItem + "_" + Year3.SelectedItem;
            string examdate = txtEleExamDate4.Text + ":" + drpDateon11.SelectedItem;
            InsRec = chkfn.InsertUpdateDelete("UPDATE AddExamSchedule SET ExamDate ='" + examdate + "' WHERE Program = '" + StreamCode.SelectedItem + "' " +
                " AND (StreamPartCode = '" + Semester.SelectedValue + "') AND (SemType = '" + drpSemType.SelectedItem + "') AND (PaperAbbr = '" + txtElecCourse4.Text.Trim() + "') AND ExamSession ='" + examsession + "'");
        }
        LblMsg.Text = " Record is Save successfully.";
        //////try
        //////{
 
        //////    string[] col = new string[14];
        //////    string[] val = new string[14];

        //////    string date1 = "", date2 = "", date3 = "", date4 = "", date5 = "", date6 = "", date7 = "", date8 = "", date9 = "", date10 = "", date11 = "";
        //////    if (txtcc1.Text != "NA")
        //////    {
        //////        //if (txtEamDatecc1.Text == "")
        //////        //{
        //////        //    LblMsg.Text = " Please Insert Date For  Paper.";
        //////        //    string popupScripta = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScripta);
        //////        //    return;
        //////        //}
        //////        //if (drpDateon1.SelectedValue == "SELECT")
        //////        //{
        //////        //    LblMsg.Text = " Please Select Session Time On.";
        //////        //    string popupScriptm = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptm);
        //////        //    return;
        //////        //}
        //////        date1 = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(txtEamDatecc1.Text.Trim())) + ":" + drpDateon1.SelectedValue;
        //////    }
        //////    else
        //////        date1 = "";
        //////    if (txtcc2.Text != "NA")
        //////    {
        //////        //if (txtEamDatecc2.Text == "")
        //////        //{
        //////        //    LblMsg.Text = " Please Insert Date For Mandatory Paper.";
        //////        //    string popupScriptb = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptb);
        //////        //    return;
        //////        //}
        //////        //if (drpDateon2.SelectedValue == "SELECT")
        //////        //{
        //////        //    LblMsg.Text = " Please Select Session Time On.";
        //////        //    string popupScriptn = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptn);
        //////        //    return;
        //////        //}
        //////        date2 = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(txtEamDatecc2.Text.Trim())) + ":" + drpDateon2.SelectedValue;
        //////    }
        //////    else
        //////        date2 = "";
        //////    if (txtcc3.Text != "NA")
        //////    {
        //////        //if (txtEamDatecc3.Text == "")
        //////        //{
        //////        //    LblMsg.Text = " Please Insert Date For Mandatory Paper.";
        //////        //    string popupScriptc = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptc);
        //////        //    return;
        //////        //}
        //////        //if (drpDateon3.SelectedValue == "SELECT")
        //////        //{
        //////        //    LblMsg.Text = " Please Select Session Time On.";
        //////        //    string popupScripto = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScripto);
        //////        //    return;
        //////        //}
        //////        date3 = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(txtEamDatecc3.Text.Trim())) + ":" + drpDateon3.SelectedValue;
        //////    }
        //////    else
        //////        date3 = "";
        //////    if (txtcc4.Text != "NA")
        //////    {
        //////        //if (txtEamDatecc4.Text == "")
        //////        //{
        //////        //    LblMsg.Text = " Please Insert Date For Mandatory Paper.";
        //////        //    string popupScriptd = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptd);
        //////        //    return;
        //////        //}
        //////        //if (drpDateon4.SelectedValue == "SELECT")
        //////        //{
        //////        //    LblMsg.Text = " Please Select Session Time On.";
        //////        //    string popupScriptp = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptp);
        //////        //    return;
        //////        //}
        //////        date4 = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(txtEamDatecc4.Text.Trim())) + ":" + drpDateon4.SelectedValue;
        //////    }
        //////    else
        //////        date4 = "";
        //////    if (txtcc5.Text != "NA")
        //////    {
        //////        //if (txtEamDatecc5.Text == "")
        //////        //{
        //////        //    LblMsg.Text = " Please Insert Date For Mandatory Paper.";
        //////        //    string popupScripte = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScripte);
        //////        //    return;
        //////        //}
        //////        //if (drpDateon5.SelectedValue == "SELECT")
        //////        //{
        //////        //    LblMsg.Text = " Please Select Session Time On.";
        //////        //    string popupScriptq = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptq);
        //////        //    return;
        //////        //}
        //////        date5 = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(txtEamDatecc5.Text.Trim())) + ":" + drpDateon5.SelectedValue;
        //////    }
        //////    else
        //////        date5 = "";
        //////    if (txtcc6.Text != "NA")
        //////    {
        //////        //if (txtEamDatecc6.Text == "")
        //////        //{
        //////        //    LblMsg.Text = " Please Insert Date For Mandatory Paper.";
        //////        //    string popupScriptf = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptf);
        //////        //    return;
        //////        //}
        //////        //if (drpDateon6.SelectedValue == "SELECT")
        //////        //{
        //////        //    LblMsg.Text = " Please Select Session Time On.";
        //////        //    string popupScriptr = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptr);
        //////        //    return;
        //////        //}
        //////        date6 = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(txtEamDatecc6.Text.Trim())) + ":" + drpDateon6.SelectedValue;
        //////    }
        //////    else
        //////        date6 = "";
        //////    if (txtcc7.Text != "NA")
        //////    {
        //////        //if (txtEamDatecc7.Text == "")
        //////        //{
        //////        //    LblMsg.Text = " Please Insert Date For Mandatory Paper.";
        //////        //    string popupScriptg = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptg);
        //////        //    return;
        //////        //}
        //////        //if (drpDateon7.SelectedValue == "SELECT")
        //////        //{
        //////        //    LblMsg.Text = " Please Select Session Time On.";
        //////        //    string popupScripts = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScripts);
        //////        //    return;
        //////        //}
        //////        date7 = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(txtEamDatecc7.Text.Trim())) + ":" + drpDateon7.SelectedValue;
        //////    }
        //////    else
        //////        date7 = "";
        //////    if (txtElecCourse1.Text != "NA")
        //////    {
        //////        //if (txtEleExamDate1.Text == "")
        //////        //{
        //////        //    LblMsg.Text = " Please Insert Date For Mandatory Paper.";
        //////        //    string popupScripth = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScripth);
        //////        //    return;
        //////        //}
        //////        //if (drpDateon8.SelectedValue == "SELECT")
        //////        //{
        //////        //    LblMsg.Text = " Please Select Session Time On.";
        //////        //    string popupScriptt = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptt);
        //////        //    return;
        //////        //}
        //////        date8 = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(txtEleExamDate1.Text.Trim())) + ":" + drpDateon8.SelectedValue;
        //////    }
        //////    else
        //////        date8 = "";
        //////    if (txtElecCourse2.Text != "NA")
        //////    {
        //////        //if (txtEleExamDate2.Text == "")
        //////        //{
        //////        //    LblMsg.Text = " Please Insert Date For Mandatory Paper.";
        //////        //    string popupScripti = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScripti);
        //////        //    return;
        //////        //}
        //////        //if (drpDateon9.SelectedValue == "SELECT")
        //////        //{
        //////        //    LblMsg.Text = " Please Select Session Time On.";
        //////        //    string popupScriptu = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptu);
        //////        //    return;
        //////        //}
        //////        date9 = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(txtEleExamDate2.Text.Trim())) + ":" + drpDateon9.SelectedValue;
        //////    }
        //////    else
        //////        date9 = "";
        //////    if (txtElecCourse3.Text != "NA")
        //////    {
        //////        //if (txtEleExamDate3.Text == "")
        //////        //{
        //////        //    LblMsg.Text = " Please Insert Date For Mandatory Paper.";
        //////        //    string popupScriptk = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptk);
        //////        //    return;
        //////        //}
        //////        //if (drpDateon10.SelectedValue == "SELECT")
        //////        //{
        //////        //    LblMsg.Text = " Please Select Session Time On.";
        //////        //    string popupScriptv = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptv);
        //////        //    return;
        //////        //}
        //////        date10 = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(txtEleExamDate3.Text.Trim())) + ":" + drpDateon10.SelectedValue;
        //////    }
        //////    else
        //////        date10 = "";
        //////    if (txtElecCourse4.Text != "NA")
        //////    {
        //////        //if (txtEleExamDate4.Text == "")
        //////        //{
        //////        //    LblMsg.Text = " Please Insert Date For Mandatory Paper.";
        //////        //    string popupScriptl = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptl);
        //////        //    return;
        //////        //}
        //////        //if (drpDateon11.SelectedValue == "SELECT")
        //////        //{
        //////        //    LblMsg.Text = " Please Select Session Time On.";
        //////        //    string popupScriptw = "<script language='javascript'>  alert('" + LblMsg.Text + " ')   </script>";
        //////        //    Page.RegisterStartupScript("PopupScript", popupScriptw);
        //////        //    return;
        //////        //}
        //////        date11 = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(txtEleExamDate4.Text.Trim())) + ":" + drpDateon11.SelectedValue;
        //////    }
        //////    else
        //////        date11 = "";
        //////    string abc = " update AssignCoursePaper  set Cdate1='" + date1 +
        //////               "', Cdate2='" + date2 +
        //////               "', Cdate3='" + date3 +
        //////               "', Cdate4='" + date4 +

        //////               "', Cdate5='" + date5 +
        //////               "', Cdate6='" + date6 +

        //////               "', Cdate7='" + date7 +
        //////               "', Edate1='" + date8 +
        //////               "',Edate2='" + date9 +
        //////               "', Edate3='" + date10 +
        //////               "', Edate4 ='" + date11 +
        //////                "' where  program='" + StreamCode.SelectedItem + "' and Semester='" + Semester.SelectedItem + "' and coursesession= '" + Year1.SelectedValue + "-" + Year2.SelectedValue + "'"
        //////         + "update AdmitGraPaper set examdate='" + date1 + "' where  paperabbr='" + txtcc1.Text + "' and StreamPartCode in (select StreamPartCode  from STREAMPART where StreamCode='" + StreamCode.SelectedValue + "' and streampart='" + Semester.SelectedItem.Text+ "')"
        //////        + "  update AdmitGraPaper set examdate='" + date2 + "' where  paperabbr='" + txtcc2.Text + "' and streampartcode in (select StreamPartCode  from STREAMPART where StreamCode='" + StreamCode.SelectedValue + "' and streampart='" + Semester.SelectedItem.Text + "')"
        //////        + "  update AdmitGraPaper set examdate='" + date3 + "' where  paperabbr='" + txtcc3.Text + "' and streampartcode in (select StreamPartCode  from STREAMPART where StreamCode='" + StreamCode.SelectedValue + "' and streampart='" + Semester.SelectedItem.Text + "')"
        //////        + "  update AdmitGraPaper set examdate='" + date4 + "' where  paperabbr='" + txtcc4.Text + "' and streampartcode in (select StreamPartCode  from STREAMPART where StreamCode='" + StreamCode.SelectedValue + "' and streampart='" + Semester.SelectedItem.Text + "')"
        //////        + "  update AdmitGraPaper set examdate='" + date5 + "' where  paperabbr='" + txtcc5.Text + "' and streampartcode in (select StreamPartCode  from STREAMPART where StreamCode='" + StreamCode.SelectedValue + "' and streampart='" + Semester.SelectedItem.Text + "')"
        //////        + "  update AdmitGraPaper set examdate='" + date6 + "' where  paperabbr='" + txtcc6.Text + "' and streampartcode in (select StreamPartCode  from STREAMPART where StreamCode='" + StreamCode.SelectedValue + "' and streampart='" + Semester.SelectedItem.Text + "')"
        //////        + "  update AdmitGraPaper set examdate='" + date7 + "' where  paperabbr='" + txtcc7.Text + "' and streampartcode in (select StreamPartCode  from STREAMPART where StreamCode='" + StreamCode.SelectedValue + "' and streampart='" + Semester.SelectedItem.Text + "')"
        //////        + "  update AdmitGraPaper set examdate='" + date8 + "' where  paperabbr='" + txtElecCourse1.Text + "' and streampartcode in (select StreamPartCode  from STREAMPART where StreamCode='" + StreamCode.SelectedValue + "' and streampart='" + Semester.SelectedItem.Text + "')"
        //////        + "  update AdmitGraPaper set examdate='" + date9 + "' where  paperabbr='" + txtElecCourse2.Text + "' and streampartcode in (select StreamPartCode  from STREAMPART where StreamCode='" + StreamCode.SelectedValue + "' and streampart='" + Semester.SelectedItem.Text + "')"
        //////        + "  update AdmitGraPaper set examdate='" + date10 + "' where  paperabbr='" + txtElecCourse3.Text + "' and streampartcode in (select StreamPartCode  from STREAMPART where StreamCode='" + StreamCode.SelectedValue + "' and streampart='" + Semester.SelectedItem.Text + "')"
        //////        + "  update AdmitGraPaper set examdate='" + date11 + "' where  paperabbr='" + txtElecCourse4.Text + "' and streampartcode in (select StreamPartCode  from STREAMPART where StreamCode='" + StreamCode.SelectedValue + "' and streampart='" + Semester.SelectedItem.Text + "')";

        //////    UnivService.Service1 ss = new UnivService.Service1();
        //////    abc = ss.UpdateData(abc);
        //////    if (abc.ToString() == "ok")
        //////    {

        //////        LblMsg.Text = " Record is Save successfully.";

        //////        string popupScript = "<script language='javascript'>" +
        //////                                       " alert('" + LblMsg.Text + " ')" +
        //////                                        "</script>";
        //////        Page.RegisterStartupScript("PopupScript", popupScript);

        //////    }
        //////    else
        //////        LblMsg.Text = abc.ToString();
        //////    // }updated
        //////}

        //////catch (Exception ex)
        //////{
        //////    LblMsg.Text = ex.Message;
        //////}


    }
    //protected void txtEamDatecc1_TextChanged(object sender, EventArgs e)
    //{
    //    if (txtcc1.Text == "NA")
    //    {
    //        string msg = " Please Assign it's Course. ";
    //        string popupScript = "<script language='javascript'>" +
    //                           " alert('" + msg + " ')" +
    //                            "</script>";
    //        Page.RegisterStartupScript("PopupScript", popupScript);

    //        txtEamDatecc1.Text = "";
    //        txtEamDatecc1.Focus();
            

    //    }
    //    else
    //    {
            
    //        drpDateon1.Focus();

    //    }
         
    //}

   
    //protected void txtEamDatecc2_TextChanged(object sender, EventArgs e)
    //{
    //    if (txtcc2.Text == "NA")
    //    {
    //        string msg = " Please Assign it's Course. ";
    //        string popupScript = "<script language='javascript'>" +
    //                           " alert('" + msg + " ')" +
    //                            "</script>";
    //        Page.RegisterStartupScript("PopupScript", popupScript);
    //        txtEamDatecc2.Text = "";
    //    }
    //}
    //protected void txtEamDatecc3_TextChanged(object sender, EventArgs e)
    //{
    //    if (txtcc3.Text == "NA")
    //    {
    //        string msg = " Please Assign it's Course. ";
    //        string popupScript = "<script language='javascript'>" +
    //                           " alert('" + msg + " ')" +
    //                            "</script>";
    //        Page.RegisterStartupScript("PopupScript", popupScript);
    //        txtEamDatecc3.Text = "";
    //    }
    //}
    //protected void txtEamDatecc4_TextChanged(object sender, EventArgs e)
    //{
    //    if (txtcc4.Text == "NA")
    //    {
    //        string msg = " Please Assign it's Course. ";
    //        string popupScript = "<script language='javascript'>" +
    //                           " alert('" + msg + " ')" +
    //                            "</script>";
    //        Page.RegisterStartupScript("PopupScript", popupScript);
    //        txtEamDatecc4.Text = "";
    //    }
    //}
    //protected void txtEamDatecc5_TextChanged(object sender, EventArgs e)
    //{
    //    if (txtcc5.Text == "NA")
    //    {
    //        string msg = " Please Assign it's Course. ";
    //        string popupScript = "<script language='javascript'>" +
    //                           " alert('" + msg + " ')" +
    //                            "</script>";
    //        Page.RegisterStartupScript("PopupScript", popupScript);
    //        txtEamDatecc5.Text = "";
    //    }
    //}
    //protected void txtEamDatecc6_TextChanged(object sender, EventArgs e)
    //{
    //    if (txtcc6.Text == "NA")
    //    {
    //        string msg = " Please Assign it's Course. ";
    //        string popupScript1 = "<script language='javascript'>" +
    //                           " alert('" + msg + " ')" +
    //                            "</script>";
    //        Page.RegisterStartupScript("PopupScript", popupScript1);
    //        txtEamDatecc6.Text = "";
            
    //    }
       
    //}
    //protected void txtEamDatecc7_TextChanged(object sender, EventArgs e)
    //{
    //    if (txtcc7.Text == "NA")
    //    {
    //        string msg = " Please Assign it's Course. ";
    //        string popupScript = "<script language='javascript'>" +
    //                           " alert('" + msg + " ')" +
    //                            "</script>";
    //        Page.RegisterStartupScript("PopupScript", popupScript);
    //        //ScriptManager.RegisterStartupScript(this, typeof(Page), "alert", "alert('Please Assign it's Course..');", true);
    //        txtEamDatecc7.Text = "";
    //       // ScriptManager.RegisterStartupScript(this, typeof(Page), "alert", "alert('No Empty fields are allowed.');", true);
    //       //txtEamDatecc6.Text = "";
    //       // return;
    //    }
    //}
    //protected void txtEleExamDate1_TextChanged(object sender, EventArgs e)
    //{
    //    if (txtElecCourse1.Text == "NA")
    //    {
    //        string msg = " Please Assign it's Course. ";
    //        string popupScript = "<script language='javascript'>" +
    //                           " alert('" + msg + " ')" +
    //                            "</script>";
    //        Page.RegisterStartupScript("PopupScript", popupScript);
    //        txtEleExamDate1.Text = "";
    //    }
    //}
    //protected void txtEleExamDate2_TextChanged(object sender, EventArgs e)
    //{
    //    if (txtElecCourse2.Text == "NA")
    //    {
    //        string msg = " Please Assign it's Course. ";
    //        string popupScript = "<script language='javascript'>" +
    //                           " alert('" + msg + " ')" +
    //                            "</script>";
    //        Page.RegisterStartupScript("PopupScript", popupScript);
    //        txtEleExamDate2.Text = "";
    //    }
    //}
    //protected void txtEleExamDate3_TextChanged(object sender, EventArgs e)
    //{
    //    if (txtElecCourse3.Text == "NA")
    //    {
    //        string msg = " Please Assign it's Course. ";
    //        string popupScript = "<script language='javascript'>" +
    //                           " alert('" + msg + " ')" +
    //                            "</script>";
    //        Page.RegisterStartupScript("PopupScript", popupScript);
    //        txtEleExamDate3.Text = "";
    //    }
    //}
    //protected void txtEleExamDate4_TextChanged(object sender, EventArgs e)
    //{
    //    if (txtElecCourse4.Text == "NA")
    //    {
    //        string msg = " Please Assign it's Course. ";
    //        string popupScript = "<script language='javascript'>" +
    //                           " alert('" + msg + " ')" +
    //                            "</script>";
    //        Page.RegisterStartupScript("PopupScript", popupScript);
    //        txtEleExamDate4.Text = "";
    //    }
    //}
    protected void month1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (month1.SelectedIndex == 1)
        {
            month2.SelectedIndex = 1;
        }
        else if (month1.SelectedIndex == 2)
        {
            month2.SelectedIndex = 2;
        }
        else
        {
            month2.SelectedIndex = 0;
        }

    }
}
