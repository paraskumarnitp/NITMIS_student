using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class UserLogDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "6") && (Session["Role"].ToString() != "16"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
                Calendar1.SelectedDate = System.DateTime.Now;   
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

         
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        // view click
        BindGrid();
          
        
        
    }
    protected void UserLogDetailView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        

        UserLogDetailView.PageIndex = e.NewPageIndex;
        BindGrid();
    }

    void BindGrid()
    {
        string sql = "";
        if (RadioButton1.Checked)
        {
            sql = "SELECT  row_number() OVER (ORDER BY ID ASC) AS Count,     LogIn.UserId, LogIn.UserName, LogIn.DeptName, LogIn.Designation, UserLogTime.LoginTime,UserLogTime.online,UserLogTime.LogoutTime , CONVERT(varchar, DATEADD(s, datediff(s, Logintime, getdate()), 0), 108) AS Duration" +
              " FROM         LogIn INNER JOIN UserLogTime ON LogIn.UserId = UserLogTime.LoginId" +
              " WHERE     (UserLogTime.LoginTime > '" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(Calendar1.SelectedDate)) + "') and " +
              "(UserLogTime.LoginTime < '" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(Calendar1.SelectedDate.AddDays(1))) + "') AND (UserLogTime.Online ='Y')";
        }
        else
            sql = "SELECT  row_number() OVER (ORDER BY ID ASC)AS Count, LogIn.UserId, LogIn.UserName, LogIn.DeptName, LogIn.Designation, UserLogTime.LoginTime,UserLogTime.online,UserLogTime.LogoutTime, CONVERT(varchar, DATEADD(s, datediff(s, Logintime, LogoutTime), 0), 108) AS Duration" +
              " FROM         LogIn INNER JOIN UserLogTime ON LogIn.UserId = UserLogTime.LoginId" +
              " WHERE     (UserLogTime.LoginTime > '" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(Calendar1.SelectedDate)) + "') and " +
              "(UserLogTime.LoginTime < '" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(Calendar1.SelectedDate.AddDays(1))) + "')";


        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        UserLogDetailView.DataSource = ds;
        UserLogDetailView.DataBind();
    }
}
