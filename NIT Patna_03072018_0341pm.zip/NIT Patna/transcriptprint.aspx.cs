using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using System.IO;
using CrystalDecisions.Shared;

public partial class transcriptprint : System.Web.UI.Page
{
    ReportDocument rpt = new ReportDocument();
    Functionreviseed fn = new Functionreviseed();
  
    string streamcode, streampartcode, examyear, str, univrollno, crt, sem, stmtp;
    protected void Page_Load(object sender, EventArgs e)
    {
        crt = Request.QueryString["crt"];
        streamcode = Request.QueryString["sc"];
        streampartcode = Request.QueryString["spc"];
        examyear = Request.QueryString["ey"];
        univrollno = Request.QueryString["urolno"];
        sem = Request.QueryString["sem"];
        stmtp = Request.QueryString["stmtp"];
        btechgrade();
    }
    protected void Page_Unload(object sender, EventArgs e)
    {
        if (rpt != null)
        {
            rpt.Close();
            rpt.Dispose();
        }
    }
    protected void btechgrade()
    {
    
        rpt.Load(Server.MapPath("~/Report/Trans_Marksheet.rpt"));
        if (univrollno!="")
        rpt.SetParameterValue(0,null );
        else
        rpt.SetParameterValue(0, streampartcode);
        rpt.SetParameterValue(1, examyear);
        rpt.SetParameterValue(2, "R");
        rpt.SetParameterValue(3, univrollno);
        rpt.SetParameterValue("@StreamPart", null, "summarytranscript");
      
        //rpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)consol;
        string filename = univrollno != "" ? univrollno : examyear;
        MemoryStream oStream = new MemoryStream();
        oStream = (MemoryStream)rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
        Response.Clear();
        Response.Buffer = true;
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "inline;filename=" + filename + ".pdf");
        Response.BinaryWrite(oStream.ToArray());
        Response.End();

        //rpt.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, false, "PersonDetails");



    }


}




    //protected void Page_LoadComplete(object sender, EventArgs e)
    //{
    //    CrystalReportViewer1.ReportSource = Session["btechgrage"];
    //}

