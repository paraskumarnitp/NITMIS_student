using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class CodeEntryDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "5")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
                ViewState.Add("EditMode", "false");
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }


            PopulateDDL popddl = new PopulateDDL();
            
            
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(ExamYear, "Year", "Select Year from Year where year >='2008'order by Year", "Year", "Year");
          //  ExamYear.Focus();
        }
        

    }

    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        RBHons.Checked = false;
        RBComp.Checked = false;
        RBSubs.Checked = false;
        RBPractH.Checked = false;
        RBPractS.Checked = false;
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        StreamCode.Focus();  
    }
    protected void RBHons_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Hons");
    }
    protected void RBPractH_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Hons");

    }
    protected void RBComp_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Comp");
    }
    protected void RBSubs_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Subs");
    }
    protected void RBPractS_CheckedChanged(object sender, EventArgs e)
    {
        GetPaperCode("Subs");
    }
    
    private void GetPaperCode(string PaperType )
    {
        PopulateDDL popddl = new PopulateDDL();
        
       if (PaperType == "Hons")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", "Select PaperName,SubPaperCode from COURSEPAPERS Where StreamCode='" + StreamCode.SelectedValue + "' And StreamPartCode='" + StreamPart.SelectedValue + "' And SubCode='" + SubCode.SelectedValue + "' order by SubPaperCode", "PaperName", "SubPaperCode");
        }
        else if (PaperType == "Comp")
        {
            popddl.Popualate(Subject, "COMPOSITION", "Select Name,CompCode from COMPOSITION order by Name", "Name", "CompCode");
        }
        else if (PaperType == "Subs")
        {
            popddl.Popualate(Subject, "SUBJECT", "Select SubCode,SubjectName from SUBJECT Where StreamCode='" + StreamCode.SelectedValue + "' and subcode<>'" + SubCode.SelectedValue + "'  order by SubjectName", "SubjectName", "SubCode");
        }

        GetMarks();
        Subject.Focus();

    }
    protected void SubCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        RBHons.Checked = false;
        RBComp.Checked = false;
        RBSubs.Checked = false;
        RBPractH.Checked = false;
        RBPractS.Checked = false;
    }


    protected void Button1_Click(object sender, EventArgs e)
    {

        
        BindGrid();
       // if (MarksEntryGrid.Rows.Count > 0)
        {
            Panel3.Enabled = false;

            Panel2.Visible = true;
            LblMsg2.Text = "";
            UnivRollNo.Focus(); 
        }
    }
    void BindGrid()
    {
         char PaperType = 'P';
        if (RBHons.Checked) PaperType = 'H';
        else if (RBComp.Checked) PaperType = 'C';
        else if (RBSubs.Checked) PaperType = 'S';
        else if (RBPractH.Checked) PaperType = 'P';
        else if (RBPractS.Checked) PaperType = 'P';
        
        UnivService.Service1 NicService = new UnivService.Service1();
        string sql = "SELECT count(*) from exampaperdetail where univrollno in (SELECT UnivRollNo FROM EXAM WHERE ExamYear = '" + ExamYear.SelectedValue + "' and streampartcode='" + StreamPart.SelectedValue + "' and subcode='" + SubCode.SelectedValue + "') and streampartcode='" + StreamPart.SelectedValue + "' and SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "' And ExamYear = '" + ExamYear.SelectedValue + "'";
        sql = NicService.GetNewCode(sql);
        LblMsg.Text  = " Total candidate :- " + sql;
        string roll="";
        if (RBCode.Checked )
            roll = "CompCode";
        else
            roll = "UnivRollNo";
        DataSet ds = new DataSet();
        if (Operator.SelectedValue == "1")
            sql = "SELECT " + roll + " UnivRollNo,CompCode , IsAppeared from exampaperdetail where univrollno in (SELECT UnivRollNo FROM EXAM WHERE ExamYear = '" + ExamYear.SelectedValue + "' and streampartcode='" + StreamPart.SelectedValue + "' and subcode='" + SubCode.SelectedValue + "') and streampartcode='" + StreamPart.SelectedValue + "' and SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "' And ExamYear = '" + ExamYear.SelectedValue + "' order by univrollno";
        else
            sql = "SELECT  " + roll + "  UnivRollNo,CompCode, IsAppeared from exampaperdetail where univrollno in (SELECT UnivRollNo FROM EXAM WHERE ExamYear = '" + ExamYear.SelectedValue + "' and streampartcode='" + StreamPart.SelectedValue + "' and subcode='" + SubCode.SelectedValue + "') and streampartcode='" + StreamPart.SelectedValue + "' and SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "' And ExamYear = '" + ExamYear.SelectedValue + "' order by univrollno";
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
        MarksGrid.DataSource = ds;
        MarksGrid.DataBind();


 
    }
    protected int SaveMarks()
    {
        SqlTransaction tran;
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        SqlDataReader rd;
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        // set Papertype
        char PaperType = 'P';
        int n = 0;
        //sql = "SELECT compcode from exampaperdetail";
        if (RBHons.Checked) PaperType = 'H';
        else if (RBComp.Checked) PaperType = 'C';
        else if (RBSubs.Checked) PaperType = 'S';
        else if (RBPractH.Checked) PaperType = 'P';
        else if (RBPractS.Checked) PaperType = 'P';


        con.Open();
       
       
        tran = con.BeginTransaction();
        cmd.Transaction = tran;
        char app = 'P', opt = '1';
        //if (Appear.Checked == false) app = 'A'; 
        string FldNm = "";
        try
        {
            if (Operator.SelectedValue == "1") opt = '1';
            else opt = '2';
            if (RBUniv.Checked == true) FldNm = "UnivRollNo";
            else FldNm = "CompCode";

            //// Check whether student is Absent or unfair means

            //cmd.CommandText = "select IsAppeared from ExamPaperDetail  where " + FldNm + "='" + RollYear.Text + UnivRollNo.Text + "' And streampartcode='" + StreamPart.SelectedValue + "' and examyear='" + ExamYear.SelectedValue + "' And SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "'";
            //rd = cmd.ExecuteReader();
            //if (rd.HasRows)
            //{
            //    rd.Read();s
            //    if (rd["IsAppeared"].ToString() == "A")
            //    {
            //        rd.Close();
            //        return -1; // Abscent student

            //    }
            //}
            //rd.Close();
            ////


               
                    if (opt == '1')
                        cmd.CommandText = "update ExamPaperDetail set EntryDate1=getDate(),opt1= '" + Session["UserId"].ToString() + "', CompCode='" +CompCode.Text.Trim ()  + "' where rtrim(" + FldNm + ")='" + RollYear.Text + UnivRollNo.Text + "' And streampartcode='" + StreamPart.SelectedValue + "' and examyear='" + ExamYear.SelectedValue + "' And SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "'";
                    else if (opt == '2')
                        cmd.CommandText = "update ExamPaperDetail set EntryDate2=getDate(),opt2= '" + Session["UserId"].ToString() + "', CompCode='" +CompCode.Text.Trim ()  +"' where rtrim(" + FldNm + ")='" + RollYear.Text + UnivRollNo.Text + "' And streampartcode='" + StreamPart.SelectedValue + "' and examyear='" + ExamYear.SelectedValue + "' And SubPaperCode='" + Subject.SelectedValue + "' And PaperType='" + PaperType + "'";

                    n=cmd.ExecuteNonQuery();
                 
            tran.Commit();
            return n;
        }
        catch (Exception ex)
        {
            tran.Rollback();
            Response.Write(ex.Message);
            return n;
        }
    }

    protected void BtnSave_Click(object sender, EventArgs e)
    {
        //if (Appear.Checked)
        //{
        //    if (MarksObt.Text.Trim() == "")
        //    {
        //        LblMsg2.Text = " Please enter marks";
        //        return;
        //    }
        //}
        //else
        //{
        //    if (MarksObt.Text.Trim() != "")
        //    {
        //        LblMsg2.Text = " Marks should be blank for abscent student";
        //        return;
        //    }
        //}
        
        int flag=SaveMarks();
        if (flag == 1)
        {
            BindGrid();
            LblMsg2.Text = "Code updated for roll no:-" +UnivRollNo.Text  ;
            UnivRollNo.Text = "";
            CompCode.Text = "";
            UnivRollNo.Focus();
        }
        else if (flag == -1)
        {
            LblMsg2.Text = " Please check Roll no. Student is not appeasred in Exam.";
            UnivRollNo.Focus(); 
        }
        else
        {
            LblMsg2.Text = "Plz check Roll No.";
            UnivRollNo.Focus();
        }
      
    }


    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Panel3.Enabled = true;
        Panel2.Visible = false ;
        LblMsg2.Text = ""; 

    }
    protected void Subject_SelectedIndexChanged(object sender, EventArgs e)
    {
        GetMarks();
    }
    protected void GetMarks()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        string sql = "";
        if (RBHons.Checked || RBPractH.Checked)
        {
            if (RBHons.Checked)
            {
                sql = "SELECT FullMarks from COURSEPAPERS where SubPapercode='" + Subject.SelectedValue + "'";
                sql = NicService.GetNewCode(sql);
                PaperMarks.Text = sql;
            }
            else
            {
                sql = "SELECT FullMarks from PracticalPAPERS where SubPapercode='" + Subject.SelectedValue + "'";
                sql = NicService.GetNewCode(sql);
                if (sql == "error")
                    PaperMarks.Text = "0";
                else
                    PaperMarks.Text = sql;
            }
        }


        else if (RBSubs.Checked || RBPractS.Checked)
        {
            if (RBSubs.Checked)
            {
                sql = "SELECT FullMarks from SUBSIDIARY where SubCode='" + Subject.SelectedValue + "'";
                sql = NicService.GetNewCode(sql);
                PaperMarks.Text = sql;
            }
            else
            {
                sql = "SELECT PrFullMarks from SUBSIDIARY where SubCode='" + Subject.SelectedValue + "'";
                sql = NicService.GetNewCode(sql);
                PaperMarks.Text = sql;
            }
        }
        else if (RBComp.Checked)
        {
            sql = "SELECT FullMarks from COMPOSITION where CompCode='" + Subject.SelectedValue + "'";
            sql = NicService.GetNewCode(sql);
            PaperMarks.Text = sql;
        }
            
    }
    protected void MarksGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        MarksGrid.PageIndex = e.NewPageIndex;
         BindGrid();
    }
}
