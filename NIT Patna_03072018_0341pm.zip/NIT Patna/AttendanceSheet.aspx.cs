using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
public partial class AttendanceSheet : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "3")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            //popddl.Popualate(ExamCollCode, "College", "Select CollName,CollCode from College where CollCode in ( select Distinct ExamCollcode from Exam ) order by CollName", "CollName", "CollCode");
            popddl.Popualate(ExamCollCode, "College", "Select CollName,ExamCollCode from EXAMCOLLEGE where ExamCollCode in ( select Distinct ExamCollcode from Exam ) order by CollName", "CollName", "ExamCollCode");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            ExamYear.Text = System.DateTime.Now.Year.ToString();
        }

    }
    protected void StreamPart_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        
    }
    protected void BtnAttendance_Click(object sender, EventArgs e)
    {
        ////Generate attendance sheet
        //SqlConnection con = new SqlConnection();
        //SqlConnection con2 = new SqlConnection();
        //SqlCommand cmd = new SqlCommand();
        //SqlDataReader reader,reader2;
        //con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        //con2.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        //cmd.CommandText = " select UnivRollNo,RegNo from Exam where ExamCollCode='" + ExamCollCode.SelectedValue +
        //                 "' And StreamCode='" + StreamCode.SelectedValue + "' And StreamPartCode='" + StreamPart.SelectedValue +
        //                 "' And ExamYear='" + ExamYear.Text + "'";
        //cmd.Connection = con;
        
        //con.Open();
        //reader = cmd.ExecuteReader();
        //UnivService.Service1 ss = new UnivService.Service1();
        //ss.UpdateData(" delete from attendancesheet");
        //string abc="";
        //string[] col = new string[6];
        //string[] val = new string[6];
        //col[0] = "ExamCollCode";
        //col[1] = "StreamCode";
        //col[2] = "UnivRollNo";
        //col[3] = "RegNo";
        //col[4] = "SubPaperCode";
        //col[5] = "PaperName";
        //val[0] = ExamCollCode.SelectedValue.ToString();
        //val[1] = StreamCode.SelectedValue.ToString();
        //while (reader.Read())
        //{
        //    val[2] = reader["UnivRollNo"].ToString();
        //    val[3] = reader["RegNo"].ToString();
        //    cmd.CommandText = " select SubPaperCode,PaperType from exampaperdetail where UnivRollNo='" + reader["UnivRollNo"].ToString() +
        //                     "' and ExamYear='" + ExamYear.Text + "' And StreamPartCode='" + StreamPart.SelectedValue + "'";
        //    cmd.Connection = con2;
        //    con2.Open();
        //    reader2 = cmd.ExecuteReader();
        //    while (reader2.Read())
        //    {
        //        val[4] = reader2["SubPaperCode"].ToString(); ;
        //        if (reader2["PaperType"].ToString() == "C")
        //        {
        //            abc=ss.GetNewCode("select Abbr from Composition where CompCode='" + reader2["SubPaperCode"].ToString () + "'");
        //        }
        //        else if (reader2["PaperType"].ToString() == "H")
        //        {
        //            abc = ss.GetNewCode("select PaperAbbr from CoursePapers where SubPaperCode='" + reader2["SubPaperCode"].ToString () + "'");
        //        }
        //        else if (reader2["PaperType"].ToString() == "S")
        //        {
        //            abc = ss.GetNewCode("select SubAbbr from Subject where SubCode='" + reader2["SubPaperCode"].ToString () + "'");
        //        }

                
        //        val[5] = abc;

        //        abc = ss.SaveData("AttendanceSheet", col, val);
        //    }
        //    reader2.Close(); 
        //    con2.Close();
        //}

        //reader.Close(); 
        //con.Close(); 
            
        ////............

    }
    protected void BtnPrint_Click(object sender, EventArgs e)
    {
        //Generate attendance sheet
        SqlConnection con = new SqlConnection();
        SqlConnection con2 = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        SqlDataReader reader, reader2;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        con2.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.CommandText = " select UnivRollNo,RegNo from Exam where ExamCollCode='" + ExamCollCode.SelectedValue +
                         "' And StreamCode='" + StreamCode.SelectedValue + "' And StreamPartCode='" + StreamPart.SelectedValue +
                         "' And ExamYear='" + ExamYear.Text + "' And SubCode='"+SubCode.SelectedValue.ToString ()  +"'";
        cmd.Connection = con;

        con.Open();
        reader = cmd.ExecuteReader();
        UnivService.Service1 ss = new UnivService.Service1();
        ss.UpdateData(" delete from attendancesheet");
        string abc = "";
        string[] col = new string[8];
        string[] val = new string[8];
        col[0] = "ExamCollCode";
        col[1] = "StreamCode";
        col[2] = "UnivRollNo";
        col[3] = "RegNo";
        col[4] = "SubPaperCode";
        col[5] = "PaperName";
        col[6] = "StreamPartCode";
        col[7] = "SubCode";

        val[0] = ExamCollCode.SelectedValue.ToString();
        val[1] = StreamCode.SelectedValue.ToString();
        val[6] = StreamPart.SelectedValue;
        val[7] = SubCode.SelectedValue; 
        while (reader.Read())
        {
            val[2] = reader["UnivRollNo"].ToString();
            val[3] = reader["RegNo"].ToString();
            cmd.CommandText = " select SubPaperCode,PaperType from exampaperdetail where UnivRollNo='" + reader["UnivRollNo"].ToString() +
                             "' and ExamYear='" + ExamYear.Text + "' And StreamPartCode='" + StreamPart.SelectedValue + "' And PaperType<>'P'";
            cmd.Connection = con2;
            con2.Open();
            reader2 = cmd.ExecuteReader();
            while (reader2.Read())
            {
                val[4] = reader2["SubPaperCode"].ToString(); ;
             /*   if (reader2["PaperType"].ToString() == "C")
                {
                    abc = ss.GetNewCode("select Abbr from Composition where CompCode='" + reader2["SubPaperCode"].ToString() + "'");
                }
                else if (reader2["PaperType"].ToString() == "H")
                {
                    abc = ss.GetNewCode("select PaperAbbr from CoursePapers where SubPaperCode='" + reader2["SubPaperCode"].ToString() + "'");
                }
                else if (reader2["PaperType"].ToString() == "S")
                {
                    abc = ss.GetNewCode("select SubAbbr from Subject where SubCode='" + reader2["SubPaperCode"].ToString() + "'");
                }*/

                abc = ss.GetNewCode("select PaperAbbr from CoursePapers where SubPaperCode='" + reader2["SubPaperCode"].ToString() + "'");


                val[5] = abc;

                abc = ss.SaveData("AttendanceSheet", col, val);
            }
            reader2.Close();
            con2.Close();
        }

        reader.Close();
        con.Close();

        //............
        //Call Report viewer

        Panel1.Visible = true;
        CR.ReportSource = crs;
        CR.RefreshReport();
       


        
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        CR.ReportSource = crs1;
        CR.RefreshReport();

    }
    protected void InstCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            ExamCollCode.SelectedValue = InstCode.Text;
        }
        catch (Exception ex)
        {
            string msg = "College Code is not correct.";
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterStartupScript("PopupScript", popupScript);
            InstCode.Text = "";
            InstCode.Focus();
            ExamCollCode.SelectedIndex = 0;
        }
    }
    protected void ExamCollCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        InstCode.Text = ExamCollCode.SelectedValue.ToString();
    }
}
