using System;
using System.IO;
using System.Data;
using System.Data.SqlClient ;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class HODallotment : System.Web.UI.Page
{

    Functionreviseed fn = new Functionreviseed();
    Functionreviseed chkfn = new Functionreviseed();
   // static int CountCourse = 0;
    //static int CountElective = 0;
    DataTable dt1 = new DataTable();
    DataRow dr = null;
 

    protected void Page_Load(object sender, EventArgs e)
    {

       if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "4")&& (Session["Role"].ToString() != "16"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }           

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(drpdlprogram, "Stream", "Select Distinct StreamCode,StreamAbbr From Stream order by StreamCode", "StreamAbbr", "StreamCode");
            popddl.Popualate(drpddlfaculty, "Login", "Select Userid,Username From Login Where DeptName = 'Fc'  and ISlock = 'N'", "Username", "Userid");
         
                     
        }      
    } 
      
   void InstCode_Enter(object sender, EventArgs e)
    {
        LblMsg.Text = "Enter Pressed";
    }  
  
      
    protected void btnshow_Click(object sender, EventArgs e)
    {
        AddRow();
    }
  
    private void AddRow()
    {
        try
        {

            if (ViewState["CurrentTable"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                int index = dtCurrentTable.Rows.Count;
                dtCurrentTable.Rows.Add(index + 1, drpddlfaculty.SelectedValue, drpddlfaculty.SelectedItem.ToString(), drpdlprogram.SelectedItem.ToString(), "HOD", drpdlprogram.SelectedValue);
                ViewState["CurrentTable"] = dtCurrentTable;
                gvcourse.DataSource = dtCurrentTable;
                gvcourse.DataBind();

            }
            else
            {
                SetInitialRow();
            }
            SetPreviousData();
        }
        catch
        {
            LblMsg.Text = "HOD already assigned for "+ drpdlprogram.SelectedItem.ToString() +" Department.";
        }
    }

    private void SetInitialRow()
    {
        try
        {
            dt1.Columns.Add(new DataColumn("RowNumber", typeof(string)));
            dt1.Columns.Add(new DataColumn("Column1", typeof(string)));
            dt1.Columns.Add(new DataColumn("Column2", typeof(string)));
            dt1.Columns.Add(new DataColumn("Column3", typeof(string)));
            dt1.Columns.Add(new DataColumn("Column4", typeof(string)));
            dt1.Columns.Add(new DataColumn("Column5", typeof(string)));
            Constraint constraint = new UniqueConstraint("constraint1",
            new DataColumn[] {dt1.Columns["column3"]}, false);
            dt1.Constraints.Add(constraint);

            dr = dt1.NewRow();
            dr["RowNumber"] = 1;
            dr["Column1"] = drpddlfaculty.SelectedValue.ToString();
            dr["Column2"] = drpddlfaculty.SelectedItem.ToString();
            dr["Column3"] = drpdlprogram.SelectedItem.ToString();
            dr["Column4"] = "HOD";
            dr["Column5"] = drpdlprogram.SelectedValue;
            dt1.Rows.Add(dr);
            //dr = dt.NewRow();
            //Store the DataTable in ViewState

            ViewState["CurrentTable"] = dt1;
            gvcourse.DataSource = dt1;
            gvcourse.DataBind();
        }
        catch(Exception ex)
        {
            LblMsg.Text = ex.ToString();
        }

    }

    private void SetPreviousData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt2 = (DataTable)ViewState["CurrentTable"];
            if (dt2.Rows.Count > 0)
            {
                for (int i = 0; i < dt2.Rows.Count; i++)
                {
                    TextBox box1 = (TextBox)gvcourse.Rows[rowIndex].Cells[1].FindControl("txtfacultycode");
                    TextBox box2 = (TextBox)gvcourse.Rows[rowIndex].Cells[2].FindControl("txtfacultyname");
                    TextBox box3 = (TextBox)gvcourse.Rows[rowIndex].Cells[3].FindControl("txtdepartment");
                    TextBox box4 = (TextBox)gvcourse.Rows[rowIndex].Cells[4].FindControl("txtdesignation");
                    TextBox box5 = (TextBox)gvcourse.Rows[rowIndex].Cells[5].FindControl("txtstreamcode");                    
                    box1.Text = dt2.Rows[i]["Column1"].ToString();
                    box2.Text = dt2.Rows[i]["Column2"].ToString();
                    box3.Text = dt2.Rows[i]["Column3"].ToString();
                    box4.Text = dt2.Rows[i]["Column4"].ToString();
                    box5.Text = dt2.Rows[i]["Column5"].ToString();
                    rowIndex++;
                }
            }
        }
    }
    
    protected void gvcourse_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "remove")
        {
            GridViewRow gvr = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
            int RowIndex = gvr.RowIndex;
            string coursecode = Convert.ToString(((TextBox)gvcourse.Rows[RowIndex].FindControl("txtfacultycode")).Text);
            string deptcode = Convert.ToString(((TextBox)gvcourse.Rows[RowIndex].FindControl("txtdepartment")).Text);
            if (ViewState["CurrentTable"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                foreach (DataRow row in dtCurrentTable.Select())
                {
                    if (row["Column1"].ToString() == coursecode && row["Column3"].ToString() == deptcode)
                    {
                        row.Delete();
                    }
                }
                dtCurrentTable.AcceptChanges();
                DataTable dt3 = new DataTable();
                dt3.Columns.Add(new DataColumn("RowNumber", typeof(string)));
                dt3.Columns.Add(new DataColumn("Column1", typeof(string)));
                dt3.Columns.Add(new DataColumn("Column2", typeof(string)));
                dt3.Columns.Add(new DataColumn("Column3", typeof(string)));
                dt3.Columns.Add(new DataColumn("Column4", typeof(string)));
                dt3.Columns.Add(new DataColumn("Column5", typeof(string)));              
                int rowIndex = 0;
                for (int l = 0; l < dtCurrentTable.Rows.Count; l++)
                {
                    dr = dt3.NewRow();
                    dr["RowNumber"] = rowIndex + 1;
                    dr["Column1"] = dtCurrentTable.Rows[l]["Column1"].ToString();
                    dr["Column2"] = dtCurrentTable.Rows[l]["Column2"].ToString();
                    dr["Column3"] = dtCurrentTable.Rows[l]["Column3"].ToString();
                    dr["Column4"] = dtCurrentTable.Rows[l]["Column4"].ToString();
                    dr["Column5"] = dtCurrentTable.Rows[l]["Column5"].ToString();
                    dt3.Rows.Add(dr);
                    rowIndex++;
                }
                ViewState["CurrentTable"] = dt3;           
                gvcourse.DataSource = dt3;
                gvcourse.DataBind();
                SetPreviousData();
               
            }
        }
    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        DataTable dt4 = new DataTable();
          dt4 = (DataTable)ViewState["CurrentTable"];
          
        string connectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlConnection connection = new SqlConnection(connectionString);
        SqlCommand command = connection.CreateCommand();
        SqlTransaction transaction = null;
        
                try
                 {
                     DataSet dshod = new DataSet();
                     connection.Open();
                     string query = "";
                     transaction = connection.BeginTransaction();
                     command.Transaction = transaction;
                     //code for save                    
                     for (int r = 0; r < dt4.Rows.Count; r++)
                     {
                         dshod.Clear();
                         query = "SELECT ID, UserRole, UserID, StreamCode, Is_Active, FCEntrytime FROM HODSettings WHERE StreamCode = '" + dt4.Rows[r]["Column5"].ToString() + "' AND Is_Active = 'Y'";
                         //SqlCommand cmd = new SqlCommand(query, connection);
                         command.CommandText = query;
                         command.ExecuteNonQuery();
                         SqlDataAdapter da = new SqlDataAdapter(command);
                         da.Fill(dshod);
                         if (dshod.Tables[0].Rows.Count > 0)
                         {
                             if (dshod.Tables[0].Rows[0]["StreamCode"].ToString() == dt4.Rows[r]["Column5"].ToString())
                             {
                                 if (dshod.Tables[0].Rows[0]["UserID"].ToString() == dt4.Rows[r]["Column1"].ToString())
                                 {
                                     // only update last update
                                     command.CommandText = "Update HODSettings Set LUEntrytime= GETDate() Where Userid = '"+ dt4.Rows[r]["Column1"].ToString() +"' and " + 
                                         " Streamcode = '" + dt4.Rows[r]["Column5"].ToString() + "' and IS_active = 'Y'";
                                     command.ExecuteNonQuery();
                                 }
                                 else
                                 {
                                     // Inactive previous record then entry new record 
                                     command.CommandText = "Update HODSettings Set Is_Active = 'N' Where Streamcode = '" + dt4.Rows[r]["Column5"].ToString() + "' and IS_active = 'Y'";
                                     command.ExecuteNonQuery();
                                     command.CommandText = "INSERT INTO HODSettings (UserRole, UserID, StreamCode, Is_Active, FCEntrytime) VALUES " +
                                                         " ('13','" + dt4.Rows[r]["Column1"].ToString() + "','" + dt4.Rows[r]["Column5"].ToString() + "','Y',GETDate())";
                                     command.ExecuteNonQuery();
                                 }

                             }
                         }
                         else
                         {
                             // insert new record
                             command.CommandText = "INSERT INTO HODSettings (UserRole, UserID, StreamCode, Is_Active, FCEntrytime) VALUES " +
                                                         " ('13','" + dt4.Rows[r][""].ToString() + "','" + dt4.Rows[r][""].ToString() + "','Y',GETDate())";
                             command.ExecuteNonQuery();
                         }
                         
                         
                     }
                     transaction.Commit();
                     LblMsg.Text = "HOD Settings Saved Successfully.";
                     btnsubmit.Text = "Save";
                 }
                 catch (Exception ex)
                 {
                     transaction.Rollback();
                     LblMsg.Text = ex.ToString();
                 }
                 finally
                 {
                     connection.Close();
                 }
               
    }     
}
