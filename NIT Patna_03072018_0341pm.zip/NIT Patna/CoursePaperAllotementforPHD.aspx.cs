using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class CoursePaperAllotementforPHD : System.Web.UI.Page
{
 
    DataTable dt1 = new DataTable();
    DataRow dr = null;
 int index = 1;
   static  string Examsession=""; 
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                //if ((Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "10"))
                //{
                //    Session["userName"] = null;
                //    FormsAuthentication.SignOut();
                //    Response.Redirect("default.aspx");
                //    return;
                //}
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(Year3, "Year", "Select Year from Year where year > '2016'order by Year", "Year", "Year");
            Year3.Text = System.DateTime.Now.Year.ToString();
          
        }
    }
    protected void month1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (month1.SelectedIndex == 1)
        {
            month2.SelectedIndex = 1;
             }
        else if (month1.SelectedIndex == 2)
        {
            month2.SelectedIndex = 2;
           
        }
        else
        {
            month2.SelectedIndex = 0;
        }
    }
    protected void btnOk_Click(object sender, EventArgs e)
    {


        string query = "SELECT DISTINCT REGISTRATION.Ackno from REGISTRATION  where TempRollNo='" + txtrollno.Text.Trim() + "' ";
        DataSet dsmasterpaper = new DataSet();
        dsmasterpaper = fnrev.SelectDataset(query);

        string ackno = dsmasterpaper.Tables[0].Rows[0]["Ackno"].ToString();



        try
        {
            string strConnString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            SqlConnection con = new SqlConnection(strConnString);

            string query1 = "SELECT DISTINCT REGISTRATION.Ackno as rollno , REGISTRATION.RegNo, REGISTRATION.ApplicantName, dscallotment.cuid  FROM   REGISTRATION INNER JOIN  dscallotment ON REGISTRATION.AckNo = dscallotment.rollno WHERE     (REGISTRATION.ackNo = '" + ackno + "')";
            SqlDataAdapter sda = new SqlDataAdapter(query1, con);
            DataSet ds = new DataSet();
            sda.Fill(ds, "REGISTRATION");

            grdregdetails.DataSource = ds;
            grdregdetails.DataBind();
        }
        catch (Exception ex)
        {
        }

       fillcourse();
        showCourse();

    }
    protected void grdregdetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {





        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {

                string roll = grdregdetails.DataKeys[e.Row.RowIndex].Value.ToString();
                GridView grdmember = e.Row.FindControl("gvmember") as GridView;

                string strConnString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
                SqlConnection con = new SqlConnection(strConnString);

                string query = "select membertype ,memuserid ,member  from dscallotment where rollno='" + roll + "'";
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                DataSet ds = new DataSet();
                sda.Fill(ds, "dscallotment");
                grdmember.DataSource = ds;
                //  grdmember.DataSource = GetData(string.Format("select membertype ,memuserid ,member  from dscallotment where rollno='" + roll + "'  "));
                grdmember.DataBind();



            }



        }
        catch (Exception ex)
        {
        }







    }


    protected void btnadd_Click(object sender, EventArgs e)
    {
        AddRow();
    }






    public void fillcourse()
    {

        string query = "select StreamCode from registration  where TempRollNo='" + txtrollno.Text.Trim() + "'";
        DataSet dsmasterpaper = new DataSet();
        dsmasterpaper = fnrev.SelectDataset(query);

        String streamcode = dsmasterpaper.Tables[0].Rows[0]["StreamCode"].ToString();

        try
        {
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(ddlcourse, "COURSEPAPERS", "SELECT     COURSEPAPERS.PaperAbbr FROM  COURSEPAPERS INNER JOIN  STREAM ON COURSEPAPERS.StreamCode = STREAM.StreamCode WHERE     (COURSEPAPERS.StreamCode IN ('" + streamcode + "')) ", "PaperAbbr", "PaperAbbr");

        }
        catch (Exception ex)
        {
        }



    }
    public void showCourse()
    {

        Examsession = month1.SelectedItem + "-" + month2.SelectedItem + "_" + Year3.SelectedItem;

        try
        {



            try
            {

                // string query = "SELECT UserId,UserName,deptName , CASE  WHEN deptName = 'fc' THEN 'HOD' else 'HOD' end ,Designation FROM Login where userrole =13";

                string query = " select pappercode,papertitle ,Credit,L,T,P,StreamPart from CoursePaperAllotementforPHD  where univrollno='" + txtrollno.Text.Trim() + "' and Examsession='" + Examsession.Trim() + "' ";
                DataSet ds = new DataSet();
                ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, query);
                // gvcourse.DataSource = ds;
                // gvcourse.DataBind();
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ToString());
                SqlDataReader dr1;
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                dr1 = cmd.ExecuteReader();

                dt1.Columns.Add(new DataColumn("RowNumber", typeof(string)));
                dt1.Columns.Add(new DataColumn("coursecode", typeof(string)));
                dt1.Columns.Add(new DataColumn("papertitle", typeof(string)));
                dt1.Columns.Add(new DataColumn("Credit", typeof(string)));
                dt1.Columns.Add(new DataColumn("L", typeof(string)));
                dt1.Columns.Add(new DataColumn("T", typeof(string)));
                dt1.Columns.Add(new DataColumn("P", typeof(string)));
                dt1.Columns.Add(new DataColumn("StreamPart", typeof(string)));
               
                Constraint constraint = new UniqueConstraint("constraint1",
               new DataColumn[] { dt1.Columns["coursecode"] }, false);
                dt1.Constraints.Add(constraint);

                while (dr1.Read())
                {

                    // 
                    try
                    {

                        dr = dt1.NewRow();
                        dr["RowNumber"] = index;
                        dr["coursecode"] = dr1[0].ToString();
                        dr["papertitle"] = dr1[1].ToString();
                        dr["Credit"] = dr1[2].ToString();
                        dr["L"] = dr1[3].ToString();
                        dr["T"] = dr1[4].ToString();
                        dr["P"] = dr1[5].ToString();
                        dr["StreamPart"] = dr1[6].ToString();
                        dt1.Rows.Add(dr);
                      
                        ViewState["CurrentTable"] = dt1;
                        gvcourse.DataSource = dt1;
                        gvcourse.DataBind();
                        index++;
                    }

                    catch (Exception ex)
                    {
                        // LblMsg.Text = "HOD already assigned for " + drpdlprogram.SelectedItem.ToString() + " Department.";

                    }

                }


                con.Close();

            }
            catch (Exception ex)
            {
               
            }








        }
        catch (Exception ex)
        {
        }


    }


    private void AddRow()
    {
         string query = "select StreamCode from registration  where TempRollNo='" + txtrollno.Text.Trim() + "'";
        DataSet dsmasterpaper = new DataSet();
        dsmasterpaper = fnrev.SelectDataset(query);

        String streamcode = dsmasterpaper.Tables[0].Rows[0]["StreamCode"].ToString();

       
        try
        {

            if (ViewState["CurrentTable"] != null)
            {

                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                int index = dtCurrentTable.Rows.Count;

                string query1 = "SELECT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName,Credit,L,T,P,StreamPart  FROM   COURSEPAPERS INNER JOIN STREAM ON COURSEPAPERS.StreamCode = STREAM.StreamCode WHERE     (COURSEPAPERS.StreamCode IN ('" + streamcode + "')) and PaperAbbr='" + ddlcourse.SelectedValue + "'  ";
                DataSet dsmasterpaper1 = new DataSet();
                dsmasterpaper1 = fnrev.SelectDataset(query1);

                String papername = dsmasterpaper1.Tables[0].Rows[0]["PaperName"].ToString();

                String credit = dsmasterpaper1.Tables[0].Rows[0]["Credit"].ToString();
                String l = dsmasterpaper1.Tables[0].Rows[0]["L"].ToString();
                String t = dsmasterpaper1.Tables[0].Rows[0]["T"].ToString();
                String p = dsmasterpaper1.Tables[0].Rows[0]["P"].ToString();
                String sem = dsmasterpaper1.Tables[0].Rows[0]["StreamPart"].ToString();

                dtCurrentTable.Rows.Add(index + 1, ddlcourse.SelectedValue, papername, credit,l,t,p,sem);

                ViewState["CurrentTable"] = dtCurrentTable;
                gvcourse.DataSource = dtCurrentTable;
                gvcourse.DataBind();
           

            }

            else
            {
                SetInitialRow();

            }
        }
        catch (Exception ex)
        {
            //LblMsg.Text = "HOD already assigned for " + drpdlprogram.SelectedItem.ToString() + " Department.";

        }
       
    }


    private void SetInitialRow()
    {


        try
        {
            dt1.Columns.Add(new DataColumn("RowNumber", typeof(string)));
            dt1.Columns.Add(new DataColumn("coursecode", typeof(string)));
            dt1.Columns.Add(new DataColumn("papertitle", typeof(string)));
            dt1.Columns.Add(new DataColumn("Credit", typeof(string)));
            dt1.Columns.Add(new DataColumn("L", typeof(string)));
            dt1.Columns.Add(new DataColumn("T", typeof(string)));
            dt1.Columns.Add(new DataColumn("P", typeof(string)));
            dt1.Columns.Add(new DataColumn("StreamPart", typeof(string)));

            Constraint constraint = new UniqueConstraint("constraint1",
               new DataColumn[] { dt1.Columns["coursecode"] }, false);
            dt1.Constraints.Add(constraint);

            dr = dt1.NewRow();

            string query = "SELECT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperName,Credit,L,T,P,StreamPart  FROM   COURSEPAPERS INNER JOIN STREAM ON COURSEPAPERS.StreamCode = STREAM.StreamCode WHERE     (COURSEPAPERS.StreamCode IN ('MA')) and PaperAbbr='" + ddlcourse.SelectedValue + "'  ";
            DataSet dsmasterpaper = new DataSet();
            dsmasterpaper = fnrev.SelectDataset(query);

            String papername = dsmasterpaper.Tables[0].Rows[0]["PaperName"].ToString();
            String credit = dsmasterpaper.Tables[0].Rows[0]["Credit"].ToString();
            String l = dsmasterpaper.Tables[0].Rows[0]["L"].ToString();
            String t = dsmasterpaper.Tables[0].Rows[0]["T"].ToString();
            String p = dsmasterpaper.Tables[0].Rows[0]["P"].ToString();
            String sem = dsmasterpaper.Tables[0].Rows[0]["StreamPart"].ToString();
            dr["RowNumber"] = index;
            dr["coursecode"] = ddlcourse.SelectedValue.ToString();
            dr["papertitle"] = papername;
            dr["Credit"] = credit;
            dr["L"] = l;
            dr["T"] = t;
            dr["P"] = p;
            dr["StreamPart"] = sem;

                 dt1.Rows.Add(dr);
            gvcourse.DataSource = dt1;
            gvcourse.DataBind();
            index++;
            ViewState["CurrentTable"] = dt1;
            

        }
        catch (Exception ex)
        {

        }


    }







    protected void btnsave_Click(object sender, EventArgs e)
    {
       string  Examsession = month1.SelectedValue + "-" + month2.SelectedValue + "_" + Year3.SelectedValue;
        DataTable dt4 = new DataTable();
        dt4 = (DataTable)ViewState["CurrentTable"];

        string connectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlConnection connection = new SqlConnection(connectionString);
        SqlCommand command = connection.CreateCommand();
        SqlTransaction transaction = null;
        try
        {
            connection.Open();

            transaction = connection.BeginTransaction();
            command.Transaction = transaction;

            string query = "select regNo from registration where TempRollNo='" + txtrollno.Text.Trim() + "' ";
            DataSet dsmasterpaper = new DataSet();
            dsmasterpaper = fnrev.SelectDataset(query);
            String regNo = dsmasterpaper.Tables[0].Rows[0]["regNo"].ToString();


            DataSet dshod = new DataSet();



            for (int r = 0; r < dt4.Rows.Count; r++)
            {
                dshod.Clear();
                string query1 = "select univrollno,RegNo,pappercode, papertitle,Credit,L,T,P, StreamPart,ExamSession from CoursePaperAllotementforPHD  where  univrollno='" + txtrollno.Text.Trim() + "' and Examsession='" + Examsession.Trim() + "' ";
                //SqlCommand cmd = new SqlCommand(query, connection);
                SqlCommand command1 = connection.CreateCommand();
                command1.CommandText = query1;
                connection.Close();
                connection.Open();
                command1.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(command1);
                da.Fill(dshod);
               // connection.Close();
                if (dshod.Tables[0].Rows.Count > 0)
                {
                    string ss = dshod.Tables[0].Rows[0]["pappercode"].ToString();
                    string sss = dt4.Rows[r]["coursecode"].ToString();
                    if (ss.Equals(sss))
                    {
                      
                    }
                    else
                    {
                        
                         connection.Close();
                        connection.Open();

                        command.CommandText = "delete from CoursePaperAllotementforPHD where   univrollno='" + txtrollno.Text.Trim() + "' and Examsession='" + Examsession.Trim() + "'  and pappercode='" + dt4.Rows[r]["coursecode"].ToString() + "'  ";
                        command.ExecuteNonQuery();
                        connection.Close();
                        connection.Open();

                        command.CommandText = "INSERT INTO CoursePaperAllotementforPHD (Univrollno ,RegNo ,pappercode,papertitle,Credit,L,T,P,StreamPart,ExamSession) VALUES " +
                                       " ('" + txtrollno.Text.Trim() + "','" + regNo + "','" + dt4.Rows[r]["coursecode"].ToString() + "','" + dt4.Rows[r]["papertitle"].ToString() + "','" + dt4.Rows[r]["Credit"].ToString() + "','" + dt4.Rows[r]["L"].ToString() + "','" + dt4.Rows[r]["T"].ToString() + "','" + dt4.Rows[r]["P"].ToString() + "'   ,'" + dt4.Rows[r]["StreamPart"].ToString() + "', '" + Examsession + "')";
                        command.ExecuteNonQuery();
                        connection.Close();
                        LblMsg.Text = "Save Sucessfully!";
                    }

                }

                else
                {

                    command.CommandText = "INSERT INTO CoursePaperAllotementforPHD (Univrollno ,RegNo ,pappercode,papertitle,Credit,L,T,P,StreamPart,ExamSession) VALUES " +
                                          " ('" + txtrollno.Text.Trim() + "','" + regNo + "','" + dt4.Rows[r]["coursecode"].ToString() + "','" + dt4.Rows[r]["papertitle"].ToString() + "','" + dt4.Rows[r]["Credit"].ToString() + "','" + dt4.Rows[r]["L"].ToString() + "','" + dt4.Rows[r]["T"].ToString() + "','" + dt4.Rows[r]["P"].ToString() + "'   ,'" + dt4.Rows[r]["StreamPart"].ToString() + "', '" + Examsession + "')";
                   connection.Close();
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                    LblMsg.Text = "Save Sucessfully!";
                }

            }
        }
        catch (Exception ex)
        {

        }
                           }



    protected void gvcourse_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "remove")
        {
            GridViewRow gvr = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
            int RowIndex = gvr.RowIndex;
            string coursecode = Convert.ToString(((TextBox)gvcourse.Rows[RowIndex].FindControl("txtcoursecode")).Text);
            string query1 = "delete from CoursePaperAllotementforPHD where pappercode='" + coursecode + "' and  Univrollno='"+txtrollno.Text.Trim ()+"' and examsession='"+ Examsession +"'";

            fnrev.InsertUpdateDelete(query1);


            try
            {
                if (ViewState["CurrentTable"] != null)
                {
                    DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                    DataTable dt3 = new DataTable();
                    foreach (DataRow row in dtCurrentTable.Select())
                    {
                        if (row["coursecode"].ToString() == coursecode)
                        {
                            row.Delete();
                            // LblMsg.Text = "  ";
                        }
                    }
                    dtCurrentTable.AcceptChanges();
                    // DataTable dt3 = new DataTable();
                    dt3.Columns.Add(new DataColumn("RowNumber", typeof(string)));
                    dt3.Columns.Add(new DataColumn("coursecode", typeof(string)));
                    dt3.Columns.Add(new DataColumn("papertitle", typeof(string)));
                    dt3.Columns.Add(new DataColumn("Credit", typeof(string)));
                    dt3.Columns.Add(new DataColumn("L", typeof(string)));
                    dt3.Columns.Add(new DataColumn("T", typeof(string)));
                    dt3.Columns.Add(new DataColumn("P", typeof(string)));
                    dt3.Columns.Add(new DataColumn("StreamPart", typeof(string)));
                    int rowIndex = 0;
                    for (int l = 0; l < dtCurrentTable.Rows.Count; l++)
                    {
                        dr = dt3.NewRow();
                        dr["RowNumber"] = rowIndex + 1;
                        dr["coursecode"] = dtCurrentTable.Rows[l]["coursecode"].ToString();
                        dr["papertitle"] = dtCurrentTable.Rows[l]["papertitle"].ToString();
                        dr["Credit"] = dtCurrentTable.Rows[l]["Credit"].ToString();
                        dr["L"] = dtCurrentTable.Rows[l]["L"].ToString();
                        dr["T"] = dtCurrentTable.Rows[l]["T"].ToString();
                        dr["P"] = dtCurrentTable.Rows[l]["P"].ToString();
                        dr["StreamPart"] = dtCurrentTable.Rows[l]["StreamPart"].ToString();

                        dt3.Rows.Add(dr);
                        rowIndex++;
                    }
                    ViewState["CurrentTable"] = dt3;
                    gvcourse.DataSource = dt3;
                    gvcourse.DataBind();

                    SetPreviousData();
                }


            }
            catch (Exception ex)
            {
                //  LblMsg.Text = "";
            }
        }
        
    }


 
 









    public void SetPreviousData()
    {

        int rowIndex = 0;

        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt2 = (DataTable)ViewState["CurrentTable"];
            if (dt2.Rows.Count > 0)
            {
                for (int i = 0; i < dt2.Rows.Count; i++)
                {
                    TextBox box1 = (TextBox)gvcourse.Rows[rowIndex].Cells[1].FindControl("txtcoursecode");
                    TextBox box2 = (TextBox)gvcourse.Rows[rowIndex].Cells[2].FindControl("txtcoursetitle");
                    TextBox box3 = (TextBox)gvcourse.Rows[rowIndex].Cells[3].FindControl("txtpapercredit");
                    TextBox box4 = (TextBox)gvcourse.Rows[rowIndex].Cells[4].FindControl("txtpaperL");
                    TextBox box5 = (TextBox)gvcourse.Rows[rowIndex].Cells[5].FindControl("txtpaperT");
                    TextBox box6 = (TextBox)gvcourse.Rows[rowIndex].Cells[5].FindControl("txtpaperP");
                    TextBox box7 = (TextBox)gvcourse.Rows[rowIndex].Cells[5].FindControl("txtsemester");



                    box1.Text = dt2.Rows[i]["coursecode"].ToString();
                    box2.Text = dt2.Rows[i]["papertitle"].ToString();
                    box3.Text = dt2.Rows[i]["Credit"].ToString();
                    box4.Text = dt2.Rows[i]["L"].ToString();
                    box5.Text = dt2.Rows[i]["T"].ToString();
                    box6.Text = dt2.Rows[i]["P"].ToString();
                    box7.Text = dt2.Rows[i]["StreamPart"].ToString();
                    
                    rowIndex++;
                }
            }
        }
        else
        {
            //  LblMsg.Text = "HOD already assigned for " + drpdlprogram.SelectedItem.ToString() + " Department.";
        }









    }

}
