using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Net;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;


public partial class OptEntryRegList : System.Web.UI.Page
{
    static int ch1 = 0, ch2 = 0, ch3 = 0, ch4 = 0, ch5 = 0, ch6 = 0;



    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if ((Session["Role"].ToString() != "2") && (Session["Role"].ToString() != "7") && (Session["Role"].ToString() != "14") && (Session["Role"].ToString() != "10"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            int CurrentYear = System.DateTime.Now.Year;
            LblMsg2.Visible = false;
            PopulateDDL popddl = new PopulateDDL();

            popddl.Popualate(Esession, "ExamSession", "select distinct ExamSession,substring(ExamSession,2,1),substring(ExamSession,9,4) from EXAM order by substring(ExamSession,9,4)desc,substring(ExamSession,2,1) desc", "ExamSession", "ExamSession");
                      
          

        }


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        

        OptEntryAdmListView.DataSource = null;
        OptEntryAdmListView.DataBind();
        LblMsg2.Visible = false;
        Button2.Visible = false;

        if (Esession.SelectedValue == "")
        {
            string script = "alert(\"Please select Exam Session !\");";
            ScriptManager.RegisterStartupScript(this, GetType(),
                                  "ServerControlScript", script, true);
        }
        else if (ch1 == 1 && ch2 == 1)
        {
            string script = "alert(\"Please select ONLY ''Program'' OR ''Branch'' !\");";
            ScriptManager.RegisterStartupScript(this, GetType(),
                                  "ServerControlScript", script, true);

        }
        else if(ch2==0 && ch5==1)
        {
            string script = "alert(\"Please select Branch !\");";
            ScriptManager.RegisterStartupScript(this, GetType(),
                                  "ServerControlScript", script, true);
        
        }

        else
        {
            BindGrid();
            Button2.Visible = true;
        }
    }
    protected void OptEntryAdmListView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        // handle for next page
        OptEntryAdmListView.PageIndex = e.NewPageIndex;

        BindGrid();
    }

    protected void BindGrid()
    {
        try
        {
            LblMsg2.Visible = false;

            string sql = "" , sql1="", sqlCount="";
            UnivService.Service1 NicService = new UnivService.Service1();
            string count = "";
            string prog = "";



            if (DropDownList1.SelectedValue == "0") //B.tech
                prog = "01,02,03,04,06,07";
            else if (DropDownList1.SelectedValue == "1")//M.Tech
                prog = "21,23,26,28,29,32";
            else if (DropDownList1.SelectedValue == "2")//B.Arch
                prog = "05";
            else if (DropDownList1.SelectedValue == "3")//MURP
                prog = "30,31";

            if (ch1 == 1)
                sql1 = "and E.streamcode in (" + prog + ") ";
                if (ch2==1)
                    sql1 += "and E.streamcode='" + DDbranch.SelectedValue + "' ";
                    if (ch5==1)
                        sql1 += "and E.streampartcode='" + DDsem.SelectedValue + "' ";
                        if (ch6==1)
                            sql1 += "and E.examtype='" + DDexamtype.SelectedValue + "' ";
                        if (ch3==1)
                            sql1 += "and R.CastCode='" + DropDownList3.SelectedValue + "' ";
                        if (ch4==1)
                            sql1 += "and E.Gender='" + DDGender.SelectedValue + "'";


                        sqlCount = "select count(distinct E.RegNo) from EXAM E inner join Stream S on E.StreamCode=S.StreamCode inner join STREAMPART SP on E.StreamPartCode=SP.StreamPartCode  inner join REGISTRATION R on E.RegNo=R.RegNo where ExamSession='" + Esession.SelectedValue + "'";
                        count = NicService.GetNewCode(sqlCount);

                        sql = "select row_number() OVER (ORDER BY R.Streamcode ASC,E.UnivRollNo ASC) AS Count,E.UnivRollno,R.AckNo,R.ApplicantName,StreamAbbr,Sp.StreamPart,E.ExamType,R.Gender,C.Category,E.ExamSession,E.EntryOptDateTime,R.DOB from EXAM E inner join Stream S on E.StreamCode=S.StreamCode inner join STREAMPART SP on E.StreamPartCode=SP.StreamPartCode  inner join REGISTRATION R on E.RegNo=R.RegNo inner join CATEGORY C on R.CastCode=C.CategoryCode" +
                              " WHERE  ExamSession='" + Esession.SelectedValue + "'";

                        if (ch1 == 1 || ch2 == 1 || ch3 == 1 || ch4 == 1 || ch5 == 1 || ch6 == 1)
                        {
                            sqlCount += sql1;
                            count = NicService.GetNewCode(sqlCount);
                            sql += sql1;

                       }
                        else
                        {

                            CBclg.Checked = false; CBbranch.Checked = false; CBcategory.Checked = false; CBGender.Checked = false; CBsem.Checked = false; CBexamtype.Checked = false;
   
                        }
      

            DataSet ds = new DataSet();
            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);

            OptEntryAdmListView.DataSource = ds;
            OptEntryAdmListView.DataBind();

            if (OptEntryAdmListView.Rows.Count.ToString() == "0")
            {
                LblMsg2.Visible = true;
                LblMsg2.Text = " No Records found...";
            }
            else
            {
                LblMsg2.Visible = true;
                LblMsg2.Text = " Total No. Of Students:" + count;
            }

        }
        catch (Exception ex)
        {
            LblMsg2.Visible = true;
            LblMsg2.Text = " Please Select Date";
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        //  string name = "'"+DDbranch.SelectedItem + "::"+ Esession.SelectedItem +"'";

        string name = "'" + Esession.SelectedItem + "'";
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename='" + name + "'.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        OptEntryAdmListView.AllowPaging = false;
        //OptEntryAdmListView.DataBind();
        BindGrid();
        OptEntryAdmListView.RenderControl(hw);
        OptEntryAdmListView.HeaderRow.Style.Add("width", "300px");
        OptEntryAdmListView.HeaderRow.Style.Add("font-size", "10px");
        OptEntryAdmListView.Style.Add("text-decoration", "none");
        OptEntryAdmListView.Style.Add("font-family", "Arial, Helvetica, sans-serif;");
        OptEntryAdmListView.Style.Add("font-size", "8px");
        StringReader sr = new StringReader(sw.ToString());
        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        htmlparser.Parse(sr);
        pdfDoc.Close();
        Response.Write(pdfDoc);
        Response.End();

    }
    public override void VerifyRenderingInServerForm(Control control)
    {


        /* Verifies that the control is rendered */
    }

    protected void CBclg_CheckedChanged(object sender, EventArgs e)
    {
        if (CBclg.Checked == true)
        {
            DropDownList1.Enabled = true;
            DropDownList1.ForeColor = System.Drawing.Color.Blue;
            ch1 = 1;
        }
        else
        {
            DropDownList1.ClearSelection();
            DropDownList1.Enabled = false;
            DropDownList1.ForeColor = System.Drawing.Color.Gray;
            ch1 = 0;
        }


    }
    protected void CBbranch_CheckedChanged(object sender, EventArgs e)
    {
        if (CBbranch.Checked == true)
        {
            DDbranch.Enabled = true;
            DDbranch.ForeColor = System.Drawing.Color.Blue;
            ch2 = 1;
        }
        else
        {
            DDbranch.ClearSelection();
            DDbranch.Enabled = false;
            DDbranch.ForeColor = System.Drawing.Color.Gray;
            ch2 = 0;
        }
    }

    protected void CBsem_CheckedChanged(object sender, EventArgs e)
    {
        if (CBsem.Checked == true)
        {
            if (CBbranch.Checked == false)
            {
                string script = "alert(\"Please select Branch !\");";
                ScriptManager.RegisterStartupScript(this, GetType(),
                                      "ServerControlScript", script, true);
            }
           
                DDsem.Enabled = true;
                DDsem.ForeColor = System.Drawing.Color.Blue;
                ch5 = 1;
            
        }
        else
        {
            DDsem.ClearSelection();
            DDsem.Enabled = false;
            DDsem.ForeColor = System.Drawing.Color.Gray;
            ch5 = 0;
        }
    }

    protected void CBexamtype_CheckedChanged(object sender, EventArgs e)
    {
        if (CBexamtype.Checked == true)
        {
            DDexamtype.Enabled = true;
            DDexamtype.ForeColor = System.Drawing.Color.Blue;
            ch6 = 1;
        }
        else
        {
            DDexamtype.ClearSelection();
            DDexamtype.Enabled = false;
            DDexamtype.ForeColor = System.Drawing.Color.Gray;
            ch6 = 0;
        }
    }

    protected void CBcategory_CheckedChanged(object sender, EventArgs e)
    {
        if (CBcategory.Checked == true)
        {
            DropDownList3.Enabled = true;
            DropDownList3.ForeColor = System.Drawing.Color.Blue;
            ch3 = 1;
        }
        else
        {
            DropDownList3.ClearSelection();
            DropDownList3.Enabled = false;
            DropDownList3.ForeColor = System.Drawing.Color.Gray;

            ch3 = 0;
        }
    }
    protected void CBGender_CheckedChanged(object sender, EventArgs e)
    {
        if (CBGender.Checked == true)
        {
            DDGender.Enabled = true;
            DDGender.ForeColor = System.Drawing.Color.Blue;
            ch4 = 1;
        }
        else
        {
            DDGender.ClearSelection();
            DDGender.Enabled = false;
            DDGender.ForeColor = System.Drawing.Color.Gray;
            ch4 = 0;
            DDGender.SelectedValue = "";
        }
    }


    protected void DDbranch_changed(object sender, EventArgs e)
    {
        if (Esession.SelectedValue == "")
        {
            string script = "alert(\"Please select Exam Session !\");";
            ScriptManager.RegisterStartupScript(this, GetType(),
                                  "ServerControlScript", script, true);
        }
        else
        {
            DDsem.Items.Clear();
            DDsem.Items.Add("--select--");
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(DDsem, "StreamPart", "SELECT DISTINCT StreamPart,S.StreamPartCode FROM STREAMPART S inner join EXAM E on S.StreamPartCode=E.StreamPartCode where ExamSession='" + Esession.SelectedValue + "' and S.StreamCode='" + DDbranch.SelectedValue + "'  ORDER BY S.StreamPart", "StreamPart", "StreamPartCode");

            
        }
    }


    protected void Esession_changed(object sender, EventArgs e)
    {
        CBbranch.Enabled = true;
        CBcategory.Enabled = true;
        CBclg.Enabled = true;
        CBexamtype.Enabled = true;
        CBGender.Enabled = true;
        CBsem.Enabled = true;

        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(DDexamtype, "ExamType", "select distinct ExamType from Exam where ExamSession='" + Esession.SelectedValue + "' order by examtype desc", "ExamType", "ExamType");

        CBclg.Checked = false; CBbranch.Checked = false;
        CBsem.Checked = false;
        CBexamtype.Checked = false;
        CBcategory.Checked = false;
        CBGender.Checked = false;
        
        ch1 = 0; ch2 = 0; ch3 = 0; ch4 = 0; ch5 = 0; ch6 = 0;

        if (DDbranch.SelectedValue != "")
        {
            DDsem.Items.Clear();
            DDsem.Items.Add("--select--");
            popddl.Popualate(DDsem, "StreamPart", "SELECT DISTINCT StreamPart,S.StreamPartCode FROM STREAMPART S inner join EXAM E on S.StreamPartCode=E.StreamPartCode where ExamSession='" + Esession.SelectedValue + "' and S.StreamCode='" + DDbranch.SelectedValue + "'  ORDER BY S.StreamPart", "StreamPart", "StreamPartCode");
  
        }

    }
}
