using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class ViewUnivRollNoDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() == "")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CastCode, "Category", "Select Category,CategoryCode from Category order by Category", "Category", "CategoryCode");
            popddl.Popualate(ReligionCode, "Religion", "Select * from Religion order by ReligionCode", "Religion", "ReligionCode");
            popddl.Popualate(PresentDistrictCode, "District", "Select DistName,DistCode from District order by DistName", "DistName", "DistCode");
           // popddl.Popualate(CmbYear,"Year", "Select Year from Year where year >'2007' order by Year", "Year", "Year");

            //popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            //popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            //popddl.Popualate(Year1, "Year", "Select Year from Year order by Year", "Year", "Year");
            //popddl.Popualate(Year2, "Year", "Select Year from Year order by Year", "Year", "Year");
            //popddl.Popualate(ExamCode1, "ExamName", "Select ExamName, ExamCode from ExamName order by ExamName", "ExamName", "ExamCode");
            //popddl.Popualate(UnivCode1, "University", "Select UnivName,UnivCode from University order by UnivName", "UnivName", "UnivCode");
            UnivRollNo.Focus();
        }
    }


    protected void BtnUnivDetails_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

        cmd.Connection = con;
        //cmd.CommandText = "select RegNo,CollCode,PresentAddress1,PresentAddress2,PresentDistrictCode,PresentPinCode," +
        //"ExamFeeAmt,ExamYear,SCBNo,SCBDate,StreamCode,StreamPartCode, SubCode  from Exam where UnivRollno='" + UnivRollNo.Text.Trim() + "'"; 
        
        cmd.CommandText=" SELECT EXAM.UnivRollNo, EXAM.CollCode, EXAM.ExamYear, EXAM.StreamCode, EXAM.StreamPartCode, EXAM.PresentAddress1, EXAM.PresentAddress2, "+
                        " EXAM.PresentDistrictCode, EXAM.PresentPinCode, EXAM.ExamFeeAmt, EXAM.SCBNo, EXAM.SCBDate, REGISTRATION.ApplicantName, "+
                        " REGISTRATION.AckNO,REGISTRATION.HindiName, REGISTRATION.FatherName, REGISTRATION.MotherName, REGISTRATION.DOB, REGISTRATION.ReligionCode,  " +
                        " REGISTRATION.Gender, REGISTRATION.CastCode FROM EXAM INNER JOIN "+
                        " REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo where  UnivRollno='" + UnivRollNo.Text.Trim() + "'";



        SqlDataReader reader;
        con.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            Panel2.Visible = true;
            LblMsg.Text = "";
            reader.Read();
            ApplicantName.Text = reader["ApplicantName"].ToString();
            HindiName.Text = reader["HindiName"].ToString();
            FatherName.Text = reader["FatherName"].ToString();
            MotherName.Text = reader["MotherName"].ToString();
            CastCode.SelectedValue = reader["CastCode"].ToString();
            DOB.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["DOB"]));
            ReligionCode.SelectedValue = reader["ReligionCode"].ToString();
            if (reader["Gender"].ToString() == "M")
                GenderM.Checked = true;
            else
                GenderF.Checked = true;
            PresentAddress1.Text = reader["PresentAddress1"].ToString();
            PresentAddress2.Text = reader["PresentAddress2"].ToString();
            PresentDistrictCode.SelectedValue = reader["PresentDistrictCode"].ToString();
            PresentPinCode.Text = reader["PresentPinCode"].ToString();
            SCBNo.Text = reader["SCBNo"].ToString();
            SCBDate.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["SCBDate"]));
            ExamFeeAmt.Text = reader["ExamFeeAmt"].ToString();
            ExamYear.Text = reader["ExamYear"].ToString();


            //PHOTO # Begin Region
            ImageUpload imgUpload = new ImageUpload();
            string strFileName = imgUpload.Image_Load(reader["AckNo"].ToString());

            if (strFileName.ToString().Contains("temp"))
            {

                string photo = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/temp.jpg";
                string strRightNow = "";
                string IUrl = "";

                strRightNow = System.DateTime.Now.ToString("ddMMyyyyHHmmss");
                IUrl = photo + "?img=" + strRightNow;

                Image1.ImageUrl = IUrl;
                Image1.DataBind();


            }
            else if (strFileName.ToString().Contains("UploadPhoto"))
            {

                Image1.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadPhoto.JPG";
                Image1.DataBind();

            }

            else
            {
                LblMsg.Text = "Error" + strFileName;
               
            }
            //PHOTO # End Region


        }
        else
        {
            LblMsg.Text = " Please check University Roll No.";
            Panel2.Visible = false;
            UnivRollNo.Focus();
        }


    }
}
