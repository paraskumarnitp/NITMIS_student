using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class SeatDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {


            if (!Page.IsPostBack)
            {

                if (Session["Role"].ToString() != "1")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }

                PopulateDDL popddl = new PopulateDDL();
                popddl.Popualate(UnivCode, "University", "Select UnivCode,UnivName from University order by UnivName", "UnivName", "UnivCode");
                popddl.Popualate(StreamCode, "Stream", "Select StreamCode,StreamAbbr from Stream order by Stream", "StreamAbbr", "StreamCode");
                ViewState.Add("EditMode", "false");
                CollCode.Focus();



            }
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message.ToString();
        }

    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {
        string abc = "";
        Panel2.Visible = false;
        if (ViewState["EditMode"].ToString() == "false")
        {
            string[] col = new string[6];
            string[] val = new string[6];
            col[0] = "UnivCode";    val[0] = UnivCode.SelectedValue;
            col[1] = "CollCode";    val[1] = CollCode.SelectedValue;
            col[2] = "StreamCode";  val[2] = StreamCode.SelectedValue;
            col[3] = "NoOfSeats";   val[3] = NoOfSeats.Text.ToString();
            col[4] = "AllotedYear"; val[4] = AllotedYear.Text.Trim();
            col[5] = "SubCode";     val[5] = SubCode.SelectedValue;


            UnivService.Service1 ss = new UnivService.Service1();
            
            abc = ss.SaveData("SeatAllocation", col, val);

            if (abc == "1")
            {
                LblMsg.Text = " Record is saved successfully" ;
                string popupScript = "<script language='javascript'>" +
                                " alert('Record is saved successfully')" +
                                 "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);


                NoOfSeats.Text = "";
                AllotedYear.Text = "";
                StreamCode.Focus();

            }
            else
            {
                LblMsg.Text = abc.ToString();
            }
        }
        else
        {



            UnivService.Service1 ss = new UnivService.Service1();
            abc = " update SEATALLOCATION set NoOfSeats='" + NoOfSeats.Text +"',AllotedYear='" + AllotedYear.Text +"' where UnivCode='" + SeatView.SelectedRow.Cells[1].Text + "' and CollCode='" + SeatView.SelectedRow.Cells[2].Text + "' and StreamCode='" + SeatView.SelectedRow.Cells[3].Text + "' and subcode='" + SubCode.SelectedValue+ "' ";


            abc = ss.UpdateData(abc);
            if (abc.ToString() == "ok")
            {
                ViewState.Add("EditMode", "false");
                LblMsg.Text = " Record is updated successfully.";
                UnivCode.Enabled = true;
                CollCode.Enabled = true;
                StreamCode.Enabled = true;
                SubCode.Enabled = true;

                NoOfSeats.Text = "";
                AllotedYear.Text = "";
                StreamCode.Focus();

            }
            else
                LblMsg.Text = abc.ToString();

        }
    }
   
    protected void UnivCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(CollCode, "College", "Select CollCode,CollName from College where collcode<>'0' and UnivCode='"+ UnivCode.SelectedValue + "'  order by CollName ", "CollName", "CollCode");
        CollCode.Focus();
    }
    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        Panel2.Visible = true;
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select UnivCode,CollCode,StreamCode,Subcode,NoOfSeats,AllotedYear from SeatAllocation order by UnivCode");
        SeatView.DataSource = ds;
        SeatView.DataBind(); 
    }
    protected void SeatView_SelectedIndexChanged(object sender, EventArgs e)
    {
        UnivCode.Enabled = false;
        CollCode.Enabled = false;
        StreamCode.Enabled = false;
        SubCode.Enabled = false;

        try
        {

            UnivCode.SelectedValue = SeatView.SelectedRow.Cells[1].Text.Trim();
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CollCode, "College", "Select CollCode,CollName from College where collcode<>'0' and UnivCode='" + UnivCode.SelectedValue + "'  order by CollName ", "CollName", "CollCode");
            CollCode.SelectedValue = SeatView.SelectedRow.Cells[2].Text.Trim();
            StreamCode.SelectedValue = SeatView.SelectedRow.Cells[3].Text.Trim();
            popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
            SubCode.SelectedValue = SeatView.SelectedRow.Cells[4].Text.Trim();

            NoOfSeats.Text = SeatView.SelectedRow.Cells[5].Text.Trim();
            AllotedYear.Text = SeatView.SelectedRow.Cells[6].Text.Trim();

            ViewState.Add("EditMode", "true");
            SubCode.Focus();
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message.ToString();
         }
    }

    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
         popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
         SubCode.Focus();

    }
  
}
