using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class MapOldCode2010 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "5")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }


            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        }
    }

    protected void MapOldCode_Click(object sender, EventArgs e)
    {
        
            SqlConnection con = new SqlConnection();
            SqlDataReader rd;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;

            cmd.CommandText = "select distinct RegNo from ExamPaperDetail where StreamPartCode='" + StreamPart.SelectedValue + "'";
            con.Open();
            rd = cmd.ExecuteReader();

            string ackNo = "";
            string oUnivRollNo = "";
            string upd;
            int TotCount = 0;
            while (rd.Read())
            {
                UnivService.Service1 NicService = new UnivService.Service1();
                ackNo = NicService.GetNewCode("Select ackno from Registration where regno='" + rd["regno"].ToString() + "'");
                oUnivRollNo = NicService.GetNewCode("Select oUnivRollNo from Regbackdetails where ackno='" + ackNo + "'");
                upd = NicService.GetNewCode("update ExamPaperDetail set compcode='" + oUnivRollNo + "' where regno='" + rd["regno"].ToString() + "'");

                //if(upd!= "error")
                TotCount++;
            }

            
            LblTot.Text = TotCount + " Records Updated";
       

    }




    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        StreamCode.Focus();  
    }
}
