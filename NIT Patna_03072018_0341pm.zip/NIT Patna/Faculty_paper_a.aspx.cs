using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Faculty_paper_a : System.Web.UI.Page
{
    Functionreviseed fn = new Functionreviseed();
    PopulateDDL popddl = new PopulateDDL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "2" && Session["Role"].ToString() != "7" && (Session["Role"].ToString() != "14"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
                popddl.Popualate(ddlfaculty, "Login", "select UserName+'-'+Designation AS UserName,RTRIM(UserId) as UserId from LogIn where IsLock='N' and (Userrole='9' or Userrole='13' or Userrole='14' or Userrole='15' ) order by UserName", "UserName", "UserId");
                ddlfaculty.Items.Insert(0, new ListItem("--Select--", "00"));
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            binddata();
            
        }

    }
    protected void binddata()
    {
        
        lblpapername.Text = "";
        lblmsg.Text="";
        isactive.Text = "Y";
        isactive.Enabled = false;
        Semester.Items.Clear();
        ddlpaper.Items.Clear();
        PaperType.Items.Clear();
        splcode.Items.Clear();
        //popddl.Popualate(examsession, "EXAM", "select top(1) examsession from EXAM order by  CAST(SUBSTRING(ExamSession,5,3)+ ExamYear AS DATETIME) desc", "EXAMSESSION", "EXAMSESSION");//Manish-06092014
        popddl.Popualate(examsession, "EXAM", "select  Distinct TOP(6) examsession,SUBSTRING(ExamSession,9,4) from EXAM order by SUBSTRING(ExamSession,9,4) desc", "EXAMSESSION", "EXAMSESSION");         
        examsession.Items.Insert(0, new ListItem("--Select--", "00"));//Manish-06092014
        popddl.Popualate(StreamCode, "Stream", "select StreamAbbr,StreamCode from STREAM", "StreamAbbr", "StreamCode");
        Semester.Items.Insert(0, new ListItem("--Select--", "00"));
        ddlpaper.Items.Insert(0, new ListItem("--Select--", "00"));
        PaperType.Items.Insert(0, new ListItem("--Select--", "00"));
        splcode.Items.Insert(0, new ListItem("--Select--", "00"));
        
        bindgrid();
    
    }
    protected void bindgrid()
    {
        string str = "SELECT LogIn.UserName, Faculty_paper_a.UserId,stream.StreamAbbr as Program, Faculty_paper_a.SplCode,d.SpDescription as Specialization, COURSEPAPERS.PaperAbbr, Faculty_paper_a.SubPaperCode, Faculty_paper_a.Is_Active, CONVERT(VARCHAR(11), Faculty_paper_a.EntryDt, 106) " +
                     " AS EntryDate, CASE WHEN Faculty_paper_a.PaperType IS NULL THEN 'All' ELSE Faculty_paper_a.PaperType END AS PaperType, Faculty_paper_a.ExamSession  FROM " + 
                     " Faculty_paper_a INNER JOIN LogIn ON Faculty_paper_a.UserId = LogIn.UserId INNER JOIN COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN STREAM ON " +
                     " COURSEPAPERS.StreamCode = STREAM.StreamCode INNER JOIN COURSESPECIALIZATION D ON D.SPCode=Faculty_paper_a.Splcode WHERE (Faculty_paper_a.ExamSession IS NOT NULL) AND (Faculty_paper_a.ExamSession = '" + examsession.SelectedValue + "')";
        DataTable dt = fn.SelectDatatable(str);
        grdfacupap.DataSource = dt;
        grdfacupap.DataBind();
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        bindsemester(StreamCode.SelectedValue);
    }
    
    protected void BtnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (isactive.SelectedValue == "Y" && ddlpaper.SelectedIndex>0 && ddlfaculty.SelectedIndex>0)
            {
                string check = "SELECT     SUM( CASE WHEN (PaperType = 'P' OR PaperType = 'T') THEN 1 WHEN PaperType IS NULL THEN 2 ELSE 0 END) as count "+
                                " FROM         Faculty_paper_a where Is_Active='Y'  and SubPaperCode=  '" + ddlpaper.SelectedValue + "' and splcode='" + splcode.SelectedValue + "' and ExamSession = '"+examsession.SelectedValue.ToString()+"'";
              
                object count = fn.singlevalue(check);
                if (count.ToString() != "")
                    {
                        if ((int)count >= 2)
                        {
                            lblmsg.Text = "Another User already active for this Course paper";
                            return;
                        }
                    }
                
            }
            else
            { lblmsg.Text = "Field cannt be entry as inactive"; return; }

            string str = "INSERT INTO Faculty_paper_a (UserId, SubPaperCode, Is_Active,PaperType,splcode,examsession) VALUES ( ";
            str += "'" + ddlfaculty.SelectedValue + "','" + ddlpaper.SelectedValue + "','" + isactive.SelectedValue + "', @paper, '"+splcode.SelectedValue+"','"+examsession.SelectedItem.ToString()+"')";
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ToString());
            int i=0;
            try
            {
               
                con.Open();
                SqlCommand cmd = new SqlCommand(str, con);
                if (PaperType.SelectedValue=="00")
                cmd.Parameters.Add("@paper", SqlDbType.Char, 1).Value = DBNull.Value;
                else
                cmd.Parameters.Add("@paper", SqlDbType.Char, 1).Value = PaperType.SelectedValue;

               i = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627)
                {
                   i = -1000;
                }
            }
            finally
            {
                con.Close();
            }
           
         
            if (i > 0)
                lblmsg.Text = "Successfully Updated !!!";
            ddlfaculty.SelectedIndex = 0;
            ddlpaper.SelectedIndex = 0;
            Semester.SelectedIndex = 0;
            bindgrid();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.Message;
        }
    }
  
  
    protected void grdfacupap_SelectedIndexChanged(object sender, EventArgs e)
    {
        int i = grdfacupap.SelectedIndex;

        ddlfaculty.ClearSelection();
        ddlfaculty.Text = grdfacupap.Rows[i].Cells[2].Text;
        ddlfaculty.Enabled = false;
        string str = "select StreamCode,StreamPartCode from COURSEPAPERS where SubPaperCode='"+grdfacupap.Rows[i].Cells[7].Text+"'";
        DataTable dt = fn.SelectDatatable(str);
        StreamCode.Text = dt.Rows[0]["StreamCode"].ToString();
        StreamCode.Enabled = false;
        bindsemester(dt.Rows[0]["StreamCode"].ToString());
        Semester.Text=(dt.Rows[0]["StreamPartCode"].ToString());
        Semester.Enabled = false;
        bindpaperassign();
        ddlpaper.Text = grdfacupap.Rows[i].Cells[7].Text;
        ddlpaper.Enabled = false;
        isactive.Text = grdfacupap.Rows[i].Cells[8].Text;
        PaperType.Items.Clear();
        PaperType.Items.Add(grdfacupap.Rows[i].Cells[10].Text);
        PaperType.Enabled = false;
        splcode.SelectedValue = grdfacupap.Rows[i].Cells[4].Text;
        splcode.Enabled = false;
        BtnSave.Visible = false;
        Btnupdate.Visible = true;
        isactive.Enabled = true;

    }
    protected void bindsemester(string sem)
    {
        //PopulateDDL popddl = new PopulateDDL();
        Semester.Items.Clear();
        ddlpaper.Items.Clear();
        PaperType.Items.Clear();
        splcode.Items.Clear();
        popddl.Popualate(splcode, "specializtion", "SELECT COALESCE (CourseSpecialization.SPCode, '00') AS SPCode, COALESCE (CourseSpecialization.SpDescription, 'NA') AS SpDescription " + 
                " FROM CourseSpecialization INNER JOIN Stream_Specialization ON CourseSpecialization.SPCode = Stream_Specialization.SplCode RIGHT OUTER JOIN STREAM ON " + 
                " Stream_Specialization.StreamCode = STREAM.StreamCode WHERE (STREAM.StreamCode = '" + sem + "')", "SpDescription", "SPCode");
       /* popddl.Popualate(splcode, "specializtion", "SELECT COALESCE (CourseSpecialization.SPCode, '00') AS SPCode, COALESCE (CourseSpecialization.SpDescription, 'NA') AS SpDescription " +
                                    " FROM  CourseSpecialization RIGHT OUTER JOIN STREAM ON CourseSpecialization.StreamCode = STREAM.StreamCode WHERE     (STREAM.StreamCode = '" + sem + "') ", "SpDescription", "SPCode"); */
        popddl.Popualate(Semester, "Streampart", "select streampart.StreamPart,STREAMPART.StreamPartCode from STREAMPART where StreamCode='" + sem + "' ", "StreamPart", "StreamPartCode");
        Semester.Items.Insert(0, new ListItem("--Select--", "00"));
        ddlpaper.Items.Insert(0, new ListItem("--Select--", "00"));
        PaperType.Items.Insert(0, new ListItem("--Select--", "00"));
        lblpapername.Text = "";
    
    }
    protected void bindpaper(string stream,string semester)
    {
        string str = "";
        //PopulateDDL popddl = new PopulateDDL();
        ddlpaper.Items.Clear();
        if (examsession.SelectedItem.ToString().IndexOf("SMR") != -1) //Manish-06092014
        {
            if (splcode.SelectedValue.ToString() == "00")
            {
                str = "SELECT DISTINCT COURSEPAPERS.PaperAbbr,COURSEPAPERS.SubPaperCode FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS " +
                    " ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode LEFT OUTER JOIN Stream_Specialization ON " +
                    " COURSEPAPERS.StreamCode = Stream_Specialization.StreamCode WHERE EXAMPAPERDETAIL.ExamSession = '" + examsession.SelectedItem.ToString() + "' AND " + 
                    " EXAMPAPERDETAIL.StreamPartCode = '" + Semester.SelectedValue + "' AND COURSEPAPERS.StreamCode = '" + StreamCode.SelectedValue + "'";
            }
            else
            {
                str = "SELECT  DISTINCT  COURSEPAPERS.PaperAbbr, COURSEPAPERS.SubPaperCode FROM EXAMPAPERDETAIL INNER JOIN " +
                      " COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN Stream_Specialization " +
                      " ON COURSEPAPERS.StreamCode = Stream_Specialization.StreamCode WHERE EXAMPAPERDETAIL.ExamSession = '" + examsession.SelectedItem.ToString() + "' " +
                      " AND EXAMPAPERDETAIL.StreamPartCode = '" + Semester.SelectedValue + "' AND COURSEPAPERS.StreamCode = '" + StreamCode.SelectedValue + "' " +
                      " AND Stream_Specialization.SPlCode = '" + splcode.SelectedValue + "'";
            }
            popddl.Popualate(ddlpaper, "EXAMPAPERDETAIL", str, "PaperAbbr", "SubPaperCode");
        }
        else
        {
            str = " select distinct PaperAbbr as COURSECODE,a.SubPaperCode from EXAMPAPERDETAIL a "+
                 " inner join COURSEPAPERS b on a.SubPaperCode=b.SubPaperCode  "+
                 " where a.streampartcode='" + Semester.SelectedValue + "' and  a.SubPaperCode not in (SELECT     SubPaperCode FROM         Faculty_paper_a where Is_Active='Y' and splcode='" + splcode.SelectedValue + "'  and ExamSession='" + examsession.SelectedItem.ToString() + "' GROUP BY SubPaperCode having SUM( CASE WHEN (PaperType = 'P' OR " +
                          " PaperType = 'T') THEN 1 WHEN PaperType IS NULL THEN 2 ELSE 0 END)>=2) and a.ExamSession='" + examsession.SelectedItem.ToString() + "'";
            popddl.Popualate(ddlpaper, "Assigncoursepaper", str, "COURSECODE", "SubPaperCode");
        }   //
        

        ddlpaper.Items.Insert(0, new ListItem("--Select--", "00"));
        lblpapername.Text = "";
    
    }


    protected void bindpaperassign()
    {
        //PopulateDDL popddl = new PopulateDDL();
        string str = " SELECT      COURSEPAPERS.PaperAbbr,Faculty_paper_a.SubPaperCode "+
                        " FROM         COURSEPAPERS INNER JOIN Faculty_paper_a "+
                        " ON COURSEPAPERS.SubPaperCode = Faculty_paper_a.SubPaperCode";
        popddl.Popualate(ddlpaper, "Assigncoursepaper", str, "PaperAbbr", "SubPaperCode");
        lblpapername.Text = "";
    
    }


    protected void Semester_SelectedIdexChanged(object sender, EventArgs e)
    {
        bindpaper(StreamCode.SelectedItem.ToString(),Semester.SelectedItem.ToString());
    }

    protected void Btnnew_Click(object sender, EventArgs e)
    {
        binddata();
        StreamCode.Enabled = true;
        Semester.Enabled = true;
        ddlpaper.Enabled = true;
        ddlfaculty.Enabled = true;
        PaperType.Enabled = true;
        BtnSave.Visible = true;
        Btnupdate.Visible = false;
        txtcourse.Text = "";
        lblmsg.Text = "";
    }
    protected void Btnupdate_Click(object sender, EventArgs e)
    {
        try
        {
            string str = "UPDATE    Faculty_paper_a SET ";


            if (isactive.SelectedValue == "Y")
            {
                string check = "select * from Faculty_paper_a where SubPaperCode='" + grdfacupap.SelectedRow.Cells[4].Text + "' and examsession='"+ grdfacupap.SelectedRow.Cells[8].Text+"' and Is_Active='Y'";
                DataTable dt = fn.SelectDatatable(check);
                if (dt.Rows.Count > 0)
                {
                    lblmsg.Text = "Another User already active for this Course paper";
                    return;
                }
            }

            str += " Is_Active = '" + isactive.SelectedValue + "',EntryDt = '" + DateTime.Now.ToString("MM/dd/yyyy") + "' where Faculty_paper_a.UserId ='" + ddlfaculty.SelectedValue + "' and  Faculty_paper_a.SubPaperCode='" + ddlpaper.SelectedValue + "' and Faculty_paper_a.examsession='"+ grdfacupap.SelectedRow.Cells[11].Text+"'";
            int i = fn.InsertUpdateDelete(str);
            if (i > 0)
                lblmsg.Text = "Successfully Updated !!!";
            bindgrid();
            //+ string.Format("{0:MM/dd/yyyy }", Convert.ToDateTime(DateTime.Now.ToString()))+
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.Message;
        }
    }
    protected void ddlpaper_SelectedIndexChanged(object sender, EventArgs e)
    {
        string str = "select PaperName from COURSEPAPERS where SubPaperCode='"+ddlpaper.SelectedValue+"'";
        string papername = (string)fn.singlevalue(str);
        lblpapername.Text = papername;
        PaperType.Items.Clear();

        str = "select Papertypes from (select 'P' as practical,'T' as Theory from COURSEPAPERS where PaperTypeCode='04' "+
            " and SubPaperCode='" + ddlpaper.SelectedValue + "' )p unpivot   (Papertypes FOR CourseCode IN (practical,Theory) )AS unpvt except  " +
            " select PaperType from Faculty_paper_a where SubPaperCode='" + ddlpaper.SelectedValue + "' and Is_Active='Y' and splcode='"+ splcode.SelectedValue +"' and examsession='"+examsession.SelectedItem.ToString()+"'";
        DataTable dt = fn.SelectDatatable(str);
        PaperType.DataSource = dt;
        PaperType.DataTextField = "Papertypes";
        PaperType.DataValueField = "Papertypes";

        PaperType.DataBind();
        if (dt.Rows.Count==0 || dt.Rows.Count>1)
            PaperType.Items.Insert(0, new ListItem("Select All", "00")); 


    }


    protected void examsession_SelectedIndexChanged(object sender, EventArgs e)
    {
        bindgrid();
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        if (examsession.SelectedValue == "00")
        {
            lblmsg.Text = "Select Examsession First";
            return;
        }
        string str = "SELECT LogIn.UserName, Faculty_paper_a.UserId,stream.StreamAbbr as Program, Faculty_paper_a.SplCode,d.SpDescription as Specialization, COURSEPAPERS.PaperAbbr, Faculty_paper_a.SubPaperCode, Faculty_paper_a.Is_Active, CONVERT(VARCHAR(11), Faculty_paper_a.EntryDt, 106) " +
                     " AS EntryDate, CASE WHEN Faculty_paper_a.PaperType IS NULL THEN 'All' ELSE Faculty_paper_a.PaperType END AS PaperType, Faculty_paper_a.ExamSession  FROM " +
                     " Faculty_paper_a INNER JOIN LogIn ON Faculty_paper_a.UserId = LogIn.UserId INNER JOIN COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN STREAM ON " +
                     " COURSEPAPERS.StreamCode = STREAM.StreamCode INNER JOIN COURSESPECIALIZATION D ON D.SPCode=Faculty_paper_a.Splcode WHERE (Faculty_paper_a.ExamSession IS NOT NULL) AND (Faculty_paper_a.ExamSession = '" + examsession.SelectedValue + "') AND (COURSEPAPERS.PaperAbbr = '" + txtcourse.Text.Trim() + "')";
        DataTable dt = fn.SelectDatatable(str);
        grdfacupap.DataSource = dt;
        grdfacupap.DataBind();
        lblmsg.Text = "";
    }
    protected void btnsearchreset_Click(object sender, EventArgs e)
    {
        txtcourse.Text = ""; lblmsg.Text = "";
        bindgrid();
    }
}
