using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Net;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
      
            txt_username.Focus();
           
         
    }

    protected void BtnNext_Click(object sender, EventArgs e)
    {
        UnivService.Service1 NicService = new UnivService.Service1();

        string sql = "";

        if (txt_username.Text != "")
        {

            sql = "SELECT Password from LOGIN where UserId='" + txt_username.Text + "'";
            string P = NicService.GetNewCode(sql);

            if (P == "error" || P == "")
            {
                LblMsg.Text = "_________Sorry, Invalid Username !_________";
                
                LblMsg.BackColor = System.Drawing.Color.Maroon;
                LblMsg.ForeColor = System.Drawing.Color.White;
                // Session["userName"] = null;
                //FormsAuthentication.SignOut();
                //Response.Redirect("default.aspx");
                //return;
            }
            else
            {
                LblMsg.Text = "";
                txt_username.ReadOnly = true;
                lblpwd.Visible = true;
                txt_password.Visible = true;
                btnSubmitLogin.Visible = true;
                BtnNext.Visible = false;
                txt_password.Text = "Password";
                ResetData.Visible = true;
                txt_username.ForeColor = System.Drawing.Color.Gray;
                txt_username.BackColor = System.Drawing.Color.LightGray;
                txt_password.Focus();

            }
        }
        else
        {
            LblMsg.Text = "";
        }
        


    }
    protected void btnSubmitLogin_Click(object sender, EventArgs e)
    {
        string strsql = "Select Password From LOGIN Where UserId=@UserId";
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        // string str = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
        SqlCommand cmd = new SqlCommand(strsql, conn);
        
        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Char, 8)).Value = txt_username.Text;

        ViewState["tempuser"] = txt_username.Text;
        //string aa = enc.EncryptPassword(Password.Text.ToString());
        //Response.Write(aa);
        bool authorised = false;
        bool temptable = true;
        try
        {
            conn.Open();
            string pwd = ((string)cmd.ExecuteScalar()).Trim();
            Encryption enc = new Encryption();

            //05 dec
            if (txt_password.Text.ToString() == "")
            {

                LblMsg.Text = "__________Please, Enter Password !_________";

                LblMsg.BackColor = System.Drawing.Color.Maroon;
                LblMsg.ForeColor = System.Drawing.Color.White;
            }
            else if (pwd != enc.EncryptPassword(txt_password.Text.ToString()))
              {

                LblMsg.Text = "__________Sorry, Invalid Password !_________";

                LblMsg.BackColor = System.Drawing.Color.Maroon;
                LblMsg.ForeColor = System.Drawing.Color.White;
              }
            else
            {
                strsql = "Select HighSecurity From Login Where userId='" + txt_username.Text + "'";
                cmd.CommandText = strsql;
                string AppAuthentication = (cmd.ExecuteScalar().ToString());


                //strsql = "Select count(*) From UserLogTime Where LoginId='"+ UserID.Text  +"' and online='Y'";
                strsql = "Select Islock From Login Where userId='" + txt_username.Text + "'";
                cmd.CommandText = strsql;
                string islock = (cmd.ExecuteScalar().ToString());
                if (islock == "Y")
                {
                    LblMsg.Text = " Your account has been locked. Please Contact to Admin";
                    return;
                }

                //if (cnt > 0)
                //{
                //    LblMsg.Text = "User is Already Login";
                //    return;
                //}
                strsql = "Select Userrole From LOGIN Where UserId=@UserId";
                cmd.CommandText = strsql;
                string Role = ((string)cmd.ExecuteScalar()).Trim();
                //shivam 

                strsql = "Select UserId from tempregister Where UserId=@UserId ";
                cmd.CommandText = strsql;
                object temp = cmd.ExecuteScalar();
                if (temp != null)
                {
                    temptable = (temp != null) ? false : true;
                }



                if (Role == "disable for all")
                {
                    string otp = DateTime.Now.ToString("ssmmfff");
                    //string otp = "954677";
                    Session.Add("otp", otp);

                    strsql = "Select ContactNo From LOGIN Where UserId=@UserId";
                    cmd.CommandText = strsql;
                    string mobno = ((string)cmd.ExecuteScalar()).Trim();
                    if (mobno == "")
                    {
                        LblMsg.Text = " Your Contact No is not available for OTP. Please Contact to Admin";
                        return;
                    }

                    string URL = "http://api.mVaayoo.com/mvaayooapi/MessageCompose?user=shivpat.1990@gmail.com:satyam&senderID=TEST SMS&receipientno=" + mobno + "&dcs=0&msgtxt=your otp for this session:" + otp + "&state=4";
                    //URL = string.Format(URL, "userName", "password", "0123456789", "9546888885", "123456");
                    System.Net.WebRequest wRequest = System.Net.WebRequest.Create(URL);
                    //wRequest.GetResponse();
                    login.Visible = false;
                    OTP.Visible = true;
                }
                else if (temptable == false)
                {
                    login.Visible = false;
                    Div3.Visible = true;
                }
                else if (AppAuthentication == "Y")
                {



                    Random random = new Random();
                    int OTP = random.Next(100000, 999999);

                    SecCode.Text = OTP.ToString(); // show the random code to be entered into app for OTP generation

                                        
                    string bCode = "";
                    //  temp = NicService.GetNewCode("select BaseCode from LogIn where UserId='" + txt_username.Text + "'");
                    strsql = "select BaseCode from LogIn where UserId='" + txt_username.Text + "'";
                    cmd.CommandText = strsql;
                    bCode = ((string)cmd.ExecuteScalar()).Trim();


                    string t1 = bCode.Substring(0, 3);  //Base Code
                    string t2 = bCode.Substring(3, 3);
                    bCode = t2 + t1;
                    if (Int32.Parse(bCode) % 2 == 0)
                    {

                        OTP = Int32.Parse(bCode) * 3 + OTP;
                        if (OTP > 999999)
                            OTP = Int32.Parse(OTP.ToString().Substring(1, 6));

                        string sql = "update LogIn set AppOTP='" + OTP + "' where UserId='" + txt_username.Text + "'";
                        UnivService.Service1 NicService = new UnivService.Service1();
                        NicService.GetNewCode(sql);

                    }
                    else
                    {

                        OTP = Int32.Parse(bCode) * 2 + OTP;
                        if (OTP > 999999)
                            OTP = Int32.Parse(OTP.ToString().Substring(1, 6));
                        string sql = "update LogIn set AppOTP='" + OTP + "' where UserId='" + txt_username.Text + "'";
                        UnivService.Service1 NicService = new UnivService.Service1();
                        NicService.GetNewCode(sql);

                    }


                    login.Visible = false;
                    AppOTP.Visible = true;




                }
                else
                {
                    strsql = "Select UnivName from Install";
                    cmd.CommandText = strsql;
                    string UnivName = ((string)cmd.ExecuteScalar()).Trim();
                    Session.Add("UnivName", UnivName);
                                       
                    strsql = "Select UserName From LOGIN Where UserId=@UserId";
                    cmd.CommandText = strsql;
                    string UserName = ((string)cmd.ExecuteScalar()).Trim();
                    Session.Add("UserName", UserName);

                    FormsAuthentication.SetAuthCookie(txt_username.Text, false);

                    //Session.Add("UserName", UserID.Text);
                    Session.Add("Role", Role);
                    authorised = true;

                    Session.Add("UserId", txt_username.Text);



                    //Session.IsNewSession;
                    //  Session.
                    //Response.Write(Session.IsNewSession.ToString()+"a<br>");
                    //Session.Add("SID", Session.SessionID.ToString());

                    // Inserting Value in User Log Time

                    UnivService.Service1 ss = new UnivService.Service1();
                    string[] col = new string[4];
                    string[] val = new string[4];

                    col[0] = "LoginId"; val[0] = txt_username.Text.ToString();
                    col[1] = "SID"; val[1] = Session.SessionID.ToString();
                    col[2] = "Online"; val[2] = "Y";
                    col[3] = "Ipadrss"; val[3] = GetIPAddress();

                    string abc = ss.SaveData("UserLogTime", col, val);
                    
                }
                                     
               }

        }
        catch (Exception exp)
        {
            LblMsg.Text = "Database error!" +
                 " Error message: " + exp.Message;
        }
        finally
        {
            cmd.Dispose();
            conn.Close();
            if (authorised)
            {
                Response.Redirect("home.aspx", false);
            }
        }
      
    }

    protected void Btnappotp_Click(object sender, EventArgs e)
    {

        bool authorised = false;

        try
        {
            SqlConnection conn = new SqlConnection();
            string strsql = "";

            SqlCommand cmd = new SqlCommand(strsql, conn);
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;


            cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Char, 6)).Value = txt_username.Text;

            ViewState["tempuser"] = txt_username.Text;

            strsql = "select AppOTP from login where UserId='" + txt_username.Text + "'";
            conn.Open();

            cmd.CommandText = strsql;
            string OTP = ((string)cmd.ExecuteScalar()).Trim();


            if (mobotp.Text == OTP)
            {
                strsql = "Select UnivName from Install";
                cmd.CommandText = strsql;
                string UnivName = ((string)cmd.ExecuteScalar()).Trim();
                Session.Add("UnivName", UnivName);

                strsql = "Select UserName From LOGIN Where UserId=@UserId";
                cmd.CommandText = strsql;
                string UserName = ((string)cmd.ExecuteScalar()).Trim();
                Session.Add("UserName", UserName);

                strsql = "Select Userrole From LOGIN Where UserId=@UserId";
                cmd.CommandText = strsql;
                string Role = ((string)cmd.ExecuteScalar()).Trim();


                if (Role == "8")
                {
                    strsql = "Select isnull(TempRollNo,'N') From Registration Where AckNo=@UserId";
                    cmd.CommandText = strsql;
                    string rollno = ((string)cmd.ExecuteScalar()).Trim();
                    if (rollno != "N")
                    {
                        Session.Add("Rollno", rollno);
                    }
                    strsql = "Select isnull(RegNo,'N') From Registration Where AckNo=@UserId";
                    cmd.CommandText = strsql;
                    string RegNo = ((string)cmd.ExecuteScalar()).Trim();
                    if (rollno != "N")
                    {
                        Session.Add("RegNo", RegNo);
                    }
                }

                FormsAuthentication.SetAuthCookie(txt_username.Text, false);

                //Session.Add("UserName", UserID.Text);
                Session.Add("Role", Role);
                authorised = true;

                Session.Add("UserId", txt_username.Text);


                UnivService.Service1 ss = new UnivService.Service1();
                string[] col = new string[3];
                string[] val = new string[3];

                col[0] = "LoginId"; val[0] = txt_username.Text.ToString();
                col[1] = "SID"; val[1] = Session.SessionID.ToString();
                col[2] = "Online"; val[2] = "Y";

                string abc = ss.SaveData("UserLogTime", col, val);

                cmd.Dispose();
                conn.Close();
            }
            else
            {
               
                LblMsg.Text = "Invalid OTP Entered. Please Try Again!!!";
            }

        }
        catch (Exception exp)
        {
            Lblmsg1.Text = "Database error!" +
                 " Error message: " + exp.Message;
        }
        finally
        {
            if (authorised)
            {
                Response.Redirect("home.aspx", false);
            }
        }
    }

    protected string GetIPAddress()
    {
        System.Web.HttpContext context = System.Web.HttpContext.Current;
        string ipAddress = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];


        if (!string.IsNullOrEmpty(ipAddress))
        {
            string[] addresses = ipAddress.Split(',');
            if (addresses.Length != 0)
            {
                return addresses[0];
            }
        }
       
        return context.Request.ServerVariables["REMOTE_ADDR"];
    }
    protected void Btnotp_Click(object sender, EventArgs e)
    { 
        
       bool authorised = false;

       try
       {
           if (txtotp.Text == Session["otp"].ToString())
           {
               SqlConnection conn = new SqlConnection();
               string strsql = "";
               string tempuser = ViewState["tempuser"].ToString();
               SqlCommand cmd = new SqlCommand(strsql, conn);
               conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
               cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Char, 5)).Value = tempuser;
               strsql = "Select UnivName from Install";

               conn.Open();

               cmd.CommandText = strsql;
               string UnivName = ((string)cmd.ExecuteScalar()).Trim();
               Session.Add("UnivName", UnivName);



               strsql = "Select Userrole From LOGIN Where UserId=@UserId";
               cmd.CommandText = strsql;
               string Role = ((string)cmd.ExecuteScalar()).Trim();

               strsql = "Select UserName From LOGIN Where UserId=@UserId";
               cmd.CommandText = strsql;
               string UserName = ((string)cmd.ExecuteScalar()).Trim();
               Session.Add("UserName", UserName);

               FormsAuthentication.SetAuthCookie(tempuser, false);

               //Session.Add("UserName", UserID.Text);
               Session.Add("Role", Role);
               authorised = true;

               Session.Add("UserId", tempuser);



               //Session.IsNewSession;
               //  Session.
               //Response.Write(Session.IsNewSession.ToString()+"a<br>");
               //Session.Add("SID", Session.SessionID.ToString());

               // Inserting Value in User Log Time

               UnivService.Service1 ss = new UnivService.Service1();
               string[] col = new string[3];
               string[] val = new string[3];

               col[0] = "LoginId"; val[0] = tempuser;
               col[1] = "SID"; val[1] = Session.SessionID.ToString();
               col[2] = "Online"; val[2] = "Y";

               string abc = ss.SaveData("UserLogTime", col, val);
               cmd.Dispose();
               conn.Close();
           }
           else
           { Lblmsg1.Text = "Incorrect OTP Entered. Please Try Again!!!"; }
          
       }
       catch (Exception exp)
       {
           Lblmsg1.Text = "Database error!" +
                " Error message: " + exp.Message;
       }
       finally
       {
           if (authorised)
           {
               Response.Redirect("home.aspx", false);
           }
       }
    }
   
    protected void chkcontactopt_CheckedChanged(object sender, EventArgs e)
    {
        if (chkcontactopt.Checked)
        {
            SqlConnection conn = new SqlConnection();
            string strsql = "";
            string tempuser = ViewState["tempuser"].ToString();
            SqlCommand cmd = new SqlCommand(strsql, conn);
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Char, 5)).Value = tempuser;


            string otp = DateTime.Now.ToString("ssmmfff");
            //string otp = "954677";
            Session["otp"] = otp;
            conn.Open();
            strsql = "Select ContactNoOpt From LOGIN Where UserId=@UserId";
            cmd.CommandText = strsql;
            string mobnoopt = ((string)cmd.ExecuteScalar()).Trim();
            if (mobnoopt == "")
            {
                LblMsg.Text = " Your Secondary Contact No is not available for OTP. Please Contact Admin";
                return;
            }

            string URL = "http://api.mVaayoo.com/mvaayooapi/MessageCompose?user=shivpat.1990@gmail.com:satyam&senderID=TEST SMS&receipientno=" + mobnoopt + "&dcs=0&msgtxt=your otp for this session:" + otp + "&state=4";
            //URL = string.Format(URL, "userName", "password", "0123456789", "9546888885", "123456");
            System.Net.WebRequest wRequest = System.Net.WebRequest.Create(URL);
            wRequest.GetResponse();
            login.Visible = false;
            OTP.Visible = true;
            Lblmsg1.Text = "Your OTP has been send to your secondary Contact No. Please Enter Your OTP No";
            cmd.Dispose();
            conn.Close();
        }
    }
    protected void btnpasschange_Click(object sender, EventArgs e)
    {
        bool authorised = false;
        try
        {
            Encryption enc = new Encryption();

            if (txtconfpass.Text != txtpass.Text)
            {
                txtconfpass.Text = "";
                txtpass.Text = "";
                txtpass.Focus();
                Label1.Text = "Please Re-Enter New Password";
                return;
            }


            string sql = "";
            //Validating Old Password
            UnivService.Service1 ss = new UnivService.Service1();



            //Setting New Password

            string abc = "";
            sql = "";



            sql = "Update LOGIN Set Password='" + enc.EncryptPassword(txtpass.Text.ToString()) + "',ContactNo='" + txtcontact.Text.Trim() + "' where UserId='" + ViewState["tempuser"].ToString() + "' ";

            abc = ss.UpdateData(sql);

            if (abc == "ok")
            {
                sql = "Delete from tempregister where UserId='" + ViewState["tempuser"].ToString() + "' ";
                abc = ss.UpdateData(sql);
                txtconfpass.Text = "";
                txtpass.Text = "";
                txtpass.Focus();
                authorised = true;
            }
            else
            {
                Label1.Text = abc.ToString();
            }


        }
        catch (Exception ex)
        {
            Label1.Text = ex.Message;
        }
        finally
        {
            if (authorised)
            {
                string msg = " Password changed successfully.Kindly Relogin with New Password";
                string popupScript = "<script language='javascript'>" +
                                   " alert('" + msg + " ')" +
                                    "</script>";
                Page.RegisterStartupScript("PopupScript", popupScript);
                login.Visible = true;
                Div3.Visible = false;


            }
        }
    }
    protected void lnkForgot_Click(object sender, EventArgs e)
    {
        password.Visible = true;
        login.Visible = false;
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection();
        string strsql = "";
        SqlCommand cmd = new SqlCommand(strsql, conn);
        conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Char, 7)).Value = txtPassReset.Text;
        conn.Open();
        strsql = "Select EmailId From Login Where UserId=@UserId";
        cmd.CommandText = strsql;
        object emailObj = cmd.ExecuteScalar();
        string email = string.Empty;
        if (emailObj == DBNull.Value)
        {
            lblMsg3.Text = "Email Id not Found. Please Contact Exam Section to Update your data";
            return;
        }
        else
        {
            email = (string)emailObj;
        }

        Guid newToken = Guid.NewGuid();
        string value = AESEncryption.Encrypt(newToken.ToString());
        string sql = "INSERT INTO ForgotToken " +
                      " (Token, UserId, Status) " +
                      " VALUES     ('" + value + "','" + txtPassReset.Text + "'," + 0 + ")";
        string abc = "";
        UnivService.Service1 ss = new UnivService.Service1();
        abc = ss.UpdateData(sql);

        if (abc == "ok")
        {
            string verificationEncode = Server.UrlEncode(value);
            string uploadUrl = string.Format("http://exam.nitp.ac.in:81/PasswordReset.aspx?Token={0}", verificationEncode);
            bool stat = EmailService.SendEmail(email, uploadUrl);
            password.Visible = false;
            login.Visible = true;
            string msg = "Reset Link has been sent to Your EmailId - " + email.ToString();
            string popupScript = "<script language='javascript'>" +
                               " alert('" + msg + " ')" +
                                "</script>";
            Page.RegisterClientScriptBlock("PopupScript", popupScript);
        }

    }

    protected void ResetData_click(object sender, EventArgs e)
    {
        Session["userName"] = null;
        FormsAuthentication.SignOut();
        Response.Redirect("default.aspx");
        return;
    }
}
