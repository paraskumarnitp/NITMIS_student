using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.Collections.Generic;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Text.RegularExpressions;

public partial class AttendanceRegister : System.Web.UI.Page
{
    ReportDocument rpt = new ReportDocument();
    Functionreviseed fn = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            try
            {

                if ((Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "9") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "15"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }

                ViewState.Add("EditMode", "false");

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }


            UnivService.Service1 NicService = new UnivService.Service1();
            int status = Convert.ToInt32(NicService.GetNewCode("select count(Enabled) from Faculty_paper_a where Userid='" + Session["userid"] + "' and Is_Active='Y'"));

            if (status <= 0)
            {

                string msg = "No Paper has been alloted to you.";
                string popupScript = "<script language='javascript'>" +
                                   " alert('" + msg + " ')" +
                                    "</script>";
                Page.RegisterClientScriptBlock("PopupScript", popupScript);
                Response.Redirect("home.aspx");
                return;
            }
            else
            {
                string strrole = "";
                if (Session["Role"].ToString() == "9")
                    strrole = " and UserId='" + Session["UserId"].ToString() + "'";

                PopulateDDL popddl = new PopulateDDL();
                popddl.Popualate(ExamYear, "Year", "select distinct ExamSession from Faculty_paper_a where is_active='Y'  order by ExamSession desc", "ExamSession", "ExamSession");
                ExamYear.Items.Insert(0, new ListItem("--Select--", "00"));
                StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
                StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
                splcode.Items.Insert(0, new ListItem("--Select--", "00"));
                Subject.Items.Insert(0, new ListItem("--Select--", "00"));
            }

        }
    }

    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        MTheory.Checked = false;
        MPrac.Checked = false;
        StreamPart.Items.Clear();
        Subject.Items.Clear();
        splcode.Items.Clear();
        string strrole = "";
        if (Session["Role"].ToString() == "9" || Session["Role"].ToString() == "13")
            strrole = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";
        PopulateDDL popddl = new PopulateDDL();
        string strspecilaization = "SELECT     CourseSpecialization.SpDescription, CourseSpecialization.SPCode " +
                                   " FROM Faculty_paper_a INNER JOIN COURSEPAPERS ON " +
                                   " Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " +
                                   " CourseSpecialization ON Faculty_paper_a.Splcode = CourseSpecialization.SPCode " +
                                   " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                                   " and COURSEPAPERS.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                                   " GROUP BY CourseSpecialization.SpDescription, CourseSpecialization.SPCode " +
                                   " order by CourseSpecialization.SPCode ";

        popddl.Popualate(splcode, "Specialization", strspecilaization, "SpDescription", "SPCode");
        string strstreampart = "SELECT     STREAMPART.StreamPart,STREAMPART.StreamPartCode " +
                             " FROM         COURSEPAPERS AS COURSEPAPERS_1 INNER JOIN " +
                             " STREAMPART ON COURSEPAPERS_1.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN " +
                             " Faculty_paper_a INNER JOIN " +
                             " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode ON COURSEPAPERS_1.PaperAbbr = COURSEPAPERS.PaperAbbr " +
                             " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                             " and (Faculty_paper_a.splcode='" + splcode.SelectedValue + "') and STREAMPART.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                             " GROUP BY STREAMPART.StreamPartCode, STREAMPART.StreamPart " +
                             " order by StreamPart";


        popddl.Popualate(StreamPart, "StreamPart", strstreampart, "StreamPart", "StreamPartCode");
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
        StreamCode.Focus();
    }
    protected void MTheory_CheckedChanged(object sender, EventArgs e)
    {
        Subject.Items.Clear();
        GetPaperCode("T");
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
    }

    protected void MPrac_CheckedChanged(object sender, EventArgs e)
    {
        Subject.Items.Clear();
        GetPaperCode("P");
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
    }

    private void GetPaperCode(string PaperType)
    {

        string Querystr = "";
        string queryjoin = "";

        Querystr = " (COURSEPAPERS.StreamPartCode='" + StreamPart.SelectedValue + "')";
        queryjoin = "COURSEPAPERS_1.SubPaperCode = COURSEPAPERS.SubPaperCode";

        string strrole = "";
        if (Session["Role"].ToString() == "9")
            strrole = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";

        string strcourse = "SELECT     COURSEPAPERS.PaperAbbr " +
                           " FROM         Faculty_paper_a INNER JOIN COURSEPAPERS AS COURSEPAPERS_1 ON " +
                           " Faculty_paper_a.SubPaperCode = COURSEPAPERS_1.SubPaperCode INNER JOIN COURSEPAPERS " +
                            " ON " + queryjoin + " INNER JOIN " +
                            " EXAMPAPERDETAIL ON COURSEPAPERS.SubPaperCode = EXAMPAPERDETAIL.SubPaperCode " +
                          " WHERE     (Faculty_paper_a.Is_Active = 'Y')   And (Faculty_paper_a.splcode = '" + splcode.SelectedValue + "') " + strrole +
                          " and" + Querystr + " and  (EXAMPAPERDETAIL.ExamSession='" + ExamYear.SelectedValue + "') and (EXAMPAPERDETAIL.ExamType in ('R','B')) and ";

        string querypart = " GROUP BY COURSEPAPERS.PaperAbbr ORDER BY COURSEPAPERS.PaperAbbr ";

        PopulateDDL popddl = new PopulateDDL();
        UnivService.Service1 NicService = new UnivService.Service1();
        //  Subcode = NicService.GetNewCode("select subcode from subject where streamcode='" + StreamCode.SelectedValue + "'");


        if (PaperType == "T")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "(COURSEPAPERS.PaperTypeCode='02' or COURSEPAPERS.PaperTypeCode='04') and (Faculty_paper_a.PaperType='T' or Faculty_paper_a.PaperType is null)" + querypart, "PaperAbbr", "PaperAbbr");
        }
        else if (PaperType == "X")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "PaperTypeCode='04'" + querypart, "PaperAbbr", "PaperAbbr");
        }
        else if (PaperType == "P")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "(COURSEPAPERS.PaperTypeCode='01' or COURSEPAPERS.PaperTypeCode='04') and (Faculty_paper_a.PaperType='P' or Faculty_paper_a.PaperType is null)" + querypart, "PaperAbbr", "PaperAbbr");
        }
        else if (PaperType == "E")
        {
            popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "PaperTypeCode='03'" + querypart, "PaperAbbr", "PaperAbbr");
        }
        Subject.Focus();
    }
    String papertype;

    protected void Page_Unload(object sender, EventArgs e)
    {
        if (rpt != null)
        {
            rpt.Close();
            rpt.Dispose();
        }

    }


    protected void splcode_SelectedIndexChanged(object sender, EventArgs e)
    {
        MTheory.Checked = false;
        // RBComp.Checked=false ;
        //MElective.Checked = false;
        //MThPr.Checked = false;
        MPrac.Checked = false;

        //shivam - 23-04-2014
        StreamPart.Items.Clear();
        Subject.Items.Clear();

        string strrole = "";
        if (Session["Role"].ToString() == "9")
            strrole = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";

        PopulateDDL popddl = new PopulateDDL();

        string strstreampart = "SELECT     STREAMPART.StreamPart,STREAMPART.StreamPartCode " +
                              " FROM         COURSEPAPERS AS COURSEPAPERS_1 INNER JOIN " +
                              " STREAMPART ON COURSEPAPERS_1.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN " +
                              " Faculty_paper_a INNER JOIN " +
                              " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode ON COURSEPAPERS_1.PaperAbbr = COURSEPAPERS.PaperAbbr " +
                              " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                              " and (Faculty_paper_a.splcode='" + splcode.SelectedValue + "') and STREAMPART.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                              " GROUP BY STREAMPART.StreamPartCode, STREAMPART.StreamPart " +
                              " order by StreamPart";


        popddl.Popualate(StreamPart, "StreamPart", strstreampart, "StreamPart", "StreamPartCode");
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
        splcode.Focus();


    }


    protected void ExamYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        string strstream = "SELECT     STREAM.StreamAbbr, STREAM.StreamCode FROM Faculty_paper_a INNER JOIN " +
                  " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " +
                  " STREAM ON COURSEPAPERS.StreamCode = STREAM.StreamCode " +
                  " Where Faculty_paper_a.Is_Active='Y' and Faculty_paper_a.examsession='" + ExamYear.SelectedValue + "'" +
                  " GROUP BY STREAM.StreamAbbr, STREAM.StreamCode order by StreamAbbr ";

        StreamCode.Items.Clear();
        popddl.Popualate(StreamCode, "Stream", strstream, "StreamAbbr", "StreamCode");
        StreamCode.Items.Insert(0, new ListItem("--Select--", "0"));
    }



    protected void Btnnew_Click(object sender, EventArgs e)
    {
        string checkEntry;
        string subPaperCode = (string)fn.singlevalue(" SELECT Subpapercode FROM COURSEPAPERS b where b.PaperAbbr='" + Subject.SelectedValue + "' and b.StreamPartCode='" + StreamPart.SelectedValue + "'");
        string selectedPaperType = string.Empty;
        if (MTheory.Checked == true)
        {
            selectedPaperType = "T";
            checkEntry = " SELECT COUNT(*) FROM AttendanceRegister  " +
                            " where Subpapercode='" + subPaperCode + "' and  ExamSession='" + ExamYear.SelectedValue + "' and SplCode='" + splcode.SelectedValue + "' and PaperType='T' and Month=" + ddlMonth.SelectedValue;
        }
        else
        {
            selectedPaperType = "P";
            checkEntry = " SELECT COUNT(*) FROM AttendanceRegister  " +
                         " where Subpapercode='" + subPaperCode + "' and  ExamSession='" + ExamYear.SelectedValue + "' and SplCode='" + splcode.SelectedValue + "' and PaperType='P' and Month=" + ddlMonth.SelectedValue;
        }
        int entryAttendance = (int)fn.singlevalue(checkEntry);
        entryAttendance = 0;
        if (entryAttendance == 0)
        {
            string insertAttendance = " INSERT INTO AttendanceRegister " +
                                      " ( SubPaperCode, ExamSession, Month, PaperType,  FacultyId, SplCode) " +
                                     " VALUES ('" + subPaperCode + "','" + ExamYear.SelectedValue + "'," + ddlMonth.SelectedValue + ",'" + selectedPaperType + "','" + Session["UserId"].ToString() + "','" + splcode.SelectedValue + "')";
            int insertCommited = fn.InsertUpdateDelete(insertAttendance);
        }

        string strque = "AttendanceRegisterPrint.aspx?spc=" + subPaperCode + "&pt=" + selectedPaperType + "&es=" + ExamYear.SelectedValue + "&sc=" + splcode.SelectedValue + "&mh=" + ddlMonth.SelectedValue;

        ScriptManager.RegisterStartupScript(this, Page.GetType(), "", "window.open('" + strque + "','Graph','height=600,width=800,resizable=yes');", true);


    }
    protected void Subject_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        string strstream = string.Empty;
        if (ExamYear.SelectedValue.Substring(0, 7) == "JAN-JUN")
        {
            strstream = "select Id,Name from Months where Id between 1 and 6 and id<= MONTH(getdate())+1";
        }
        else if (ExamYear.SelectedValue.Substring(0, 7) == "JUL-DEC")
        {
            strstream = "select Id,Name from Months where Id between 7 and 12 and id<= MONTH(getdate())+1";
        }
        else
        {
            strstream = "select Id,Name from Months where Id=7";
        }
        ddlMonth.Items.Clear();
        popddl.Popualate(ddlMonth, "Month", strstream, "Name", "Id");
        ddlMonth.Items.Insert(0, new ListItem("--Select--", "0"));
    }
}
