using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class DraftEntry : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //bindadmyear(); bindStream();
            ddlexamsession.Items.Insert(0, new ListItem(ConfigurationManager.AppSettings["draftexamsession"].ToString(), ConfigurationManager.AppSettings["draftexamsession"].ToString()));
            bindstudent();
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        int Insrec = 0; string countval = "0";
        if (txtrollno.Text.Trim() == "")
        {
            lblmsg.Text = "Roll No Required";
            return;
        }
        if (txtamount.Text.Trim() == "")
        {
            lblmsg.Text = "Amount Required";
            return;
        }
        DataTable dtchkprev = fnrev.SelectDatatable("SELECT COUNT(*) FROM AmountReceived WHERE (ExamSession = '" + ConfigurationManager.AppSettings["draftexamsession"].ToString() + "') AND UnivrollNo = '" + txtrollno.Text.Trim() + "' " + 
            " AND (PaymentMode = 'DD')");
        if (dtchkprev.Rows.Count > 0)
        {
            countval = dtchkprev.Rows[0][0].ToString();
        }       
        if (Convert.ToInt32(countval) > 0)
        {
            Insrec = fnrev.InsertUpdateDelete("UPDATE AmountReceived SET TotalAmount = '" + txtamount.Text.Trim() + "' WHERE (ExamSession = '" + ConfigurationManager.AppSettings["draftexamsession"].ToString() + "') AND (PaymentMode = 'DD') AND UnivRollNo = '" + txtrollno.Text.Trim() + "'");
            bindstudent();
        }
        else
        {
            Insrec = fnrev.InsertUpdateDelete("INSERT INTO AmountReceived (UnivRollNo, ExamSession, TotalAmount, PaymentMode, Ctime, Uid) " +
                " VALUES ('" + txtrollno.Text.Trim() + "','" + ddlexamsession.SelectedValue.ToString() + "','" + txtamount.Text.Trim() + "','DD',GETDATE(),'" + Session["UserId"].ToString() + "')");
            bindstudent();
        }
        if (Insrec != 0)
        {
            lblmsg.Text = "Draft Record Saved.";
            bindstudent();
        }
        else
        {
            lblmsg.Text = "Draft Record Not Saved.";
        }
    }

    private void bindstudent()
    {
        DataTable dtstdlist = fnrev.SelectDatatable("SELECT ROW_NUMBER() OVER(ORDER BY (SELECT 1)) As Id, UnivRollNo, TotalAmount, PaymentMode FROM AmountReceived WHERE (ExamSession = '" + ddlexamsession.SelectedValue.ToString() + "') AND (PaymentMode = 'DD')");
        //gvstudentlist.DataSource = dtstdlist;
        //gvstudentlist.DataBind();

        if (dtstdlist.Rows.Count > 0)
        {
            string tablestring = "";

            for (int i = 0; i < dtstdlist.Rows.Count; i++)
                {
                    tablestring += "<tr>";
                    tablestring += "<td>" + dtstdlist.Rows[i]["Id"].ToString() + "</td>";
                    tablestring += "<td>" + dtstdlist.Rows[i]["UnivRollNo"].ToString() + "</td>";
                    tablestring += "<td>" + dtstdlist.Rows[i]["TotalAmount"].ToString() + "</td>";
                    tablestring += "<td>" + dtstdlist.Rows[i]["PaymentMode"].ToString() + "</td>";                   
                    //tablestring += "<td><a href=\"\\FarmerRedg.aspx?fi=" + dtgrid.Rows[i]["FarmerId"].ToString() + " >View/Edit </a></td>";
                    tablestring += "</tr>";
                }
                tlist.InnerHtml = tablestring;           
        }
        else
            tlist.InnerHtml = "";
    }
}
