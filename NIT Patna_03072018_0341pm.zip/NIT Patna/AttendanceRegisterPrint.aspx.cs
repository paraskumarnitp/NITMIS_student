using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using System.IO;

public partial class AttendanceRegisterPrint : System.Web.UI.Page
{
    ReportDocument rpt = new ReportDocument();
    Functionreviseed fn = new Functionreviseed();
    ReportDocument crystalReport = new ReportDocument();
    string subPaperCode, paperType, month, examsession, splcode;
    protected void Page_Load(object sender, EventArgs e)
    {
        subPaperCode = Request.QueryString["spc"];
        paperType = Request.QueryString["pt"];
        examsession = Request.QueryString["es"];
        splcode = Request.QueryString["sc"];
        month = Request.QueryString["mh"];
        GetAttendanceRegister();
    }
    protected void Page_Unload(object sender, EventArgs e)
    {
        if (rpt != null)
        {
            rpt.Close();
            rpt.Dispose();
        }
    }
    protected void GetAttendanceRegister()
    {

        string getStudents = " SELECT   e.StreamAbbr as Program,d.StreamPart as Semester,f.Name as Months, " +
                        " b.UnivRollNo,c.ApplicantName,g.paperabbr,g.papername,h.UserName,a.examsession " +
                        " FROM AttendanceRegister a inner join Attendance b on a.SubPaperCode=b.SubPaperCode " +
                        " and a.ExamSession=b.ExamSession inner join REGISTRATION c on b.RegNo=c.RegNo " +
                        " inner join STREAMPART d on b.StreamPartCode=d.StreamPartCode inner join STREAM e " +
                        " on d.StreamCode=e.StreamCode inner join Months f on a.Month=f.Id inner join " +
                        " coursepapers g on a.subpapercode=g.subpapercode inner join login h on a.FacultyId=h.UserId " +
                        " where a.SubPaperCode='" + subPaperCode + "' and a.Month=" + month + " and a.ExamSession='" + examsession + "' and a.SplCode='" + splcode + "' and a.PaperType='" + paperType + "'";
        DataTable dt = fn.SelectDatatable(getStudents);
        rpt.Load(Server.MapPath("~/Report/rptattendanceRegister.rpt"));
        //dt.TableName = "AttendanceRegister";
        //dt.WriteXmlSchema(Server.MapPath("~/AttendanceRegister.xsd"));
        rpt.SetDataSource(dt);
        MemoryStream oStream = new MemoryStream();
        oStream = (MemoryStream)rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
        Response.Clear();
        Response.Buffer = true;
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "inline;filename=report.pdf");
        Response.BinaryWrite(oStream.ToArray());
        Response.End();


    }


}




//protected void Page_LoadComplete(object sender, EventArgs e)
//{
//    CrystalReportViewer1.ReportSource = Session["btechgrage"];
//}

