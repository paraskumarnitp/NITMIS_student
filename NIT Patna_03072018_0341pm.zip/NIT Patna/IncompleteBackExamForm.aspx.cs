using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class IncompleteBackExamForm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "5")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            PopulateDDL popddl = new PopulateDDL();
            
            popddl.Popualate(PresentDistrictCode, "District", "Select DistName,DistCode from District order by DistName", "DistName", "DistCode");
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(Year1, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(Year2, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(ReligionCode, "Religion", "Select * from Religion order by ReligionCode", "Religion", "ReligionCode");
            
            
            popddl.Popualate(RegNo, "Exam", "Select RegNo from Exam where verifystatus='B'", "RegNo", "RegNo");
            RegNo.Focus();


        }
    }
    protected void BtnReg_Click(object sender, EventArgs e)
    {
        try
        {


            Panel1.Visible = true;
            BtnUpdate.Visible = true;

            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;
            cmd.CommandText = "select RegNo,ReasonOfRejection,date,StreamPartCode,ExamYear from RejectedExamForm where RegNo='" + RegNo.Text + "' ";
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            string ReaderStreamPart = "";
            string ReaderExamYear = "";

            if (reader.HasRows)
            {
                reader.Read();
                LblMsg.Text = reader["ReasonOfRejection"].ToString();

                ReaderStreamPart = reader["StreamPartCode"].ToString();
                ReaderExamYear = reader["ExamYear"].ToString();

                reader.Close();
                con.Close();

            }
            ViewExamFormDetail(RegNo.Text.Trim());
            ViewExamFormOtherDetails(RegNo.Text.Trim(), ReaderStreamPart, ReaderExamYear);
            ViewExamPaperDetails(RegNo.Text.Trim(), ReaderStreamPart, ReaderExamYear);
        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }


    }
    protected void ViewExamFormDetail(string RegNo)
    {
        try
        {


            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

            cmd.Connection = con;
            cmd.CommandText = " select AckNo,ApplicantName,HindiName,FatherName,MotherName,DOB,Gender,CastCode," +
                     "ReligionCode,CourseSession from Registration where RegNo='" + RegNo + "'";
            SqlDataReader reader;
            con.Open();
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                //Panel2.Visible = true;
                ApplicantName.Text = reader["ApplicantName"].ToString();
                HindiName.Text = reader["HindiName"].ToString();
                FatherName.Text = reader["FatherName"].ToString();
                MotherName.Text = reader["MotherName"].ToString();
                DOB.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["DOB"]));
                ReligionCode.SelectedValue = reader["ReligionCode"].ToString();
                CastCode.SelectedValue = reader["CastCode"].ToString();
                if (reader["Gender"].ToString() == "M")
                    GenderM.Checked = true;
                else
                    GenderF.Checked = true;
                Year1.Text = (reader["CourseSession"].ToString()).Substring(0, 4);
                Year2.Text = (reader["CourseSession"].ToString()).Substring(5, 4);


                //Image Load

                ImageUpload imgUpload = new ImageUpload();
                string strFileName = imgUpload.Image_Load(reader["AckNo"].ToString());


                if (strFileName.ToString().Contains("temp"))
                {


                    string photo = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/temp.jpg";

                    string strRightNow = "";
                    string IUrl = "";

                    strRightNow = System.DateTime.Now.ToString("ddMMyyyyHHmmss");
                    IUrl = photo + "?img=" + strRightNow;

                    Image3.ImageUrl = IUrl;
                    Image3.DataBind();


                }
                else if (strFileName.ToString().Contains("UploadPhoto"))
                {

                    Image3.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadPhoto.JPG";
                    Image3.DataBind();

                }

                else
                {
                    LblMsg.Text = "Error" + strFileName;

                }

                // IMAGE load --End
                reader.Close();

            }

        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }


    }
    protected void ViewExamFormOtherDetails(string RegNo, string strpartcode, string examyear)
    {
        
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;

        cmd.Connection = con;
        cmd.CommandText = " select ClassRollNo,PresentAddress1,PresentAddress2,PresentDistrictCode,PresentPinCode," +
            "SCBNo,SCBDate,ExamFeeAmt,ExamFormNo,ExamType,ExamYear, " +
            "StreamCode,StreamPartCode,subcode,ModeOfExam from Exam where RegNo='" + RegNo + "' And StreamPartCode='" + strpartcode + "'";

        SqlDataReader reader;
        con.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            reader.Read();

            ClassRollNo.Text = reader["ClassRollNo"].ToString();
            PresentAddress1.Text = reader["PresentAddress1"].ToString();
            PresentAddress2.Text = reader["PresentAddress2"].ToString();
            PresentDistrictCode.SelectedValue = reader["PresentDistrictCode"].ToString();
            PresentPinCode.Text = reader["PresentPinCode"].ToString();
            SCBNo.Text = reader["SCBNo"].ToString();
            SCBDate.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["SCBDate"].ToString()));
            ExamFeeAmt.Text = reader["ExamFeeAmt"].ToString();
            ExamFormNo.Text = reader["ExamFormNo"].ToString();
            ExamType.SelectedValue = reader["ExamType"].ToString();
            ExamYear.Text = reader["ExamYear"].ToString();
            StreamCode.SelectedValue = reader["StreamCode"].ToString();
            
            //mode of exam
            if (reader["ModeOfExam"].ToString() == "E")               ModeOfExamE.Checked = true;
            else if (reader["ModeOfExam"].ToString() == "H")          ModeOfExamH.Checked = true;
            else                                                      ModeOfExamN.Checked = true;

            //mode of exam


            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
            StreamPart.SelectedValue = reader["streampartcode"].ToString();

            popddl.Popualate(SubCode, "Subject", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
            SubCode.SelectedValue = reader["subcode"].ToString();

        }

        reader.Close();
    }
    protected void ViewExamPaperDetails(string regno,string strpartcode,string examyear)
    {

        PopulateList poplist = new PopulateList();
        
        CompPaper.Items.Clear();
        HPaper.Items.Clear();
        SPaper.Items.Clear();
        // Set Composition Paper
        string str= "SELECT SubPaperCode FROM EXAMPAPERDETAIL " +
        "WHERE RegNo='" + regno + "' AND ExamYear = '" + examyear + "' AND StreamPartCode = '" + strpartcode + "' And  PaperType='C'" ;
        int i = 0;
        string sql = "Select Name,compCode from COMPOSITION Where compcode in (" + str + ")";
        poplist.Popualate(CompPaper, "composition", sql, "Name", "compCode");
        for (i = 0; i < CompPaper.Items.Count; i++)
        {

            CompPaper.Items[i].Selected = true;
        }

        // Set Subsidiary Paper
        str = "SELECT SubPaperCode FROM EXAMPAPERDETAIL " +
        "WHERE RegNo='" + regno + "' AND ExamYear = '" + examyear + "' AND StreamPartCode = '" + strpartcode + "' And  PaperType='S'";
        i = 0;
        sql = "Select SubCode,SubjectName from SUBJECT Where SubCode in (" + str +")";
        poplist.Popualate(SPaper, "SUBJECT", sql, "SubjectName", "SubCode");
        for (i = 0; i < SPaper.Items.Count; i++)
        {

            SPaper.Items[i].Selected = true;
        }

        // Set Honours Paper
        str = "SELECT SubPaperCode FROM EXAMPAPERDETAIL " +
        "WHERE RegNo='" + regno + "' AND ExamYear = '" + examyear + "' AND StreamPartCode = '" + strpartcode + "' And  PaperType='H'";
        i = 0;
        sql = "Select PaperName,SubPaperCode from COURSEPAPERS Where SubPaperCode in (" + str+")";
        poplist.Popualate(HPaper, "COURSEPAPERS", sql, "PaperName", "SubPaperCode");
        for (i = 0; i < HPaper.Items.Count; i++)
        {
            //HPaper.SelectedIndex = i;
            HPaper.Items[i].Selected = true;
        }



        //SqlConnection con = new SqlConnection();
        //SqlCommand cmd = new SqlCommand();
        //cmd.Connection = con;
        //con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        //cmd.Connection = con;
        //SqlDataReader reader;
        //con.Open();
        //reader = cmd.ExecuteReader();
        //if (reader.HasRows)
        //{
        //    string papernm="";
            
        //    UnivService.Service1 ss = new UnivService.Service1();
        //    int i=0;
        //    while (reader.Read())
        //    {
                
        //        if (reader["papertype"].ToString() == "C")
        //        {
        //            papernm =ss.GetNewCode ("select Abbr from Composition where Compcode='"+ reader["subpaperCode"].ToString ()+"'");
        //            CompPaper.Items.Add(papernm);
               //        }
                   
        //        else if (reader["papertype"].ToString() == "H")
        //        {
        //            papernm = ss.GetNewCode("select paperAbbr from Coursepapers where subpapercode='" + reader["subpaperCode"].ToString() + "'");
        //            HPaper.Items.Add(papernm);
        //        }
        //        else if (reader["papertype"].ToString() == "S")
        //        {
        //            papernm = ss.GetNewCode("select subAbbr from Subject where subcode='" + reader["subpaperCode"].ToString() + "'");
        //            SPaper.Items.Add(papernm);
        //        }
        //    }

        //}
        //reader.Close();



    }
    protected void BtnUpdate_Click(object sender, EventArgs e)
    {
        try
        {

            char MoE;
            if (ModeOfExamE.Checked == true) MoE = 'E';
            else if (ModeOfExamH.Checked == true) MoE = 'H';
            else MoE = 'N';

            //Update Exam Table

            string abc = " update Exam  set PresentAddress1='" + PresentAddress1.Text.Trim() +
                        "', PresentAddress2='" + PresentAddress2.Text.Trim() +
                        "', PresentDistrictCode='" + PresentDistrictCode.SelectedValue +
                        "', PresentPinCode='" + PresentPinCode.Text +

                        "', StreamCode='" + StreamCode.SelectedValue +
                        "', CollCode='" + CollCode.SelectedValue +
                       
                        "', ExamType='" + ExamType.Text.Trim() +
                        "', ClassRollNo='" + ClassRollNo.Text.Trim() +

                        "', SCBNo='" + SCBNo.Text.Trim() +
                        "', SCBDate='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(SCBDate.Text)) +
                        "', ExamFeeAmt='" + ExamFeeAmt.Text.Trim() +
                        "', ExamFormNo='" + ExamFormNo.Text.Trim() +
                        "',ExamYear='" + ExamYear.Text.Trim() +
                        "', StreamPartCode='" + StreamPart.SelectedValue +
                        "', SubCode ='" + SubCode.SelectedValue +
                       "', ModeOfExam='"+ MoE + //mode of exam
                        "' where RegNo='" + RegNo.SelectedValue + "' and StreamPartCode='" + StreamPart.SelectedValue + "' ";


            UnivService.Service1 ss = new UnivService.Service1();
            abc = ss.UpdateData(abc);

         //updtae Exampaper detail
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;
            cmd.CommandText = "Delete From ExamPaperDetail Where RegNo='"+RegNo.Text  +"' And StreamPartCode='"+StreamPart.SelectedValue  +"'";
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            SavePaper();







            //Update Verify Status in Exam table && delete Rejected Exam Form
            abc = "update Exam set verifystatus='N' where Regno='" + RegNo.Text + "' and StreamPartcode='" + StreamPart.SelectedValue + "' ";
            abc = ss.UpdateData(abc);
            abc = "delete from RejectedExamForm where RegNo='" + RegNo.SelectedValue + "' and StreamPartcode='" + StreamPart.SelectedValue + "' ";
            abc = ss.UpdateData(abc);



            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(RegNo, "Exam", "Select RegNo from Exam where verifystatus='B'", "RegNo", "RegNo");

            if (abc.ToString() == "ok")
            {

               LblMsg.Text = " Record is updated successfully.";
               BtnUpdate.Visible = false;  


           }
            else
                LblMsg.Text = abc.ToString();
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }
    protected void SavePaperDetail(string pcode, string ptype)
    {

        try
        {

            string SaveFlag = "";

            string[] col = new string[5];
            string[] val = new string[5];


            // Colume Variable--Field Name

            col[0] = "RegNo"; val[0] = RegNo.Text.Trim();
            col[1] = "StreamPartCode"; val[1] = StreamPart.SelectedValue;
            col[2] = "SubPaperCode"; val[2] = pcode;
            col[3] = "PaperType"; val[3] = ptype;
            col[4] = "ExamYear"; val[4] = ExamYear.Text.Trim();


            UnivService.Service1 NicService = new UnivService.Service1();
            SaveFlag = NicService.SaveData("ExamPaperDetail", col, val);

            if (SaveFlag == "1")
            {
                LblMsg.Text = "";
            }
            else
            {
                LblMsg.Text = SaveFlag.ToString();
            }

        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

    }
    protected void SavePaper()
    {
        try
        {

            int i = 0;

            // Composition Paper 
            for (i = 0; i < CompPaper.Items.Count; i++)
            {
                if (CompPaper.Items[i].Selected == true)
                {
                    SavePaperDetail(CompPaper.Items[i].Value.ToString(), "C");
                }
            }

            // Honours Paper 
            for (i = 0; i < HPaper.Items.Count; i++)
            {
                if (HPaper.Items[i].Selected == true)
                {
                    SavePaperDetail(HPaper.Items[i].Value.ToString(), "H");
                }
            }

            // Subsidiary Paper 
            for (i = 0; i < SPaper.Items.Count; i++)
            {
                if (SPaper.Items[i].Selected == true)
                {
                    SavePaperDetail(SPaper.Items[i].Value.ToString(), "S");
                }
            }
        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }

    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
        popddl.Popualate(SubCode, "CoursePapers", "SELECT  SubjectName,SubCode FROM  SUBJECT where StreamCode='" + StreamCode.SelectedValue + "' or SubCode='000' order by SubjectName", "SUBJECTName", "SubCode");
        StreamCode.Focus();
        PopulateList poplist = new PopulateList();
        poplist.Popualate(CompPaper, "COMPOSITION", "Select CompCode,Name from COMPOSITION  order by Name", "Name", "CompCode");
        StreamCode.Focus(); 



    }
    protected void SubCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        GetSubcode();
    }
    protected void GetSubcode()
    {
        PopulateList poplist = new PopulateList();
        poplist.Popualate(HPaper, "COURSEPAPERS", "Select PaperName,SubPaperCode from COURSEPAPERS Where StreamCode='" + StreamCode.SelectedValue + "' And StreamPartCode='" + StreamPart.SelectedValue + "' And SubCode='" + SubCode.SelectedValue + "' order by SubPaperCode", "PaperName", "SubPaperCode");
        poplist.Popualate(SPaper, "SUBJECT", "Select SubCode,SubjectName from SUBJECT Where StreamCode='" + StreamCode.SelectedValue + "' and subcode<>'" + SubCode.SelectedValue + "'  order by SubjectName", "SubjectName", "SubCode");
        SubCode.Focus();
    }
    protected void StreamPart_SelectedIndexChanged(object sender, EventArgs e)
    {
        GetSubcode();
    }
}
