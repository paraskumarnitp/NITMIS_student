using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CategoryFeeSettings : System.Web.UI.Page
{
    Functionreviseed fnrev = new Functionreviseed();
    string querypart;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            bindadmyear(); bindStream();
            ddlexamSession.Items.Insert(0, new ListItem(ConfigurationManager.AppSettings["ddexamsession"].ToString(), ConfigurationManager.AppSettings["ddexamsession"].ToString()));
        }
    }

    private void bindadmyear()
    {
        DataTable dtadmyear = fnrev.SelectDatatable("SELECT DISTINCT ADmyear FROM REGISTRATION WHERE ADMYEAR >= '" + ConfigurationManager.AppSettings["ADMYear"].ToString() + "'");
        if (dtadmyear.Rows.Count > 0)
        {
            ddladmyear.DataSource = dtadmyear;
            ddladmyear.DataTextField = "ADmyear";
            ddladmyear.DataValueField = "ADmyear";
            ddladmyear.DataBind();
            ddladmyear.Items.Insert(0, new ListItem("--SELECT--", "00"));
        }    
    }

    private void bindStream()
    {
        DataTable dtstream = fnrev.SelectDatatable("SELECT StreamAbbr, StreamCode FROM STREAM WHERE StreamCode <> '00' order by StreamCode");
        if (dtstream.Rows.Count > 0)
        {
            ddlprogram.DataSource = dtstream;
            ddlprogram.DataTextField = "StreamAbbr";
            ddlprogram.DataValueField = "StreamCode";
            ddlprogram.DataBind();
            ddlprogram.Items.Insert(0, new ListItem("--SELECT--", "00"));
        }
    }
    protected void ddlprogram_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable dtprogram = fnrev.SelectDatatable("SELECT DISTINCT EXAM.StreamPartCode, STREAMPART.StreamPart FROM EXAM INNER JOIN " + 
            " REGISTRATION ON EXAM.RegNo = REGISTRATION.RegNo INNER JOIN STREAMPART ON EXAM.StreamPartCode = STREAMPART.StreamPartCode " +
            " WHERE (EXAM.ExamSession = '" + ConfigurationManager.AppSettings["prevexamsession"].ToString() + "') AND (EXAM.StreamCode = '" + ddlprogram.SelectedValue + "') " +
            " AND (REGISTRATION.AdmYear >= '" + ConfigurationManager.AppSettings["ADMYear"].ToString() + "')");
        if (dtprogram.Rows.Count > 0)
        {
            ddlsemester.DataSource = dtprogram;
            ddlsemester.DataTextField = "StreamPart";
            ddlsemester.DataValueField = "StreamPartCode";
            ddlsemester.DataBind();
            ddlsemester.Items.Insert(0, new ListItem("--SELECT--", "00"));
        }
    }
    protected void btngetlist_Click(object sender, EventArgs e)
    {
        querypart = " WHERE (EXAM.ExamSession = '" + ConfigurationManager.AppSettings["prevexamsession"].ToString() + "') AND Exam.StreamPartCode = '"+ ddlsemester.SelectedValue +"' AND (REGISTRATION.AdmYear >= '" + ConfigurationManager.AppSettings["ADMYear"].ToString() + "')";
        bindgrid(querypart);
    }

    private void bindgrid(string sqlpart)
    {
        DataTable dtstudentlist = fnrev.SelectDatatable("SELECT DISTINCT EXAM.RegNo, EXAM.UnivRollNo, REGISTRATION.ApplicantName, " +
            " replace(convert(NVARCHAR, REGISTRATION.DOB, 106), ' ', '/') AS DOB FROM EXAM INNER JOIN REGISTRATION ON " +
            " EXAM.RegNo = REGISTRATION.RegNo "+sqlpart);
        gvstudentlist.DataSource = dtstudentlist;
        gvstudentlist.DataBind();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        querypart = " WHERE  Exam.UnivRollNo = '"+txtrollno.Text.Trim().ToString()+"'";
        bindgrid(querypart);
    }


    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            string countval = "0";
            if (gvstudentlist.Rows.Count > 0)
            {
                //foreach (GridViewRow rowindex in gvstudentlist)
                //{
                //    string Regno = gvstudentlist.DataKeys[].DataKeyNames[i].ToString();
                //    string RollNo = gvstudentlist.Rows[i].Cells[0].Text;
                //    RadioButtonList rdb = (RadioButtonList)gvstudentlist.Rows[i].Cells[0].FindControl("rdbcategorylist");
                //    string categoryvalue = rdb.SelectedValue.ToString();
                //}
                int InsRec = 0;
                for (int i = 0; i < gvstudentlist.Rows.Count; i++)
                {
                    string Regno = gvstudentlist.DataKeys[i].Values[0].ToString();
                    string RollNo = gvstudentlist.Rows[i].Cells[0].Text;
                    RadioButtonList rdb = (RadioButtonList)gvstudentlist.Rows[i].Cells[0].FindControl("rdbcategorylist");
                    string categoryvalue = rdb.SelectedValue.ToString();
                    if ((categoryvalue == "SC_ST_PWD") || (categoryvalue == "EBC_B_1_L") || (categoryvalue == "EBC_B_5_L"))
                    {
                        DataTable dtcount = fnrev.SelectDatatable("SELECT COUNT(*) AS Rcount FROM CategoryFeeSettings WHERE ExamSession = '"+ConfigurationManager.AppSettings["ddexamsession"].ToString()+"' and regNo = '" + Regno + "'");
                        if (dtcount.Rows.Count > 0)
                        {
                            countval = dtcount.Rows[0][0].ToString();
                        }
                        if (Convert.ToInt32(countval) > 0)
                        {
                            InsRec = fnrev.InsertUpdateDelete("UPDATE CategoryFeeSettings SET FeeCategoryType ='" + categoryvalue + "', Uid ='" + Session["UserId"].ToString() + "', Mtime = GETDATE() WHERE (RegNo = '" + Regno + "') AND (ExamSession = '" + ConfigurationManager.AppSettings["ddexamsession"].ToString() + "')");
                        }
                        else
                        {
                            InsRec = fnrev.InsertUpdateDelete("INSERT INTO CategoryFeeSettings (RegNo, ExamSession, FeeCategoryType, " +
                                                       " cid, Ctime) VALUES ('" + Regno + "','" + ConfigurationManager.AppSettings["ddexamsession"].ToString() + "','" + categoryvalue + "','" + Session["UserId"].ToString() + "',GETDATE())");
                        }
                    }

                    // code for fee concession on the basis of category fee waive ---
                    
                    if (categoryvalue == "SC_ST_PWD")
                    {
                        InsRec = fnrev.InsertUpdateDelete("INSERT INTO FeeConcession (UnivRollNo, ExamSession, Amount, Remarks, Ctime, Uid) " +
                          " VALUES ('" + RollNo + "','" + ConfigurationManager.AppSettings["ddexamsession"].ToString() + "','62500.00','Category Fee Waive',GETDATE(),'"+Session["UserId"].ToString()+"')");                       
                    }
                    else if (categoryvalue == "EBC_B_1_L")
                    {
                        InsRec = fnrev.InsertUpdateDelete("INSERT INTO FeeConcession (UnivRollNo, ExamSession, Amount, Remarks, Ctime, Uid) " +
                            " VALUES ('" + RollNo + "','" + ConfigurationManager.AppSettings["ddexamsession"].ToString() + "','62500.00','Category Fee Waive',GETDATE(),'" + Session["UserId"].ToString() + "')");
                    }
                    else if (categoryvalue == "EBC_B_5_L")
                    {
                        double amount = Math.Ceiling(((double)(62500 * 2) / (double)3));
                        InsRec = fnrev.InsertUpdateDelete("INSERT INTO FeeConcession (UnivRollNo, ExamSession, Amount, Remarks, Ctime, Uid) " +
                          " VALUES ('" + RollNo + "','" + ConfigurationManager.AppSettings["ddexamsession"].ToString() + "','" + amount + "','Category Fee Waive',GETDATE(),'" + Session["UserId"].ToString() + "')");                       
                    }        

                }
                if (InsRec != 0)
                {
                    lblmsg.Text = "Setting(s) Saved Successfully.";
                }
                else
                {
                    lblmsg.Text = "Setting(s) Not Saved Successfully.";
                }
            }
        }
        catch {
            lblmsg.Text = "Error occurred during Saved, Try Again.";
        }
    }
}
