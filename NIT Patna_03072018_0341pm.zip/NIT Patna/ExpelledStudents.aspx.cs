using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;


public partial class ExpelledStudents : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "3")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(CollCode, "College", "Select CollName,CollCode from College order by CollName", "CollName", "CollCode");
            popddl.Popualate(UnfairList, "UnfairMeans", "Select UnfairDesc,UnfairCode from UnfairMeans order by UnfairDesc", "UnfairDesc", "UnfairCode");

        }
    }
    protected void BtnSave_Click(object sender, EventArgs e)
    {
        SaveRecord();
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void BtnReg_Click(object sender, EventArgs e)
    {

        try
        {

            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;

            cmd.CommandText = " select RegNo,CollCode,StreamCode,StreamPartCode from Exam where UnivRollNo='" + UnivRollNo.Text + "'";
            SqlDataReader reader;
            LblMsg.Text = "";
            RegNo.Text = "";
            con.Open();
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
         
                reader.Read();
                Panel2.Visible = true;
                
                RegNo.Text = reader["regNo"].ToString();
                UnivRoll.Text = UnivRollNo.Text.ToString();
                StreamCode.SelectedValue = reader["StreamCode"].ToString();
                CollCode.Text = reader["CollCode"].ToString();

                BtnSave.Enabled = true;
                //UnivRollNo.Enabled = false;
                //BtnReg.Enabled = false;

                PopulateDDL popddl = new PopulateDDL();
                popddl.Popualate(StreamPart, "StreamPart", "Select StreamPart,StreamPartCode from StreamPart Where StreamCode='" + StreamCode.SelectedValue + "'order by StreamPartCode", "StreamPart", "StreamPartCode");
                
                string spc = reader["StreamPartCode"].ToString();
                        StreamPart.SelectedIndex = 0;
                reader.Close();


                //Get Student Name
                cmd.CommandText = " Select ApplicantName from registration where RegNo='" + RegNo.Text + "'";
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    StudentName.Text = reader["ApplicantName"].ToString();
                    reader.Close();
                }

           }
           else
            {
                LblMsg.Text = " Please check University Roll no.";
                Panel2.Visible = false;
                UnivRollNo.Focus();
            }
            con.Close();
            ExamYear.Text = System.DateTime.Now.Year.ToString();


        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }

    protected void SaveRecord()
    {

        string[] col = new string[8];
        string[] val = new string[8];

        
        // Colume Variable--Field Name
        col[0] = "UnivRollNo";      val[0] = UnivRoll.Text.ToString();
        col[1] = "RegNo";           val[1] = RegNo.Text.ToString();
        col[2] = "CollCode";        val[2] = CollCode.SelectedValue.ToString();
        col[3] = "StreamCode";      val[3] = StreamCode.SelectedValue.ToString();
        col[4] = "StreamPartCode";  val[4] = StreamPart.SelectedValue.ToString();
        col[5] = "ExamYear";        val[5] = ExamYear.Text.ToString();
        col[6] = "Remarks";         val[6] = Remarks.Text.ToString();
        col[7] = "UnfairCode";      val[7] = UnfairList.SelectedValue; 

        try
        {
            string SaveFlag = "";

            //if (UnivRoll.TextText.ToString() == "")
            //{
            //    LblMsg.Text = "Univroll no should not be blank...";
            //    return;

            //}

            UnivService.Service1 NicService = new UnivService.Service1();
            SaveFlag = NicService.SaveData("ExpelledStudents", col, val);

            if (SaveFlag == "1")
            {
                LblMsg.Text = "Successfully Saved - " +UnivRollNo.Text.ToString();
                UnivRollNo.Text = "";
                RegNo.Text = "";
                BtnSave.Enabled = false;
            }
            else
            {
                LblMsg.Text = "Error" + "Already entered.... Plz check";
            }
        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }

    protected void UnfairList_SelectedIndexChanged(object sender, EventArgs e)
    {
        UnivService.Service1 NicService = new UnivService.Service1();
        Punishment.Text = NicService.GetNewCode("Select punishment from Unfairmeans where Unfaircode='"+UnfairList.SelectedValue+"'");
        NicService.Dispose();

    }
}
