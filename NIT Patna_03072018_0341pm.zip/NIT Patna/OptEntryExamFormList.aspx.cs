using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class OptEntryExamFormList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["UserId"].ToString() == "")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }
            Calendar1.SelectedDate = System.DateTime.Now;
            LblMsg2.Visible = false;
        }
        
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        BindGrid();
    }
    protected void OptEntryExamFormListView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        
    }
    protected void BindGrid()
    {
        try
        {
            LblMsg2.Visible = false;

            string sql = "";


            //sql = "select row_number() OVER (ORDER BY UserID ASC)AS Count,AckNo,RegFormNo,ApplicantName,FatherName,DOB,CollCOde,StreamCode,CourseSession  from registration" +
            //  " WHERE     ( EntryOptDateTime = '" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(Calendar1.SelectedDate)) + "') and " +
            //  "(UserId='" + Session["UserId"].ToString() + "') ";

            sql = "select row_number() OVER (ORDER BY UserID ASC)AS Count," +
               "RegNo,ExamFormNo,CollCode,StreamCode,StreamPartCode,ExamType,ExamYear from exam" +
               " WHERE     ( EntryOptDateTime = '" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(Calendar1.SelectedDate)) + "') and " +
               "(UserId='" + Session["UserId"].ToString() + "') ";


            DataSet ds = new DataSet();
            ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, sql);
            OptEntryExamFormListView.DataSource = ds;
            OptEntryExamFormListView.DataBind();
        }
        catch (Exception ex)
        {
            LblMsg2.Visible = true;
            LblMsg2.Text = " Please Select Date";
        }
    }
    protected void OptEntryExamFormListView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        // page change
        OptEntryExamFormListView.PageIndex = e.NewPageIndex ;
        BindGrid();

    }
}
