using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class ExamFormEntry : System.Web.UI.Page
{
    Functionreviseed chkfn = new Functionreviseed();
    string RegNo = "";
    DataTable dt1 = new DataTable();
    DataRow dr = null;
    DataRow[] dr1;
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "4" && Session["Role"].ToString() != "10")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            ExamType.Items.Insert(0,new ListItem(ConfigurationManager.AppSettings["ddexamsession"].ToString(),ConfigurationManager.AppSettings["ddexamsession"].ToString()));
            PopulateDDL popddl = new PopulateDDL();
            popddl.Popualate(CasteCode, "Category", "Select Category,CategoryCode from Category order by Category", "Category", "CategoryCode");
            popddl.Popualate(Year1, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(Year2, "Year", "Select Year from Year order by Year", "Year", "Year");
            popddl.Popualate(ReligionCode, "Religion", "Select * from Religion order by ReligionCode", "Religion", "ReligionCode");
            popddl.Popualate(Program, "Stream", "Select Stream, StreamCode from Stream Where STUDY='Y' order by Stream", "Stream", "StreamCode");
            popddl.Popualate(ddlbranch, "Stream", "Select StreamAbbr, StreamCode from Stream Where STUDY='Y' order by StreamAbbr", "StreamAbbr", "StreamCode");
            
            PopulateList poplist = new PopulateList();
            
            RollNo.Focus();
        }

        RegFormEntryYear.Attributes.Add("onKeyPress", "return onlyNumbers(this);");
        ExamFeeAmt.Attributes.Add("onKeyPress", "return onlyNumbers(this);");       

    }

    DataTable dt = new DataTable();
    protected void SaveExam()
    {

        try
        {


            dt.Columns.Add("sem");
            dt.Columns.Add("examtype");
            // Check duplicate Entry of Form (On ExamFormNo , Collcode,streampart,examyear)

            SqlConnection con = new SqlConnection();
            SqlDataReader rd;
            SqlCommand cmd = new SqlCommand();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;
            UnivService.Service1 NicService = new UnivService.Service1();


            //RegNo = NicService.GetNewCode("Select TOP(1) RegNo From EXAMPAPERDETAIL Where UnivRollNo = '" + RollNo.Text.ToString().Trim() + "' AND RegNo IS NOT NULL");
            string streamcode = "";
            streamcode = NicService.GetNewCode("select streamcode  from stream where StreamAbbr='" + ddlbranch.SelectedItem + "'");


            string subcode = "";
            subcode = NicService.GetNewCode("select subcode  from subject  where streamcode='" + streamcode + "' ");
            //cmd.CommandText = "select RegNo from Exam where ExamFormNo= '" + examformno + "' AND CollCode='002' and StreamPartCode='" + StreamPart.SelectedValue + "'and examyear='" + ExamYear.Text + "' ";
            ////////if (Label1.Text != "")
            ////////{
            if (gvcourse.Rows.Count > 0)
            {
                for (int t = 0; t < gvcourse.Rows.Count; t++)
                {
                    TextBox box1 = (TextBox)gvcourse.Rows[t].Cells[2].FindControl("txtsem");
                    TextBox box2 = (TextBox)gvcourse.Rows[t].Cells[5].FindControl("txtspartcode");
                    TextBox box3 = (TextBox)gvcourse.Rows[t].Cells[3].FindControl("txtexamtype");
                    if (box1.Text != "")
                    {
                        dr1 = dt.Select("sem = '" + box2.Text.ToString() + "'");
                        if (dr1.Length == 0)
                        {
                            string extype = box3.Text != "R" ? "N" : box3.Text;
                            dt.Rows.Add(box2.Text, extype);

                        }
                    }
                }

            }
            DataRow[] dr4;
            DataTable dtcourse = new DataTable();
            dtcourse.Columns.Add("course");
            dtcourse.Columns.Add("StreamPartCode", typeof(string));
            dtcourse.Columns.Add("PaperType", typeof(string));
            dtcourse.Columns.Add("ExamType", typeof(string));
            //examsession1 = ExamType.SelectedItem.ToString();

            DataTable dtattendance = new DataTable();
            dtattendance.Columns.Add("course");
            dtattendance.Columns.Add("StreamPartCode", typeof(string));
            dtattendance.Columns.Add("PaperType", typeof(string));
            dtattendance.Columns.Add("ExamType", typeof(string));

            if (gvcourse.Rows.Count > 0)
            {
                for (int h = 0; h < gvcourse.Rows.Count; h++)
                {
                    TextBox box5 = (TextBox)gvcourse.Rows[h].Cells[5].FindControl("txtspartcode");
                    TextBox box6 = (TextBox)gvcourse.Rows[h].Cells[6].FindControl("txtpapercode");
                    TextBox box7 = (TextBox)gvcourse.Rows[h].Cells[3].FindControl("txtexamtype");
                    TextBox box8 = (TextBox)gvcourse.Rows[h].Cells[7].FindControl("ptypecode");
                    if (box5.Text != "" && box6.Text != "" && box7.Text != "" && box8.Text != "")
                    {
                        dr4 = dtcourse.Select("course =" + box6.Text);
                        if (dr4.Length == 0)
                        {
                            dtcourse.Rows.Add(box6.Text, box5.Text, box8.Text, box7.Text);
                            if (box7.Text != "N")
                            {
                                dtattendance.Rows.Add(box6.Text, box5.Text, box8.Text, box7.Text);
                            }
                        }
                    }
                }
            }

            string gender = GenderM.Checked == true ? "M" : "F";
            RegNo = (string)ViewState["RegNo"];
            string connectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = connection.CreateCommand();
           SqlTransaction transaction = null;
            try
            {
                connection.Open();
                transaction = connection.BeginTransaction();
                command.Transaction = transaction;
                command.CommandText = "Insert INto EXAMPAPERDETAIL_History Select * From EXAMPAPERDETAIL Where UnivRollNo = '" + RollNo.Text.Trim().ToString() + "' and ExamSession = '" + ExamType.SelectedItem.ToString() + "'";
                command.ExecuteNonQuery();
                
                command.CommandText = "Delete From EXAMPAPERDETAIL Where UnivRollNo = '" + RollNo.Text.Trim().ToString() + "' and ExamSession = '" + ExamType.SelectedItem.ToString() + "'";
                command.ExecuteNonQuery();              
                command.CommandText = "Delete From Attendance Where UnivRollNo = '" + RollNo.Text.Trim().ToString() + "' and ExamSession = '" + ExamType.SelectedItem.ToString() + "'";
                command.ExecuteNonQuery();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    try
                    {
                        command.CommandText = "INSERT INTO EXAM(UnivRollNo, CollCode, ClassRollNo, ExamYear, StreamCode,StreamPartCode, SubCode, ExamFeeAmt," +
                            " PaymentId, PaymentDate, ExamFormNo, ExamType, UserId, EntryOptDateTime, Gender, ModeOfExam, ExamCollCode, ModeOfPayment, Bank, " +
                            " RegNo, ExamSession) VALUES ('" + RollNo.Text.Trim() + "','002','" + RollNo.Text.Trim() + "','" + RegFormEntryYear.Text.Trim() + "', " +
                            " '" + streamcode + "','" + dt.Rows[i]["sem"].ToString() + "','" + subcode + "','" + ExamFeeAmt.Text.Trim() + "','" + SCBNo.Text.Trim() + "'," +
                            " '" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(SCBDate.Text.Trim())) + "','" + Program.SelectedValue + RollNo.Text.Trim() + dt.Rows[i]["sem"].ToString() + "'," +
                            " '" + dt.Rows[i]["examtype"].ToString() + "','" + Session["UserId"].ToString() + "','" + string.Format("{0:MM/dd/yyyy}", System.DateTime.Now) + "'," +
                            " '" + gender + "','E','002','" + ddlPaymentmode.SelectedItem.ToString() + "','" + txtbankname.Text.Trim() + "','" + RegNo + "','" + ExamType.SelectedItem.ToString() + "')";
                        command.ExecuteNonQuery();
                    }
                    catch
                    {
 
                    }
                }
                for (int j = 0; j < dtcourse.Rows.Count; j++)
                {

                    command.CommandText = "INSERT INTO EXAMPAPERDETAIL (RegNo, UnivRollNo, StreamPartCode, SubPaperCode, PaperType, ExamYear, ExamType," +
                        " ExamSession) VALUES ('" + RegNo + "','" + RollNo.Text.Trim().ToString() + "','" + dtcourse.Rows[j]["StreamPartCode"].ToString() + "'," +
                        " '" + dtcourse.Rows[j]["course"].ToString() + "','" + dtcourse.Rows[j]["PaperType"].ToString() + "','" + RegFormEntryYear.Text + "'," +
                        " '" + dtcourse.Rows[j]["ExamType"].ToString() + "','" + ExamType.SelectedItem.ToString() + "')";
                    command.ExecuteNonQuery();
                }
                for (int j = 0; j < dtattendance.Rows.Count; j++)
                {

                    command.CommandText = "INSERT INTO Attendance (RegNo, UnivRollNo, StreamPartCode, SubPaperCode, PaperType, Examyear, ExamSession," +
                        " ExamType) VALUES ('" + RegNo + "','" + RollNo.Text.Trim().ToString() + "','" + dtattendance.Rows[j]["StreamPartCode"].ToString() + "'," +
                        " '" + dtattendance.Rows[j]["course"].ToString() + "','" + dtattendance.Rows[j]["PaperType"].ToString() + "','" + RegFormEntryYear.Text + "'," +
                        " '" + ExamType.SelectedItem.ToString() + "','" + dtattendance.Rows[j]["ExamType"].ToString() + "')";
                    command.ExecuteNonQuery();
                }
                transaction.Commit();
                LblMsg.Text = "Exam Form Successfully Saved";
            }
            catch(Exception ex)
            {
                transaction.Rollback();
                LblMsg.Text = ex.Message;
            }
            finally
            {
                connection.Close();
            }

            //for (int i = 0; i < dt.Rows.Count; i++)
            //{
            //    val[5] = dt.Rows[i]["sem"].ToString();
            //    string examformno = Program.SelectedValue + RollNo.Text.Trim() + dt.Rows[i]["sem"].ToString();
            //    val[10] = examformno;
            //    val[11] = dt.Rows[i]["examtype"].ToString();
            //    SaveFlag = NicService.SaveData("Exam", col, val);
            //}


        }
        catch (Exception ex)
        {
            LblMsg.Text = ex.ToString();
        }

    }
        string examsession1;
    protected void SaveExampaper()
    {
        dr1 = null;
        // DataTable dtexampaper = new DataTable();
        DataTable dtcourse = new DataTable();
        dtcourse.Columns.Add("course");
        dtcourse.Columns.Add("StreamPartCode", typeof(string));
        dtcourse.Columns.Add("PaperType", typeof(string));
        dtcourse.Columns.Add("ExamType", typeof(string));
        examsession1 = ExamType.SelectedItem.ToString();

        DataTable dtattendance = new DataTable();
        dtattendance.Columns.Add("course");
        dtattendance.Columns.Add("StreamPartCode", typeof(string));
        dtattendance.Columns.Add("PaperType", typeof(string));
        dtattendance.Columns.Add("ExamType", typeof(string));
        //if (ddlsqc1.SelectedItem.ToString() != "NA")
        //{
        if (gvcourse.Rows.Count > 0)
        {
            for (int h = 0; h < gvcourse.Rows.Count; h++)
            {
                TextBox box5 = (TextBox)gvcourse.Rows[h].Cells[5].FindControl("txtspartcode");
                TextBox box6 = (TextBox)gvcourse.Rows[h].Cells[6].FindControl("txtpapercode");
                TextBox box7 = (TextBox)gvcourse.Rows[h].Cells[3].FindControl("txtexamtype");
                TextBox box8 = (TextBox)gvcourse.Rows[h].Cells[7].FindControl("ptypecode");
                if (box5.Text != "" && box6.Text != "" && box7.Text != "" && box8.Text != "")
                {
                    dr1 = dtcourse.Select("course =" + box6.Text);
                    if (dr1.Length == 0)
                    {
                        dtcourse.Rows.Add(box6.Text, box5.Text, box8.Text, box7.Text);
                        if (box7.Text != "N")
                        {
                            dtattendance.Rows.Add(box6.Text, box5.Text, box8.Text, box7.Text);
                        }
                    }
                }
            }
        }
        UnivService.Service1 NicService = new UnivService.Service1();
        for (int j = 0; j < dtcourse.Rows.Count; j++)
        {

            try
            {

                string SaveFlag = "";
                string[] col = new string[8];
                string[] val = new string[8];


                // Colume Variable--Field Name
                col[0] = "RegNo"; val[0] = RegNo;
                col[1] = "UnivRollNo"; val[1] = RollNo.Text.Trim().ToString();
                col[2] = "StreamPartCode"; val[2] = dtcourse.Rows[j]["StreamPartCode"].ToString();
                col[3] = "SubPaperCode"; val[3] = dtcourse.Rows[j]["course"].ToString();
                col[4] = "PaperType"; val[4] = dtcourse.Rows[j]["PaperType"].ToString();
                col[5] = "ExamYear"; val[5] = RegFormEntryYear.Text;
                col[6] = "ExamType"; val[6] = dtcourse.Rows[j]["ExamType"].ToString();
                col[7] = "ExamSession"; val[7] = examsession1;

                // UnivService.Service1 NicService = new UnivService.Service1();
                SaveFlag = NicService.SaveData("ExamPaperDetail", col, val);
                //SaveFlag = NicService.SaveData("Attendance", col, val);
                if (SaveFlag == "1")
                {
                    LblMsg.Text = "";
                }
                else
                {
                    LblMsg.Text = SaveFlag.ToString();
                }

            }

            catch (Exception ex)
            {
                LblMsg.Text = ex.Message;
            }


        }
        for (int j = 0; j < dtattendance.Rows.Count; j++)
        {

            try
            {

                string SaveFlag = "";
                string[] col = new string[8];
                string[] val = new string[8];


                // Colume Variable--Field Name
                col[0] = "RegNo"; val[0] = RegNo;
                col[1] = "UnivRollNo"; val[1] = RollNo.Text.Trim().ToString();
                col[2] = "StreamPartCode"; val[2] = dtattendance.Rows[j]["StreamPartCode"].ToString();
                col[3] = "SubPaperCode"; val[3] = dtattendance.Rows[j]["course"].ToString();
                col[4] = "PaperType"; val[4] = dtattendance.Rows[j]["PaperType"].ToString();
                col[5] = "ExamYear"; val[5] = RegFormEntryYear.Text;
                col[6] = "ExamType"; val[6] = dtattendance.Rows[j]["ExamType"].ToString(); ;
                col[7] = "ExamSession"; val[7] = examsession1;

                // UnivService.Service1 NicService = new UnivService.Service1();
                SaveFlag = NicService.SaveData("Attendance", col, val);
                if (SaveFlag == "1")
                {
                    LblMsg.Text = "";
                }
                else
                {
                    LblMsg.Text = SaveFlag.ToString();
                }

            }

            catch (Exception ex)
            {
                LblMsg.Text = ex.Message;
            }


        }

    }


    string examsession = ""; DataSet dscourse; DataSet dsstuvalidate; string stremtypecode = "";
    protected void BtnReg_Click(object sender, EventArgs e)
    {
       
        Refreshcontrols();
        try
        {
           
            string ackno = "";
            LblMsg.Text = "";

            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
            cmd.Connection = con;
            SqlDataReader reader;
         /*    con.Open();
            
           cmd.CommandText = "select UnivRollNo,ExamYear, Remarks,UnfairMeans.Year  from ExpelledStudents,UnfairMeans where UnivRollNo='" + RollNo.Text.ToString().Trim() + "' And DebarredFromExam='Y' order by Examyear desc";
            reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                reader.Read();
                // condition
                //Expelled Exam Year+ No. of years 4 Expelled => CurrentExam Year

                if (int.Parse(reader["ExamYear"].ToString()) + int.Parse(reader[3].ToString()) <= int.Parse(DateTime.Now.Year.ToString()))
                {

                }
                else
                {
                    reader.Read();
                    LblMsg.Text = "Roll No.-" + reader["UnivRollNo"].ToString() + " has unfair case-" + reader["Remarks"].ToString() + " in exam year " + reader["ExamYear"].ToString() + ".... PLZ Contact Examination incharge";
                    reader.Close();
                    con.Close();
                    return;
                }
            }
            reader.Close();
            */
            string regvalue = ""; string sql1 = "";
            UnivService.Service1 NICService = new UnivService.Service1();
            if (RollNo.Text.ToString().IndexOf('A') > 0 || RollNo.Text.ToString().IndexOf('B') > 0)
            {
                sql1 = "SELECT Distinct REGISTRATION.RegNo FROM EXAMPAPERDETAIL INNER JOIN REGISTRATION ON " +
                    " EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE (EXAMPAPERDETAIL.UnivRollNo = '" + RollNo.Text.Trim() + "') " +
                    " AND (EXAMPAPERDETAIL.RegNo IS NOT NULL)";
            }
            else sql1 = "Select RegNo From REGISTRATION Where TempRollno = '" + RollNo.Text.ToString().Trim() + "'";

            RegNo = NICService.GetNewCode(sql1);
            ViewState["RegNo"] = RegNo;


            sql1 = "Select StreamPartCode From Exam Where univRollno = '" + RollNo.Text.ToString().Trim() + "' and ExamSession = '"+ExamType.SelectedValue.ToString()+"' order by ExamType Desc";
            ViewState["StreamPartCode"] = NICService.GetNewCode(sql1);

            cmd.CommandText = "select count(*) N from registration where RegNo='" + RegNo + "' "; 
            SqlDataReader rd;                     
            con.Open();
            rd = cmd.ExecuteReader();
            rd.Read();
            string temp = rd["N"].ToString();
            con.Close();
            rd.Close();

            //Check max duration
            string maxduration = "";
            if (temp == "2")
            {
                cmd.CommandText = "SELECT REGISTRATION.CourseSession,REGISTRATION.StreamCode,STREAM.StreamTypeCode " +
                " FROM REGISTRATION INNER JOIN STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode " +
                " WHERE REGISTRATION.RegNo = '" + RegNo + "' AND REGISTRATION.MigrationStatus = 'N' and IsOld='Y'";
            }
            else
            {
                cmd.CommandText = "SELECT REGISTRATION.CourseSession,REGISTRATION.StreamCode,STREAM.StreamTypeCode " +
                " FROM REGISTRATION INNER JOIN STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode " +
                " WHERE REGISTRATION.RegNo = '" + RegNo + "' AND (REGISTRATION.MigrationStatus = 'N' or REGISTRATION.MigrationStatus IS NULL)";
            }
            
            con.Open();
            
            reader = cmd.ExecuteReader();
           if (reader.HasRows) // Seesion Check
            {
                reader.Read();
                stremtypecode = reader["StreamTypeCode"].ToString();
             /*   string yr = (reader["CourseSession"].ToString()).Substring(0, 4);
                maxduration = NicService.GetNewCode("Select MaxDuration From Stream Where StreamCode='" + reader["StreamCode"].ToString() + "'");
                if ((int.Parse(yr) + int.Parse(maxduration)) < int.Parse(System.DateTime.Now.Year.ToString()))
                {
                    LblMsg.Text = "Your session is expired. Please contact exam admin";
                    reader.Close();
                    con.Close();
                    return;
                }*/
            }
            con.Close();
            reader.Close(); 
            // Check Student eligibility for appear in Special Exam
            //dsstuvalidate = chkfn.SelectDataset("SELECT Distinct TRBTec.SubPaperCode, COURSEPAPERS.PaperAbbr FROM TRBTec " +
            //    " INNER JOIN COURSEPAPERS ON TRBTec.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE (TRBTec.Grade " +
            //    " IN ('F', 'F*','I')) AND (TRBTec.RegNo='" + RegNo + "') AND (TRBTec.ExamSession " +
            //    " IN (Select Top(2) ExamSession From ExamSession order by " +
            //    " CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4) As Datetime) desc))");
            fillbncourse();

             
            
            if (temp == "2") 
            {
                cmd.CommandText = " select AckNo,ApplicantName,FatherName,MotherName,DOB,Gender,MaritalStatus,CastCode,NationalityCode," +
     "CollCode,AdmissionDate,RegNo,CourseSession,PresentAddress1,PresentAddress2,PresentDistrictCode,PresentPinCode," +
     "ReligionCode,CourseSession  from Registration where RegNo='" + RegNo + "' And MigrationStatus='N' and IsOld='Y'";
            }
            else
            {
                cmd.CommandText = "select AckNo,ApplicantName,FatherName,MotherName,DOB,Gender,CastCode,NationalityCode,CollCode," +
                    "AdmissionDate,RegNo,Streamcode,StreamPartcode,CourseSession,TempRollNo,ReligionCode from Registration where " +
                    " RegNo='" + RegNo + "' And (REGISTRATION.MigrationStatus = 'N' or REGISTRATION.MigrationStatus IS NULL)";  
                  
            }
            LblMsg.Text = "";
            con.Open();
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();              
                ackno = reader["AckNo"].ToString();
                             
                ApplicantName.Text = reader["ApplicantName"].ToString();
               
                if (reader["FatherName"].ToString() != "") FatherName.Text = reader["FatherName"].ToString();
                else FatherName.Text = "Data Unavailable";
                if (reader["MotherName"].ToString()!="") MotherName.Text = reader["MotherName"].ToString();
                else MotherName.Text = "Data Unavailable";
                if (reader["DOB"].ToString() == "") DOB.Text = "Data Unavailable";
                else DOB.Text = string.Format("{0:dd/MM/yyyy}", Convert.ToDateTime(reader["DOB"]));

                if (reader["ReligionCode"].ToString()!="") ReligionCode.SelectedValue = reader["ReligionCode"].ToString();
                CasteCode.SelectedValue = reader["CastCode"].ToString();
                //Program.SelectedValue = reader["Streamcode"].ToString();
                //ddlbranch.SelectedValue = reader["StreamPartcode"].ToString();
                PopulateDDL popddl = new PopulateDDL();
                popddl.Popualate(Program, "Stream", "Select Stream, StreamCode from Stream Where StreamCode = '" + reader["Streamcode"].ToString() + "' ", "Stream", "StreamCode");

                //popddl.Popualate(Semester, "STREAMPART", "Select StreamPartCode,STREAMPART from STREAMPART where StreamCode in ('" + Program.SelectedValue + "','00')  order by STREAMPART", "STREAMPART", "StreamPartCode");
                popddl.Popualate(ddlbranch, "Stream", "Select StreamAbbr, StreamCode from Stream Where StreamCode = '" + reader["Streamcode"].ToString() + "' ", "StreamAbbr", "StreamCode");                //Select StreamPartCode,STREAMPART from STREAMPART where StreamCode = '07'
                //popddl.Popualate(ddlbacklogsemester, "STREAMPART", "Select StreamPartCode,STREAMPART from STREAMPART where StreamCode  in ('" + Program.SelectedValue + "','00')  order by STREAMPART", "STREAMPART", "StreamPartCode");
                //string streamcode = reader["Streamcode"].ToString();
                //string streampartcode = reader["StreamPartcode"].ToString();

                txtrollno.Text = RollNo.Text ;
              
                txtenrollmentno.Text = reader["AckNo"].ToString();
                              

                if (reader["Gender"].ToString() == "M")
                {
                    GenderF.Checked = false;
                    GenderM.Checked = true;
                }
                else
                {
                    GenderM.Checked = false;
                    GenderF.Checked = true;
                }

                if (reader["CourseSession"].ToString() != "")
                {
                    Year1.Text = (reader["CourseSession"].ToString()).Substring(0, 4);
                    Year2.Text = (reader["CourseSession"].ToString()).Substring(5, 4);
                }
                reader.Close();



                DataSet dspaymentdetails = chkfn.SelectDataset("SELECT ModeOfPayment,ExamYear,PaymentId ,Bank, ExamFeeAmt, convert(varchar,convert(datetime,PaymentDate,105),103) As paydate FROM EXAM Where ExamSession = '" + ExamType.SelectedItem.ToString() + "' AND RegNo = '" + RegNo + "'");
                if (dspaymentdetails.Tables[0].Rows.Count > 0)
                {
                    ddlPaymentmode.SelectedValue = dspaymentdetails.Tables[0].Rows[0]["ModeOfPayment"].ToString();
                    txtbankname.Text = dspaymentdetails.Tables[0].Rows[0]["Bank"].ToString();
                    ExamFeeAmt.Text = dspaymentdetails.Tables[0].Rows[0]["ExamFeeAmt"].ToString();
                    SCBDate.Text = dspaymentdetails.Tables[0].Rows[0]["paydate"].ToString();
                    RegFormEntryYear.Text = dspaymentdetails.Tables[0].Rows[0]["ExamYear"].ToString();
                    SCBNo.Text = dspaymentdetails.Tables[0].Rows[0]["PaymentId"].ToString();
                    
                }
                //Image Load

                ImageUpload imgUpload = new ImageUpload();
                string strFileName = imgUpload.Image_Load(ackno);


                if (strFileName.ToString().Contains("temp"))
                {


                    string photo = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/temp.jpg";

                    string strRightNow = "";
                    string IUrl = "";

                    strRightNow = System.DateTime.Now.ToString("ddMMyyyyHHmmss");
                    IUrl = photo + "?img=" + strRightNow;

                    Image3.ImageUrl = IUrl;
                    Image3.DataBind();


                }
                else if (strFileName.ToString().Contains("UploadPhoto"))
                {

                    Image3.ImageUrl = Request.Url.AbsoluteUri.Substring(0, Request.Url.AbsoluteUri.LastIndexOf("/") + 1) + @"image/UploadPhoto.JPG";
                    Image3.DataBind();

                }

                else
                {
                    LblMsg.Text = "Error" + strFileName;

                }

                fillcourse();
            }
            else
            {
                LblMsg.Text = " Please check ROll no.";
                //Panel2.Visible = false;
                RollNo.Focus();
            }

        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }


    }

    private void fillbncourse()
    {
        string sql1 = "";
        LblMsg.Text = "";
        UnivService.Service1 NICService = new UnivService.Service1();
        if (RollNo.Text.ToString().IndexOf('A') > 0 || RollNo.Text.ToString().IndexOf('B') > 0)
        {
            sql1 = "SELECT Distinct REGISTRATION.RegNo FROM EXAMPAPERDETAIL INNER JOIN REGISTRATION ON " +
                " EXAMPAPERDETAIL.RegNo = REGISTRATION.RegNo WHERE (EXAMPAPERDETAIL.UnivRollNo = '" + RollNo.Text.Trim() + "') " +
                " AND (EXAMPAPERDETAIL.RegNo IS NOT NULL)";
        }
        else sql1 = "Select RegNo From REGISTRATION Where TempRollno = '" + RollNo.Text.ToString().Trim() + "'";

        RegNo = NICService.GetNewCode(sql1);
        if (stremtypecode == "01")
        {
            dsstuvalidate = chkfn.SelectDataset("SELECT COURSEPAPERS.PaperAbbr, CourseCodeOfferedDetail.SubPaperCode  " + 
                " FROM CourseCodeOfferedDetail INNER JOIN COURSEPAPERS ON CourseCodeOfferedDetail.SubPaperCode = COURSEPAPERS.SubPaperCode " + 
                " WHERE (CourseCodeOfferedDetail.CourseCodeOfferedId IN (SELECT DISTINCT Id FROM CourseCodeOffered WHERE (ExamSession = '"+ExamType.SelectedValue.ToString()+"') " +
                " AND (StreamPartCode = '" + ViewState["StreamPartCode"].ToString() + "'))) Union SELECT Distinct COURSEPAPERS.PaperAbbr, cgpa.SubPaperCode FROM cgpa INNER JOIN " +
                 " COURSEPAPERS ON cgpa.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE cgpa.RegNo = '" + RegNo + "' " +
                 " AND cgpa.Grade IN ('F*','F','I','X')");
        }
        else
        {
            dsstuvalidate = chkfn.SelectDataset("SELECT  COURSEPAPERS.PaperAbbr , CourseCodeOfferedDetail.SubPaperCode " +
                " FROM CourseCodeOfferedDetail INNER JOIN COURSEPAPERS ON CourseCodeOfferedDetail.SubPaperCode = COURSEPAPERS.SubPaperCode " +
                " WHERE (CourseCodeOfferedDetail.CourseCodeOfferedId IN (SELECT DISTINCT Id FROM CourseCodeOffered WHERE (ExamSession = '" + ExamType.SelectedValue.ToString() + "') " +
                " AND (StreamPartCode = '" + ViewState["StreamPartCode"].ToString() + "'))) Union SELECT Distinct COURSEPAPERS.PaperAbbr, cgpa_Mtec.SubPaperCode FROM cgpa_Mtec INNER JOIN " +
                " COURSEPAPERS ON cgpa_Mtec.SubPaperCode = COURSEPAPERS.SubPaperCode WHERE cgpa_Mtec.RegNo = '" + RegNo + "' " +
                " AND cgpa_Mtec.Grade IN ('F*','F','I','X')");
        }

        if (dsstuvalidate.Tables[0].Rows.Count > 0)
        {

            ddlcourse.DataSource = dsstuvalidate.Tables[0];
            ddlcourse.DataTextField = "PaperAbbr";
            ddlcourse.DataValueField = "SubPaperCode";
            ddlcourse.DataBind();

            ddlcourse.Items.Insert(0, new ListItem("--Select--", "0"));

            //ddlexamtype.Items.Clear();
            //ddlexamtype.Items.Insert(0, new ListItem("Select", "0"));
            //ddlexamtype.Items.Insert(1, new ListItem("B", "B"));
            //ddlexamtype.Items.Insert(2, new ListItem("N", "N"));
        }
        else
        {
            LblMsg.Text = "Course paper(s) not found.";
            return;
        }
    }
    private void fillcourse()
    {

        dt1.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column1", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column2", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column3", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column4", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column5", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column6", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column7", typeof(string)));


        if (stremtypecode == "01")
        {
            sql = "SELECT STREAMPART.StreamPart, EXAMPAPERDETAIL.ExamType, COURSEPAPERS.PaperName, EXAMPAPERDETAIL.StreamPartCode," +
            " COURSEPAPERS.PaperAbbr, EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.PaperType FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS " +
            " ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode " +
            " Where Univrollno = '" + RollNo.Text.Trim().ToString() + "' AND ExamSession = '" + ExamType.SelectedItem + "'";
        }
        else
        {
            sql = "SELECT STREAMPART.StreamPart, EXAMPAPERDETAIL.ExamType, COURSEPAPERS.PaperName, EXAMPAPERDETAIL.StreamPartCode," +
                       " COURSEPAPERS.PaperAbbr, EXAMPAPERDETAIL.SubPaperCode, EXAMPAPERDETAIL.PaperType FROM EXAMPAPERDETAIL INNER JOIN COURSEPAPERS " +
                       " ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN STREAMPART ON EXAMPAPERDETAIL.StreamPartCode = STREAMPART.StreamPartCode " +
                       " Where Univrollno = '" + RollNo.Text.Trim().ToString() + "' AND ExamSession = '" + ExamType.SelectedItem + "'";
        }
        DataSet dsaddrec = chkfn.SelectDataset(sql);
        if (dsaddrec.Tables[0].Rows.Count > 0)
        {
            for (int r = 0; r < dsaddrec.Tables[0].Rows.Count; r++)
            {
                dr = dt1.NewRow();
                dr["RowNumber"] = 1 + r;
                dr["Column1"] = dsaddrec.Tables[0].Rows[r]["PaperAbbr"].ToString();
                dr["Column2"] = dsaddrec.Tables[0].Rows[r]["StreamPart"].ToString();
                dr["Column3"] = dsaddrec.Tables[0].Rows[r]["ExamType"].ToString();
                dr["Column4"] = dsaddrec.Tables[0].Rows[r]["PaperName"].ToString();
                dr["Column5"] = dsaddrec.Tables[0].Rows[r]["Streampartcode"].ToString();
                dr["Column6"] = dsaddrec.Tables[0].Rows[r]["SubPaperCode"].ToString();
                dr["Column7"] = dsaddrec.Tables[0].Rows[r]["PaperType"].ToString();
                dt1.Rows.Add(dr);
            }
            //dr = dt.NewRow();
            //Store the DataTable in ViewState

            ViewState["CurrentTable"] = dt1;
            gvcourse.DataSource = dt1;
            gvcourse.DataBind();

           
        }
        else
        {
            ViewState["CurrentTable"] = dt1;
            ddlPaymentmode.Enabled = true;
            SCBNo.Enabled = true;
            SCBDate.Enabled = true;
            txtbankname.Enabled = true;
            ExamFeeAmt.Enabled = true;
        }
        SetPreviousData();
        checklink();
        
    }
    private void checklink()
    {
        DataSet nonelective = new DataSet();
        object spartcode = chkfn.singlevalue("Select StreamPartCode From ExamPaperDetail Where Univrollno = '" + RollNo.Text + "' And ExamSession = '" + ExamType.SelectedItem.ToString() + "' and ExamType = 'R'");
        if (spartcode == null)
        {
           /* DataSet dsspartcode = chkfn.SelectDataset("Select Distinct StreamPartCode From ExamPaperDetail Where Univrollno = '" + RollNo.Text + "' And ExamSession = '" + ExamType.SelectedItem.ToString() + "'");
            for (int y = 0; y < dsspartcode.Tables[0].Rows.Count; y++)
            {
                nonelective = chkfn.SelectDataset("Select corecourses from  (select * from (select program, CourseSession,ExamSession, " +
                           " Semester,CoreCourseCode1,  CoreCourseCode2,CoreCourseCode3,CoreCourseCode4,CoreCourseCode5, CoreCourseCode6, " +
                           " CoreCourseCode7,EleCourseCode1,EleCourseCode2,  Stream.StreamCode,streampart.StreamPartCode from AssignCoursePaper " +
                           " inner join STREAM  on AssignCoursePaper.program=STREAM.StreamAbbr inner join STREAMPART on " +
                           " STREAMPART.StreamPart=AssignCoursePaper.Semester AND  STREAM.StreamCode = STREAMPART.StreamCode where " +
                           " Stream.StreamCode='" + ddlbranch.SelectedValue + "' and StreamPartCode='" + dsspartcode.Tables[0].Rows[y]["StreamPartCode"].ToString() + "' and ExamSession='" + ExamType.SelectedItem.ToString() + "')sa  Unpivot " +
                           " (corecourses For coursecode in (CoreCourseCode1,CoreCourseCode2,CoreCourseCode3,CoreCourseCode4,CoreCourseCode5, " +
                           " CoreCourseCode6,CoreCourseCode7,EleCourseCode1,EleCourseCode2)) as ds  where corecourses<>'NA') as final inner " +
                           " join COURSEPAPERS on final.StreamCode=COURSEPAPERS.StreamCode  and final.StreamPartCode=COURSEPAPERS.StreamPartCode " +
                           " and final.corecourses=COURSEPAPERS.PaperAbbr ");

                for (int t = 0; t < gvcourse.Rows.Count; t++)
                {
                    if (nonelective.Tables[0].Rows.Count > 0)
                    {
                        string coursevalue = Convert.ToString(((TextBox)gvcourse.Rows[t].FindControl("txtcoursecode")).Text);
                        DataRow[] dr2 = nonelective.Tables[0].Select("corecourses = '" + coursevalue + "'");
                        if (dr2.Length > 0)
                        {
                            gvcourse.Rows[t].Cells[8].Enabled = false;
                        }
                    }
                }
            } */
        }
        else
        {
            nonelective = chkfn.SelectDataset("Select corecourses from  (select * from (select program, CourseSession,ExamSession, " +
                " Semester,CoreCourseCode1,  CoreCourseCode2,CoreCourseCode3,CoreCourseCode4,CoreCourseCode5, CoreCourseCode6, " +
                " CoreCourseCode7,EleCourseCode1,EleCourseCode2,  Stream.StreamCode,streampart.StreamPartCode from AssignCoursePaper " +
                " inner join STREAM  on AssignCoursePaper.program=STREAM.StreamAbbr inner join STREAMPART on " +
                " STREAMPART.StreamPart=AssignCoursePaper.Semester AND  STREAM.StreamCode = STREAMPART.StreamCode where " +
                " Stream.StreamCode='" + ddlbranch.SelectedValue + "' and StreamPartCode='" + spartcode.ToString() + "' and ExamSession='" + ExamType.SelectedItem.ToString() + "')sa  Unpivot " +
                " (corecourses For coursecode in (CoreCourseCode1,CoreCourseCode2,CoreCourseCode3,CoreCourseCode4,CoreCourseCode5, " +
                " CoreCourseCode6,CoreCourseCode7,EleCourseCode1,EleCourseCode2)) as ds  where corecourses<>'NA') as final inner " +
                " join COURSEPAPERS on final.StreamCode=COURSEPAPERS.StreamCode  and final.StreamPartCode=COURSEPAPERS.StreamPartCode " +
                " and final.corecourses=COURSEPAPERS.PaperAbbr ");

            for (int t = 0; t < gvcourse.Rows.Count; t++)
            {
                if (nonelective.Tables[0].Rows.Count > 0)
                {
                    string coursevalue = Convert.ToString(((TextBox)gvcourse.Rows[t].FindControl("txtcoursecode")).Text);
                    DataRow[] dr2 = nonelective.Tables[0].Select("corecourses = '" + coursevalue + "'");
                    if (dr2.Length > 0)
                    {
                        gvcourse.Rows[t].Cells[8].Enabled = false;
                    }
                }
            }
        }
    }
    private TextBox TextBox(TextBox ApplicantName)
    {
        throw new Exception("The method or operation is not implemented.");
    }
    
    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            if (gvcourse.Rows.Count > 0)
            {
               
                SaveExam();
                
            }
            else
            {
                LblMsg.Text = "Invalid Course Selection.";
            }
        
           
            // Save Data in ExamPaperDetail

        }

        catch (Exception ex)
        {
            LblMsg.Text = ex.Message;
        }
    }
         
   
    protected void Refreshcontrols()
    {      
        Program.Items.Clear(); ddlbranch.Items.Clear(); txtrollno.Text = "";
        txtenrollmentno.Text = ""; ddlcourse.Items.Clear(); ddlexamtype.SelectedIndex = 0;
        ViewState["CurrentTable"] = null;
        DataTable dt3 = (DataTable)ViewState["CurrentTable"];
        gvcourse.DataSource = dt3;
        gvcourse.DataBind();

    }
    string sql = "";
    protected void btnadd_Click(object sender, EventArgs e)
    {
        UnivService.Service1 NICService = new UnivService.Service1();
        stremtypecode = NICService.GetNewCode("SELECT STREAM.StreamTypeCode FROM REGISTRATION INNER JOIN " +
         " STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode WHERE REGISTRATION.Ackno = '" + txtenrollmentno.Text + "'");
        AddRow();
        fillbncourse();
    }

    private void AddRow()
    {
        
        if (ViewState["CurrentTable"] != null)
        {

            
            string action = (string)ViewState["Action"];
            if (action == "elective")
            {
                int rowindex = (int)ViewState["index"];
                
                if (rowindex != null)
                {
                    rowindex = rowindex + 1;
                    DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                    foreach (DataRow row in dtCurrentTable.Select())
                    {
                        if (row["RowNumber"].ToString() == rowindex.ToString())
                        {
                            row.Delete();
                        }
                    }
                    dtCurrentTable.AcceptChanges();
                    DataTable dt3 = new DataTable();
                    dt3.Columns.Add(new DataColumn("RowNumber", typeof(string)));
                    dt3.Columns.Add(new DataColumn("Column1", typeof(string)));
                    dt3.Columns.Add(new DataColumn("Column2", typeof(string)));
                    dt3.Columns.Add(new DataColumn("Column3", typeof(string)));
                    dt3.Columns.Add(new DataColumn("Column4", typeof(string)));
                    dt3.Columns.Add(new DataColumn("Column5", typeof(string)));
                    dt3.Columns.Add(new DataColumn("Column6", typeof(string)));
                    dt3.Columns.Add(new DataColumn("Column7", typeof(string)));

                    int rowIndex = 0;
                    for (int l = 0; l < dtCurrentTable.Rows.Count; l++)
                    {
                        dr = dt3.NewRow();
                        dr["RowNumber"] = rowIndex + 1;
                        dr["Column1"] = dtCurrentTable.Rows[l]["Column1"].ToString();
                        dr["Column2"] = dtCurrentTable.Rows[l]["Column2"].ToString();
                        dr["Column3"] = dtCurrentTable.Rows[l]["Column3"].ToString();
                        dr["Column4"] = dtCurrentTable.Rows[l]["Column4"].ToString();
                        dr["Column5"] = dtCurrentTable.Rows[l]["Column5"].ToString();
                        dr["Column6"] = dtCurrentTable.Rows[l]["Column6"].ToString();
                        dr["Column7"] = dtCurrentTable.Rows[l]["Column7"].ToString();

                        dt3.Rows.Add(dr);
                        rowIndex++;
                    }
                    ViewState["CurrentTable"] = dt3;
                }
                sql = " Select PaperAbbr,PaperTypeCode,SubPaperCode,StreamPart,StreamPartCode,PaperName From COURSEPAPERS Where SubPaperCode = '" + ddlcourse.SelectedValue + "'";
            }
            else
            {
                if (stremtypecode == "01")
                {
                    string regno = (string)ViewState["RegNo"];
                    sql = " Select PaperAbbr,PaperTypeCode,SubPaperCode,StreamPart,StreamPartCode,PaperName From COURSEPAPERS Where SubPaperCode = '" + ddlcourse.SelectedValue + "'";
                    //sql = "SELECT COURSEPAPERS.PaperAbbr, COURSEPAPERS.PaperTypeCode, cgpa.SubPaperCode, STREAMPART.StreamPart," +
                    //" cgpa.StreamPart AS Streampartcode,cgpa.Grade,COURSEPAPERS.PaperName FROM cgpa INNER JOIN COURSEPAPERS ON " +
                    //" cgpa.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN STREAMPART ON cgpa.StreamPart = STREAMPART.StreamPartcode " +
                    //" WHERE cgpa.Grade IN ('F', 'F*', 'I','X') AND cgpa.RegNo = '" + regno + "' AND " +
                    //" cgpa.SubPaperCode = '" + ddlcourse.SelectedValue + "'";
                }
                else
                {
                    string regno = (string)ViewState["RegNo"];
                    sql = " Select PaperAbbr,PaperTypeCode,SubPaperCode,StreamPart,StreamPartCode,PaperName From COURSEPAPERS Where SubPaperCode = '" + ddlcourse.SelectedValue + "'";
                }
               
            }
            DataSet dsaddrec = chkfn.SelectDataset(sql);
            if (dsaddrec.Tables[0].Rows.Count>0)
            {
                string ptypecode = "";
                if (dsaddrec.Tables[0].Rows[0]["PaperTypeCode"].ToString() == "01")
                    ptypecode = "P";
                else if (dsaddrec.Tables[0].Rows[0]["PaperTypeCode"].ToString() == "02")
                    ptypecode = "T";
                else if (dsaddrec.Tables[0].Rows[0]["PaperTypeCode"].ToString() == "04")
                    ptypecode = "X";
                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                int index = dtCurrentTable.Rows.Count;
                string extype = ddlexamtype.SelectedItem.ToString();               
                
                 dtCurrentTable.Rows.Add(index + 1, dsaddrec.Tables[0].Rows[0]["PaperAbbr"].ToString(), dsaddrec.Tables[0].Rows[0]["StreamPart"].ToString(), extype, dsaddrec.Tables[0].Rows[0]["PaperName"].ToString(), dsaddrec.Tables[0].Rows[0]["Streampartcode"].ToString(), dsaddrec.Tables[0].Rows[0]["SubPaperCode"].ToString(), ptypecode);
            ViewState["CurrentTable"] = dtCurrentTable;
            gvcourse.DataSource = dtCurrentTable;
            gvcourse.DataBind();
            ViewState["Action"] = null;
            
            }

        }
        SetPreviousData();
        checklink();
    }
       
    private void SetPreviousData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt2 = (DataTable)ViewState["CurrentTable"];
            if (dt2.Rows.Count > 0)
            {
                for (int i = 0; i < dt2.Rows.Count; i++)
                {
                    TextBox box1 = (TextBox)gvcourse.Rows[rowIndex].Cells[1].FindControl("txtcoursecode");
                    TextBox box2 = (TextBox)gvcourse.Rows[rowIndex].Cells[2].FindControl("txtsem");
                    TextBox box3 = (TextBox)gvcourse.Rows[rowIndex].Cells[3].FindControl("txtexamtype");
                    TextBox box4 = (TextBox)gvcourse.Rows[rowIndex].Cells[4].FindControl("txtcoursetitle");
                    TextBox box5 = (TextBox)gvcourse.Rows[rowIndex].Cells[5].FindControl("txtspartcode");
                    TextBox box6 = (TextBox)gvcourse.Rows[rowIndex].Cells[6].FindControl("txtpapercode");
                    TextBox box7 = (TextBox)gvcourse.Rows[rowIndex].Cells[7].FindControl("ptypecode");
                    box1.Text = dt2.Rows[i]["Column1"].ToString();
                    box2.Text = dt2.Rows[i]["Column2"].ToString();
                    box3.Text = dt2.Rows[i]["Column3"].ToString();
                    box4.Text = dt2.Rows[i]["Column4"].ToString();
                    box5.Text = dt2.Rows[i]["Column5"].ToString();
                    box6.Text = dt2.Rows[i]["Column6"].ToString();
                    box7.Text = dt2.Rows[i]["Column7"].ToString();
                    rowIndex++;
                }
            }
        }
    }
    string coursecode = "";
    protected void gvcourse_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "remove")
        {
            GridViewRow gvr = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
            int RowIndex = gvr.RowIndex;
            ViewState["index"] = RowIndex;
             coursecode = Convert.ToString(((TextBox)gvcourse.Rows[RowIndex].FindControl("txtcoursecode")).Text);
            string examtype = Convert.ToString(((TextBox)gvcourse.Rows[RowIndex].FindControl("txtexamtype")).Text);
            string spartcode = Convert.ToString(((TextBox)gvcourse.Rows[RowIndex].FindControl("txtspartcode")).Text);
            
            //if (examtype == "R")
            //{
            //    DataSet dselective1 = chkfn.SelectDataset("Select corecourses,SubPaperCode from (select * from ( SELECT ElectiveCoursePaper.program, " + 
            //        " ElectiveCoursePaper.CourseSession, ElectiveCoursePaper.ExamSession, ElectiveCoursePaper.Semester,ElectiveCoursePaper.CoreCourseCode1," + 
            //        " ElectiveCoursePaper.CoreCourseCode2, ElectiveCoursePaper.CoreCourseCode3, ElectiveCoursePaper.CoreCourseCode4,STREAM.StreamCode, " + 
            //        " STREAMPART.StreamPartCode FROM AssignCoursePaper INNER JOIN ElectiveCoursePaper ON AssignCoursePaper.ExamSession = ElectiveCoursePaper.ExamSession " + 
            //        " AND AssignCoursePaper.Semester = ElectiveCoursePaper.Semester AND AssignCoursePaper.SplCode = ElectiveCoursePaper.SplCode AND " + 
            //        " AssignCoursePaper.program = ElectiveCoursePaper.program AND AssignCoursePaper.EleCourseCode3 = ElectiveCoursePaper.ElectiveId INNER " + 
            //        " JOIN STREAMPART INNER JOIN STREAM ON STREAMPART.StreamCode = STREAM.StreamCode ON AssignCoursePaper.Semester = STREAMPART.StreamPart " +
            //        " AND AssignCoursePaper.program = STREAM.StreamAbbr WHERE (STREAM.StreamCode = '" + ddlbranch.SelectedValue + "') AND (STREAMPART.StreamPartCode = '" + spartcode + "') AND " +
            //        " (AssignCoursePaper.ExamSession = '" + ExamType.SelectedItem.ToString() + "'))sa  Unpivot (corecourses For coursecode in (CoreCourseCode1,CoreCourseCode2," + 
            //        " CoreCourseCode3,CoreCourseCode4)) as ds where corecourses<>'NA') as   final inner join COURSEPAPERS on final.StreamCode=COURSEPAPERS.StreamCode " + 
            //        " and final.StreamPartCode=COURSEPAPERS.StreamPartCode  and final.corecourses=COURSEPAPERS.PaperAbbr ");
            //    DataSet dselective2 = chkfn.SelectDataset("Select corecourses,SubPaperCode from (select * from ( SELECT ElectiveCoursePaper.program, " + 
            //        " ElectiveCoursePaper.CourseSession, ElectiveCoursePaper.ExamSession, ElectiveCoursePaper.Semester,ElectiveCoursePaper.CoreCourseCode1," + 
            //        " ElectiveCoursePaper.CoreCourseCode2, ElectiveCoursePaper.CoreCourseCode3, ElectiveCoursePaper.CoreCourseCode4,STREAM.StreamCode, " + 
            //        " STREAMPART.StreamPartCode FROM AssignCoursePaper INNER JOIN ElectiveCoursePaper ON AssignCoursePaper.ExamSession = ElectiveCoursePaper.ExamSession " + 
            //        " AND AssignCoursePaper.Semester = ElectiveCoursePaper.Semester AND AssignCoursePaper.SplCode = ElectiveCoursePaper.SplCode AND " + 
            //        " AssignCoursePaper.program = ElectiveCoursePaper.program AND AssignCoursePaper.EleCourseCode4 = ElectiveCoursePaper.ElectiveId INNER " + 
            //        " JOIN STREAMPART INNER JOIN STREAM ON STREAMPART.StreamCode = STREAM.StreamCode ON AssignCoursePaper.Semester = STREAMPART.StreamPart " +
            //        " AND AssignCoursePaper.program = STREAM.StreamAbbr WHERE (STREAM.StreamCode = '" + ddlbranch.SelectedValue + "') AND (STREAMPART.StreamPartCode = '" + spartcode + "') AND " +
            //        " (AssignCoursePaper.ExamSession = '" + ExamType.SelectedItem.ToString() + "'))sa  Unpivot (corecourses For coursecode in (CoreCourseCode1,CoreCourseCode2," + 
            //        " CoreCourseCode3,CoreCourseCode4)) as ds where corecourses<>'NA') as   final inner join COURSEPAPERS on final.StreamCode=COURSEPAPERS.StreamCode " + 
            //        " and final.StreamPartCode=COURSEPAPERS.StreamPartCode  and final.corecourses=COURSEPAPERS.PaperAbbr ");
            //    DataSet dselective3 = chkfn.SelectDataset("Select corecourses,SubPaperCode from (select * from ( SELECT ElectiveCoursePaper.program, " +
            //       " ElectiveCoursePaper.CourseSession, ElectiveCoursePaper.ExamSession, ElectiveCoursePaper.Semester,ElectiveCoursePaper.CoreCourseCode1," +
            //       " ElectiveCoursePaper.CoreCourseCode2, ElectiveCoursePaper.CoreCourseCode3, ElectiveCoursePaper.CoreCourseCode4,STREAM.StreamCode, " +
            //       " STREAMPART.StreamPartCode FROM AssignCoursePaper INNER JOIN ElectiveCoursePaper ON AssignCoursePaper.ExamSession = ElectiveCoursePaper.ExamSession " +
            //       " AND AssignCoursePaper.Semester = ElectiveCoursePaper.Semester AND AssignCoursePaper.SplCode = ElectiveCoursePaper.SplCode AND " +
            //       " AssignCoursePaper.program = ElectiveCoursePaper.program AND AssignCoursePaper.EleCourseCode5 = ElectiveCoursePaper.ElectiveId INNER " +
            //       " JOIN STREAMPART INNER JOIN STREAM ON STREAMPART.StreamCode = STREAM.StreamCode ON AssignCoursePaper.Semester = STREAMPART.StreamPart " +
            //       " AND AssignCoursePaper.program = STREAM.StreamAbbr WHERE (STREAM.StreamCode = '" + ddlbranch.SelectedValue + "') AND (STREAMPART.StreamPartCode = '" + spartcode + "') AND " +
            //       " (AssignCoursePaper.ExamSession = '" + ExamType.SelectedItem.ToString() + "'))sa  Unpivot (corecourses For coursecode in (CoreCourseCode1,CoreCourseCode2," +
            //       " CoreCourseCode3,CoreCourseCode4)) as ds where corecourses<>'NA') as   final inner join COURSEPAPERS on final.StreamCode=COURSEPAPERS.StreamCode " +
            //       " and final.StreamPartCode=COURSEPAPERS.StreamPartCode  and final.corecourses=COURSEPAPERS.PaperAbbr ");
            //    if (dselective1.Tables[0].Rows.Count > 0)
            //    {
            //        DataRow[] dr3 = dselective1.Tables[0].Select("corecourses = '" + coursecode + "'");
            //        if (dr3.Length > 0)
            //        {
            //            ddlcourse.DataSource = dselective1.Tables[0];
            //            ddlcourse.DataTextField = "corecourses";
            //            ddlcourse.DataValueField = "SubPaperCode";
            //            ddlcourse.DataBind();
            //            //ddlexamtype.Items.Clear();
            //            //ddlexamtype.Items.Add(new ListItem("R", "R"));
            //            ViewState["Action"] = "elective";
                        
            //        }
            //    }
            //    if (dselective2.Tables[0].Rows.Count > 0)
            //    {
            //        DataRow[] dr3 = dselective2.Tables[0].Select("corecourses = '" + coursecode + "'");
            //        if (dr3.Length > 0)
            //        {
            //            ddlcourse.DataSource = dselective2.Tables[0];
            //            ddlcourse.DataTextField = "corecourses";
            //            ddlcourse.DataValueField = "SubPaperCode";
            //            ddlcourse.DataBind();
            //            ddlexamtype.Items.Clear();
            //            ddlexamtype.Items.Add(new ListItem("R", "R"));
            //            ViewState["Action"] = "elective";
                        
            //        }
            //    }
            //    if (dselective3.Tables[0].Rows.Count > 0)
            //    {
            //        DataRow[] dr3 = dselective3.Tables[0].Select("corecourses = '" + coursecode + "'");
            //        if (dr3.Length > 0)
            //        {
            //            ddlcourse.DataSource = dselective3.Tables[0];
            //            ddlcourse.DataTextField = "corecourses";
            //            ddlcourse.DataValueField = "SubPaperCode";
            //            ddlcourse.DataBind();
            //            ddlexamtype.Items.Clear();
            //            ddlexamtype.Items.Add(new ListItem("R", "R"));
            //            ViewState["Action"] = "elective";

            //        }
            //    }
              
            //}
            //else
            //{
                removerow();
            //}

        }
    }

    protected void removerow()
    {
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            foreach (DataRow row in dtCurrentTable.Select())
            {
                if (row["Column1"].ToString() == coursecode)
                {
                    row.Delete();
                }
            }
            dtCurrentTable.AcceptChanges();
            DataTable dt3 = new DataTable();
            dt3.Columns.Add(new DataColumn("RowNumber", typeof(string)));
            dt3.Columns.Add(new DataColumn("Column1", typeof(string)));
            dt3.Columns.Add(new DataColumn("Column2", typeof(string)));
            dt3.Columns.Add(new DataColumn("Column3", typeof(string)));
            dt3.Columns.Add(new DataColumn("Column4", typeof(string)));
            dt3.Columns.Add(new DataColumn("Column5", typeof(string)));
            dt3.Columns.Add(new DataColumn("Column6", typeof(string)));
            dt3.Columns.Add(new DataColumn("Column7", typeof(string)));

            int rowIndex = 0;
            for (int l = 0; l < dtCurrentTable.Rows.Count; l++)
            {
                dr = dt3.NewRow();
                dr["RowNumber"] = rowIndex + 1;
                dr["Column1"] = dtCurrentTable.Rows[l]["Column1"].ToString();
                dr["Column2"] = dtCurrentTable.Rows[l]["Column2"].ToString();
                dr["Column3"] = dtCurrentTable.Rows[l]["Column3"].ToString();
                dr["Column4"] = dtCurrentTable.Rows[l]["Column4"].ToString();
                dr["Column5"] = dtCurrentTable.Rows[l]["Column5"].ToString();
                dr["Column6"] = dtCurrentTable.Rows[l]["Column6"].ToString();
                dr["Column7"] = dtCurrentTable.Rows[l]["Column7"].ToString();

                dt3.Rows.Add(dr);
                rowIndex++;
            }
            ViewState["CurrentTable"] = dt3;
            gvcourse.DataSource = dt3;
            gvcourse.DataBind();
            SetPreviousData();
            checklink();
        }
    }
    protected void gvcourse_RowDataBound(object sender, GridViewRowEventArgs e)
    {
       
               
    }
    protected void chkbimprovement_CheckedChanged(object sender, EventArgs e)
    {

    }
}
