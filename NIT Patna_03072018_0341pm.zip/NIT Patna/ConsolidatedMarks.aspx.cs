using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
using System.Collections.Generic;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

public partial class MarksEntryDetails2 : System.Web.UI.Page
{
    ReportDocument crystalReport = new ReportDocument();
    string criteria = "false";
    string Subcode;   
    Functionreviseed fn = new Functionreviseed();   
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            Session["checkclear"] = criteria;
            try
            {

                if ((Session["Role"].ToString() != "10") && (Session["Role"].ToString() != "5") && (Session["Role"].ToString() != "4") && (Session["Role"].ToString() != "9") && (Session["Role"].ToString() != "13") && (Session["Role"].ToString() != "15"))
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx?error=RoleNotFoundException");
                }

                ViewState.Add("EditMode", "false");

            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx?error=PageException");
            }
            string strrole = "";
            if (Session["Role"].ToString() == "9")
                strrole = " and UserId='" + Session["UserId"].ToString() + "'";

            PopulateDDL popddl = new PopulateDDL();

            popddl.Popualate(ExamYear, "Year", "Select Distinct Top(2) ExamSession,CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4) AS DATETIME) as examyear From EXAMPAPERDETAIL order by CAST(SUBSTRING(ExamSession,5,3)+ SUBSTRING(ExamSession,9,4) AS DATETIME) DESC", "ExamSession", "ExamSession");
            //ExamYear.Items.Insert(0, new ListItem("--Select--", "00"));
            bindstream();        
           
            StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
            splcode.Items.Insert(0, new ListItem("--Select--", "00"));
            Subject.Items.Insert(0, new ListItem("--Select--", "00"));
            //  ExamYear.Focus();
        }
        
    }

    protected void Page_Unload(object sender, EventArgs e)
    {
        if (crystalReport != null)
        {
            crystalReport.Close();
            crystalReport.Dispose();
        }

    }


    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        StreamPart.Items.Clear();
        Subject.Items.Clear();
        splcode.Items.Clear();
        string strrole = "";
        if (Session["Role"].ToString() == "9")
            strrole = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";
       
        PopulateDDL popddl = new PopulateDDL();
        string strspecilaization = "SELECT CourseSpecialization.SpDescription, CourseSpecialization.SPCode " +
                                   " FROM Faculty_paper_a INNER JOIN COURSEPAPERS ON " +
                                   " Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " +
                                   " CourseSpecialization ON Faculty_paper_a.Splcode = CourseSpecialization.SPCode " +
                                   " WHERE     (Faculty_paper_a.Is_Active IN ('N','Y')) " +
                                   " and COURSEPAPERS.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                                   " GROUP BY CourseSpecialization.SpDescription, CourseSpecialization.SPCode " +
                                   " order by CourseSpecialization.SPCode ";

        popddl.Popualate(splcode, "Specialization", strspecilaization, "SpDescription", "SPCode");
        string strstreampart = "SELECT     STREAMPART.StreamPart,STREAMPART.StreamPartCode "+
                             " FROM         COURSEPAPERS AS COURSEPAPERS_1 INNER JOIN "+
                             " STREAMPART ON COURSEPAPERS_1.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN "+
                             " Faculty_paper_a INNER JOIN "+
                             " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode ON COURSEPAPERS_1.PaperAbbr = COURSEPAPERS.PaperAbbr "+
                             " WHERE     (Faculty_paper_a.Is_Active IN ('N','Y')) " +
                             " and (Faculty_paper_a.splcode='" + splcode.SelectedValue + "') and STREAMPART.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                             " GROUP BY STREAMPART.StreamPartCode, STREAMPART.StreamPart " +
                             " order by StreamPart";


        popddl.Popualate(StreamPart, "StreamPart", strstreampart, "StreamPart", "StreamPartCode");
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
        StreamCode.Focus();
    }
    private void GetPaperCode()
    {

        string Querystr = "";
        string queryjoin = "";

        if (StreamPart.SelectedItem.ToString().IndexOf('A') > 0 || StreamPart.SelectedItem.ToString().IndexOf('B') > 0)
        {
            Querystr = " (COURSEPAPERS.StreamPart = '" + StreamPart.SelectedItem.ToString() + "')";
            queryjoin = "COURSEPAPERS_1.PaperAbbr = COURSEPAPERS.PaperAbbr";
        }
        else
        {
            Querystr = " (COURSEPAPERS.StreamPartCode='" + StreamPart.SelectedValue + "')";
            queryjoin = "COURSEPAPERS_1.SubPaperCode = COURSEPAPERS.SubPaperCode";
        }

        string strrole = "";
        if (Session["Role"].ToString() == "9")
            strrole = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";

        string strcourse = "SELECT     COURSEPAPERS.PaperAbbr " +
                           " FROM         Faculty_paper_a INNER JOIN COURSEPAPERS AS COURSEPAPERS_1 ON " +
                           " Faculty_paper_a.SubPaperCode = COURSEPAPERS_1.SubPaperCode INNER JOIN COURSEPAPERS " +
                            " ON " + queryjoin + " INNER JOIN " +
                            " EXAMPAPERDETAIL ON COURSEPAPERS.SubPaperCode = EXAMPAPERDETAIL.SubPaperCode " +
                          " WHERE     (Faculty_paper_a.Is_Active IN ('N','Y'))   And (Faculty_paper_a.splcode = '" + splcode.SelectedValue + "') " + strrole +
                          " and" + Querystr + " and  (EXAMPAPERDETAIL.ExamSession='" + ExamYear.SelectedValue + "') and ";

        string querypart = " GROUP BY COURSEPAPERS.PaperAbbr ORDER BY COURSEPAPERS.PaperAbbr ";

        PopulateDDL popddl = new PopulateDDL();
        UnivService.Service1 NicService = new UnivService.Service1();
        Subcode = NicService.GetNewCode("select subcode from subject where streamcode='" + StreamCode.SelectedValue + "'");

        popddl.Popualate(Subject, "COURSEPAPERS", strcourse + "(COURSEPAPERS.PaperTypeCode='02' or COURSEPAPERS.PaperTypeCode='01' or COURSEPAPERS.PaperTypeCode='04') and (Faculty_paper_a.PaperType='T' or Faculty_paper_a.PaperType is null)" + querypart, "PaperAbbr", "PaperAbbr");
        
        Subject.Focus();
    }   

    bool HasRecords(DataSet dataSet)
    {
        foreach (DataTable dt in dataSet.Tables) if (dt.Rows.Count > 0) return true;
        return false;
    }
    
    // bool checkclear = false;
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Panel3.Enabled = true;
        StreamPart.SelectedIndex = 0;
        StreamCode.SelectedIndex = 0;
        Subject.Items.Clear();
        PaperMarks.Text = "";
        PTMarks.Text = "";
        panelinterthpract.Visible = false;
        PaperMarks.Text = "";
        LblMsg.Text = "";
        ExamYear.SelectedIndex = 0;
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        bindgrid();
        Panel3.Enabled = false;
    }
    string Query1 = "";
    protected void Subject_SelectedIndexChanged(object sender, EventArgs e)
    {
        bindpapermarks();        
    }
    protected void bindpapermarks()
    {
        UnivService.Service1 NicService = new UnivService.Service1();
       string papercode = NicService.GetNewCode("select Subpapercode from CoursePapers where PaperAbbr='" + Subject.SelectedValue + "' and StreamPartCode = '" + StreamPart.SelectedValue + "'");

       DataSet dsfullmarks = fn.SelectDataset("SELECT ISNULL(COURSEPAPERS.FullMarks,0) AS THFM, ISNULL(PRACTICALPAPERS.FullMarks,0) AS PTFM " +
                     " FROM COURSEPAPERS LEFT OUTER JOIN PRACTICALPAPERS ON COURSEPAPERS.SubPaperCode = PRACTICALPAPERS.SubPaperCode " +
                     " WHERE (COURSEPAPERS.SubPaperCode = '" + papercode + "')");
        if (dsfullmarks.Tables[0].Rows.Count > 0)
        {
            PaperMarks.Text = dsfullmarks.Tables[0].Rows[0]["THFM"].ToString();
            PTMarks.Text = dsfullmarks.Tables[0].Rows[0]["PTFM"].ToString();
        }
    }
    protected void bindgrid()
    {
       string Querystr = "";
        if (StreamPart.SelectedItem.ToString().IndexOf('A') > 0 || StreamPart.SelectedItem.ToString().IndexOf('B') > 0)
        {
            Querystr = " (COURSEPAPERS.StreamPart = '" + StreamPart.SelectedItem.ToString() + "' )";
        }
        else
        {
            Querystr = " (COURSEPAPERS.StreamPartCode='" + StreamPart.SelectedValue + "')";

        }
        string strexamtype = "";
        Query1 = "Select EXAMPAPERDETAIL.UnivRollNo,Attendance.TheoryTotalCl, Attendance.TheoryAttendance, " + 
                " Attendance.ThMedRelaxation, EXAMPAPERDETAIL.TH_Attendance, EXAMPAPERDETAIL.ClassTest1,EXAMPAPERDETAIL.ClassTest2, " + 
                " EXAMPAPERDETAIL.Midsem,Attendance.PracticalTotalCl, Attendance.PracticalAttendance,Attendance.PrMedRelaxation, " + 
                " EXAMPAPERDETAIL.PR_Attendance, EXAMPAPERDETAIL.PracticalRecord,EXAMPAPERDETAIL.PRClassPerfor, " +
                " EXAMPAPERDETAIL.Prpreendsemviva , EXAMPAPERDETAIL.ExamSession, STREAM.StreamAbbr, COURSEPAPERS.PaperAbbr, " +
                " COURSEPAPERS.StreamPart,EXAMPAPERDETAIL.THEndsem, EXAMPAPERDETAIL.PREndSem FROM REGISTRATION INNER JOIN EXAMPAPERDETAIL INNER JOIN " +
                " COURSEPAPERS ON EXAMPAPERDETAIL.SubPaperCode = COURSEPAPERS.SubPaperCode ON REGISTRATION.RegNo = EXAMPAPERDETAIL.RegNo INNER JOIN "+
                " STREAM ON REGISTRATION.StreamCode = STREAM.StreamCode LEFT OUTER JOIN "+
                " Attendance ON EXAMPAPERDETAIL.RegNo = Attendance.RegNo AND EXAMPAPERDETAIL.StreamPartCode = Attendance.StreamPartCode AND  "+
                " EXAMPAPERDETAIL.SubPaperCode = Attendance.SubPaperCode AND EXAMPAPERDETAIL.ExamSession = Attendance.ExamSession "+
                " WHERE EXAMPAPERDETAIL.ExamSession = '" + ExamYear.SelectedValue + "' AND " +
                " COURSEPAPERS.PaperAbbr = '" + Subject.SelectedValue + "' AND ISNULL(REGISTRATION.SplCode,'00')='" + splcode.SelectedValue + "' AND " +
                Querystr + " order by UnivRollNo";

            
                crystalReport.Load(Server.MapPath("~/Report/rptconsomarks.rpt"));
                dsconsomarks objdsconsomarks = GetData(Query1);
                crystalReport.SetDataSource(objdsconsomarks);
                crystalReport.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, false, "ExportedReport");
                //CrystalReportViewer1.ReportSource = crystalReport;
                panelinterthpract.Visible = true;
                LblMsg.Text = "";
            
            //    LblMsg.Text = "<b style=" + "Font-size:13px;" + ">Record(S) not found according to above criteria!";
            
        

    }            
   
    private dsconsomarks GetData(string query)
    {
        string conString = ConfigurationManager.ConnectionStrings["UNIVERSITYConnectionString1"].ConnectionString;
        SqlCommand cmd = new SqlCommand(query);
        using (SqlConnection con = new SqlConnection(conString))
        {
            using (SqlDataAdapter sda = new SqlDataAdapter())
            {
                cmd.Connection = con;

                sda.SelectCommand = cmd;
                using (dsconsomarks objdsconsomarks = new dsconsomarks())
                {
                    sda.Fill(objdsconsomarks, "DataTable1");
                    return objdsconsomarks;
                }
            }
        }
    }
    
    protected void StreamPart_SelectedIndexChanged(object sender, EventArgs e)
    {
        GetPaperCode();
        bindpapermarks();
    }
    protected void splcode_SelectedIndexChanged(object sender, EventArgs e)
    {
        StreamPart.Items.Clear();
        Subject.Items.Clear();

        string strrole = "";
        if (Session["Role"].ToString() == "9")
            strrole = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";

        PopulateDDL popddl = new PopulateDDL();

        string strstreampart = "SELECT     STREAMPART.StreamPart,STREAMPART.StreamPartCode " +
                              " FROM         COURSEPAPERS AS COURSEPAPERS_1 INNER JOIN " +
                              " STREAMPART ON COURSEPAPERS_1.StreamPartCode = STREAMPART.StreamPartCode INNER JOIN " +
                              " Faculty_paper_a INNER JOIN " +
                              " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode ON COURSEPAPERS_1.PaperAbbr = COURSEPAPERS.PaperAbbr " +
                              " WHERE     (Faculty_paper_a.Is_Active = 'Y') " +
                              " and (Faculty_paper_a.splcode='" + splcode.SelectedValue + "') and STREAMPART.StreamCode='" + StreamCode.SelectedValue + "'" + strrole +
                              " GROUP BY STREAMPART.StreamPartCode, STREAMPART.StreamPart " +
                              " order by StreamPart";


        popddl.Popualate(StreamPart, "StreamPart", strstreampart, "StreamPart", "StreamPartCode");
        StreamPart.Items.Insert(0, new ListItem("--Select--", "00"));
        Subject.Items.Insert(0, new ListItem("--Select--", "00"));
        splcode.Focus();
    }
    protected void ExamYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        bindstream();
    }
    protected void bindstream()
    {
        string struserid = "";
        if (Session["Role"].ToString() == "9")
            struserid = "  AND (Faculty_paper_a.UserId = '" + Session["UserId"].ToString() + "') ";
        else struserid = "";
        PopulateDDL popddl = new PopulateDDL();
        string strstream = "SELECT     STREAM.StreamAbbr, STREAM.StreamCode FROM Faculty_paper_a INNER JOIN " +
                          " COURSEPAPERS ON Faculty_paper_a.SubPaperCode = COURSEPAPERS.SubPaperCode INNER JOIN " +
                          " STREAM ON COURSEPAPERS.StreamCode = STREAM.StreamCode " +
                          " Where Faculty_paper_a.Is_Active in ('N','Y') AND (Faculty_paper_a.ExamSession = '" + ExamYear.SelectedItem.ToString() + "') " +
                          " "+ struserid +" GROUP BY STREAM.StreamAbbr, STREAM.StreamCode order by StreamAbbr ";
        popddl.Popualate(StreamCode, "Stream", strstream, "StreamAbbr", "StreamCode");
        StreamCode.Items.Insert(0, new ListItem("--Select--", "00"));
    }
}
