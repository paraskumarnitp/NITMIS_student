using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;
public partial class Subsidiary : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() != "1")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

           
            PopulateDDL popddl = new PopulateDDL();
            
            popddl.Popualate(StreamCode, "Stream", "Select StreamAbbr, StreamCode from Stream order by StreamAbbr", "StreamAbbr", "StreamCode");
            popddl.Popualate(SubCode, "SUBJECT", "Select subcode,SubjectName from Subject where streamcode='" + StreamCode.SelectedValue + "' and streamcode not in (select streamcode from stream where streamtypecode<>'02') order by subjectname", "SubjectName", "subCode");
            //popddl.Popualate(SubCode, "SUBJECT", "Select subcode,SubjectName from Subject where streamcode not in (select streamcode from stream where streamtypecode<>'02') order by subjectname", "SubjectName", "subCode");
            ViewState.Add("EditMode", "false");
        }
    }

    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        Panel2.Visible = true;
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select * from SUBSIDIARY order by SubCode");
        SubsidiaryPaperView.DataSource = ds;
        SubsidiaryPaperView.DataBind();
    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {
        string abc = "";
        Panel2.Visible = false;
        if (ViewState["EditMode"].ToString() == "false")
        {
            string[] col = new string[5];
            string[] val = new string[5];
            
            col[0] = "SubCode";
            col[1] = "FullMarks";
            col[2] = "PassMarks";
            col[3] = "PrFullMarks";
            col[4] = "PrPassMarks";

            Panel2.Visible = false;

            
            val[0] = SubCode.SelectedValue;
            val[1] = FullMarks.Text;
            val[2] = PassMarks.Text;


            // save practical Marks
            if (Practical.Checked == true)
            {
                val[3] = PrFullMarks.Text;
                val[4] = PrPassMarks.Text;
            }
            else
            {
                val[3] = "0";
                val[4] = "0";
            }

            UnivService.Service1 ss = new UnivService.Service1();
            abc = ss.SaveData("Subsidiary", col, val);

            if (abc == "1")
            {
                LblMsg.Text = " Subsidiary Paper is saved successfully. ";
                string popupScript = "<script language='javascript'>" +
                                " alert('Paper is saved successfully." +
                                 "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);
            }

            else
            {
                LblMsg.Text = abc.ToString();
            }
            FullMarks.Text = "";
            PassMarks.Text = "";
            PrFullMarks.Text = "";
            PrPassMarks.Text = "";
            Practical.Checked = false;
            SubCode.Focus();
        }
        else
        {

            UnivService.Service1 ss = new UnivService.Service1();
            abc = " update Subsidiary set FullMarks= '" + FullMarks.Text + "',PassMarks='" + PassMarks.Text + "',PrFullMarks= '" + PrFullMarks.Text + "',PrPassMarks='" + PrPassMarks.Text + "' where SubCode='" + SubsidiaryPaperView.SelectedRow.Cells[1].Text + "'";
            
            
            abc = ss.UpdateData(abc);
            if (abc.ToString() == "ok")
            {
                ViewState.Add("EditMode", "false");
                LblMsg.Text = " Record is updated successfully.";

                
                FullMarks.Text = "";
                PassMarks.Text = "";
                PrFullMarks.Text = "";
                PrPassMarks.Text = "";
                Practical.Checked = false;
                SubCode.Focus();

            }
            else
                LblMsg.Text = abc.ToString();

        }

    }
    protected void SubsidiaryPaperView_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();

        UnivService.Service1 ss = new UnivService.Service1();
        string streamcode=ss.GetNewCode ("Select streamcode from subject where subcode='"+ SubsidiaryPaperView.SelectedRow.Cells[1].Text + "'");
        StreamCode.SelectedValue = streamcode;
        
        popddl.Popualate(SubCode, "SUBJECT", "Select subcode,SubjectName from Subject where streamcode='" + StreamCode.SelectedValue + "' and streamcode not in (select streamcode from stream where streamtypecode<>'02') order by subjectname", "SubjectName", "subCode");
        SubCode.SelectedValue = SubsidiaryPaperView.SelectedRow.Cells[1].Text;
        FullMarks.Text = SubsidiaryPaperView.SelectedRow.Cells[2].Text;
        PassMarks.Text = SubsidiaryPaperView.SelectedRow.Cells[3].Text;
        PrFullMarks.Text = SubsidiaryPaperView.SelectedRow.Cells[4].Text;
        PrPassMarks.Text = SubsidiaryPaperView.SelectedRow.Cells[5].Text;
        Practical.Checked = false;

       
        ViewState.Add("EditMode", "true");
        SubCode.Focus();
    }
    protected void StreamCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateDDL popddl = new PopulateDDL();
        popddl.Popualate(SubCode, "SUBJECT", "Select subcode,SubjectName from Subject where streamcode='" + StreamCode.SelectedValue + "' and streamcode not in (select streamcode from stream where streamtypecode<>'02' and streamtypecode<>'03' ) order by subjectname", "SubjectName", "subCode");
        
    }
}