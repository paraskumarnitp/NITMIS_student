using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NIC.Connection;
using NIC.ApplicationFramework.Data;

public partial class College : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                if (Session["Role"].ToString() != "1")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                }
                PopulateDDL popddl = new PopulateDDL();
                popddl.Popualate(UnivCode, "University", "Select UnivCode,UnivName from University order by UnivName", "UnivName", "UnivCode");
                popddl.Popualate(DistCode, "District", "Select Distcode,DistName from District order by DistName", "DistName", "DistCode");
                UnivService.Service1 ss = new UnivService.Service1();
                string univcode = ss.GetNewCode("select univcode from install");
                UnivCode.SelectedValue = univcode;
                ViewState.Add("EditMode", "false");
            }
        }
        catch (Exception ex)
        {
            Response.Redirect("default.aspx");
        }
    }
    protected void BtnSave_Click(object sender, ImageClickEventArgs e)
    {

        string abc = "";
        Panel2.Visible = false;
        if (ViewState["EditMode"].ToString() == "false")
        {
            
            string[] col = new string[15];
            string[] val = new string[15];

            col[0] = "UnivCode"; val[0] = UnivCode.SelectedValue;
            col[1] = "CollCode";
            col[2] = "CollFullName"; val[2] = CollFullName.Text.Trim();
            col[3] = "CollName"; val[3] = CollName.Text.Trim();
            col[4] = "CollType"; val[4] = CollType.SelectedValue;
            col[5] = "DateOfConst"; val[5] = string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(DateOfConst.Text));
            col[6] = "PrincipalName"; val[6] = PrincipalName.Text.Trim();
            col[7] = "Address1"; val[7] = Address1.Text.Trim();
            col[8] = "Address2"; val[8] = Address2.Text.Trim();
            col[9] = "DistCode"; val[9] = DistCode.SelectedValue;
            col[10] = "PinCode"; val[10] = PinCode.Text.Trim();
            col[11] = "PhoneNo"; val[11] = PhoneNo.Text.Trim();
            col[12] = "Fax"; val[12] = Fax.Text.Trim();
            col[13] = "Email"; val[13] = Email.Text.Trim();
            col[14] = "ExamCapacity"; val[14] = ExamCapacity.Text;

            val[0] = UnivCode.Text.Trim();
            UnivService.Service1 ss = new UnivService.Service1();
            string SQL = "SELECT     ISNULL(MAX(Abs(CollCode)), '0') + 1 AS NewCollCode FROM COLLEGE";
            string NewCollegeCode = ss.GetNewCode(SQL);
            NewCollegeCode = string.Format("{0:D3}", Convert.ToInt16(NewCollegeCode));

            val[1] = string.Format("{0:D3}", Convert.ToInt16(NewCollegeCode));


            abc = ss.SaveData("College", col, val);

            if (abc == "1")
            {
                LblMsg.Text = " College is saved successfully. College Code= " + NewCollegeCode;
                string popupScript = "<script language='javascript'>" +
                                " alert('College is saved successfully. College Code=   " + NewCollegeCode + " ')" +
                                 "</script>";

                Page.RegisterStartupScript("PopupScript", popupScript);

                CollName.Text = "";
                DateOfConst.Text = "";
                PrincipalName.Text = "";
                Address1.Text = "";
                Address2.Text = "";
                PinCode.Text = "";
                PhoneNo.Text = "";
                Fax.Text = "";
                Email.Text = "";
                ExamCapacity.Text = "";
                CollName.Focus();


            }
            else
            {
                LblMsg.Text = abc.ToString();
            }
        }
        else
        {

            UnivService.Service1 ss = new UnivService.Service1();
            abc = " update College set UnivCode='" + UnivCode.SelectedValue + "', CollFullName='" + CollFullName.Text.Trim() + "', CollName='" + CollName.Text.Trim() + "', CollType='" + CollType.SelectedValue + "', DateOfConst='" + string.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(DateOfConst.Text)) +
                  "', PrincipalName='" + PrincipalName.Text.Trim() + "', Address1='" + Address1.Text.Trim() + "', Address2='" + Address2.Text.Trim() + "', DistCode='" + DistCode.SelectedValue.Trim () + "', PinCode='" + PinCode.Text.Trim() + "', PhoneNo='" + PhoneNo.Text.Trim() + "', Email='" + Email.Text.Trim() + "' , Fax='" + Fax.Text.Trim() + "',ExamCapacity='" + ExamCapacity.Text.Trim() + "' where CollCode='" + CollegeView.SelectedRow.Cells[2].Text + "'";
            abc = ss.UpdateData(abc);
            if (abc.ToString() == "ok")
            {
                ViewState.Add("EditMode", "false");
                LblMsg.Text = " Record is updated successfully.";
                CollName.Text = "";
                DateOfConst.Text = "";
                PrincipalName.Text = "";
                Address1.Text = "";
                Address2.Text = "";
                PinCode.Text = "";
                PhoneNo.Text = "";
                Fax.Text = "";
                Email.Text = "";
                ExamCapacity.Text = "";
                CollName.Focus();


            }
            else
                LblMsg.Text = abc.ToString();

        }



        
    }
    protected void BtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        Panel2.Visible = true;
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(SqlConnectionMgmt.GetConnectionString(), CommandType.Text, "select * from College   order by CollCode");
        CollegeView.DataSource = ds;
        CollegeView.DataBind(); 
    }
    protected void CollegeView_SelectedIndexChanged(object sender, EventArgs e)
    {
        //DistrictNm.Text = DistrictView.SelectedRow.Cells[2].Text;
        //Response.Write(CollegeView.SelectedRow.Cells[1].Text);
        UnivCode.SelectedValue = CollegeView.SelectedRow.Cells[1].Text;
        CollFullName.Text = CollegeView.SelectedRow.Cells[3].Text;
        CollName.Text = CollegeView.SelectedRow.Cells[4].Text;
        CollType.SelectedValue = CollegeView.SelectedRow.Cells[5].Text;       
        DateOfConst.Text = CollegeView.SelectedRow.Cells[6].Text.Substring (0,10);
        PrincipalName.Text = CollegeView.SelectedRow.Cells[7].Text;
        Address1.Text = CollegeView.SelectedRow.Cells[8].Text;
        Address2.Text = CollegeView.SelectedRow.Cells[9].Text; ;
        DistCode.SelectedValue = CollegeView.SelectedRow.Cells[10].Text;
        PinCode.Text = CollegeView.SelectedRow.Cells[11].Text;
        PhoneNo.Text = CollegeView.SelectedRow.Cells[12].Text;
        Email.Text = CollegeView.SelectedRow.Cells[13].Text; 
        Fax.Text = CollegeView.SelectedRow.Cells[14].Text;
        ExamCapacity.Text = CollegeView.SelectedRow.Cells[15].Text;  
        ViewState.Add("EditMode", "true");
        CollFullName.Focus(); 
    }
    protected void UnivCode_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
