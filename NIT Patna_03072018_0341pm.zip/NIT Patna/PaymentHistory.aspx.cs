using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class PaymentHistory : System.Web.UI.Page
{
    Functionreviseed appfn = new Functionreviseed();
    UnivService.Service1 nic = new UnivService.Service1();

    PopulateDDL popddl = new PopulateDDL();
    protected void Page_Load(object sender, EventArgs e)
    {

        
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["Role"].ToString() == "10" || Session["Role"].ToString() != "17")
                {
                    Session["userName"] = null;
                    FormsAuthentication.SignOut();
                    Response.Redirect("default.aspx");
                    return;
                } 
             //   bindhistory();
            }
            catch (Exception ex)
            {
                Response.Redirect("default.aspx");
            }

        }

        popddl.Popualate(ddlExamYear, "EXAM", "select distinct SUBSTRING(ExamSession,9,4) as eyear from EXAM order by eyear DESC", "eyear", "eyear");
    }

    DataSet dspayhistory;
    private void bindhistory()
    {
        try
        {

          
                dspayhistory = appfn.SelectDataset("with cte as (SELECT DISTINCT PaymentId AS TransactionNo, ExamFeeAmt AS Paid_Amount, CONVERT(Varchar, PaymentDate, 103) AS PayDate, ModeOfPayment AS Mode_Of_Payment, Bank, " +
                    " ExamSession AS Exam_Session FROM EXAM WHERE (RegNo = '" + txtRegno.Text.Trim() + "' OR UnivRollNo = '" + txtRegno.Text.Trim() + "') AND (ModeOfPayment <> '----Select One----') AND Status <> 'DRAFT') SELECT * FROM cte ORDER BY SUBSTRING(Exam_Session,9,4) DESC");
            
            //else
            //{
            //    dspayhistory = appfn.SelectDataset("with cte as (SELECT DISTINCT PaymentId AS TransactionNo, FeeAmount AS Paid_Amount, CONVERT(Varchar, PaymentDate, 103) AS PayDate, " +
            //        " PaymentMode AS Mode_Of_Payment, PayBank, ExamSession AS Exam_Session FROM Phdregistration WHERE (RegNo = '" + Session["RegNo"].ToString() + "') AND ((PaymentMode <> '----Select One----') " +
            //        " OR (PaymentMode IS NOT NULL))) SELECT * FROM cte ORDER BY SUBSTRING(Exam_Session,9,4) DESC");
            //}


            gvpayment.DataSource = dspayhistory.Tables[0];
            gvpayment.DataBind();
        }
        catch (Exception e)
        {
            lblmsg.Text = "Ooops! Server to Busy, Please Try Again";
        }
    }
    protected void grdfacupap_SelectedIndexChanged(object sender, EventArgs e)
    {
        int i = gvpayment.SelectedIndex;
        string modeofpayment = gvpayment.Rows[i].Cells[4].Text;
        string transactionid = gvpayment.Rows[i].Cells[1].Text;
        string examsession = gvpayment.Rows[i].Cells[6].Text;
        if (modeofpayment == "Challan" || modeofpayment == "DD" || modeofpayment == "E-CHALLAN")
        {
            lblmsg.Text = "Provisional Receipt is allowed only for ONLINE Mode Payment.";
        }
        else
        {
            string tmpUrl = "ProvisionalReceipt.aspx?tid=" + appfn.EncodePasswordToBase64(transactionid) + "&es=" + appfn.EncodePasswordToBase64(examsession) + "&candID=" + appfn.EncodePasswordToBase64(txtRegno.Text.Trim());
            Response.Redirect(tmpUrl);
        }
    }
    protected void btnFundDetail_Click(object sender, EventArgs e)
    {
        bindhistory();
    }
}
